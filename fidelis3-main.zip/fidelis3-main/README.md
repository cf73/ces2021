# Fidelis AV

Modern e-commerce and content platform for Fidelis AV, built with Next.js and Supabase.

## Repository layout

```
fidelis3/
├── nextjs/      # The application (Next.js 15, App Router) — deployed to Vercel
└── supabase/    # Database migrations and edge functions for the shared Supabase project
```

The legacy Statamic/Laravel CMS and the interim Vite React SPA were removed; all content now lives in Supabase (Postgres + Storage).

## Development

```bash
cd nextjs
npm install
npm run dev
```

Requires Node 20+. Create `nextjs/.env.local` with the variables documented in [`nextjs/ENV_VARIABLES.md`](nextjs/ENV_VARIABLES.md).

## Deployment (Vercel)

- Framework preset: Next.js
- Root Directory: `nextjs`
- Build command: `npm run build`

Environment variables are managed in the Vercel dashboard; see [`nextjs/ENV_VARIABLES.md`](nextjs/ENV_VARIABLES.md) and [`nextjs/SECURITY.md`](nextjs/SECURITY.md).

---

Maintained by Fidelis AV.
