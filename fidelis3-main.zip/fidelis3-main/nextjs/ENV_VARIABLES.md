# Environment Variables

## Required Variables

### Supabase Configuration
```bash
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SECRET_KEY=your-service-role-key
```

### Site Configuration
```bash
NEXT_PUBLIC_SITE_URL=http://localhost:3000  # Change to production URL in production
```

### Admin Access
```bash
ADMIN_EMAILS=admin1@example.com,admin2@example.com
```

### Cache Revalidation
```bash
REVALIDATE_SECRET=your-secure-random-string
```

### PayPal Configuration
```bash
NEXT_PUBLIC_PAYPAL_CLIENT_ID=your-paypal-client-id
```

### AI Services
```bash
ANTHROPIC_API_KEY=sk-ant-your-api-key
ANTHROPIC_MODEL=claude-opus-4-8              # optional; defaults to latest Opus
ANTHROPIC_MAX_TOKENS=8192                    # optional; Flesh Out / batch generation
ANTHROPIC_CLASSIFICATION_MAX_TOKENS=1024     # optional; amplifier classification scripts
ANTHROPIC_QUOTE_MAX_TOKENS=2048               # optional; web quote extraction
```

### Email Service (Contact Form)
```bash
RESEND_API_KEY=re_your_api_key
CONTACT_BCC=ops@example.com,owner@example.com
```

## Optional Variables

### Web Search for Quote Extraction
```bash
TAVILY_API_KEY=tvly-your-api-key
```

**What it does**: Automatically searches the web for professional product reviews and extracts compelling quotes when generating AI content.

**How to get it**:
1. Sign up at https://tavily.com
2. Free tier includes 1,000 searches/month
3. Copy your API key

**If not provided**: The system will skip quote search and only generate product relationships and brief descriptions. A warning will be logged: `⚠️ Tavily API key not configured, skipping web search for quotes`

## Local Development

Create a `.env.local` file in the `nextjs` directory with all the variables above.

## Production (Vercel)

Add all variables in Vercel Dashboard:
1. Go to Settings → Environment Variables
2. Add each variable
3. Select "Production", "Preview", and "Development" environments
4. Redeploy after adding variables

## Security Notes

- ⚠️ Never commit `.env.local` to git
- ⚠️ Use different keys for development and production
- ⚠️ `NEXT_PUBLIC_*` variables are exposed to the browser
- ⚠️ Non-public variables are only available server-side

