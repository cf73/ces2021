# Security Notes and Deployment Checklist

## Environment Variables
- `NEXT_PUBLIC_SUPABASE_URL`: public URL (safe for client).
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`: anon key only (safe for client).
- `SUPABASE_SECRET_KEY`: **server-side only**; never expose to client bundles or `.env.local` committed to git.
- `ADMIN_EMAILS`: comma-separated admin allowlist for protected API routes.
- `REVALIDATE_SECRET`: secret token required to call `/api/revalidate`.
- Store envs in hosting provider secrets; keep `.env.local` gitignored.

## Supabase Key Usage
- Client and server helpers (`lib/supabase-client.ts`, `lib/supabase-server.ts`) use ONLY the anon key.
- Service-role key must only be used in secure server contexts (not in frontend code).

## Supabase RLS Expectations
- Products, News, Pre-Owned, Manufacturers: public read of published rows; authenticated writes only.
- Storage (images bucket): public read for asset delivery; restrict writes to authenticated users; no sensitive data in public bucket.
- Ensure RLS is enabled on all tables and policies match the above rules before launch.

## Production Expectations
- RLS enabled on all tables (public read of published rows; authenticated writes only).
- Storage: public bucket only for public assets; no sensitive uploads in public buckets.
- CSP and security headers set in `next.config.ts`.

## Applied Controls
- CSP set in `next.config.ts`. Note: `script-src` and `style-src` still allow `'unsafe-inline'` (required by current inline styles/scripts); production `'unsafe-eval'` is not allowed. Do not loosen further; tightening requires testing PayPal and Supabase flows.
- Rate limiting: token bucket (in-memory, per instance) on contact, newsletter subscribe, and AI generation APIs.
- HTML sanitization: DOMPurify (`lib/sanitize.ts`) on rendered CMS/news HTML; user input escaped before inclusion in outbound email HTML.
- Upload validation: image type and size checks (see `lib/sanitize.ts` constants).
- Env hygiene: service key server-only; anon key client/server; Supabase clients fail closed if env vars are missing; `.env.local` gitignored.
- No secrets committed to the repository. If a key is ever committed, rotate it immediately at the provider.

## Launch Checklist
- [ ] Confirm Supabase RLS matches expectations above.
- [ ] Confirm storage bucket rules restrict writes to authenticated users.
- [ ] Verify security headers and CSP load without console errors.
- [ ] Provide prod env vars in hosting secrets (no service key in client).
- [ ] Optional: add rate limit to any other public POST routes if added later.

## CI/Deploy Checklist
- Provide required env vars in deploy platform (no plaintext in repo).
- Do not commit `.env.local`.
- Verify build logs show no missing env warnings.


