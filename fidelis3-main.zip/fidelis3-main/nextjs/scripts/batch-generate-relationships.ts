#!/usr/bin/env tsx
import { config } from 'dotenv';
import { resolve } from 'path';
import { createClient } from '@supabase/supabase-js';
import Anthropic from '@anthropic-ai/sdk';
import * as fs from 'fs';
import * as readline from 'readline';
import { DEFAULT_ANTHROPIC_MODEL, DEFAULT_ANTHROPIC_MAX_TOKENS } from '../lib/anthropic-config';

// Load environment variables
config({ path: resolve(__dirname, '../.env.local') });

// Initialize clients
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseSecretKey = process.env.SUPABASE_SECRET_KEY;
const anthropicKey = process.env.ANTHROPIC_API_KEY;

if (!supabaseUrl || !supabaseSecretKey || !anthropicKey) {
  console.error('Missing required environment variables in nextjs/.env.local:');
  console.error('  NEXT_PUBLIC_SUPABASE_URL, SUPABASE_SECRET_KEY, ANTHROPIC_API_KEY');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseSecretKey);
const anthropic = new Anthropic({ apiKey: anthropicKey });

// Progress file path
const PROGRESS_FILE = resolve(__dirname, '../.ai-generation-progress.json');

// Rate limiting: 30,000 tokens/min limit, each request ~50k tokens
// Safe delay: 150 seconds between requests (2.5 minutes)
const DELAY_BETWEEN_REQUESTS = 150000; // 150 seconds in milliseconds

interface Progress {
  lastProcessedId: string | null;
  processedCount: number;
  totalCount: number;
  startTime: string;
  lastUpdateTime: string;
  errors: Array<{ productId: string; productTitle: string; error: string }>;
  skipped: number;
}

interface Product {
  id: string;
  title: string;
  slug: string;
  price?: number;
  category_id?: string;
  manufacturer_id?: string;
  brief_description?: string;
  content?: string;
  system_category?: string;
  published: boolean;
  updated_at: string;
  pairs_well_with?: string[];
  also_consider?: string[];
  pairs_reasoning?: string;
  pairs_cta?: string;
  pairs_helper?: string;
  also_reasoning?: string;
  also_cta?: string;
  also_helper?: string;
  ai_last_generated?: string;
  categories?: { id: string; name: string; slug: string };
  manufacturer?: { id: string; name: string; slug: string };
}

// Load or create progress
function loadProgress(): Progress | null {
  if (fs.existsSync(PROGRESS_FILE)) {
    const data = fs.readFileSync(PROGRESS_FILE, 'utf-8');
    return JSON.parse(data);
  }
  return null;
}

function saveProgress(progress: Progress) {
  progress.lastUpdateTime = new Date().toISOString();
  fs.writeFileSync(PROGRESS_FILE, JSON.stringify(progress, null, 2));
}

function deleteProgress() {
  if (fs.existsSync(PROGRESS_FILE)) {
    fs.unlinkSync(PROGRESS_FILE);
  }
}

// Check if product needs generation
function needsGeneration(product: Product, forceMode: boolean): boolean {
  if (forceMode) return true;
  
  // New product - never generated
  if (!product.ai_last_generated) return true;
  
  // Empty relationships
  if (!product.pairs_well_with?.length && !product.also_consider?.length) return true;
  
  // Has relationships but missing AI reasoning/helper text (legacy data)
  if (((product.pairs_well_with?.length ?? 0) > 0 && !product.pairs_reasoning) ||
      ((product.also_consider?.length ?? 0) > 0 && !product.also_reasoning)) {
    return true;
  }
  
  // Incomplete AI data (has some but not all fields)
  const hasPartialData = 
    (product.pairs_reasoning && !product.pairs_helper) ||
    (product.pairs_cta && !product.pairs_helper) ||
    (product.also_reasoning && !product.also_helper) ||
    (product.also_cta && !product.also_helper);
  
  if (hasPartialData) return true;
  
  // Product updated after last generation
  if (new Date(product.updated_at) > new Date(product.ai_last_generated)) return true;
  
  return false;
}

// Generate suggestions for a single product
async function generateForProduct(product: Product, allProducts: Product[]): Promise<void> {
  // Build product list (full catalog with full details)
  const filteredProducts = allProducts.filter(p => p.id !== product.id && p.published);
  
  const sameCategoryProducts = filteredProducts.filter(p => 
    p.categories?.name === product.categories?.name
  );
  
  const otherProducts = filteredProducts.filter(p => 
    p.categories?.name !== product.categories?.name
  );
  
  const prioritizedProducts = [...sameCategoryProducts, ...otherProducts];
  
  const productList = prioritizedProducts.map(p => ({
    id: p.id,
    title: p.title,
    category: p.categories?.name,
    manufacturer: p.manufacturer?.name,
    price: p.price,
    system_category: p.system_category,
    brief_description: p.brief_description?.substring(0, 200),
    content_excerpt: p.content?.substring(0, 300)
  }));

  const prompt = `You are a seasoned high-end audio specialist with decades of experience matching components. Your expertise includes understanding power requirements, impedance matching, sonic characteristics (warm/analytical), and system synergies.

IMPORTANT: For "Also Consider" suggestions, you MUST follow these rules strictly:
1. Same category only (e.g., "Interconnects" → only "Interconnects")
2. Price within 30% range: calculate (current_price × 0.7) to (current_price × 1.3)
3. If no products meet these criteria, return empty "alsoConsider" array

CRITICAL: Use ONLY the exact "id" field from the inventory list (UUID format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx). NEVER use product names, model numbers, or any other identifiers.

CRITICAL: Only reference products that are ACTUALLY in your "pairsWellWith" or "alsoConsider" arrays. NEVER mention products not in the suggested lists.

CURRENT PRODUCT:
- Title: ${product.title}
- Manufacturer: ${product.manufacturer?.name}
- Category: ${product.categories?.name}
- System Category: ${product.system_category || 'N/A'}
- Price: $${product.price}
- Description: ${product.brief_description || 'N/A'}
- Details: ${product.content?.substring(0, 500) || 'N/A'}

AVAILABLE INVENTORY (complete catalog - ${productList.length} products):
${JSON.stringify(productList, null, 2)}

YOUR TASK:

1. **"GOOD SYNERGIES" (MINIMUM 4 products, up to 6 that complement this product)**
   You MUST suggest at least 4 complementary products unless absolutely no logical pairings exist.
   Think like an audiophile building a complete system. Consider:
   - Power matching: Does a speaker need high power or work with low-watt tube amps?
   - Sonic character: Do warm tubes complement analytical speakers? Do forgiving components pair with revealing sources?
   - System building: What components complete a logical audio chain?
   - Technical compatibility: Impedance, sensitivity, output voltage, etc.
   - Price is flexible here - focus on sonic and technical synergy
   
   CRITICAL RULE - NO SAME CATEGORY:
   - NEVER suggest products from the same category as the current product
   - Speakers cannot be paired with other speakers
   - Amplifiers cannot be paired with other amplifiers
   - DACs cannot be paired with other DACs
   - Integrated amplifiers are standalone units - NEVER pair with preamps or power amps
   - Focus on complementary components that complete a system
   
   CRITICAL RULE - ELECTROSTATIC HEADPHONES REQUIRE SPECIAL AMPLIFIERS:
   - If the current product is an electrostatic headphone (detected by keywords like "electrostatic", "Stax", "SR-", manufacturer "Stax", or category "Headphones" with electrostatic characteristics), you MUST follow these rules STRICTLY:
   - NEVER suggest power amplifiers for electrostatic headphones - they are completely incompatible
   - NEVER suggest regular headphone amplifiers (like "Headphone Amplifiers" category) for electrostatic headphones - they are completely incompatible
   - EXCEPTION: Stax headphone amplifiers (like SRM-T8000, SRM-500T, etc.) ARE compatible - Stax manufactures electrostatic equipment and their headphone amps are designed for electrostatic headphones
   - Electrostatic headphones require specialized electrostatic amplifiers/drivers that provide high-voltage bias - regular headphone amps cannot drive them
   - ONLY suggest electrostatic amplifiers/drivers OR Stax headphone amplifiers (products specifically designed for electrostatic headphones, often called "drivers" or "electrostatic amplifiers")
   - If electrostatic amplifiers/drivers or Stax headphone amplifiers are available, they MUST be the PRIMARY recommendations - they are essential, not optional
   - Only after suggesting electrostatic amplifiers/drivers should you consider other components like source equipment, cables, or power conditioning
   - An expert audio sales rep would NEVER suggest a regular headphone amp for electrostatic headphones - this is a fundamental technical incompatibility
   
   CRITICAL RULE - ELECTROSTATIC SPEAKERS REQUIRE SPECIAL AMPLIFIERS:
   - If the current product is an electrostatic speaker (detected by keywords like "electrostatic", "Martin Logan", "Quad", "Sound Lab", "ESL", or category "Speakers" with electrostatic characteristics), you MUST follow these rules STRICTLY:
   - NEVER suggest standard power amplifiers for electrostatic speakers - they are completely incompatible
   - NEVER suggest integrated amplifiers for electrostatic speakers - they are completely incompatible
   - NEVER suggest regular amplifiers of any type for electrostatic speakers - they are completely incompatible
   - Electrostatic speakers require specialized electrostatic driver/amplifier units that provide high-voltage bias - standard amplifiers cannot drive them
   - ONLY suggest electrostatic amplifiers/drivers (products specifically designed for electrostatic speakers, often called "electrostatic drivers", "ESL amplifiers", or "electrostatic power supplies")
   - If electrostatic amplifiers/drivers are available, they MUST be the PRIMARY recommendations - they are essential, not optional
   - Only after suggesting electrostatic amplifiers/drivers should you consider other components like source equipment, cables, or power conditioning
   - An expert audio sales rep would NEVER suggest a standard amplifier for electrostatic speakers - this is a fundamental technical incompatibility
   
   CRITICAL RULE - RESPECT SIGNAL CHAIN LOGIC:
   - Analog source products (turntables, phono stages, cartridges, tone arms) should ONLY pair with other analog components, speakers, amplifiers, cables, and power conditioning
   - NEVER suggest digital components (DACs, streamers, CD players) for analog source products
   - Digital source products (DACs, streamers, CD players) should ONLY pair with other digital components, speakers, amplifiers, cables, and power conditioning
   - NEVER suggest analog source components (turntables, phono stages) for digital source products
   - Speakers and amplifiers are neutral—they work with both analog and digital chains
   
   MANUFACTURER PRIORITY RULE:
   - If the current product's manufacturer also makes a component that pairs well with it, prioritize that over similar components from other manufacturers
   - This creates better system coherence and matching aesthetic/engineering philosophy
   
   Examples of good synergies:
   - High-efficiency horn speakers + low-power tube amplifiers
   - Detailed analytical DACs + warm, musical amplifiers
   - High-resolution turntables + precision phono stages
   - Revealing speakers + forgiving source components
   - Same-manufacturer preamp + power amp combinations

2. **"ALSO CONSIDER" (MINIMUM 2 products, up to 4 alternative products)**
   You MUST suggest at least 2 alternatives if any exist in the price range. If fewer than 2 qualify, return what you can find.
   These are direct alternatives in the SAME category with STRICT price matching:
   - Must be EXACTLY the same product category (${product.categories?.name})
   - Current product price: $${product.price}
   - CALCULATE THE EXACT PRICE RANGE: $${Math.round((product.price || 0) * 0.7)} to $${Math.round((product.price || 0) * 1.3)}
   - ONLY suggest products whose price falls within $${Math.round((product.price || 0) * 0.7)}-$${Math.round((product.price || 0) * 1.3)}
   - DO NOT suggest products outside this range - VERIFY each product's price before including it
   - Should offer similar performance tier but perhaps different sonic signature or features
   - If NO products meet these strict criteria, return EMPTY array for "alsoConsider"

CRITICAL RULES - NO EXCEPTIONS:
- Only use product IDs from the inventory list (exact UUID strings in format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)
- NEVER use product names, model numbers, or any other identifiers - ONLY use the exact "id" field from the inventory
- For "Good Synergies": Focus on characteristics and compatibility, not rigid type rules
- MANUFACTURER PRIORITY: Always prioritize same-manufacturer components over similar ones from other manufacturers
- For "Also Consider": 
  * MUST be same category (e.g., "Interconnects" → only "Interconnects", "Speaker Cables" → only "Speaker Cables")
  * MUST be within 30% price range (calculate: current price × 0.7 to current price × 1.3)
  * If no products meet these criteria, return empty array for "alsoConsider"
- If no logical pairings exist, return empty arrays
- Consider the product descriptions to understand technical characteristics

PRICE CALCULATION EXAMPLE:
- Product costs $3,000 → "Also Consider" must be between $2,100 and $3,900 (30% tolerance)
- Product costs $10,000 → "Also Consider" must be between $7,000 and $13,000 (30% tolerance)

CRITICAL RULES FOR REASONING TEXT:
- NEVER mention price, budget, cost, value, or any financial terms
- NEVER mention price ranges like "$7,000-$13,000" or "acceptable price range"
- Focus ONLY on technical characteristics, sonic qualities, and compatibility
- Explain WHY components work together based on specifications and sound
- Example good reasoning: "These speakers' high efficiency pairs perfectly with low-power tube amplification"
- Example BAD reasoning: "These products occupy similar price points" or "within acceptable price range"

FORBIDDEN PHRASES IN REASONING:
- "price point", "price range", "budget", "cost", "value proposition"
- "acceptable price", "similar pricing", "price tier"
- Any mention of dollar amounts or financial considerations
- "afford", "expensive", "cheap", "premium pricing"

REQUIRED APPROACH:
- Discuss ONLY technical specifications and sonic characteristics
- Explain compatibility based on impedance, power, efficiency, etc.
- Describe sound signatures: warm, analytical, detailed, musical, etc.
- Mention build quality, engineering philosophy, design approach

Return ONLY valid JSON in this exact format:
{
  "pairsWellWith": ["uuid1", "uuid2", ...],
  "pairsReasoning": "Explain the audiophile logic behind these synergies (e.g., 'These high-efficiency speakers pair beautifully with low-power tube amplifiers, allowing the warmth and musicality of tubes to shine without power concerns. The same-manufacturer power amp is prioritized for its matching aesthetic and engineering philosophy')",
  "pairsCTA": "A brief, contextual question (e.g., 'Building a tube-based system?' or 'Considering a complete analog setup?')",
  "pairsHelper": "Write 1-2 sentences that make someone excited to hear these SPECIFIC products together. Reference ONLY products in your pairsWellWith array. Talk like an enthusiast who's actually listened to these combinations. Focus on what makes the pairing work—technical synergies, sonic characteristics, design philosophies. Be natural and conversational. You can mention topology, voicing, engineering approach, or specific features IF relevant, but don't force it. Vary your style—sometimes technical, sometimes poetic, always genuine. Example good approaches: 'These components share a philosophy of uncompromising resolution—come hear what that means in practice' or 'High efficiency meets low power the way it should—musical, dynamic, totally engaging'",
  "alsoConsider": ["uuid3", "uuid4", ...],
  "alsoReasoning": "Explain why these alternatives are comparable (e.g., 'These DACs offer similar resolution but with different sonic signatures')",
  "alsoCTA": "A brief, contextual question (e.g., 'Evaluating turntables?' or 'Choosing between speaker cables?')",
  "alsoHelper": "Write 1-2 sentences that help someone understand what makes these alternatives different. Reference ONLY products in your alsoConsider array. Talk like you've actually compared them. Focus on real differences in sound, approach, or philosophy. Be natural—not a checklist of specs. Vary your style. Example good approaches: 'Each takes a different path to resolution—one's about transparency, another about musicality, the third splits the difference beautifully' or 'The voicing varies more than you'd expect at this level—bring your favorite tracks and you'll hear which one speaks your language'"
}`;

  try {
    const message = await anthropic.messages.create({
      model: DEFAULT_ANTHROPIC_MODEL,
      max_tokens: DEFAULT_ANTHROPIC_MAX_TOKENS,
      messages: [{
        role: 'user',
        content: prompt
      }]
    });

    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    
    if (!jsonMatch) {
      throw new Error('Invalid AI response format');
    }

    // Remove JavaScript-style comments that AI sometimes adds to JSON
    const cleanedJson = jsonMatch[0]
      .replace(/\/\/.*$/gm, '') // Remove single-line comments
      .replace(/,(\s*[}\]])/g, '$1'); // Remove trailing commas
    
    const suggestions = JSON.parse(cleanedJson);
    
    // Check if current product is an electrostatic headphone
    const isElectrostaticHeadphone = 
      product.categories?.name?.toLowerCase().includes('headphone') &&
      (product.title?.toLowerCase().includes('electrostatic') ||
       product.title?.toLowerCase().includes('stax') ||
       product.title?.toLowerCase().includes('sr-') ||
       product.manufacturer?.name?.toLowerCase().includes('stax') ||
       product.brief_description?.toLowerCase().includes('electrostatic') ||
       product.content?.toLowerCase().includes('electrostatic'));

    // Check if current product is an electrostatic speaker
    const isElectrostaticSpeaker = 
      product.categories?.name?.toLowerCase().includes('speaker') &&
      (product.title?.toLowerCase().includes('electrostatic') ||
       product.title?.toLowerCase().includes('esl') ||
       product.title?.toLowerCase().includes('martin logan') ||
       product.title?.toLowerCase().includes('quad') ||
       product.title?.toLowerCase().includes('sound lab') ||
       product.manufacturer?.name?.toLowerCase().includes('martin logan') ||
       product.manufacturer?.name?.toLowerCase().includes('quad') ||
       product.manufacturer?.name?.toLowerCase().includes('sound lab') ||
       product.brief_description?.toLowerCase().includes('electrostatic') ||
       product.content?.toLowerCase().includes('electrostatic'));

    // Check if current product is a planar magnetic speaker (Magnepan)
    const isPlanarMagneticSpeaker = 
      product.categories?.name?.toLowerCase().includes('speaker') &&
      (product.title?.toLowerCase().includes('magnepan') ||
       product.title?.toLowerCase().includes('planar') ||
       product.manufacturer?.name?.toLowerCase().includes('magnepan') ||
       product.brief_description?.toLowerCase().includes('planar') ||
       product.brief_description?.toLowerCase().includes('magnepan') ||
       product.content?.toLowerCase().includes('planar') ||
       product.content?.toLowerCase().includes('magnepan'));

    // Check if current product is a standard integrated amplifier (not high-current)
    const isStandardIntegratedAmp = 
      product.categories?.name?.toLowerCase().includes('integrated') &&
      !product.title?.toLowerCase().includes('high-current') &&
      !product.title?.toLowerCase().includes('high current') &&
      !product.brief_description?.toLowerCase().includes('high-current') &&
      !product.brief_description?.toLowerCase().includes('high current') &&
      !product.brief_description?.toLowerCase().includes('stable into 2 ohms') &&
      !product.brief_description?.toLowerCase().includes('difficult loads') &&
      !product.content?.toLowerCase().includes('high-current') &&
      !product.content?.toLowerCase().includes('high current');

    // Check if current product is a 300B tube amplifier
    const is300BTubeAmp = 
      (product.categories?.name?.toLowerCase().includes('power') || 
       product.categories?.name?.toLowerCase().includes('amplifier')) &&
      (product.title?.toLowerCase().includes('300b') ||
       product.title?.toLowerCase().includes('300 b') ||
       product.brief_description?.toLowerCase().includes('300b') ||
       product.brief_description?.toLowerCase().includes('300 b') ||
       product.brief_description?.toLowerCase().includes('triode') ||
       product.content?.toLowerCase().includes('300b') ||
       product.content?.toLowerCase().includes('300 b') ||
       product.content?.toLowerCase().includes('triode'));

    // Check if current product is a Stenheim/aluminum speaker
    const isStenheimAluminumSpeaker = 
      product.categories?.name?.toLowerCase().includes('speaker') &&
      (product.title?.toLowerCase().includes('stenheim') ||
       product.title?.toLowerCase().includes('alumine') ||
       product.title?.toLowerCase().includes('aluminum') ||
       product.manufacturer?.name?.toLowerCase().includes('stenheim') ||
       product.brief_description?.toLowerCase().includes('stenheim') ||
       product.brief_description?.toLowerCase().includes('aluminum') ||
       product.brief_description?.toLowerCase().includes('alumine') ||
       product.content?.toLowerCase().includes('stenheim') ||
       product.content?.toLowerCase().includes('aluminum') ||
       product.content?.toLowerCase().includes('alumine'));

    // Apply server-side filtering
    const filteredAlsoConsider = suggestions.alsoConsider.filter((productId: string) => {
      const suggestedProduct = allProducts.find(p => p.id === productId);
      if (!suggestedProduct || !suggestedProduct.price || !product.price) return false;
      
      const minPrice = product.price * 0.7;
      const maxPrice = product.price * 1.3;
      
      return suggestedProduct.price >= minPrice && suggestedProduct.price <= maxPrice;
    });

    const filteredPairsWellWith = suggestions.pairsWellWith.filter((productId: string) => {
      const suggestedProduct = allProducts.find(p => p.id === productId);
      if (!suggestedProduct) return false;
      
      if (suggestedProduct.categories?.id === product.categories?.id) return false;
      
      if (product.categories?.name?.toLowerCase().includes('integrated') && 
          (suggestedProduct.categories?.name?.toLowerCase().includes('pre') || 
           suggestedProduct.categories?.name?.toLowerCase().includes('power'))) {
        return false;
      }
      
      // CRITICAL: Electrostatic headphones cannot pair with power amps or regular headphone amps
      if (isElectrostaticHeadphone) {
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        const manufacturerName = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        
        // Check if this is an electrostatic amplifier/driver
        // Stax headphone amplifiers are electrostatic-compatible, so include them
        const isElectrostaticAmp = 
          categoryName.includes('electrostatic') ||
          categoryName.includes('driver') ||
          productTitle.includes('electrostatic') ||
          productTitle.includes('driver') ||
          productTitle.includes('stax') ||
          productTitle.includes('srm-') || // Stax amplifier model prefix
          manufacturerName.includes('stax') || // Stax manufacturer = electrostatic-compatible
          productDesc.includes('electrostatic') ||
          productDesc.includes('driver');
        
        // Exclude ALL power amplifiers (unless they're electrostatic)
        if ((categoryName.includes('power') || categoryName.includes('amplifier')) && !isElectrostaticAmp) {
          return false;
        }
        
        // Exclude regular headphone amplifiers UNLESS they're from Stax (which makes electrostatic amps)
        // Stax headphone amplifiers are designed for electrostatic headphones
        if (categoryName.includes('headphone') && categoryName.includes('amplifier')) {
          // Allow Stax headphone amplifiers (they're electrostatic-compatible)
          if (manufacturerName.includes('stax') || productTitle.includes('stax') || productTitle.includes('srm-')) {
            // This is a Stax headphone amp - allow it
            return true;
          }
          // Exclude all other headphone amplifiers (they're incompatible)
          if (!isElectrostaticAmp) {
            return false;
          }
        }
      }
      
      // CRITICAL: Electrostatic speakers cannot pair with standard amplifiers
      if (isElectrostaticSpeaker) {
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        const manufacturerName = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        
        // Check if this is an electrostatic amplifier/driver for speakers
        const isElectrostaticDriver = 
          categoryName.includes('electrostatic') ||
          categoryName.includes('driver') ||
          categoryName.includes('esl') ||
          productTitle.includes('electrostatic') ||
          productTitle.includes('driver') ||
          productTitle.includes('esl') ||
          productTitle.includes('electrostatic amplifier') ||
          productTitle.includes('electrostatic power') ||
          manufacturerName.includes('martin logan') ||
          manufacturerName.includes('quad') ||
          manufacturerName.includes('sound lab') ||
          productDesc.includes('electrostatic') ||
          productDesc.includes('driver') ||
          productDesc.includes('esl');
        
        // Exclude ALL standard amplifiers (power, integrated, etc.) unless they're electrostatic drivers
        if ((categoryName.includes('power') || 
             categoryName.includes('integrated') || 
             categoryName.includes('amplifier')) && !isElectrostaticDriver) {
          return false;
        }
      }
      
      // CRITICAL: Planar magnetic speakers (Magnepan) cannot pair with standard integrated amplifiers
      if (isPlanarMagneticSpeaker) {
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Check if this is a high-current amplifier (required for planar magnetic speakers)
        const isHighCurrentAmp = 
          productTitle.includes('high-current') ||
          productTitle.includes('high current') ||
          productDesc.includes('high-current') ||
          productDesc.includes('high current') ||
          productDesc.includes('stable into 2 ohms') ||
          productDesc.includes('doubles power into 4 ohms') ||
          productDesc.includes('difficult loads') ||
          productDesc.includes('low impedance') ||
          (categoryName.includes('power') && (productDesc.includes('high current') || productDesc.includes('high-current')));
        
        // Exclude standard integrated amplifiers (they cannot drive planar magnetic speakers)
        if (categoryName.includes('integrated') && !isHighCurrentAmp) {
          return false;
        }
        
        // Exclude low-power amplifiers (planar magnetic speakers need high current)
        if (categoryName.includes('amplifier') && !isHighCurrentAmp) {
          // Allow power amplifiers (they're more likely to be high-current), but filter out low-power ones
          if (productDesc.includes('low power') || productDesc.includes('low-power') || 
              productDesc.includes('tube') && !productDesc.includes('high power')) {
            return false;
          }
        }
      }
      
      // CRITICAL: Standard integrated amplifiers cannot drive planar magnetic speakers
      if (isStandardIntegratedAmp) {
        const suggestedTitle = suggestedProduct.title?.toLowerCase() || '';
        const suggestedManufacturer = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        const suggestedDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Check if suggested product is a planar magnetic speaker (Magnepan)
        const isPlanarMagnetic = 
          suggestedProduct.categories?.name?.toLowerCase().includes('speaker') &&
          (suggestedTitle.includes('magnepan') ||
           suggestedTitle.includes('planar') ||
           suggestedManufacturer.includes('magnepan') ||
           suggestedDesc.includes('planar') ||
           suggestedDesc.includes('magnepan'));
        
        // Exclude planar magnetic speakers - standard integrated amps cannot drive them
        if (isPlanarMagnetic) {
          return false;
        }
      }
      
      // CRITICAL: 300B tube amplifiers are for horn speakers only
      if (is300BTubeAmp) {
        const suggestedTitle = suggestedProduct.title?.toLowerCase() || '';
        const suggestedDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Check if suggested product is a horn speaker
        const isHornSpeaker = 
          suggestedProduct.categories?.name?.toLowerCase().includes('speaker') &&
          (suggestedTitle.includes('horn') ||
           suggestedDesc.includes('horn') ||
           suggestedDesc.includes('high efficiency') ||
           (suggestedDesc.includes('efficiency') && (suggestedDesc.includes('95') || suggestedDesc.includes('96') || suggestedDesc.includes('97') || suggestedDesc.includes('98') || suggestedDesc.includes('99') || suggestedDesc.includes('100'))));
        
        // Check if suggested product is a Stenheim/aluminum speaker (incompatible)
        const isStenheimAluminum = 
          suggestedProduct.categories?.name?.toLowerCase().includes('speaker') &&
          (suggestedTitle.includes('stenheim') ||
           suggestedTitle.includes('alumine') ||
           suggestedTitle.includes('aluminum') ||
           suggestedProduct.manufacturer?.name?.toLowerCase().includes('stenheim') ||
           suggestedDesc.includes('stenheim') ||
           suggestedDesc.includes('aluminum') ||
           suggestedDesc.includes('alumine'));
        
        // Only allow horn speakers for 300B tube amplifiers
        if (!isHornSpeaker && suggestedProduct.categories?.name?.toLowerCase().includes('speaker')) {
          return false;
        }
        
        // Explicitly exclude Stenheim/aluminum speakers
        if (isStenheimAluminum) {
          return false;
        }
      }
      
      // CRITICAL: Stenheim/aluminum speakers require high-powered solid-state amplifiers
      if (isStenheimAluminumSpeaker) {
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Check if this is a 300B tube amplifier (incompatible)
        const is300B = 
          productTitle.includes('300b') ||
          productTitle.includes('300 b') ||
          productDesc.includes('300b') ||
          productDesc.includes('300 b') ||
          productDesc.includes('triode');
        
        // Check if this is a high-powered solid-state amplifier
        const isHighPowerSolidState = 
          (categoryName.includes('power') || categoryName.includes('integrated')) &&
          !productDesc.includes('tube') &&
          !productDesc.includes('300b') &&
          !productDesc.includes('300 b') &&
          (productDesc.includes('high power') ||
           productDesc.includes('high-power') ||
           productDesc.includes('100w') ||
           productDesc.includes('200w') ||
           productDesc.includes('300w') ||
           productDesc.includes('solid state') ||
           productDesc.includes('solid-state'));
        
        // Exclude 300B tube amplifiers - Stenheim speakers need solid-state current
        if (is300B) {
          return false;
        }
        
        // Exclude low-power tube amplifiers
        if (categoryName.includes('amplifier') && productDesc.includes('tube') && !isHighPowerSolidState) {
          return false;
        }
        
        // Prefer high-powered solid-state amplifiers
        if (categoryName.includes('amplifier') && !isHighPowerSolidState && !productDesc.includes('solid state') && !productDesc.includes('solid-state')) {
          // Allow if it's clearly a high-power solid-state amp based on power rating
          const hasHighPower = /(100|200|300|400|500)\s*w/i.test(productDesc) || 
                               /(100|200|300|400|500)\s*watts/i.test(productDesc);
          if (!hasHighPower) {
            return false;
          }
        }
      }
      
      return true;
    });
    
    // For electrostatic headphones, prioritize electrostatic amplifiers/drivers
    if (isElectrostaticHeadphone) {
      const electrostaticAmps = filteredPairsWellWith.filter((productId: string) => {
        const suggestedProduct = allProducts.find(p => p.id === productId);
        if (!suggestedProduct) return false;
        
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        const manufacturerName = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        
        // Prioritize electrostatic amps, drivers, and Stax products (all Stax amps are electrostatic-compatible)
        return categoryName.includes('electrostatic') || 
               categoryName.includes('driver') ||
               productTitle.includes('electrostatic') ||
               productTitle.includes('driver') ||
               productTitle.includes('stax') ||
               productTitle.includes('srm-') || // Stax amplifier model prefix
               manufacturerName.includes('stax') || // Stax manufacturer = electrostatic-compatible
               productDesc.includes('electrostatic') ||
               productDesc.includes('driver');
      });
      
      // Move electrostatic amps to the front - they are REQUIRED for electrostatic headphones
      const otherProducts = filteredPairsWellWith.filter((id: string) => !electrostaticAmps.includes(id));
      filteredPairsWellWith.length = 0;
      filteredPairsWellWith.push(...electrostaticAmps, ...otherProducts);
    }
    
    // For electrostatic speakers, prioritize electrostatic amplifiers/drivers
    if (isElectrostaticSpeaker) {
      const electrostaticDrivers = filteredPairsWellWith.filter((productId: string) => {
        const suggestedProduct = allProducts.find(p => p.id === productId);
        if (!suggestedProduct) return false;
        
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        const manufacturerName = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        
        // Prioritize electrostatic drivers/amplifiers for speakers
        return categoryName.includes('electrostatic') || 
               categoryName.includes('driver') ||
               categoryName.includes('esl') ||
               productTitle.includes('electrostatic') ||
               productTitle.includes('driver') ||
               productTitle.includes('esl') ||
               productTitle.includes('electrostatic amplifier') ||
               productTitle.includes('electrostatic power') ||
               manufacturerName.includes('martin logan') ||
               manufacturerName.includes('quad') ||
               manufacturerName.includes('sound lab') ||
               productDesc.includes('electrostatic') ||
               productDesc.includes('driver') ||
               productDesc.includes('esl');
      });
      
      // Move electrostatic drivers to the front - they are REQUIRED for electrostatic speakers
      const otherProducts = filteredPairsWellWith.filter((id: string) => !electrostaticDrivers.includes(id));
      filteredPairsWellWith.length = 0;
      filteredPairsWellWith.push(...electrostaticDrivers, ...otherProducts);
    }
    
    // For planar magnetic speakers, prioritize high-current amplifiers
    if (isPlanarMagneticSpeaker) {
      const highCurrentAmps = filteredPairsWellWith.filter((productId: string) => {
        const suggestedProduct = allProducts.find(p => p.id === productId);
        if (!suggestedProduct) return false;
        
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Prioritize high-current amplifiers (required for planar magnetic speakers)
        return (categoryName.includes('power') || categoryName.includes('integrated')) &&
               (productTitle.includes('high-current') ||
                productTitle.includes('high current') ||
                productDesc.includes('high-current') ||
                productDesc.includes('high current') ||
                productDesc.includes('stable into 2 ohms') ||
                productDesc.includes('doubles power into 4 ohms') ||
                productDesc.includes('difficult loads') ||
                productDesc.includes('low impedance'));
      });
      
      // Move high-current amps to the front - they are REQUIRED for planar magnetic speakers
      const otherProducts = filteredPairsWellWith.filter((id: string) => !highCurrentAmps.includes(id));
      filteredPairsWellWith.length = 0;
      filteredPairsWellWith.push(...highCurrentAmps, ...otherProducts);
    }

    // Check if we need quality control regeneration
    const pairsFiltered = suggestions.pairsWellWith.length > filteredPairsWellWith.length;
    const alsoFiltered = suggestions.alsoConsider.length > filteredAlsoConsider.length;
    
    console.log(`  📊 Filtering check:`, {
      pairsOriginal: suggestions.pairsWellWith.length,
      pairsFiltered: filteredPairsWellWith.length,
      alsoOriginal: suggestions.alsoConsider.length,
      alsoFiltered: filteredAlsoConsider.length,
      needsQC: pairsFiltered || alsoFiltered
    });
    
    let finalSuggestions = suggestions;
    
    if ((pairsFiltered || alsoFiltered) && (filteredPairsWellWith.length > 0 || filteredAlsoConsider.length > 0)) {
      console.log('  🔄 Quality control: Regenerating text for filtered products...');
      
      // Build quality control prompt that ONLY asks for text generation
      const qcPrompt = `You are a seasoned high-end audio specialist. 

QUALITY CONTROL MODE: Generate text for pre-selected products only.

CURRENT PRODUCT:
- Title: ${product.title}
- Manufacturer: ${product.manufacturer?.name}
- Category: ${product.categories?.name}
- Price: $${product.price}

SELECTED "GOOD SYNERGIES" PRODUCTS (generate text for these exact products):
${filteredPairsWellWith.map((id: string) => {
  const p = allProducts.find(prod => prod.id === id);
  return p ? `- ${p.title} by ${p.manufacturer?.name} (${p.categories?.name})` : '';
}).filter(Boolean).join('\n')}

SELECTED "ALSO CONSIDER" PRODUCTS (generate text for these exact products):
${filteredAlsoConsider.map((id: string) => {
  const p = allProducts.find(prod => prod.id === id);
  return p ? `- ${p.title} by ${p.manufacturer?.name} (${p.categories?.name})` : '';
}).filter(Boolean).join('\n')}

YOUR TASK: Generate ONLY the reasoning, CTA, and helper text for these specific products.

CRITICAL: Only reference products listed above. Do not invent or mention other products.

Return ONLY valid JSON:
{
  "pairsWellWith": ${JSON.stringify(filteredPairsWellWith)},
  "pairsReasoning": "Technical explanation of why these specific products pair well...",
  "pairsCTA": "Brief contextual question...",
  "pairsHelper": "1-2 passionate sentences about these specific products...",
  "alsoConsider": ${JSON.stringify(filteredAlsoConsider)},
  "alsoReasoning": "Why these specific alternatives are comparable...",
  "alsoCTA": "Brief contextual question...",
  "alsoHelper": "1-2 sentences about comparing these specific products..."
}`;
      
      const qcMessage = await anthropic.messages.create({
        model: DEFAULT_ANTHROPIC_MODEL,
        max_tokens: DEFAULT_ANTHROPIC_MAX_TOKENS,
        messages: [{ role: 'user', content: qcPrompt }]
      });
      
      const qcText = qcMessage.content[0].type === 'text' ? qcMessage.content[0].text : '';
      const qcMatch = qcText.match(/\{[\s\S]*\}/);
      
      if (qcMatch) {
        // Remove comments from JSON
        const cleanedQcJson = qcMatch[0]
          .replace(/\/\/.*$/gm, '')
          .replace(/,(\s*[}\]])/g, '$1');
        const qcSuggestions = JSON.parse(cleanedQcJson);
        // Use quality control text but keep filtered product arrays
        finalSuggestions = {
          pairsWellWith: filteredPairsWellWith,
          pairsReasoning: qcSuggestions.pairsReasoning,
          pairsCTA: qcSuggestions.pairsCTA,
          pairsHelper: qcSuggestions.pairsHelper,
          alsoConsider: filteredAlsoConsider,
          alsoReasoning: qcSuggestions.alsoReasoning,
          alsoCTA: qcSuggestions.alsoCTA,
          alsoHelper: qcSuggestions.alsoHelper
        };
        
        console.log(`  ✅ QC complete:`, {
          pairsHasReasoning: !!qcSuggestions.pairsReasoning,
          alsoHasReasoning: !!qcSuggestions.alsoReasoning,
          pairsReasoningLength: qcSuggestions.pairsReasoning?.length || 0,
          alsoReasoningLength: qcSuggestions.alsoReasoning?.length || 0
        });
      }
    }
    
    console.log(`  💾 Final data to save:`, {
      pairsCount: (product.pairs_well_with?.length || 0) + filteredPairsWellWith.filter((id: string) => !(product.pairs_well_with || []).includes(id)).length,
      alsoCount: (product.also_consider?.length || 0) + filteredAlsoConsider.filter((id: string) => !(product.also_consider || []).includes(id)).length,
      hasAlsoReasoning: !!finalSuggestions.alsoReasoning
    });
    
    // Merge with existing relationships
    const mergedPairs = [
      ...(product.pairs_well_with || []),
      ...filteredPairsWellWith.filter((id: string) => !(product.pairs_well_with || []).includes(id))
    ];
    
    const mergedAlso = [
      ...(product.also_consider || []),
      ...filteredAlsoConsider.filter((id: string) => !(product.also_consider || []).includes(id))
    ];
    
    // Save to database
    const { error } = await supabase
      .from('products')
      .update({
        pairs_well_with: mergedPairs,
        also_consider: mergedAlso,
        pairs_reasoning: finalSuggestions.pairsReasoning || null,
        pairs_cta: finalSuggestions.pairsCTA || null,
        pairs_helper: finalSuggestions.pairsHelper || null,
        also_reasoning: finalSuggestions.alsoReasoning || null,
        also_cta: finalSuggestions.alsoCTA || null,
        also_helper: finalSuggestions.alsoHelper || null,
        ai_generation_status: 'success',
        ai_generation_error: null,
        ai_last_generated: new Date().toISOString()
      })
      .eq('id', product.id);
    
    if (error) throw error;
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    
    await supabase
      .from('products')
      .update({
        ai_generation_status: 'failed',
        ai_generation_error: errorMessage,
        ai_last_generated: new Date().toISOString()
      })
      .eq('id', product.id);
    
    throw error;
  }
}

// Delay function
function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Ask user for confirmation
function askQuestion(question: string): Promise<string> {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  
  return new Promise(resolve => {
    rl.question(question, answer => {
      rl.close();
      resolve(answer.toLowerCase().trim());
    });
  });
}

// Main execution
async function main() {
  console.log('🚀 Batch AI Relationship Generation\n');
  
  const forceMode = process.argv.includes('--force');
  const retryFailed = process.argv.includes('--retry-failed');
  
  // Load existing progress
  let progress = loadProgress();
  
  if (progress && !retryFailed && !forceMode) {
    console.log(`📋 Found existing progress:`);
    console.log(`   - Processed: ${progress.processedCount}/${progress.totalCount}`);
    console.log(`   - Errors: ${progress.errors.length}`);
    console.log(`   - Started: ${new Date(progress.startTime).toLocaleString()}`);
    console.log(`   - Last update: ${new Date(progress.lastUpdateTime).toLocaleString()}\n`);
    
    const answer = await askQuestion('Resume from last checkpoint? (y/n): ');
    
    if (answer !== 'y' && answer !== 'yes') {
      console.log('Starting fresh...\n');
      deleteProgress();
      progress = null;
    }
  }
  
  // Fetch all products
  console.log('📦 Loading product catalog...');
  
  const { data: allProducts, error: fetchError } = await supabase
    .from('products')
    .select(`
      *,
      categories:product_categories!products_category_id_fkey(id, name, slug),
      manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
    `)
    .eq('published', true)
    .order('title');
  
  if (fetchError || !allProducts) {
    console.error('❌ Error fetching products:', fetchError);
    process.exit(1);
  }
  
  console.log(`✅ Loaded ${allProducts.length} products\n`);
  
  // Determine which products need processing
  let productsToProcess: Product[];
  
  if (retryFailed && progress) {
    console.log('♻️  Retry mode: Processing only failed products...\n');
    const failedIds = progress.errors.map(e => e.productId);
    productsToProcess = allProducts.filter(p => failedIds.includes(p.id));
  } else if (forceMode) {
    console.log('⚡ Force mode: Processing ALL products...\n');
    productsToProcess = allProducts;
  } else {
    productsToProcess = allProducts.filter(p => needsGeneration(p, false));
    
    console.log('🔍 Analysis:');
    console.log(`   - Total products: ${allProducts.length}`);
    console.log(`   - Need generation: ${productsToProcess.length}`);
    console.log(`   - Up to date: ${allProducts.length - productsToProcess.length}\n`);
    
    const breakdown = {
      never: productsToProcess.filter(p => !p.ai_last_generated).length,
      empty: productsToProcess.filter(p => !p.pairs_well_with?.length && !p.also_consider?.length).length,
      legacy: productsToProcess.filter(p => 
        (p.pairs_well_with?.length && !p.pairs_reasoning) ||
        (p.also_consider?.length && !p.also_reasoning)
      ).length,
      incomplete: productsToProcess.filter(p =>
        (p.pairs_reasoning && !p.pairs_helper) ||
        (p.also_reasoning && !p.also_helper)
      ).length,
      updated: productsToProcess.filter(p =>
        p.ai_last_generated && new Date(p.updated_at) > new Date(p.ai_last_generated)
      ).length
    };
    
    console.log('📊 Breakdown:');
    console.log(`   - Never generated: ${breakdown.never}`);
    console.log(`   - Empty relationships: ${breakdown.empty}`);
    console.log(`   - Legacy (needs AI text): ${breakdown.legacy}`);
    console.log(`   - Incomplete fields: ${breakdown.incomplete}`);
    console.log(`   - Recently updated: ${breakdown.updated}\n`);
  }
  
  if (productsToProcess.length === 0) {
    console.log('✅ All products are up to date!');
    return;
  }
  
  // Skip already processed if resuming
  if (progress?.lastProcessedId) {
    const lastIndex = productsToProcess.findIndex(p => p.id === progress?.lastProcessedId);
    if (lastIndex >= 0) {
      productsToProcess = productsToProcess.slice(lastIndex + 1);
      console.log(`⏭️  Skipping ${lastIndex + 1} already-processed products\n`);
    }
  }
  
  // Estimate time and cost
  const estimatedMinutes = Math.ceil((productsToProcess.length * DELAY_BETWEEN_REQUESTS) / 60000);
  const estimatedHours = Math.floor(estimatedMinutes / 60);
  const remainingMinutes = estimatedMinutes % 60;
  const estimatedCost = (productsToProcess.length * 50000 * 0.25) / 1000000 + (productsToProcess.length * 500 * 1.25) / 1000000;
  
  console.log('⏱️  Estimates:');
  console.log(`   - Time: ${estimatedHours}h ${remainingMinutes}m (150s per product)`);
  console.log(`   - Cost: ~$${estimatedCost.toFixed(2)} (using Claude Haiku)`);
  console.log(`   - Products: ${productsToProcess.length}\n`);
  
  const answer = await askQuestion('Continue? (y/n): ');
  
  if (answer !== 'y' && answer !== 'yes') {
    console.log('Cancelled.');
    process.exit(0);
  }
  
  // Initialize progress if starting fresh
  if (!progress) {
    progress = {
      lastProcessedId: null,
      processedCount: 0,
      totalCount: productsToProcess.length,
      startTime: new Date().toISOString(),
      lastUpdateTime: new Date().toISOString(),
      errors: [],
      skipped: 0
    };
  }
  
  // Set up Ctrl+C handler
  process.on('SIGINT', () => {
    console.log('\n\n⚠️  Interrupted! Saving progress...');
    saveProgress(progress!);
    console.log('✅ Progress saved. Run script again to resume.\n');
    process.exit(0);
  });
  
  // Process products
  console.log('\n🎯 Starting generation...\n');
  
  for (let i = 0; i < productsToProcess.length; i++) {
    const product = productsToProcess[i];
    const current = i + 1;
    const total = productsToProcess.length;
    const percent = Math.round((current / total) * 100);
    
    console.log(`[${current}/${total}] (${percent}%) ${product.title}`);
    
    try {
      await generateForProduct(product, allProducts);
      
      progress.processedCount++;
      progress.lastProcessedId = product.id;
      saveProgress(progress);
      
      console.log(`  ✅ Success`);
      
      // Rate limiting delay (except for last product)
      if (i < productsToProcess.length - 1) {
        const secondsRemaining = DELAY_BETWEEN_REQUESTS / 1000;
        console.log(`  ⏳ Waiting ${secondsRemaining}s for rate limit...\n`);
        await delay(DELAY_BETWEEN_REQUESTS);
      }
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.log(`  ❌ Failed: ${errorMessage}`);
      
      progress.errors.push({
        productId: product.id,
        productTitle: product.title,
        error: errorMessage
      });
      
      saveProgress(progress);
      
      // Check if it's a rate limit error - if so, wait longer
      if (errorMessage.includes('rate_limit') || errorMessage.includes('429')) {
        console.log(`  ⏸️  Rate limit hit. Waiting 60s before continuing...\n`);
        await delay(60000);
      } else if (errorMessage.includes('credit balance')) {
        console.log(`\n❌ Credit balance exhausted. Progress saved.`);
        console.log(`   Run script again after adding credits to resume.\n`);
        process.exit(1);
      } else {
        console.log(`  ⏭️  Continuing to next product...\n`);
      }
    }
  }
  
  // Final summary
  console.log('\n' + '='.repeat(60));
  console.log('📊 BATCH GENERATION COMPLETE\n');
  console.log(`✅ Successfully processed: ${progress.processedCount}/${productsToProcess.length}`);
  console.log(`❌ Errors: ${progress.errors.length}`);
  console.log(`⏭️  Skipped (up to date): ${progress.skipped}`);
  
  if (progress.errors.length > 0) {
    console.log('\n⚠️  Failed products:');
    progress.errors.forEach(e => {
      console.log(`   - ${e.productTitle}: ${e.error}`);
    });
    console.log('\n💡 Run with --retry-failed to process only failures');
  }
  
  const duration = Date.now() - new Date(progress.startTime).getTime();
  const hours = Math.floor(duration / 3600000);
  const minutes = Math.floor((duration % 3600000) / 60000);
  
  console.log(`\n⏱️  Total time: ${hours}h ${minutes}m`);
  console.log('='.repeat(60) + '\n');
  
  // Clean up progress file on success
  if (progress.errors.length === 0) {
    deleteProgress();
    console.log('✨ All done! Progress file cleaned up.\n');
  } else {
    console.log('📝 Progress file saved for retry.\n');
  }
}

main().catch(error => {
  console.error('\n💥 Fatal error:', error);
  process.exit(1);
});



