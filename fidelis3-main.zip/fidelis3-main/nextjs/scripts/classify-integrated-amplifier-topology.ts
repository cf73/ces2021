#!/usr/bin/env tsx
import { config } from 'dotenv';
import { resolve } from 'path';
import { createClient } from '@supabase/supabase-js';
import Anthropic from '@anthropic-ai/sdk';
import { TavilyClient } from 'tavily';
import { DEFAULT_ANTHROPIC_MODEL, ANTHROPIC_CLASSIFICATION_MAX_TOKENS } from '../lib/anthropic-config';

config({ path: resolve(__dirname, '../.env.local') });

type ProductTopology = 'tube' | 'solid_state' | 'hybrid';

interface ProductRow {
  id: string;
  title: string;
  slug: string;
  content?: string | null;
  brief_description?: string | null;
  specs?: string | null;
  topology?: ProductTopology | null;
  manufacturer?: { name?: string | null } | null;
  categories?: { name?: string | null; slug?: string | null } | null;
}

interface Classification {
  topology: ProductTopology | null;
  confidence: 'high' | 'medium' | 'low';
  evidence: string;
  source: 'local' | 'web' | 'none';
}

const DRY_RUN = process.argv.includes('--dry-run');
const MIN_CONFIDENCE_TO_WRITE: Classification['confidence'][] = ['high'];

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseWriteKey = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabaseReadKey = supabaseWriteKey || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const tavilyApiKey = process.env.TAVILY_API_KEY;
const anthropicApiKey = process.env.ANTHROPIC_API_KEY;

if (!supabaseUrl || !supabaseReadKey) {
  console.error('Missing Supabase credentials.');
  console.error('Required in nextjs/.env.local: NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.');
  process.exit(1);
}

if (!DRY_RUN && !supabaseWriteKey) {
  console.error('Missing Supabase write credentials.');
  console.error('Required for writes in nextjs/.env.local: SUPABASE_SECRET_KEY.');
  process.exit(1);
}

const supabaseKey = (DRY_RUN ? supabaseReadKey : supabaseWriteKey) as string;
const supabase = createClient(supabaseUrl, supabaseKey);
const tavily = tavilyApiKey ? new TavilyClient({ apiKey: tavilyApiKey }) : null;
const anthropic = anthropicApiKey ? new Anthropic({ apiKey: anthropicApiKey }) : null;

const normalizeText = (value?: string | null) =>
  (value || '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

const snippetAround = (text: string, pattern: RegExp) => {
  const match = text.match(pattern);
  if (!match || match.index === undefined) return '';
  const start = Math.max(0, match.index - 80);
  const end = Math.min(text.length, match.index + match[0].length + 80);
  return text.slice(start, end).trim();
};

function classifyFromLocalText(product: ProductRow): Classification {
  const text = normalizeText([
    product.title,
    product.manufacturer?.name,
    product.brief_description,
    product.content,
    product.specs,
  ].filter(Boolean).join(' '));

  const hybridPattern = /\b(hybrid|tube pre(?:amp|amplifier| stage).{0,80}(solid[-\s]?state|transistor|mosfet)|solid[-\s]?state.{0,80}tube|vacuum tube.{0,80}(solid[-\s]?state|transistor|mosfet))\b/i;
  const tubePattern = /\b(all[-\s]?tube|tube integrated|vacuum tube|valve amplifier|valve integrated|tube complement|kt88|kt120|kt150|el34|300b|6550|12ax7|12au7)\b/i;
  const solidStatePattern = /\b(solid[-\s]?state|class\s?[ad]|class\s?a\/b|mosfet|transistor|gan fet|hypex|purifi)\b/i;

  if (hybridPattern.test(text)) {
    return {
      topology: 'hybrid',
      confidence: 'high',
      evidence: snippetAround(text, hybridPattern),
      source: 'local',
    };
  }

  if (tubePattern.test(text) && !solidStatePattern.test(text)) {
    return {
      topology: 'tube',
      confidence: 'high',
      evidence: snippetAround(text, tubePattern),
      source: 'local',
    };
  }

  if (solidStatePattern.test(text) && !tubePattern.test(text)) {
    return {
      topology: 'solid_state',
      confidence: 'high',
      evidence: snippetAround(text, solidStatePattern),
      source: 'local',
    };
  }

  return {
    topology: null,
    confidence: 'low',
    evidence: 'No strong topology signal in local product text.',
    source: 'none',
  };
}

function extractJson(text: string) {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const raw = fenced?.[1] || text;
  const objectMatch = raw.match(/\{[\s\S]*\}/);
  return objectMatch ? JSON.parse(objectMatch[0]) : JSON.parse(raw);
}

async function classifyFromWeb(product: ProductRow): Promise<Classification> {
  if (!tavily || !anthropic) {
    return {
      topology: null,
      confidence: 'low',
      evidence: 'TAVILY_API_KEY or ANTHROPIC_API_KEY not configured.',
      source: 'none',
    };
  }

  const productName = `${product.manufacturer?.name || ''} ${product.title}`.trim();
  const search = await tavily.search({
    query: `${productName} integrated amplifier tube solid state hybrid topology`,
    search_depth: 'basic',
    max_results: 8,
    include_answer: false,
    include_raw_content: false,
  });

  const results = (search.results || [])
    .map((result: { title: string; url: string; content: string }, index: number) =>
      `SOURCE ${index + 1}\nTitle: ${result.title}\nURL: ${result.url}\nContent: ${result.content}`
    )
    .join('\n\n');

  if (!results) {
    return {
      topology: null,
      confidence: 'low',
      evidence: 'No web search results found.',
      source: 'web',
    };
  }

  const prompt = `Classify this high-end audio integrated amplifier by amplifier topology.

Allowed topology values:
- tube: all-tube/valve integrated amplifier
- solid_state: transistor, MOSFET, class A, class A/B, class D, GaN, or other non-tube integrated amplifier
- hybrid: tube/valve preamp or input stage combined with solid-state output/power stage

Product: ${productName}

Search results:
${results}

Return JSON only:
{
  "topology": "tube" | "solid_state" | "hybrid" | null,
  "confidence": "high" | "medium" | "low",
  "evidence": "short source-based reason"
}

Use "high" only when the sources clearly establish the topology.`;

  const message = await anthropic.messages.create({
    model: DEFAULT_ANTHROPIC_MODEL,
    max_tokens: ANTHROPIC_CLASSIFICATION_MAX_TOKENS,
    messages: [{ role: 'user', content: prompt }],
  });

  const responseText = message.content[0]?.type === 'text' ? message.content[0].text : '{}';
  const parsed = extractJson(responseText);
  const topology = ['tube', 'solid_state', 'hybrid'].includes(parsed.topology)
    ? parsed.topology as ProductTopology
    : null;

  return {
    topology,
    confidence: parsed.confidence === 'high' || parsed.confidence === 'medium' ? parsed.confidence : 'low',
    evidence: String(parsed.evidence || 'No evidence returned.'),
    source: 'web',
  };
}

async function getIntegratedAmplifiers(): Promise<ProductRow[]> {
  const { data: categories, error: categoryError } = await supabase
    .from('product_categories')
    .select('id, name, slug');

  if (categoryError) throw categoryError;

  const category = categories?.find(category =>
    category.slug === 'integrated-amplifiers' ||
    category.name?.trim().toLowerCase() === 'integrated amplifiers'
  );

  if (!category) {
    throw new Error('Could not find the Integrated Amplifiers category.');
  }

  const productSelect = `
    id,
    title,
    slug,
    content,
    brief_description,
    specs,
    topology,
    manufacturer:manufacturers!products_manufacturer_id_fkey(name),
    categories:product_categories!products_category_id_fkey(name, slug)
  `;

  const productSelectWithoutTopology = `
    id,
    title,
    slug,
    content,
    brief_description,
    specs,
    manufacturer:manufacturers!products_manufacturer_id_fkey(name),
    categories:product_categories!products_category_id_fkey(name, slug)
  `;

  const queryProducts = (select: string) => supabase
    .from('products')
    .select(select)
    .eq('category_id', category.id)
    .eq('published', true)
    .order('title', { ascending: true });

  let { data: products, error: productsError } = await queryProducts(productSelect);

  if (productsError?.code === '42703' && DRY_RUN) {
    console.warn('products.topology does not exist yet; dry run will preview classifications without existing topology values.');
    const fallback = await queryProducts(productSelectWithoutTopology);
    products = fallback.data;
    productsError = fallback.error;
  }

  if (productsError) throw productsError;
  return (products || []) as unknown as ProductRow[];
}

async function main() {
  console.log(`${DRY_RUN ? 'Dry run: ' : ''}classifying Integrated Amplifier topology`);

  const products = await getIntegratedAmplifiers();
  console.log(`Found ${products.length} published Integrated Amplifier products.`);

  let updated = 0;
  let skipped = 0;

  for (const product of products) {
    if (product.topology) {
      console.log(`- ${product.manufacturer?.name || 'Unknown'} ${product.title}: already ${product.topology}`);
      skipped += 1;
      continue;
    }

    let classification = classifyFromLocalText(product);
    if (!classification.topology || classification.confidence !== 'high') {
      classification = await classifyFromWeb(product);
    }

    const label = `${product.manufacturer?.name || 'Unknown'} ${product.title}`;
    if (
      classification.topology &&
      MIN_CONFIDENCE_TO_WRITE.includes(classification.confidence)
    ) {
      console.log(`- ${label}: ${classification.topology} (${classification.source})`);
      console.log(`  Evidence: ${classification.evidence}`);

      if (!DRY_RUN) {
        const { error } = await supabase
          .from('products')
          .update({ topology: classification.topology })
          .eq('id', product.id);

        if (error) throw error;
      }

      updated += 1;
    } else {
      console.log(`- ${label}: skipped (${classification.confidence})`);
      console.log(`  Reason: ${classification.evidence}`);
      skipped += 1;
    }
  }

  console.log(`Done. ${DRY_RUN ? 'Would update' : 'Updated'} ${updated}; skipped ${skipped}.`);
}

main().catch(error => {
  console.error('Topology classification failed:', error);
  process.exit(1);
});
