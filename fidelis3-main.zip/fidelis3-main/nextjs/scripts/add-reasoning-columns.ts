import { supabase } from '../lib/supabase';

async function addReasoningColumns() {
  console.log('Adding reasoning columns to products table...');
  
  // Execute raw SQL to add columns
  const { error } = await supabase.rpc('exec_sql', {
    sql: `
      ALTER TABLE products 
      ADD COLUMN IF NOT EXISTS pairs_reasoning TEXT,
      ADD COLUMN IF NOT EXISTS also_reasoning TEXT;
    `
  });
  
  if (error) {
    console.error('Error adding columns:', error);
    console.log('\nPlease run this SQL manually in Supabase SQL Editor:');
    console.log('ALTER TABLE products ADD COLUMN IF NOT EXISTS pairs_reasoning TEXT, ADD COLUMN IF NOT EXISTS also_reasoning TEXT;');
  } else {
    console.log('✅ Columns added successfully!');
  }
}

addReasoningColumns();

