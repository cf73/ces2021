#!/usr/bin/env tsx
import { config } from 'dotenv';
import { resolve } from 'path';
import { createClient } from '@supabase/supabase-js';
import Anthropic from '@anthropic-ai/sdk';
import { TavilyClient } from 'tavily';
import { DEFAULT_ANTHROPIC_MODEL, ANTHROPIC_CLASSIFICATION_MAX_TOKENS } from '../lib/anthropic-config';

config({ path: resolve(__dirname, '../.env.local') });

type ProductTopology = 'tube' | 'solid_state' | 'hybrid';
type ProductAmplifierClass = 'class_a' | 'class_ab' | 'class_d' | 'class_g' | 'class_h';
type Confidence = 'high' | 'medium' | 'low';

interface ProductRow {
  id: string;
  title: string;
  slug: string;
  content?: string | null;
  brief_description?: string | null;
  specs?: string | null;
  topology?: ProductTopology | null;
  amplifier_class?: ProductAmplifierClass | null;
  manufacturer?: { name?: string | null } | null;
  categories?: { name?: string | null; slug?: string | null } | null;
}

interface Classification {
  topology: ProductTopology | null;
  amplifier_class: ProductAmplifierClass | null;
  confidence: Confidence;
  evidence: string;
  source: 'manual' | 'local' | 'web' | 'none';
}

const DRY_RUN = process.argv.includes('--dry-run');
const FORCE = process.argv.includes('--force');

const AMPLIFIER_CATEGORY_SLUGS = [
  'integrated-amplifiers',
  'power-amplifiers',
  'pre-amps',
  'phonostage',
  'headphone-amplifiers',
];

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseWriteKey = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabaseReadKey = supabaseWriteKey || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const tavilyApiKey = process.env.TAVILY_API_KEY;
const anthropicApiKey = process.env.ANTHROPIC_API_KEY;

if (!supabaseUrl || !supabaseReadKey) {
  console.error('Missing Supabase credentials.');
  console.error('Required in nextjs/.env.local: NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.');
  process.exit(1);
}

if (!DRY_RUN && !supabaseWriteKey) {
  console.error('Missing Supabase write credentials.');
  console.error('Required for writes in nextjs/.env.local: SUPABASE_SECRET_KEY.');
  process.exit(1);
}

const supabaseKey = (DRY_RUN ? supabaseReadKey : supabaseWriteKey) as string;
const supabase = createClient(supabaseUrl, supabaseKey);
const tavily = tavilyApiKey ? new TavilyClient({ apiKey: tavilyApiKey }) : null;
const anthropic = anthropicApiKey ? new Anthropic({ apiKey: anthropicApiKey }) : null;
let hasAmplifierClassColumn = true;

const manualKey = (manufacturer?: string | null, title?: string | null) =>
  `${manufacturer || ''} ${title || ''}`.trim().toLowerCase().replace(/\s+/g, ' ');

const MANUAL_CLASSIFICATIONS: Record<string, Classification> = {
  'boulder 866': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Boulder 866 is documented as a solid-state Class AB integrated amplifier.', source: 'manual' },
  'cambridge audio axa35': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'AXA35 is documented as a Class AB integrated amplifier.', source: 'manual' },
  'rega brio mk7': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Rega Brio Mk7 is documented as a Class AB integrated amplifier.', source: 'manual' },
  'cambridge audio cxa81 mkii': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'CXA81 MkII is documented as a Class AB integrated amplifier.', source: 'manual' },
  'accuphase e-4000': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Accuphase E-4000 uses Class AB power transistors.', source: 'manual' },
  'accuphase e-5000': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Accuphase E-5000 uses Class AB power transistors.', source: 'manual' },
  'accuphase e3000': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Accuphase E-3000 uses Class AB power transistors.', source: 'manual' },
  'rega elex mk4': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Rega Elex Mk4 uses Rega Class A/B amplifier circuitry.', source: 'manual' },
  'rega elicit mk v': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Rega Elicit Mk V is documented with Class A/B amplifier circuitry.', source: 'manual' },
  'hegel h120': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Hegel H120 is a solid-state Class AB integrated amplifier.', source: 'manual' },
  'hegel h190v': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Hegel H190v is documented as Class AB.', source: 'manual' },
  'hegel h400': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Hegel H400 is documented as Class AB.', source: 'manual' },
  'mola mola kula': { topology: 'solid_state', amplifier_class: 'class_d', confidence: 'high', evidence: 'Mola Mola Kula uses NCore-inspired Class D amplification.', source: 'manual' },
  'audio research i/70': { topology: 'tube', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Audio Research I/70 is a 6550 vacuum-tube integrated amplifier.', source: 'manual' },
  'pass labs int-25': { topology: 'solid_state', amplifier_class: 'class_a', confidence: 'high', evidence: 'Pass Labs INT-25 is a solid-state Class A integrated amplifier.', source: 'manual' },
  'pass labs int-60': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Pass Labs INT-60 is biased deeply into Class A before transitioning beyond that range.', source: 'manual' },
  'pass labs int-250': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Pass Labs INT-250 is biased into Class A for initial output and then operates beyond that range.', source: 'manual' },
  'mcintosh ma12000': { topology: 'hybrid', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MA12000 combines tube preamp stages with solid-state output.', source: 'manual' },
  'mcintosh ma252': { topology: 'hybrid', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MA252 combines tube preamp stages with solid-state output.', source: 'manual' },
  'mcintosh ma352': { topology: 'hybrid', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MA352 combines tube preamp stages with solid-state output.', source: 'manual' },
  'mcintosh ma5300': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MA5300 is a solid-state integrated amplifier.', source: 'manual' },
  'mcintosh ma8950': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MA8950 is a solid-state integrated amplifier.', source: 'manual' },
  'mcintosh ma9500': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MA9500 is documented as solid state.', source: 'manual' },
  'esoteric f-01': { topology: 'solid_state', amplifier_class: 'class_a', confidence: 'high', evidence: 'Esoteric F-01 is documented as a Class A integrated amplifier.', source: 'manual' },
  'rega io': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Rega io uses Class A/B amplifier circuitry.', source: 'manual' },

  'boulder 1151': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Boulder 1151 is a solid-state power amplifier.', source: 'manual' },
  'boulder 1162': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Boulder 1162 is a solid-state power amplifier.', source: 'manual' },
  'boulder 1163': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Boulder 1163 is a solid-state power amplifier.', source: 'manual' },
  'eversolo amp-f2': { topology: 'solid_state', amplifier_class: 'class_d', confidence: 'high', evidence: 'EverSolo AMP-F2 is a Class D power amplifier.', source: 'manual' },
  'air tight atm-1e': { topology: 'tube', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Air Tight ATM-1E is a tube power amplifier.', source: 'manual' },
  'air tight atm-300r': { topology: 'tube', amplifier_class: 'class_a', confidence: 'high', evidence: 'Air Tight ATM-300R is a 300B single-ended tube amplifier.', source: 'manual' },
  'conrad-johnson cl120se': { topology: 'tube', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Conrad-Johnson CL120SE is a tube power amplifier.', source: 'manual' },
  'conrad-johnson classic 62se': { topology: 'tube', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Conrad-Johnson Classic 62SE is a tube power amplifier.', source: 'manual' },
  'audio research d-80': { topology: 'tube', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Audio Research D-80 is a tube power amplifier.', source: 'manual' },
  'audio research s-100': { topology: 'solid_state', amplifier_class: 'class_d', confidence: 'high', evidence: 'Audio Research S-100 is a solid-state Class D power amplifier.', source: 'manual' },
  'audio research s-200': { topology: 'solid_state', amplifier_class: 'class_d', confidence: 'high', evidence: 'Audio Research S-200 is a solid-state Class D power amplifier.', source: 'manual' },
  'hegel h30a': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Hegel H30A is a solid-state power amplifier.', source: 'manual' },
  'jmf audio hqs 6002': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'JMF Audio HQS 6002 is a solid-state power amplifier.', source: 'manual' },
  'mcintosh mc152': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MC152 is a solid-state power amplifier.', source: 'manual' },
  'mcintosh mc275': { topology: 'tube', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MC275 is a vacuum-tube power amplifier.', source: 'manual' },
  'mcintosh mc312': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MC312 is a solid-state power amplifier.', source: 'manual' },
  'mcintosh mc451': { topology: 'hybrid', amplifier_class: null, confidence: 'high', evidence: 'McIntosh MC451 combines tube and solid-state amplifier sections.', source: 'manual' },
  'mcintosh mc462': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MC462 is a solid-state power amplifier.', source: 'manual' },
  'mcintosh mc611': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'McIntosh MC611 is a solid-state power amplifier.', source: 'manual' },
  'accuphase p-4600': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Accuphase P-4600 is a Class AB power amplifier.', source: 'manual' },
  'spl performer m1000': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'SPL Performer m1000 is a solid-state power amplifier.', source: 'manual' },
  'spl performer s1200': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'SPL Performer s1200 is a solid-state power amplifier.', source: 'manual' },
  'spl performer s800': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'SPL Performer s800 is a solid-state power amplifier.', source: 'manual' },
  'spl performer s900': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'SPL Performer s900 is a solid-state power amplifier.', source: 'manual' },
  'esoteric s-05xe': { topology: 'solid_state', amplifier_class: 'class_a', confidence: 'high', evidence: 'Esoteric S-05XE is documented as a Class A power amplifier.', source: 'manual' },
  'msb s202': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'MSB S202 is a solid-state power amplifier.', source: 'manual' },
  'pass labs x150.8': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Pass Labs X150.8 is a solid-state amplifier biased into Class A for initial output.', source: 'manual' },
  'pass labs x250.8': { topology: 'solid_state', amplifier_class: 'class_ab', confidence: 'high', evidence: 'Pass Labs X250.8 is a solid-state amplifier biased into Class A for initial output.', source: 'manual' },
  'pass labs xa25': { topology: 'solid_state', amplifier_class: 'class_a', confidence: 'high', evidence: 'Pass Labs XA25 is a solid-state Class A power amplifier.', source: 'manual' },

  'mcintosh c22': { topology: 'tube', amplifier_class: null, confidence: 'high', evidence: 'McIntosh C22 is a vacuum-tube preamplifier.', source: 'manual' },
  'mcintosh c2800': { topology: 'tube', amplifier_class: null, confidence: 'high', evidence: 'McIntosh C2800 is a vacuum-tube preamplifier.', source: 'manual' },
  'mcintosh c8': { topology: 'tube', amplifier_class: null, confidence: 'high', evidence: 'McIntosh C8 is a vacuum-tube preamplifier.', source: 'manual' },
  'audio research ls-2': { topology: 'hybrid', amplifier_class: null, confidence: 'high', evidence: 'Audio Research LS-2 is a hybrid tube/FET line-stage preamplifier.', source: 'manual' },
  'audio research ls-3': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Audio Research LS-3 is a solid-state line-stage preamplifier.', source: 'manual' },
  'spl director mkii': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'SPL Director MkII is a solid-state preamplifier/DAC.', source: 'manual' },
  'spl elector': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'SPL Elector is a solid-state preamplifier.', source: 'manual' },
  'eversolo dmp-a8': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'EverSolo DMP-A8 is a solid-state streamer/DAC/preamp.', source: 'manual' },
  'hegel p30a': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Hegel P30A is a solid-state preamplifier.', source: 'manual' },
  'jmf audio prs 1.5': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'JMF Audio PRS 1.5 is a solid-state preamplifier.', source: 'manual' },
  'pass labs xp-12': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Pass Labs XP-12 is a solid-state preamplifier.', source: 'manual' },

  'cambridge audio duo': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Cambridge Audio Duo is a solid-state phono preamp.', source: 'manual' },
  'cambridge audio solo': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Cambridge Audio Solo is a solid-state phono preamp.', source: 'manual' },
  'rega fono mc mk4': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Rega Fono MC Mk4 is a solid-state phono preamp.', source: 'manual' },
  'rega fono mm mk5': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Rega Fono MM Mk5 is a solid-state phono preamp.', source: 'manual' },
  'sutherland 20/20': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Sutherland 20/20 is a solid-state phono preamp.', source: 'manual' },
  'sutherland duo': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Sutherland Duo is a solid-state phono preamp.', source: 'manual' },
  'sutherland insight': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Sutherland Insight is a solid-state phono preamp.', source: 'manual' },
  'sutherland kc vibe mk2': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Sutherland KC Vibe Mk2 is a solid-state phono preamp.', source: 'manual' },
  'sutherland little loco': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Sutherland Little Loco is a solid-state transimpedance phono preamp.', source: 'manual' },
  'sutherland sutz': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Sutherland SUTZ is a solid-state transimpedance phono preamp.', source: 'manual' },
  'sutherland tz vibe': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Sutherland TZ Vibe is a solid-state transimpedance phono preamp.', source: 'manual' },
  'spl phonos': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'SPL Phonos is a solid-state phono preamp.', source: 'manual' },
  'spl phonos duo': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'SPL Phonos Duo is a solid-state phono preamp.', source: 'manual' },
  'jmf audio phs 7.2': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'JMF Audio PHS 7.2 is a solid-state phono stage.', source: 'manual' },
  'grimm audio pw1': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Grimm Audio PW1 is a solid-state phono preamp.', source: 'manual' },
  'hegel v10': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Hegel V10 is a solid-state phono preamp.', source: 'manual' },
  'pass labs xp-17': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'Pass Labs XP-17 is a solid-state phono preamp.', source: 'manual' },

  'pass labs hpa-1': { topology: 'solid_state', amplifier_class: 'class_a', confidence: 'high', evidence: 'Pass Labs HPA-1 is a solid-state Class A headphone amplifier.', source: 'manual' },
  'mcintosh mha200': { topology: 'tube', amplifier_class: null, confidence: 'high', evidence: 'McIntosh MHA200 is a vacuum-tube headphone amplifier.', source: 'manual' },
  'spl phonitor se + dac768xs': { topology: 'solid_state', amplifier_class: null, confidence: 'high', evidence: 'SPL Phonitor SE is a solid-state headphone amplifier.', source: 'manual' },
};

const normalizeText = (value?: string | null) =>
  (value || '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();

const snippetAround = (text: string, pattern: RegExp) => {
  const match = text.match(pattern);
  if (!match || match.index === undefined) return '';
  const start = Math.max(0, match.index - 80);
  const end = Math.min(text.length, match.index + match[0].length + 80);
  return text.slice(start, end).trim();
};

function classifyFromManual(product: ProductRow): Classification | null {
  return MANUAL_CLASSIFICATIONS[manualKey(product.manufacturer?.name, product.title)] || null;
}

function classifyFromLocalText(product: ProductRow): Classification {
  const text = normalizeText([
    product.title,
    product.manufacturer?.name,
    product.categories?.name,
    product.brief_description,
    product.content,
    product.specs,
  ].filter(Boolean).join(' '));

  const hybridPattern = /\b(hybrid|tube pre(?:amp|amplifier| stage).{0,80}(solid[-\s]?state|transistor|mosfet)|solid[-\s]?state.{0,80}tube|vacuum tube.{0,80}(solid[-\s]?state|transistor|mosfet))\b/i;
  const tubePattern = /\b(all[-\s]?tube|vacuum tube|valve amplifier|tube complement|kt88|kt120|kt150|el34|300b|6550|12ax7|12au7|6h30|6922)\b/i;
  const solidStatePattern = /\b(solid[-\s]?state|class\s?[adgh]|class\s?a\/b|class\s?ab|mosfet|transistor|gan fet|hypex|purifi|ncore|fet)\b/i;
  const classPatterns: Array<[ProductAmplifierClass, RegExp]> = [
    ['class_ab', /\bclass\s?(?:a\/b|ab)\b/i],
    ['class_a', /\bclass\s?a\b/i],
    ['class_d', /\b(class\s?d|ncore|hypex|purifi)\b/i],
    ['class_g', /\bclass\s?g\b/i],
    ['class_h', /\bclass\s?h\b/i],
  ];

  const amplifierClass = classPatterns.find(([, pattern]) => pattern.test(text))?.[0] || null;

  if (hybridPattern.test(text)) {
    return { topology: 'hybrid', amplifier_class: amplifierClass, confidence: 'high', evidence: snippetAround(text, hybridPattern), source: 'local' };
  }

  if (tubePattern.test(text) && !solidStatePattern.test(text)) {
    return { topology: 'tube', amplifier_class: amplifierClass, confidence: 'high', evidence: snippetAround(text, tubePattern), source: 'local' };
  }

  if (solidStatePattern.test(text) && !tubePattern.test(text)) {
    return { topology: 'solid_state', amplifier_class: amplifierClass, confidence: 'high', evidence: snippetAround(text, solidStatePattern), source: 'local' };
  }

  return { topology: null, amplifier_class: amplifierClass, confidence: amplifierClass ? 'medium' : 'low', evidence: 'No strong topology signal in local product text.', source: 'none' };
}

function extractJson(text: string) {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const raw = fenced?.[1] || text;
  const objectMatch = raw.match(/\{[\s\S]*\}/);
  return objectMatch ? JSON.parse(objectMatch[0]) : JSON.parse(raw);
}

async function classifyFromWeb(product: ProductRow): Promise<Classification> {
  if (!tavily || !anthropic) {
    return { topology: null, amplifier_class: null, confidence: 'low', evidence: 'TAVILY_API_KEY or ANTHROPIC_API_KEY not configured.', source: 'none' };
  }

  const productName = `${product.manufacturer?.name || ''} ${product.title}`.trim();
  const search = await tavily.search({
    query: `${productName} ${product.categories?.name || 'amplifier'} tube solid state hybrid Class A AB D topology specs`,
    search_depth: 'basic',
    max_results: 8,
    include_answer: false,
    include_raw_content: false,
  });

  const results = (search.results || [])
    .map((result: { title: string; url: string; content: string }, index: number) =>
      `SOURCE ${index + 1}\nTitle: ${result.title}\nURL: ${result.url}\nContent: ${result.content}`
    )
    .join('\n\n');

  if (!results) {
    return { topology: null, amplifier_class: null, confidence: 'low', evidence: 'No web search results found.', source: 'web' };
  }

  const prompt = `Classify this high-end audio product by circuit topology and amplifier operating class.

Allowed topology values:
- tube: all-tube/valve product
- solid_state: transistor, FET, MOSFET, op-amp, Class D, GaN, or other non-tube product
- hybrid: tube/valve stage combined with solid-state stage

Allowed amplifier_class values:
- class_a
- class_ab
- class_d
- class_g
- class_h
- null when not clearly documented or not meaningful for this preamp/phono stage

Product: ${productName}
Category: ${product.categories?.name}

Search results:
${results}

Return JSON only:
{
  "topology": "tube" | "solid_state" | "hybrid" | null,
  "amplifier_class": "class_a" | "class_ab" | "class_d" | "class_g" | "class_h" | null,
  "confidence": "high" | "medium" | "low",
  "evidence": "short source-based reason"
}

Use "high" only when the sources clearly establish the values.`;

  const message = await anthropic.messages.create({
    model: DEFAULT_ANTHROPIC_MODEL,
    max_tokens: ANTHROPIC_CLASSIFICATION_MAX_TOKENS,
    messages: [{ role: 'user', content: prompt }],
  });

  const responseText = message.content[0]?.type === 'text' ? message.content[0].text : '{}';
  const parsed = extractJson(responseText);
  const topology = ['tube', 'solid_state', 'hybrid'].includes(parsed.topology) ? parsed.topology as ProductTopology : null;
  const amplifierClass = ['class_a', 'class_ab', 'class_d', 'class_g', 'class_h'].includes(parsed.amplifier_class) ? parsed.amplifier_class as ProductAmplifierClass : null;

  return {
    topology,
    amplifier_class: amplifierClass,
    confidence: parsed.confidence === 'high' || parsed.confidence === 'medium' ? parsed.confidence : 'low',
    evidence: String(parsed.evidence || 'No evidence returned.'),
    source: 'web',
  };
}

async function getAmplifierProducts(): Promise<ProductRow[]> {
  const { data: categories, error: categoryError } = await supabase
    .from('product_categories')
    .select('id, name, slug')
    .in('slug', AMPLIFIER_CATEGORY_SLUGS);

  if (categoryError) throw categoryError;
  const categoryIds = (categories || []).map(category => category.id);

  const productSelect = `
    id,
    title,
    slug,
    content,
    brief_description,
    specs,
    topology,
    amplifier_class,
    manufacturer:manufacturers!products_manufacturer_id_fkey(name),
    categories:product_categories!products_category_id_fkey(name, slug)
  `;

  const productSelectWithoutAmplifierClass = `
    id,
    title,
    slug,
    content,
    brief_description,
    specs,
    topology,
    manufacturer:manufacturers!products_manufacturer_id_fkey(name),
    categories:product_categories!products_category_id_fkey(name, slug)
  `;

  const queryProducts = (select: string) => supabase
    .from('products')
    .select(select)
    .in('category_id', categoryIds)
    .eq('published', true)
    .order('title', { ascending: true });

  let { data: products, error: productsError } = await queryProducts(productSelect);

  if (productsError?.code === '42703') {
    hasAmplifierClassColumn = false;
    console.warn('products.amplifier_class does not exist yet; class values will be previewed but not written.');
    const fallback = await queryProducts(productSelectWithoutAmplifierClass);
    products = fallback.data;
    productsError = fallback.error;
  }

  if (productsError) throw productsError;
  return (products || []) as unknown as ProductRow[];
}

async function main() {
  console.log(`${DRY_RUN ? 'Dry run: ' : ''}classifying amplifier products`);

  const products = await getAmplifierProducts();
  console.log(`Found ${products.length} published amplifier products.`);

  let updated = 0;
  let skipped = 0;

  for (const product of products) {
    if (!FORCE && product.topology && product.amplifier_class) {
      console.log(`- ${product.manufacturer?.name || 'Unknown'} ${product.title}: already topology=${product.topology}, class=${product.amplifier_class || 'blank'}`);
      skipped += 1;
      continue;
    }

    let classification = classifyFromManual(product) || classifyFromLocalText(product);
    if ((!classification.topology || classification.confidence !== 'high') && (!product.topology || FORCE)) {
      classification = await classifyFromWeb(product);
    }

    const update: Partial<Pick<ProductRow, 'topology' | 'amplifier_class'>> = {};
    if ((FORCE || !product.topology) && classification.topology && classification.confidence === 'high') {
      update.topology = classification.topology;
    }
    if (hasAmplifierClassColumn && (FORCE || !product.amplifier_class) && classification.amplifier_class && classification.confidence === 'high') {
      update.amplifier_class = classification.amplifier_class;
    }

    const label = `${product.manufacturer?.name || 'Unknown'} ${product.title}`;
    if (Object.keys(update).length > 0) {
      console.log(`- ${label}: ${JSON.stringify(update)} (${classification.source})`);
      console.log(`  Evidence: ${classification.evidence}`);

      if (!DRY_RUN) {
        const { error } = await supabase
          .from('products')
          .update(update)
          .eq('id', product.id);

        if (error) throw error;
      }

      updated += 1;
    } else {
      console.log(`- ${label}: skipped (${classification.confidence})`);
      console.log(`  Reason: ${classification.evidence}`);
      skipped += 1;
    }
  }

  console.log(`Done. ${DRY_RUN ? 'Would update' : 'Updated'} ${updated}; skipped ${skipped}.`);
}

main().catch(error => {
  console.error('Amplifier classification failed:', error);
  process.exit(1);
});
