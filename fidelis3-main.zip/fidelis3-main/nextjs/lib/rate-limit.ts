type TokenBucket = {
  tokens: number;
  lastRefill: number;
};

const buckets = new Map<string, TokenBucket>();

/**
 * Simple in-memory token bucket rate limiter.
 * Defaults: 20 requests per 5 minutes per key.
 */
export function checkRateLimit(
  key: string,
  {
    capacity = 20,
    intervalMs = 5 * 60 * 1000, // 5 minutes
    cost = 1
  } = {}
): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const bucket = buckets.get(key) || { tokens: capacity, lastRefill: now };

  // Refill tokens
  const elapsed = now - bucket.lastRefill;
  if (elapsed > 0) {
    const refill = Math.floor((elapsed / intervalMs) * capacity);
    bucket.tokens = Math.min(capacity, bucket.tokens + refill);
    bucket.lastRefill = now;
  }

  if (bucket.tokens < cost) {
    buckets.set(key, bucket);
    return { allowed: false, remaining: 0 };
  }

  bucket.tokens -= cost;
  buckets.set(key, bucket);
  return { allowed: true, remaining: bucket.tokens };
}

