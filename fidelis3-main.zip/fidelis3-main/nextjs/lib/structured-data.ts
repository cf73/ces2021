/**
 * Structured Data (JSON-LD) Utilities for SEO
 * Generates schema.org markup for better search engine understanding
 */

import type { Product, Manufacturer, News, PreOwned, BusinessInfo } from './supabase';

/**
 * Organization Schema - For homepage and sitewide
 */
const formatPhoneForSchema = (phone?: string) => {
  if (!phone) return '+1-603-880-4434';
  const digits = phone.replace(/\D/g, '');
  if (digits.length === 10) {
    return `+1-${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6)}`;
  }
  return `+1-${digits}`;
};

export function generateOrganizationSchema(businessInfo?: BusinessInfo | null) {
  const phone = formatPhoneForSchema(businessInfo?.phone);
  const email = businessInfo?.email || 'info@fidelisav.com';
  const streetAddress = businessInfo?.address_line1 || '460 Amherst St';
  const locality = businessInfo?.city || 'Nashua';
  const region = businessInfo?.state || 'NH';
  const postalCode = businessInfo?.postal_code || '03063';
  return {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    '@id': 'https://fidelisav.com/#organization',
    name: businessInfo?.company_name || 'Fidelis AV',
    alternateName: 'Fidelis Home Audio',
    description:
      businessInfo?.short_description ||
      'High-end audio equipment dealer in Nashua, NH. Six decades of experience in curating premium audio systems.',
    url: 'https://fidelisav.com',
    telephone: phone,
    email,
    address: {
      '@type': 'PostalAddress',
      streetAddress,
      addressLocality: locality,
      addressRegion: region,
      postalCode,
      addressCountry: 'US'
    },
    geo: {
      '@type': 'GeoCoordinates',
      latitude: 42.7654,
      longitude: -71.4676
    },
    priceRange: '$$$',
    openingHoursSpecification: [
      {
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: ['Tuesday', 'Wednesday', 'Thursday', 'Friday'],
        opens: '10:00',
        closes: '18:00'
      },
      {
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: 'Saturday',
        opens: '10:00',
        closes: '17:00'
      }
    ],
    sameAs: [
      'https://www.google.com/maps/place/Fidelis+Home+Audio'
    ]
  };
}

/**
 * Product Schema - For product detail pages
 */
export function generateProductSchema(product: Product, manufacturer?: Manufacturer) {
  const schema: any = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    '@id': `https://fidelisav.com/products/${product.slug}#product`,
    name: product.title,
    description: product.brief_description || product.content?.substring(0, 200) || '',
    brand: manufacturer ? {
      '@type': 'Brand',
      name: manufacturer.name
    } : undefined,
    offers: product.price ? {
      '@type': 'Offer',
      priceCurrency: 'USD',
      price: product.price,
      availability: 'https://schema.org/InStock',
      seller: {
        '@type': 'Organization',
        name: 'Fidelis AV'
      }
    } : undefined,
    image: product.product_hero_image ? [product.product_hero_image] : undefined,
    url: `https://fidelisav.com/products/${product.slug}`
  };

  // Clean up undefined values
  Object.keys(schema).forEach(key => schema[key] === undefined && delete schema[key]);
  
  return schema;
}

/**
 * Article Schema - For news pages
 */
export function generateArticleSchema(article: News) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Article',
    '@id': `https://fidelisav.com/news/${article.slug}#article`,
    headline: article.title,
    description: article.summary || article.brief_description || '',
    image: article.image || undefined,
    datePublished: article.news_date || article.created_at,
    dateModified: article.updated_at,
    author: {
      '@type': 'Organization',
      name: 'Fidelis AV'
    },
    publisher: {
      '@type': 'Organization',
      name: 'Fidelis AV',
      logo: {
        '@type': 'ImageObject',
        url: 'https://fidelisav.com/logo512.png'
      }
    },
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': `https://fidelisav.com/news/${article.slug}`
    }
  };
}

/**
 * PreOwned Product Schema
 */
export function generatePreOwnedProductSchema(item: PreOwned) {
  const schema: any = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    '@id': `https://fidelisav.com/pre-owned/${item.slug || item.id}#product`,
    name: item.title,
    description: item.description || '',
    offers: item.your_price && !item.hide_your_price ? {
      '@type': 'Offer',
      priceCurrency: 'USD',
      price: item.your_price,
      availability: 'https://schema.org/InStock',
      itemCondition: 'https://schema.org/UsedCondition',
      seller: {
        '@type': 'Organization',
        name: 'Fidelis AV'
      }
    } : undefined,
    image: item.images && item.images.length > 0 ? item.images : undefined,
    url: `https://fidelisav.com/pre-owned/${item.slug || item.id}`
  };

  // Clean up undefined values
  Object.keys(schema).forEach(key => schema[key] === undefined && delete schema[key]);
  
  return schema;
}

/**
 * Breadcrumb Schema - For navigation
 */
export function generateBreadcrumbSchema(items: Array<{ name: string; url: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.url
    }))
  };
}

/**
 * Manufacturer/Brand Schema
 */
export function generateBrandSchema(manufacturer: Manufacturer) {
  const schema: any = {
    '@context': 'https://schema.org',
    '@type': 'Brand',
    '@id': `https://fidelisav.com/manufacturers/${manufacturer.slug}#brand`,
    name: manufacturer.name,
    description: manufacturer.description || undefined,
    logo: manufacturer.logo || undefined,
    url: manufacturer.website || `https://fidelisav.com/manufacturers/${manufacturer.slug}`
  };

  // Clean up undefined values
  Object.keys(schema).forEach(key => schema[key] === undefined && delete schema[key]);
  
  return schema;
}

/**
 * WebSite Schema - For homepage search functionality
 */
export function generateWebSiteSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    '@id': 'https://fidelisav.com/#website',
    name: 'Fidelis AV',
    url: 'https://fidelisav.com',
    potentialAction: {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: 'https://fidelisav.com/products/list?search={search_term_string}'
      },
      'query-input': 'required name=search_term_string'
    }
  };
}

