/**
 * HTML Sanitization Utility
 * Uses DOMPurify to sanitize HTML content to prevent XSS attacks
 */

import DOMPurify from 'isomorphic-dompurify';

/**
 * Sanitize HTML content to prevent XSS attacks
 * @param dirty - The HTML string to sanitize
 * @returns Sanitized HTML string
 */
export function sanitizeHTML(dirty: string): string {
  if (!dirty) return '';
  
  const config = {
    // Allow common HTML tags
    ALLOWED_TAGS: [
      'p', 'br', 'strong', 'em', 'u', 's', 'a', 'ul', 'ol', 'li',
      'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 'code', 'pre',
      'img', 'div', 'span'
    ],
    // Allow common attributes
    ALLOWED_ATTR: [
      'href', 'title', 'target', 'rel', 'class', 'id',
      'src', 'alt', 'width', 'height'
    ],
    // Force all links to open in new tab with noopener noreferrer
    ALLOW_DATA_ATTR: false,
    // Keep spaces in tags
    KEEP_CONTENT: true,
  };

  // Sanitize the HTML
  let clean = DOMPurify.sanitize(dirty, config);
  
  // Ensure all external links have proper security attributes
  clean = clean.replace(
    /<a\s+([^>]*href=["'][^"']*["'][^>]*)>/gi,
    (match, attrs) => {
      // Check if it already has rel attribute
      if (!/rel=/i.test(attrs)) {
        return `<a ${attrs} rel="noopener noreferrer">`;
      } else if (!/noopener|noreferrer/i.test(attrs)) {
        // Add noopener noreferrer to existing rel
        return match.replace(/rel=["']([^"']*)["']/i, 'rel="$1 noopener noreferrer"');
      }
      return match;
    }
  );
  
  return clean;
}

/**
 * Sanitize plain text to prevent any HTML injection
 * @param text - The text to sanitize
 * @returns Escaped text safe for display
 */
export function sanitizeText(text: string): string {
  if (!text) return '';
  
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

/**
 * Validate file upload types
 * @param file - The file to validate
 * @param allowedTypes - Array of allowed MIME types
 * @returns Whether the file type is allowed
 */
export function validateFileType(file: File, allowedTypes: string[]): boolean {
  return allowedTypes.includes(file.type);
}

/**
 * Validate file size
 * @param file - The file to validate
 * @param maxSizeMB - Maximum file size in megabytes
 * @returns Whether the file size is within limits
 */
export function validateFileSize(file: File, maxSizeMB: number): boolean {
  const maxSizeBytes = maxSizeMB * 1024 * 1024;
  return file.size <= maxSizeBytes;
}

/**
 * Allowed image types for upload
 */
export const ALLOWED_IMAGE_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/gif',
  'image/webp',
  'image/avif'
];

/**
 * Maximum image file size in MB
 */
export const MAX_IMAGE_SIZE_MB = 10;

