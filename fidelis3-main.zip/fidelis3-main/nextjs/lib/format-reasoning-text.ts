/**
 * Utility to parse AI-generated reasoning text into structured format
 * for better readability and scannability
 */

export interface FormattedReasoning {
  sentences: string[];
  hasMultiplePoints: boolean;
}

/**
 * Parses reasoning text into structured format
 * - Splits on sentence boundaries (periods followed by space)
 * - Preserves product names and technical terms
 * - Handles edge cases (short text, already formatted, etc.)
 */
export function formatReasoningText(reasoning: string): FormattedReasoning {
  if (!reasoning || reasoning.trim().length === 0) {
    return { sentences: [], hasMultiplePoints: false };
  }

  // Clean up the text
  let cleaned = reasoning.trim();

  // Split on sentence boundaries (period, exclamation, question mark followed by space)
  // But preserve common abbreviations and decimal numbers
  const sentenceEndings = /([.!?])\s+(?=[A-Z])/g;
  
  // Split into sentences
  const sentences: string[] = [];
  let lastIndex = 0;
  let match;

  // First, try to split on sentence boundaries
  while ((match = sentenceEndings.exec(cleaned)) !== null) {
    const sentence = cleaned.substring(lastIndex, match.index + 1).trim();
    if (sentence.length > 0) {
      sentences.push(sentence);
    }
    lastIndex = match.index + match[0].length;
  }

  // Add the last sentence
  const lastSentence = cleaned.substring(lastIndex).trim();
  if (lastSentence.length > 0) {
    sentences.push(lastSentence);
  }

  // If we didn't find sentence boundaries, try splitting on commas for very long sentences
  if (sentences.length === 1 && sentences[0].length > 200) {
    const longSentence = sentences[0];
    // Split on commas, but only if the resulting parts are substantial
    const commaParts = longSentence.split(/,\s+/);
    if (commaParts.length > 2) {
      // Reconstruct sentences from comma parts
      const newSentences: string[] = [];
      let currentSentence = commaParts[0];
      
      for (let i = 1; i < commaParts.length; i++) {
        const part = commaParts[i];
        // If adding this part would make the sentence too long, start a new one
        if (currentSentence.length + part.length > 150 && currentSentence.length > 50) {
          newSentences.push(currentSentence + '.');
          currentSentence = part;
        } else {
          currentSentence += ', ' + part;
        }
      }
      
      if (currentSentence.length > 0) {
        newSentences.push(currentSentence);
      }
      
      if (newSentences.length > 1) {
        sentences.length = 0;
        sentences.push(...newSentences);
      }
    }
  }

  // Filter out very short sentences (likely artifacts)
  const validSentences = sentences.filter(s => s.length > 10);

  // If we still only have one sentence, return it as-is
  if (validSentences.length <= 1) {
    return {
      sentences: validSentences.length > 0 ? validSentences : [cleaned],
      hasMultiplePoints: false,
    };
  }

  return {
    sentences: validSentences,
    hasMultiplePoints: true,
  };
}



