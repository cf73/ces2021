import { supabase } from './supabase-client';
import { supabaseAdmin } from './supabase-server-admin';
import { generateProductSuggestions } from './ai-suggestions';
import { searchForProductQuote } from './web-search-quotes';
import type { Product } from './supabase';
import { formatReasoningText } from './format-reasoning-text';

const normalizeReasoningForStorage = (text?: string | null): string => {
  if (!text) return '';
  const formatted = formatReasoningText(text);
  if (!formatted.sentences.length) {
    return text.trim();
  }
  return formatted.sentences.join('\n');
};

const sanitizeRelationshipNotes = (
  notes: unknown,
  selectedIds: string[]
): Record<string, string> => {
  if (!notes || typeof notes !== 'object') return {};

  return selectedIds.reduce<Record<string, string>>((acc, id) => {
    const value = (notes as Record<string, unknown>)[id];
    if (typeof value !== 'string') return acc;

    const note = value.replace(/\s+/g, ' ').trim();
    if (!note) return acc;

    acc[id] = note.slice(0, 140);
    return acc;
  }, {});
};

const mergeRelationshipNotes = (
  existingNotes: unknown,
  generatedNotes: unknown,
  selectedIds: string[]
) => sanitizeRelationshipNotes(
  {
    ...(existingNotes && typeof existingNotes === 'object' ? existingNotes : {}),
    ...(generatedNotes && typeof generatedNotes === 'object' ? generatedNotes : {}),
  },
  selectedIds
);

/**
 * Generate AI-powered product relationships if they don't exist
 * This runs server-side when a product page is first rendered
 * Returns true if relationships were generated, false if they already existed
 */
export async function ensureProductRelationships(product: Product, allProducts: Product[]): Promise<boolean> {
  console.log(`🤖 Checking relationships for: ${product.title}`);
  
  const client = supabaseAdmin || supabase;
  
  try {
    // Mark as generating
    await client
      .from('products')
      .update({
        ai_generation_status: 'generating',
        ai_last_generated: new Date().toISOString()
      })
      .eq('id', product.id);
    
    // Search for a quote if product doesn't have one
    let webQuote = null;
    let webQuoteAttribution = null;
    if (!product.quote || product.quote.trim().length === 0) {
      console.log(`🔍 Product has no quote, searching web for reviews...`);
      const quoteResult = await searchForProductQuote(product);
      if (quoteResult.quote && quoteResult.attribution) {
        webQuote = quoteResult.quote;
        webQuoteAttribution = quoteResult.attribution;
        console.log(`✨ Found quote from web: "${webQuote.substring(0, 100)}..."`);
      }
    }
    
    // Generate AI suggestions (includes brief description)
    const suggestions = await generateProductSuggestions({
      currentProduct: product,
      allProducts
    });
    
    // Apply server-side filtering to enforce rules
    // Filter "Also Consider" to strictly enforce 30% price rule
    const filteredAlsoConsider = suggestions.alsoConsider.filter(productId => {
      const suggestedProduct = allProducts.find(p => p.id === productId);
      if (!suggestedProduct || !suggestedProduct.price || !product.price) return false;
      
      const minPrice = product.price * 0.7;
      const maxPrice = product.price * 1.3;
      
      return suggestedProduct.price >= minPrice && suggestedProduct.price <= maxPrice;
    });

    // Check if current product is an electrostatic headphone
    const isElectrostaticHeadphone = 
      product.categories?.name?.toLowerCase().includes('headphone') &&
      (product.title?.toLowerCase().includes('electrostatic') ||
       product.title?.toLowerCase().includes('stax') ||
       product.title?.toLowerCase().includes('sr-') ||
       product.manufacturer?.name?.toLowerCase().includes('stax') ||
       product.brief_description?.toLowerCase().includes('electrostatic') ||
       product.content?.toLowerCase().includes('electrostatic'));

    // Check if current product is an electrostatic speaker
    const isElectrostaticSpeaker = 
      product.categories?.name?.toLowerCase().includes('speaker') &&
      (product.title?.toLowerCase().includes('electrostatic') ||
       product.title?.toLowerCase().includes('esl') ||
       product.title?.toLowerCase().includes('martin logan') ||
       product.title?.toLowerCase().includes('quad') ||
       product.title?.toLowerCase().includes('sound lab') ||
       product.manufacturer?.name?.toLowerCase().includes('martin logan') ||
       product.manufacturer?.name?.toLowerCase().includes('quad') ||
       product.manufacturer?.name?.toLowerCase().includes('sound lab') ||
       product.brief_description?.toLowerCase().includes('electrostatic') ||
       product.content?.toLowerCase().includes('electrostatic'));

    // Check if current product is a planar magnetic speaker (Magnepan)
    const isPlanarMagneticSpeaker = 
      product.categories?.name?.toLowerCase().includes('speaker') &&
      (product.title?.toLowerCase().includes('magnepan') ||
       product.title?.toLowerCase().includes('planar') ||
       product.manufacturer?.name?.toLowerCase().includes('magnepan') ||
       product.brief_description?.toLowerCase().includes('planar') ||
       product.brief_description?.toLowerCase().includes('magnepan') ||
       product.content?.toLowerCase().includes('planar') ||
       product.content?.toLowerCase().includes('magnepan'));

    // Check if current product is a standard integrated amplifier (not high-current)
    const isStandardIntegratedAmp = 
      product.categories?.name?.toLowerCase().includes('integrated') &&
      !product.title?.toLowerCase().includes('high-current') &&
      !product.title?.toLowerCase().includes('high current') &&
      !product.brief_description?.toLowerCase().includes('high-current') &&
      !product.brief_description?.toLowerCase().includes('high current') &&
      !product.brief_description?.toLowerCase().includes('stable into 2 ohms') &&
      !product.brief_description?.toLowerCase().includes('difficult loads') &&
      !product.content?.toLowerCase().includes('high-current') &&
      !product.content?.toLowerCase().includes('high current');

    // Check if current product is a 300B tube amplifier
    const is300BTubeAmp = 
      (product.categories?.name?.toLowerCase().includes('power') || 
       product.categories?.name?.toLowerCase().includes('amplifier')) &&
      (product.title?.toLowerCase().includes('300b') ||
       product.title?.toLowerCase().includes('300 b') ||
       product.brief_description?.toLowerCase().includes('300b') ||
       product.brief_description?.toLowerCase().includes('300 b') ||
       product.brief_description?.toLowerCase().includes('triode') ||
       product.content?.toLowerCase().includes('300b') ||
       product.content?.toLowerCase().includes('300 b') ||
       product.content?.toLowerCase().includes('triode'));

    // Check if current product is a Stenheim/aluminum speaker
    const isStenheimAluminumSpeaker = 
      product.categories?.name?.toLowerCase().includes('speaker') &&
      (product.title?.toLowerCase().includes('stenheim') ||
       product.title?.toLowerCase().includes('alumine') ||
       product.title?.toLowerCase().includes('aluminum') ||
       product.manufacturer?.name?.toLowerCase().includes('stenheim') ||
       product.brief_description?.toLowerCase().includes('stenheim') ||
       product.brief_description?.toLowerCase().includes('aluminum') ||
       product.brief_description?.toLowerCase().includes('alumine') ||
       product.content?.toLowerCase().includes('stenheim') ||
       product.content?.toLowerCase().includes('aluminum') ||
       product.content?.toLowerCase().includes('alumine'));

    // Filter "Good Synergies" to exclude same-category products
    const filteredPairsWellWith = suggestions.pairsWellWith.filter(productId => {
      const suggestedProduct = allProducts.find(p => p.id === productId);
      if (!suggestedProduct) return false;
      
      // Exclude products from the same category (speakers can't pair with speakers, etc.)
      if (suggestedProduct.categories?.id === product.categories?.id) {
        return false;
      }
      
      // Special rule: Integrated amplifiers are standalone - don't pair with preamps or power amps
      if (product.categories?.name?.toLowerCase().includes('integrated') && 
          (suggestedProduct.categories?.name?.toLowerCase().includes('pre') || 
           suggestedProduct.categories?.name?.toLowerCase().includes('power'))) {
        return false;
      }
      
      // CRITICAL: Electrostatic headphones cannot pair with power amps or regular headphone amps
      if (isElectrostaticHeadphone) {
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        const manufacturerName = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        
        // Check if this is an electrostatic amplifier/driver
        // Stax headphone amplifiers are electrostatic-compatible, so include them
        const isElectrostaticAmp = 
          categoryName.includes('electrostatic') ||
          categoryName.includes('driver') ||
          productTitle.includes('electrostatic') ||
          productTitle.includes('driver') ||
          productTitle.includes('stax') ||
          productTitle.includes('srm-') || // Stax amplifier model prefix
          manufacturerName.includes('stax') || // Stax manufacturer = electrostatic-compatible
          productDesc.includes('electrostatic') ||
          productDesc.includes('driver');
        
        // Exclude ALL power amplifiers (unless they're electrostatic)
        if ((categoryName.includes('power') || categoryName.includes('amplifier')) && !isElectrostaticAmp) {
          return false;
        }
        
        // Exclude regular headphone amplifiers UNLESS they're from Stax (which makes electrostatic amps)
        // Stax headphone amplifiers are designed for electrostatic headphones
        if (categoryName.includes('headphone') && categoryName.includes('amplifier')) {
          // Allow Stax headphone amplifiers (they're electrostatic-compatible)
          if (manufacturerName.includes('stax') || productTitle.includes('stax') || productTitle.includes('srm-')) {
            // This is a Stax headphone amp - allow it
            return true;
          }
          // Exclude all other headphone amplifiers (they're incompatible)
          if (!isElectrostaticAmp) {
            return false;
          }
        }
      }
      
      // CRITICAL: Electrostatic speakers cannot pair with standard amplifiers
      if (isElectrostaticSpeaker) {
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        const manufacturerName = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        
        // Check if this is an electrostatic amplifier/driver for speakers
        const isElectrostaticDriver = 
          categoryName.includes('electrostatic') ||
          categoryName.includes('driver') ||
          categoryName.includes('esl') ||
          productTitle.includes('electrostatic') ||
          productTitle.includes('driver') ||
          productTitle.includes('esl') ||
          productTitle.includes('electrostatic amplifier') ||
          productTitle.includes('electrostatic power') ||
          manufacturerName.includes('martin logan') ||
          manufacturerName.includes('quad') ||
          manufacturerName.includes('sound lab') ||
          productDesc.includes('electrostatic') ||
          productDesc.includes('driver') ||
          productDesc.includes('esl');
        
        // Exclude ALL standard amplifiers (power, integrated, etc.) unless they're electrostatic drivers
        if ((categoryName.includes('power') || 
             categoryName.includes('integrated') || 
             categoryName.includes('amplifier')) && !isElectrostaticDriver) {
          return false;
        }
      }
      
      // CRITICAL: Planar magnetic speakers (Magnepan) cannot pair with standard integrated amplifiers
      if (isPlanarMagneticSpeaker) {
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Check if this is a high-current amplifier (required for planar magnetic speakers)
        const isHighCurrentAmp = 
          productTitle.includes('high-current') ||
          productTitle.includes('high current') ||
          productDesc.includes('high-current') ||
          productDesc.includes('high current') ||
          productDesc.includes('stable into 2 ohms') ||
          productDesc.includes('doubles power into 4 ohms') ||
          productDesc.includes('difficult loads') ||
          productDesc.includes('low impedance') ||
          (categoryName.includes('power') && (productDesc.includes('high current') || productDesc.includes('high-current')));
        
        // Exclude standard integrated amplifiers (they cannot drive planar magnetic speakers)
        if (categoryName.includes('integrated') && !isHighCurrentAmp) {
          return false;
        }
        
        // Exclude low-power amplifiers (planar magnetic speakers need high current)
        if (categoryName.includes('amplifier') && !isHighCurrentAmp) {
          // Allow power amplifiers (they're more likely to be high-current), but filter out low-power ones
          if (productDesc.includes('low power') || productDesc.includes('low-power') || 
              productDesc.includes('tube') && !productDesc.includes('high power')) {
            return false;
          }
        }
      }
      
      // CRITICAL: Standard integrated amplifiers cannot drive planar magnetic speakers
      if (isStandardIntegratedAmp) {
        const suggestedTitle = suggestedProduct.title?.toLowerCase() || '';
        const suggestedManufacturer = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        const suggestedDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Check if suggested product is a planar magnetic speaker (Magnepan)
        const isPlanarMagnetic = 
          suggestedProduct.categories?.name?.toLowerCase().includes('speaker') &&
          (suggestedTitle.includes('magnepan') ||
           suggestedTitle.includes('planar') ||
           suggestedManufacturer.includes('magnepan') ||
           suggestedDesc.includes('planar') ||
           suggestedDesc.includes('magnepan'));
        
        // Exclude planar magnetic speakers - standard integrated amps cannot drive them
        if (isPlanarMagnetic) {
          return false;
        }
      }
      
      // CRITICAL: 300B tube amplifiers are for horn speakers only
      if (is300BTubeAmp) {
        const suggestedTitle = suggestedProduct.title?.toLowerCase() || '';
        const suggestedDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Check if suggested product is a horn speaker
        const isHornSpeaker = 
          suggestedProduct.categories?.name?.toLowerCase().includes('speaker') &&
          (suggestedTitle.includes('horn') ||
           suggestedDesc.includes('horn') ||
           suggestedDesc.includes('high efficiency') ||
           (suggestedDesc.includes('efficiency') && (suggestedDesc.includes('95') || suggestedDesc.includes('96') || suggestedDesc.includes('97') || suggestedDesc.includes('98') || suggestedDesc.includes('99') || suggestedDesc.includes('100'))));
        
        // Check if suggested product is a Stenheim/aluminum speaker (incompatible)
        const isStenheimAluminum = 
          suggestedProduct.categories?.name?.toLowerCase().includes('speaker') &&
          (suggestedTitle.includes('stenheim') ||
           suggestedTitle.includes('alumine') ||
           suggestedTitle.includes('aluminum') ||
           suggestedProduct.manufacturer?.name?.toLowerCase().includes('stenheim') ||
           suggestedDesc.includes('stenheim') ||
           suggestedDesc.includes('aluminum') ||
           suggestedDesc.includes('alumine'));
        
        // Only allow horn speakers for 300B tube amplifiers
        if (!isHornSpeaker && suggestedProduct.categories?.name?.toLowerCase().includes('speaker')) {
          return false;
        }
        
        // Explicitly exclude Stenheim/aluminum speakers
        if (isStenheimAluminum) {
          return false;
        }
      }
      
      // CRITICAL: Stenheim/aluminum speakers require high-powered solid-state amplifiers
      if (isStenheimAluminumSpeaker) {
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Check if this is a 300B tube amplifier (incompatible)
        const is300B = 
          productTitle.includes('300b') ||
          productTitle.includes('300 b') ||
          productDesc.includes('300b') ||
          productDesc.includes('300 b') ||
          productDesc.includes('triode');
        
        // Check if this is a high-powered solid-state amplifier
        const isHighPowerSolidState = 
          (categoryName.includes('power') || categoryName.includes('integrated')) &&
          !productDesc.includes('tube') &&
          !productDesc.includes('300b') &&
          !productDesc.includes('300 b') &&
          (productDesc.includes('high power') ||
           productDesc.includes('high-power') ||
           productDesc.includes('100w') ||
           productDesc.includes('200w') ||
           productDesc.includes('300w') ||
           productDesc.includes('solid state') ||
           productDesc.includes('solid-state'));
        
        // Exclude 300B tube amplifiers - Stenheim speakers need solid-state current
        if (is300B) {
          return false;
        }
        
        // Exclude low-power tube amplifiers
        if (categoryName.includes('amplifier') && productDesc.includes('tube') && !isHighPowerSolidState) {
          return false;
        }
        
        // Prefer high-powered solid-state amplifiers
        if (categoryName.includes('amplifier') && !isHighPowerSolidState && !productDesc.includes('solid state') && !productDesc.includes('solid-state')) {
          // Allow if it's clearly a high-power solid-state amp based on power rating
          const hasHighPower = /(100|200|300|400|500)\s*w/i.test(productDesc) || 
                               /(100|200|300|400|500)\s*watts/i.test(productDesc);
          if (!hasHighPower) {
            return false;
          }
        }
      }
      
      return true;
    });
    
    // For electrostatic headphones, prioritize electrostatic amplifiers/drivers
    if (isElectrostaticHeadphone) {
      const electrostaticAmps = filteredPairsWellWith.filter(productId => {
        const suggestedProduct = allProducts.find(p => p.id === productId);
        if (!suggestedProduct) return false;
        
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        const manufacturerName = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        
        // Prioritize electrostatic amps, drivers, and Stax products (all Stax amps are electrostatic-compatible)
        return categoryName.includes('electrostatic') || 
               categoryName.includes('driver') ||
               productTitle.includes('electrostatic') ||
               productTitle.includes('driver') ||
               productTitle.includes('stax') ||
               productTitle.includes('srm-') || // Stax amplifier model prefix
               manufacturerName.includes('stax') || // Stax manufacturer = electrostatic-compatible
               productDesc.includes('electrostatic') ||
               productDesc.includes('driver');
      });
      
      // Move electrostatic amps to the front - they are REQUIRED for electrostatic headphones
      const otherProducts = filteredPairsWellWith.filter(id => !electrostaticAmps.includes(id));
      filteredPairsWellWith.length = 0;
      filteredPairsWellWith.push(...electrostaticAmps, ...otherProducts);
    }
    
    // For electrostatic speakers, prioritize electrostatic amplifiers/drivers
    if (isElectrostaticSpeaker) {
      const electrostaticDrivers = filteredPairsWellWith.filter(productId => {
        const suggestedProduct = allProducts.find(p => p.id === productId);
        if (!suggestedProduct) return false;
        
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        const manufacturerName = suggestedProduct.manufacturer?.name?.toLowerCase() || '';
        
        // Prioritize electrostatic drivers/amplifiers for speakers
        return categoryName.includes('electrostatic') || 
               categoryName.includes('driver') ||
               categoryName.includes('esl') ||
               productTitle.includes('electrostatic') ||
               productTitle.includes('driver') ||
               productTitle.includes('esl') ||
               productTitle.includes('electrostatic amplifier') ||
               productTitle.includes('electrostatic power') ||
               manufacturerName.includes('martin logan') ||
               manufacturerName.includes('quad') ||
               manufacturerName.includes('sound lab') ||
               productDesc.includes('electrostatic') ||
               productDesc.includes('driver') ||
               productDesc.includes('esl');
      });
      
      // Move electrostatic drivers to the front - they are REQUIRED for electrostatic speakers
      const otherProducts = filteredPairsWellWith.filter(id => !electrostaticDrivers.includes(id));
      filteredPairsWellWith.length = 0;
      filteredPairsWellWith.push(...electrostaticDrivers, ...otherProducts);
    }
    
    // For planar magnetic speakers, prioritize high-current amplifiers
    if (isPlanarMagneticSpeaker) {
      const highCurrentAmps = filteredPairsWellWith.filter(productId => {
        const suggestedProduct = allProducts.find(p => p.id === productId);
        if (!suggestedProduct) return false;
        
        const categoryName = suggestedProduct.categories?.name?.toLowerCase() || '';
        const productTitle = suggestedProduct.title?.toLowerCase() || '';
        const productDesc = (suggestedProduct.brief_description || suggestedProduct.content || '').toLowerCase();
        
        // Prioritize high-current amplifiers (required for planar magnetic speakers)
        return (categoryName.includes('power') || categoryName.includes('integrated')) &&
               (productTitle.includes('high-current') ||
                productTitle.includes('high current') ||
                productDesc.includes('high-current') ||
                productDesc.includes('high current') ||
                productDesc.includes('stable into 2 ohms') ||
                productDesc.includes('doubles power into 4 ohms') ||
                productDesc.includes('difficult loads') ||
                productDesc.includes('low impedance'));
      });
      
      // Move high-current amps to the front - they are REQUIRED for planar magnetic speakers
      const otherProducts = filteredPairsWellWith.filter(id => !highCurrentAmps.includes(id));
      filteredPairsWellWith.length = 0;
      filteredPairsWellWith.push(...highCurrentAmps, ...otherProducts);
    }

    console.log(`🔍 Filtering results for ${product.title}:`, {
      originalPairs: suggestions.pairsWellWith.length,
      filteredPairs: filteredPairsWellWith.length,
      originalAlso: suggestions.alsoConsider.length,
      filteredAlso: filteredAlsoConsider.length
    });

    // Debug: Log filtered-out products
    if (suggestions.alsoConsider.length > filteredAlsoConsider.length) {
      console.log('⚠️ Some "Also Consider" products were filtered out:');
      suggestions.alsoConsider.forEach(id => {
        if (!filteredAlsoConsider.includes(id)) {
          const suggestedProduct = allProducts.find(p => p.id === id);
          if (!suggestedProduct) {
            console.log(`  ❌ Product ID not found: ${id}`);
          } else if (!suggestedProduct.price || !product.price) {
            console.log(`  ❌ Missing price: ${suggestedProduct.title} (price: ${suggestedProduct.price})`);
          } else {
            const minPrice = product.price * 0.7;
            const maxPrice = product.price * 1.3;
            console.log(`  ❌ Price out of range: ${suggestedProduct.title} ($${suggestedProduct.price}) - range: $${minPrice}-$${maxPrice}`);
          }
        }
      });
    }

    // If products were filtered out, regenerate text to match what's actually shown
    let pairsReasoning = suggestions.pairsReasoning;
    let pairsCTA = suggestions.pairsCTA;
    let pairsHelper = suggestions.pairsHelper;
    let alsoReasoning = suggestions.alsoReasoning;
    let alsoCTA = suggestions.alsoCTA;
    let alsoHelper = suggestions.alsoHelper;
    let pairsNotes = sanitizeRelationshipNotes(suggestions.pairsNotes, filteredPairsWellWith);
    let alsoNotes = sanitizeRelationshipNotes(suggestions.alsoNotes, filteredAlsoConsider);
    
    // Check if filtering removed products - if so, regenerate text
    const pairsFiltered = suggestions.pairsWellWith.length > filteredPairsWellWith.length;
    const alsoFiltered = suggestions.alsoConsider.length > filteredAlsoConsider.length;
    
    if ((pairsFiltered || alsoFiltered) && filteredPairsWellWith.length > 0 || filteredAlsoConsider.length > 0) {
      console.log('🔄 Regenerating text for filtered product lists...');
      
      // Get actual product details for filtered lists
      const filteredPairsProducts = allProducts.filter(p => filteredPairsWellWith.includes(p.id));
      const filteredAlsoProducts = allProducts.filter(p => filteredAlsoConsider.includes(p.id));
      
      // Regenerate with only the products that passed filtering
      const refinedSuggestions = await generateProductSuggestions({
        currentProduct: product,
        allProducts: allProducts,
        // Pass the filtered lists so AI only references these products
        forcedPairsWellWith: filteredPairsWellWith,
        forcedAlsoConsider: filteredAlsoConsider
      });
      
      pairsReasoning = refinedSuggestions.pairsReasoning;
      pairsCTA = refinedSuggestions.pairsCTA;
      pairsHelper = refinedSuggestions.pairsHelper;
      alsoReasoning = refinedSuggestions.alsoReasoning;
      alsoCTA = refinedSuggestions.alsoCTA;
      alsoHelper = refinedSuggestions.alsoHelper;
      pairsNotes = sanitizeRelationshipNotes(refinedSuggestions.pairsNotes, filteredPairsWellWith);
      alsoNotes = sanitizeRelationshipNotes(refinedSuggestions.alsoNotes, filteredAlsoConsider);
    }
    
    // Don't save if all products were filtered out
    if (filteredPairsWellWith.length === 0) {
      pairsReasoning = product.pairs_reasoning || '';
      pairsCTA = product.pairs_cta || '';
      pairsHelper = product.pairs_helper || '';
    }
    if (filteredAlsoConsider.length === 0) {
      alsoReasoning = product.also_reasoning || '';
      alsoCTA = product.also_cta || '';
      alsoHelper = product.also_helper || '';
    }
    
    // Merge with existing relationships (using filtered results)
    const mergedPairs = [
      ...(product.pairs_well_with || []),
      ...filteredPairsWellWith.filter(id => !(product.pairs_well_with || []).includes(id))
    ];
    
    const mergedAlso = [
      ...(product.also_consider || []),
      ...filteredAlsoConsider.filter(id => !(product.also_consider || []).includes(id))
    ];
    const mergedPairsNotes = mergeRelationshipNotes(product.pairs_notes, pairsNotes, mergedPairs);
    const mergedAlsoNotes = mergeRelationshipNotes(product.also_notes, alsoNotes, mergedAlso);
    
    // Only update if we're adding new suggestions or found a quote
    const hasNewSuggestions = 
      mergedPairs.length > (product.pairs_well_with?.length || 0) ||
      mergedAlso.length > (product.also_consider?.length || 0) ||
      (webQuote && webQuoteAttribution);
    
    if (!hasNewSuggestions) {
      console.log(`✅ ${product.title} already has complete relationships and quote`);
      return false;
    }
    
    console.log(`💾 Merging AI suggestions for ${product.title}:`, {
      existingPairs: product.pairs_well_with?.length || 0,
      newPairs: mergedPairs.length,
      existingAlso: product.also_consider?.length || 0,
      newAlso: mergedAlso.length
    });
    
    // Use AI-generated brief description if product doesn't have one
    const briefDescription = product.brief_description || suggestions.briefDescription;
    
    // Prepare update object
    const updateData: any = {
      pairs_well_with: mergedPairs,
      also_consider: mergedAlso,
      pairs_notes: mergedPairsNotes,
      also_notes: mergedAlsoNotes,
      pairs_reasoning: normalizeReasoningForStorage(pairsReasoning),
      pairs_cta: pairsCTA,
      pairs_helper: pairsHelper,
      also_reasoning: normalizeReasoningForStorage(alsoReasoning),
      also_cta: alsoCTA,
      also_helper: alsoHelper,
      brief_description: briefDescription,
      ai_generation_status: 'success',
      ai_generation_error: null
    };
    
    // Add web-sourced quote if found
    if (webQuote && webQuoteAttribution) {
      updateData.quote = webQuote;
      updateData.quote_attribution = webQuoteAttribution;
      console.log(`📝 Adding web-sourced quote to product`);
    }
    
    const { data: updateResult, error} = await client
      .from('products')
      .update(updateData)
      .eq('id', product.id)
      .select();
    
    if (error) {
      console.error(`❌ Error saving relationships for ${product.title}:`, error);
      
      // Mark as failed
      await client
        .from('products')
        .update({
          ai_generation_status: 'failed',
          ai_generation_error: error.message || 'Database update failed'
        })
        .eq('id', product.id);
      
      return false;
    } else {
      console.log(`✅ Merged relationships for ${product.title}`);
      return true;
    }
  } catch (error) {
    console.error(`❌ Error generating relationships for ${product.title}:`, error);
    
    // Mark as failed with error message
    await client
      .from('products')
      .update({
        ai_generation_status: 'failed',
        ai_generation_error: error instanceof Error ? error.message : 'Unknown error during AI generation'
      })
      .eq('id', product.id);
    
    return false;
  }
}

/**
 * Generate AI-powered product relationships without saving to database
 * Returns the generated suggestions that can be applied to local state
 * This is used for preview/dry-run mode where changes are tracked but not saved
 */
export async function generateProductRelationshipsPreview(
  product: Product,
  allProducts: Product[]
): Promise<{
  pairs_well_with: string[];
  also_consider: string[];
  pairs_notes: Record<string, string>;
  also_notes: Record<string, string>;
  pairs_reasoning: string;
  pairs_cta: string;
  pairs_helper: string;
  also_reasoning: string;
  also_cta: string;
  also_helper: string;
  brief_description?: string;
  quote?: string;
  quote_attribution?: string;
} | null> {
  console.log(`🤖 Generating preview relationships for: ${product.title}`);
  
  try {
    // Search for a quote if product doesn't have one
    let webQuote = null;
    let webQuoteAttribution = null;
    if (!product.quote || product.quote.trim().length === 0) {
      console.log(`🔍 Product has no quote, searching web for reviews...`);
      const quoteResult = await searchForProductQuote(product);
      if (quoteResult.quote && quoteResult.attribution) {
        webQuote = quoteResult.quote;
        webQuoteAttribution = quoteResult.attribution;
        console.log(`✨ Found quote from web: "${webQuote.substring(0, 100)}..."`);
      }
    }
    
    // Generate AI suggestions (includes brief description)
    const suggestions = await generateProductSuggestions({
      currentProduct: product,
      allProducts
    });
    
    // Apply server-side filtering to enforce rules (same as ensureProductRelationships)
    const filteredAlsoConsider = suggestions.alsoConsider.filter(productId => {
      const suggestedProduct = allProducts.find(p => p.id === productId);
      if (!suggestedProduct || !suggestedProduct.price || !product.price) return false;
      
      const minPrice = product.price * 0.7;
      const maxPrice = product.price * 1.3;
      
      return suggestedProduct.price >= minPrice && suggestedProduct.price <= maxPrice;
    });

    const filteredPairsWellWith = suggestions.pairsWellWith.filter(productId => {
      const suggestedProduct = allProducts.find(p => p.id === productId);
      if (!suggestedProduct) return false;
      
      if (suggestedProduct.categories?.id === product.categories?.id) {
        return false;
      }
      
      if (product.categories?.name?.toLowerCase().includes('integrated') && 
          (suggestedProduct.categories?.name?.toLowerCase().includes('pre') || 
           suggestedProduct.categories?.name?.toLowerCase().includes('power'))) {
        return false;
      }
      
      return true;
    });

    // Regenerate text if filtering removed products
    let pairsReasoning = suggestions.pairsReasoning;
    let pairsCTA = suggestions.pairsCTA;
    let pairsHelper = suggestions.pairsHelper;
    let alsoReasoning = suggestions.alsoReasoning;
    let alsoCTA = suggestions.alsoCTA;
    let alsoHelper = suggestions.alsoHelper;
    let pairsNotes = sanitizeRelationshipNotes(suggestions.pairsNotes, filteredPairsWellWith);
    let alsoNotes = sanitizeRelationshipNotes(suggestions.alsoNotes, filteredAlsoConsider);
    
    const pairsFiltered = suggestions.pairsWellWith.length > filteredPairsWellWith.length;
    const alsoFiltered = suggestions.alsoConsider.length > filteredAlsoConsider.length;
    
    if ((pairsFiltered || alsoFiltered) && (filteredPairsWellWith.length > 0 || filteredAlsoConsider.length > 0)) {
      console.log('🔄 Regenerating text for filtered product lists...');
      
      const refinedSuggestions = await generateProductSuggestions({
        currentProduct: product,
        allProducts: allProducts,
        forcedPairsWellWith: filteredPairsWellWith,
        forcedAlsoConsider: filteredAlsoConsider
      });
      
      pairsReasoning = refinedSuggestions.pairsReasoning;
      pairsCTA = refinedSuggestions.pairsCTA;
      pairsHelper = refinedSuggestions.pairsHelper;
      alsoReasoning = refinedSuggestions.alsoReasoning;
      alsoCTA = refinedSuggestions.alsoCTA;
      alsoHelper = refinedSuggestions.alsoHelper;
      pairsNotes = sanitizeRelationshipNotes(refinedSuggestions.pairsNotes, filteredPairsWellWith);
      alsoNotes = sanitizeRelationshipNotes(refinedSuggestions.alsoNotes, filteredAlsoConsider);
    }
    
    // Use existing values if all products were filtered out
    if (filteredPairsWellWith.length === 0) {
      pairsReasoning = product.pairs_reasoning || '';
      pairsCTA = product.pairs_cta || '';
      pairsHelper = product.pairs_helper || '';
    }
    if (filteredAlsoConsider.length === 0) {
      alsoReasoning = product.also_reasoning || '';
      alsoCTA = product.also_cta || '';
      alsoHelper = product.also_helper || '';
    }
    
    // Merge with existing relationships
    const mergedPairs = [
      ...(product.pairs_well_with || []),
      ...filteredPairsWellWith.filter(id => !(product.pairs_well_with || []).includes(id))
    ];
    
    const mergedAlso = [
      ...(product.also_consider || []),
      ...filteredAlsoConsider.filter(id => !(product.also_consider || []).includes(id))
    ];
    const mergedPairsNotes = mergeRelationshipNotes(product.pairs_notes, pairsNotes, mergedPairs);
    const mergedAlsoNotes = mergeRelationshipNotes(product.also_notes, alsoNotes, mergedAlso);
    
    // Use AI-generated brief description if product doesn't have one
    const briefDescription = product.brief_description || suggestions.briefDescription;
    
    return {
      pairs_well_with: mergedPairs,
      also_consider: mergedAlso,
      pairs_notes: mergedPairsNotes,
      also_notes: mergedAlsoNotes,
      pairs_reasoning: normalizeReasoningForStorage(pairsReasoning),
      pairs_cta: pairsCTA,
      pairs_helper: pairsHelper,
      also_reasoning: normalizeReasoningForStorage(alsoReasoning),
      also_cta: alsoCTA,
      also_helper: alsoHelper,
      brief_description: briefDescription,
      ...(webQuote && webQuoteAttribution ? {
        quote: webQuote,
        quote_attribution: webQuoteAttribution
      } : {})
    };
  } catch (error) {
    console.error(`❌ Error generating preview relationships for ${product.title}:`, error);
    throw error;
  }
}

export async function generateRelationshipCopyForSelections(
  product: Product,
  allProducts: Product[],
  options: {
    pairsSelection?: string[];
    alsoSelection?: string[];
    regeneratePairs?: boolean;
    regenerateAlso?: boolean;
  }
): Promise<{
  pairs_reasoning?: string;
  pairs_cta?: string;
  pairs_helper?: string;
  pairs_notes?: Record<string, string>;
  also_reasoning?: string;
  also_cta?: string;
  also_helper?: string;
  also_notes?: Record<string, string>;
} | null> {
  const { regeneratePairs = true, regenerateAlso = true } = options || {};
  if (!regeneratePairs && !regenerateAlso) {
    return null;
  }

  try {
    const resolvedPairs = (options.pairsSelection && options.pairsSelection.length > 0
      ? options.pairsSelection
      : product.pairs_well_with) || [];
    const resolvedAlso = (options.alsoSelection && options.alsoSelection.length > 0
      ? options.alsoSelection
      : product.also_consider) || [];

    const suggestions = await generateProductSuggestions({
      currentProduct: product,
      allProducts,
      forcedPairsWellWith: resolvedPairs,
      forcedAlsoConsider: resolvedAlso
    });
    const pairsNotes = sanitizeRelationshipNotes(suggestions.pairsNotes, resolvedPairs);
    const alsoNotes = sanitizeRelationshipNotes(suggestions.alsoNotes, resolvedAlso);

    console.log('📝 Relationship card notes generated:', {
      pairs: Object.keys(pairsNotes).length,
      also: Object.keys(alsoNotes).length
    });

    return {
      ...(regeneratePairs
        ? {
            pairs_reasoning: normalizeReasoningForStorage(suggestions.pairsReasoning || ''),
            pairs_cta: suggestions.pairsCTA || '',
            pairs_helper: suggestions.pairsHelper || '',
            pairs_notes: pairsNotes
          }
        : {}),
      ...(regenerateAlso
        ? {
            also_reasoning: normalizeReasoningForStorage(suggestions.alsoReasoning || ''),
            also_cta: suggestions.alsoCTA || '',
            also_helper: suggestions.alsoHelper || '',
            also_notes: alsoNotes
          }
        : {})
    };
  } catch (error) {
    console.error(
      `❌ Error generating relationship copy for ${product.title}:`,
      error
    );
    return null;
  }
}

