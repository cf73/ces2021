import { NextResponse } from 'next/server';
import type { User } from '@supabase/supabase-js';
import supabaseAdmin from './supabase-server-admin';

type AdminCheckResult =
  | { user: User }
  | { response: NextResponse };

const parseAdminEmails = () => {
  const raw = process.env.ADMIN_EMAILS || '';
  return new Set(
    raw
      .split(',')
      .map(email => email.trim().toLowerCase())
      .filter(Boolean)
  );
};

export const requireAdmin = async (request: Request): Promise<AdminCheckResult> => {
  if (!supabaseAdmin) {
    return {
      response: NextResponse.json(
        { error: 'Supabase admin client not configured' },
        { status: 500 }
      )
    };
  }

  const authHeader = request.headers.get('authorization') || '';
  const token = authHeader.startsWith('Bearer ')
    ? authHeader.slice('Bearer '.length)
    : authHeader;

  if (!token) {
    return {
      response: NextResponse.json(
        { error: 'Authorization token required' },
        { status: 401 }
      )
    };
  }

  const { data, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !data?.user) {
    return {
      response: NextResponse.json(
        { error: 'Invalid or expired session' },
        { status: 401 }
      )
    };
  }

  const adminEmails = parseAdminEmails();
  const userEmail = data.user.email?.toLowerCase();

  if (!adminEmails.size || !userEmail || !adminEmails.has(userEmail)) {
    return {
      response: NextResponse.json(
        { error: 'Admin access required' },
        { status: 403 }
      )
    };
  }

  return { user: data.user };
};
