export const DEFAULT_ANTHROPIC_MODEL =
  process.env.ANTHROPIC_MODEL || 'claude-opus-4-8';

/** Full product copy generation (Flesh Out, batch relationships). */
export const DEFAULT_ANTHROPIC_MAX_TOKENS = Number(
  process.env.ANTHROPIC_MAX_TOKENS || 8192
);

/** Short structured classification responses. */
export const ANTHROPIC_CLASSIFICATION_MAX_TOKENS = Number(
  process.env.ANTHROPIC_CLASSIFICATION_MAX_TOKENS || 1024
);

/** Quote extraction from web search results. */
export const ANTHROPIC_QUOTE_MAX_TOKENS = Number(
  process.env.ANTHROPIC_QUOTE_MAX_TOKENS || 2048
);

export function extractToolUseInput<T>(
  content: Array<{ type: string; name?: string; input?: unknown }>,
  toolName: string
): T | null {
  const block = content.find(
    item => item.type === 'tool_use' && item.name === toolName
  );
  return block?.input ? (block.input as T) : null;
}

export function parseModelJsonResponse<T>(responseText: string): T {
  const fenced = responseText.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const raw = fenced?.[1]?.trim() || responseText.trim();
  const jsonMatch = raw.match(/\{[\s\S]*\}/);

  if (!jsonMatch) {
    throw new SyntaxError('AI response did not include JSON.');
  }

  const cleanedJson = jsonMatch[0]
    .replace(/\/\/.*$/gm, '')
    .replace(/,(\s*[}\]])/g, '$1');

  try {
    return JSON.parse(cleanedJson) as T;
  } catch (error) {
    const preview = cleanedJson.slice(0, 240).replace(/\s+/g, ' ');
    throw new SyntaxError(
      `AI returned invalid JSON (${error instanceof Error ? error.message : 'parse error'}). Preview: ${preview}...`
    );
  }
}

export function formatAnthropicError(error: unknown): string {
  if (!(error instanceof Error)) {
    return 'Error generating suggestions. Please try again.';
  }

  if (error instanceof SyntaxError || error.message.includes('invalid JSON')) {
    return 'AI returned malformed JSON. Please try Flesh Out again.';
  }

  let apiMessage = error.message;

  try {
    const jsonMatch = error.message.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      apiMessage = parsed.error?.message || apiMessage;
    }
  } catch {
    // Keep the original message if parsing fails.
  }

  if (error.message.includes('credit balance') || apiMessage.includes('credit balance')) {
    return 'Anthropic API credit balance too low. Please add credits at https://console.anthropic.com/settings/billing';
  }

  if (
    error.message.includes('not_found_error') ||
    apiMessage.startsWith('model:')
  ) {
    return `Anthropic model unavailable (${apiMessage}). Set ANTHROPIC_MODEL to a current model ID.`;
  }

  if (error.message.includes('rate_limit') || error.message.includes('429')) {
    return 'API rate limit exceeded. Please wait a moment and try again.';
  }

  if (error.message.includes('truncated')) {
    return error.message;
  }

  return apiMessage;
}
