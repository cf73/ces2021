import { supabase } from './supabase-client';
import type { SupabaseClient } from '@supabase/supabase-js';
import type {
  Product,
  ProductCategory,
  Manufacturer,
  News,
  PreOwned,
  Testimonial,
  EvergreenCarousel,
  HomeHeroImage,
  BusinessInfo,
  StoreHourEntry,
} from './supabase';

// Authentication functions
export const signIn = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
};

export const signUp = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });
  return { data, error };
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const getCurrentUser = async () => {
  const { data: { user }, error } = await supabase.auth.getUser();
  return { user, error };
};

export const onAuthStateChange = (callback: (user: any) => void) => {
  return supabase.auth.onAuthStateChange((event, session) => {
    callback(session?.user || null);
  });
};

// Product functions
export const getProducts = async (): Promise<Product[]> => {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('published', true)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching products:', error);
    return [];
  }

  return data || [];
};

export const getProductsWithCategories = async (includeUnpublished = false): Promise<Product[]> => {
  let query = supabase
    .from('products')
    .select(`
      *,
      categories:product_categories!products_category_id_fkey(id, name, slug),
      manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
    `)
    .order('created_at', { ascending: false });

  if (!includeUnpublished) {
    query = query.eq('published', true);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching products with categories:', error);
    return [];
  }

  return data || [];
};

export const getProductBySlug = async (slug: string, includeUnpublished = false): Promise<Product | null> => {
  let query = supabase
    .from('products')
    .select(`
      *,
      categories:product_categories!products_category_id_fkey(id, name, slug),
      manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
    `)
    .eq('slug', slug)
    .limit(1);
  
  if (!includeUnpublished) {
    query = query.eq('published', true);
  }
  
  const { data, error } = await query.maybeSingle();

  if (error) {
    console.error('Error fetching product:', error);
    return null;
  }

  return data;
};

export const getProductsByIds = async (productIds: string[]): Promise<Product[]> => {
  if (!productIds || productIds.length === 0) {
    return [];
  }

  // Filter out invalid UUIDs (AI sometimes generates product codes instead of UUIDs)
  const validUuids = productIds.filter(id => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return uuidRegex.test(id);
  });

  if (validUuids.length === 0) {
    console.log('⚠️ No valid UUIDs found in product IDs:', productIds);
    return [];
  }

  console.log('🔍 Fetching products by IDs:', validUuids);

  const { data, error } = await supabase
    .from('products')
    .select(`
      *,
      categories:product_categories!products_category_id_fkey(id, name, slug),
      manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
    `)
    .in('id', validUuids)
    .eq('published', true);

  if (error) {
    console.error('Error fetching products by IDs:', error);
    console.error('Valid UUIDs that failed:', validUuids);
    return [];
  }

  console.log('✅ Found products:', data?.length || 0, 'out of', validUuids.length, 'valid UUIDs');
  
  // Sort results to match the order of the input productIds array
  // This ensures products appear in the same order they're referenced in AI reasoning
  if (data) {
    const sortedData = validUuids
      .map(id => data.find(product => product.id === id))
      .filter((product): product is Product => product !== undefined);
    return sortedData;
  }
  
  return [];
};

export const searchProducts = async (query: string): Promise<Product[]> => {
  if (!query || query.length < 2) {
    return [];
  }

  // First, find manufacturers that match the query
  const { data: matchingManufacturers } = await supabase
    .from('manufacturers')
    .select('id')
    .ilike('name', `%${query}%`);

  const manufacturerIds = matchingManufacturers?.map(m => m.id) || [];

  // Build the query
  let productsQuery = supabase
    .from('products')
    .select(`
      *,
      categories:product_categories!products_category_id_fkey(id, name, slug),
      manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
    `)
    .eq('published', true);

  // Search by title OR manufacturer_id (if we found matching manufacturers)
  if (manufacturerIds.length > 0) {
    productsQuery = productsQuery.or(`title.ilike.%${query}%,manufacturer_id.in.(${manufacturerIds.join(',')})`);
  } else {
    productsQuery = productsQuery.ilike('title', `%${query}%`);
  }

  const { data, error } = await productsQuery.limit(10);

  if (error) {
    console.error('Error searching products:', error);
    return [];
  }

  return data || [];
};

// Search interface for unified search results
export interface SearchResult {
  id: string;
  type: 'product' | 'news' | 'pre-owned' | 'manufacturer';
  title: string;
  description?: string;
  image?: string;
  slug: string;
  url: string;
}

const createSearchSnippet = (text?: string | null, maxLength = 140): string => {
  if (!text) return '';
  const cleaned = normalizeTextForMentions(text);
  if (cleaned.length <= maxLength) {
    return cleaned;
  }
  return `${cleaned.slice(0, maxLength).trim()}…`;
};

// Individual search functions for each content type
const searchNews = async (query: string): Promise<News[]> => {
  const { data, error } = await supabase
    .from('news')
    .select('*')
    .eq('published', true)
    .ilike('title', `%${query}%`)
    .order('news_date', { ascending: false })
    .limit(5);

  if (error) {
    console.error('Error searching news:', error);
    return [];
  }

  return data || [];
};

const searchPreOwned = async (query: string): Promise<PreOwned[]> => {
  const { data, error } = await supabase
    .from('pre_owned')
    .select('*')
    .eq('published', true)
    .or(`title.ilike.%${query}%,description.ilike.%${query}%`)
    .order('updated_at', { ascending: false })
    .limit(5);

  if (error) {
    console.error('Error searching pre-owned:', error);
    return [];
  }

  return data || [];
};

const searchManufacturers = async (query: string): Promise<Manufacturer[]> => {
  let baseQuery = supabase
    .from('manufacturers')
    .select('*')
    .ilike('name', `%${query}%`)
    .order('name')
    .limit(5);

  baseQuery = baseQuery.eq('published', true);

  const { data, error } = await baseQuery;

  if (error) {
    const missingColumn = error.message?.toLowerCase().includes('published');
    if (missingColumn) {
      console.warn(
        'Published column missing on manufacturers table while searching. Falling back to legacy query.'
      );
      const { data: legacyData, error: legacyError } = await supabase
        .from('manufacturers')
        .select('*')
        .ilike('name', `%${query}%`)
        .order('name')
        .limit(5);
      if (legacyError) {
        console.error('Error searching manufacturers:', legacyError);
        return [];
      }
      return legacyData || [];
    }

    console.error('Error searching manufacturers:', error);
    return [];
  }

  return data || [];
};

// Unified search function across all content types
export const searchAll = async (query: string): Promise<SearchResult[]> => {
  if (!query || query.length < 2) {
    return [];
  }

  // Perform parallel queries across all content types
  const [products, news, preOwned, manufacturers] = await Promise.all([
    searchProducts(query),
    searchNews(query),
    searchPreOwned(query),
    searchManufacturers(query)
  ]);

  // Transform and combine results
  const results: SearchResult[] = [
    ...products.map(p => ({
      id: p.id,
      type: 'product' as const,
      title: p.title,
      description: createSearchSnippet(p.brief_description || p.content || ''),
      image: p.product_hero_image,
      slug: p.slug,
      url: `/products/${p.slug}`
    })),
    ...news.map(n => ({
      id: n.id,
      type: 'news' as const,
      title: n.title,
      description: createSearchSnippet(n.summary || n.brief_description || n.main_content || n.content || ''),
      image: n.image,
      slug: n.slug,
      url: `/news/${n.slug}`
    })),
    ...preOwned.map(po => ({
      id: po.id,
      type: 'pre-owned' as const,
      title: po.title,
      description: createSearchSnippet(po.description),
      image: po.images?.[0],
      slug: po.slug,
      url: `/pre-owned/${po.slug}`
    })),
    ...manufacturers.map(m => ({
      id: m.id,
      type: 'manufacturer' as const,
      title: m.name,
      description: createSearchSnippet(m.description),
      image: m.logo,
      slug: m.slug,
      url: `/manufacturers/${m.slug}`
    }))
  ];

  return results;
};

export const getProductById = async (productId: string): Promise<Product | null> => {
  const { data, error } = await supabase
    .from('products')
    .select(`
      *,
      categories:product_categories!products_category_id_fkey(id, name, slug),
      manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
    `)
    .eq('id', productId)
    .single();

  if (error) {
    console.error('Error fetching product by ID:', error);
    return null;
  }

  return data;
};

// Category functions
export const getProductCategories = async (): Promise<ProductCategory[]> => {
  const { data, error } = await supabase
    .from('product_categories')
    .select('*')
    .order('name');

  if (error) {
    console.error('Error fetching product categories:', error);
    return [];
  }

  return data || [];
};

export const updateCategoryHeroProduct = async (categoryId: string, productId: string | null) => {
  const { data, error } = await supabase
    .from('product_categories')
    .update({ hero_product_id: productId })
    .eq('id', categoryId)
    .select()
    .single();

  if (error) {
    console.error('Error updating category hero product:', error);
    throw error;
  }

  return data;
};

// Manufacturer functions
export const getManufacturers = async (includeUnpublished = false): Promise<Manufacturer[]> => {
  let query = supabase
    .from('manufacturers')
    .select('*')
    .order('name');

  if (!includeUnpublished) {
    query = query.eq('published', true);
  }

  const { data, error } = await query;

  if (error) {
    // If the published column doesn't exist yet (migration not run), fall back to legacy behavior
    const missingColumn = error.message?.toLowerCase().includes('published');
    if (missingColumn) {
      console.warn('Published column missing on manufacturers table. Falling back to legacy fetch. Run the latest migration to enable publishing controls.');
      const { data: legacyData, error: legacyError } = await supabase
        .from('manufacturers')
        .select('*')
        .order('name');
      if (legacyError) {
        console.error('Error fetching manufacturers:', legacyError);
        return [];
      }
      return legacyData || [];
    }

    console.error('Error fetching manufacturers:', error);
    return [];
  }

  return data || [];
};

export const getManufacturerBySlug = async (slug: string, includeUnpublished = false): Promise<Manufacturer | null> => {
  let query = supabase
    .from('manufacturers')
    .select('*')
    .eq('slug', slug);

  if (!includeUnpublished) {
    query = query.eq('published', true);
  }

  const { data, error } = await query.single();

  if (error) {
    const missingColumn = error.message?.toLowerCase().includes('published');
    if (missingColumn) {
      console.warn('Published column missing on manufacturers table. Falling back to legacy fetch. Run the latest migration to enable publishing controls.');
      const { data: legacyData, error: legacyError } = await supabase
    .from('manufacturers')
    .select('*')
    .eq('slug', slug)
    .single();
      if (legacyError) {
        console.error('Error fetching manufacturer:', legacyError);
        return null;
      }
      return legacyData;
    }

    console.error('Error fetching manufacturer:', error);
    return null;
  }

  return data;
};

// Manufacturer-Category relationship functions
export const getCategoriesForManufacturer = async (manufacturerId: string): Promise<ProductCategory[]> => {
  const { data, error } = await supabase
    .from('manufacturer_categories')
    .select('category_id, product_categories!inner(id, name, slug)')
    .eq('manufacturer_id', manufacturerId);
  
  if (error) {
    console.error('Error fetching categories for manufacturer:', error);
    return [];
  }
  
  return data?.flatMap(d => d.product_categories || []) || [];
};

export const getManufacturersForCategory = async (categoryId: string): Promise<Manufacturer[]> => {
  const { data, error } = await supabase
    .from('manufacturer_categories')
    .select('manufacturer_id, manufacturers!inner(id, name, slug)')
    .eq('category_id', categoryId);
  
  if (error) {
    console.error('Error fetching manufacturers for category:', error);
    return [];
  }
  
  return data?.flatMap(d => d.manufacturers || []) || [];
};

export const addCategoryToManufacturer = async (
  manufacturerId: string, 
  categoryId: string
): Promise<void> => {
  const { error } = await supabase
    .from('manufacturer_categories')
    .insert({ manufacturer_id: manufacturerId, category_id: categoryId });
  
  if (error) {
    console.error('Error adding category to manufacturer:', error);
    throw error;
  }
};

// Get all manufacturer-category relationships for instant filtering
export const getAllManufacturerCategoryRelationships = async (): Promise<Map<string, Set<string>>> => {
  const { data, error } = await supabase
    .from('manufacturer_categories')
    .select('manufacturer_id, category_id');
  
  if (error) {
    console.error('Error fetching relationships:', error);
    return new Map();
  }
  
  const relationshipMap = new Map<string, Set<string>>();
  
  data?.forEach(rel => {
    // Map manufacturer_id -> Set of category_ids
    if (!relationshipMap.has(rel.manufacturer_id)) {
      relationshipMap.set(rel.manufacturer_id, new Set());
    }
    relationshipMap.get(rel.manufacturer_id)!.add(rel.category_id);
    
    // Also map category_id -> Set of manufacturer_ids (for bidirectional lookup)
    const reverseKey = `cat_${rel.category_id}`;
    if (!relationshipMap.has(reverseKey)) {
      relationshipMap.set(reverseKey, new Set());
    }
    relationshipMap.get(reverseKey)!.add(rel.manufacturer_id);
  });
  
  return relationshipMap;
};

// Batch add multiple categories to a manufacturer
export const addMultipleCategoriesToManufacturer = async (
  manufacturerId: string,
  categoryIds: string[]
): Promise<void> => {
  const inserts = categoryIds.map(categoryId => ({
    manufacturer_id: manufacturerId,
    category_id: categoryId
  }));
  
  const { error } = await supabase
    .from('manufacturer_categories')
    .insert(inserts);
  
  if (error) {
    console.error('Error adding multiple categories to manufacturer:', error);
    throw error;
  }
};

// Batch add multiple manufacturers to a category
export const addMultipleManufacturersToCategory = async (
  categoryId: string,
  manufacturerIds: string[]
): Promise<void> => {
  const inserts = manufacturerIds.map(manufacturerId => ({
    manufacturer_id: manufacturerId,
    category_id: categoryId
  }));
  
  const { error } = await supabase
    .from('manufacturer_categories')
    .insert(inserts);
  
  if (error) {
    console.error('Error adding multiple manufacturers to category:', error);
    throw error;
  }
};

// Helper function to generate slug from name
const generateSlug = (name: string): string => {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '') // Remove special characters
    .replace(/\s+/g, '-')      // Replace spaces with hyphens
    .replace(/-+/g, '-');       // Replace multiple hyphens with single hyphen
};

// Create new category
export const createNewCategory = async (name: string): Promise<ProductCategory> => {
  const slug = generateSlug(name);
  
  // Check if category with this name or slug already exists
  const { data: existing } = await supabase
    .from('product_categories')
    .select('id, name, slug')
    .or(`name.eq.${name},slug.eq.${slug}`)
    .single();
  
  if (existing) {
    // Return existing category instead of creating duplicate
    return existing;
  }
  
  const { data, error } = await supabase
    .from('product_categories')
    .insert({ name, slug })
    .select()
    .single();
  
  if (error) {
    console.error('Error creating new category:', error);
    throw error;
  }
  
  return data;
};

// Create new manufacturer
export const createNewManufacturer = async (name: string): Promise<Manufacturer> => {
  const slug = generateSlug(name);
  
  // Check if manufacturer with this name or slug already exists
  const { data: existing } = await supabase
    .from('manufacturers')
    .select('id, name, slug')
    .or(`name.eq.${name},slug.eq.${slug}`)
    .single();
  
  if (existing) {
    // Return existing manufacturer instead of creating duplicate
    return existing;
  }
  
  const { data, error } = await supabase
    .from('manufacturers')
    .insert({ name, slug })
    .select()
    .single();
  
  if (error) {
    console.error('Error creating new manufacturer:', error);
    throw error;
  }
  
  return data;
};

// News functions
export const getNews = async (): Promise<News[]> => {
  const { data, error } = await supabase
    .from('news')
    .select('*')
    .eq('published', true)
    .order('news_date', { ascending: false })
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching news:', error);
    return [];
  }

  return data || [];
};

export const getNewsBySlug = async (slug: string): Promise<News | null> => {
  // Try to find published by slug
  let { data, error } = await supabase
    .from('news')
    .select('*')
    .eq('slug', slug)
    .eq('published', true)
    .single();

  // If not found, try by id (published)
  if (error || !data) {
    const { data: dataById } = await supabase
      .from('news')
      .select('*')
      .eq('id', slug)
      .eq('published', true)
      .single();
    if (dataById) return dataById;
  }

  // If still not found, allow draft/unpublished for editors (client-side auth will gate edit tools)
  if (!data) {
    const { data: draftBySlug } = await supabase
      .from('news')
      .select('*')
      .eq('slug', slug)
      .single();
    if (draftBySlug) return draftBySlug;

    const { data: draftById } = await supabase
      .from('news')
      .select('*')
      .eq('id', slug)
      .single();
    if (draftById) return draftById;
  }

  return data;
};

export const getAdjacentNews = async (currentArticleId: string): Promise<{ previous: News | null; next: News | null }> => {
  const { data: allNews, error } = await supabase
    .from('news')
    .select('*')
    .eq('published', true)
    .order('news_date', { ascending: false })
    .order('created_at', { ascending: false });

  if (error || !allNews) {
    console.error('Error fetching news for navigation:', error);
    return { previous: null, next: null };
  }

  const currentIndex = allNews.findIndex(article => article.id === currentArticleId);
  
  if (currentIndex === -1) {
    return { previous: null, next: null };
  }

  const previous = currentIndex < allNews.length - 1 ? allNews[currentIndex + 1] : null;
  const next = currentIndex > 0 ? allNews[currentIndex - 1] : null;

  return { previous, next };
};

// Pre-owned functions
export const getPreOwned = async (includeUnpublished = false): Promise<PreOwned[]> => {
  let query = supabase
    .from('pre_owned')
    .select('*')
    .order('updated_at', { ascending: false });

  if (!includeUnpublished) {
    query = query.eq('published', true);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching pre-owned items:', error);
    return [];
  }

  return data || [];
};

export const getPreOwnedBySlug = async (slug: string, includeUnpublished = false): Promise<PreOwned | null> => {
  // Try to find by slug first
  let query = supabase
    .from('pre_owned')
    .select('*')
    .eq('slug', slug);

  if (!includeUnpublished) {
    query = query.eq('published', true);
  }

  let { data, error } = await query.single();

  // If not found by slug, try by ID as fallback (for legacy URLs or items without slugs)
  if (error) {
    let fallbackQuery = supabase
      .from('pre_owned')
      .select('*')
      .eq('id', slug);

    if (!includeUnpublished) {
      fallbackQuery = fallbackQuery.eq('published', true);
    }

    const { data: dataById, error: errorById } = await fallbackQuery.single();
    
    if (errorById) {
      return null;
    }
    
    return dataById;
  }

  return data;
};

export const getPreOwnedById = async (id: string): Promise<PreOwned | null> => {
  const { data, error } = await supabase
    .from('pre_owned')
    .select('*')
    .eq('id', id)
    .eq('published', true)
    .single();

  if (error) {
    console.error('Error fetching pre-owned item:', error);
    return null;
  }

  return data;
};

// Home page functions
export const getEvergreenCarousel = async (): Promise<EvergreenCarousel[]> => {
  const { data, error } = await supabase
    .from('evergreen_carousel')
    .select('*')
    .eq('published', true)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching evergreen carousel:', error);
    return [];
  }

  return data || [];
};

export const getHomeHeroImages = async (): Promise<HomeHeroImage[]> => {
  const { data, error } = await supabase
    .from('home_hero_images')
    .select('*')
    .eq('published', true)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching home hero images:', error);
    return [];
  }

  return data || [];
};

export const getTestimonials = async (): Promise<Testimonial[]> => {
  const { data, error } = await supabase
    .from('testimonials')
    .select('*')
    .eq('published', true)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching testimonials:', error);
    return [];
  }

  return data || [];
};

// Admin functions
export const adminGetAllProducts = async (): Promise<Product[]> => {
  const { data, error } = await supabase
    .from('products')
    .select(`
      *,
      categories:product_categories!products_category_id_fkey(id, name, slug),
      manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
    `)
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Error fetching all products:', error);
    return [];
  }

  return data || [];
};

export const adminListHomeHeroImages = async (): Promise<HomeHeroImage[]> => {
  const { data, error } = await supabase
    .from('home_hero_images')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) {
    console.error('Error listing home hero images (admin):', error);
    return [];
  }
  return data || [];
};

export const createProduct = async (productData: Partial<Product>) => {
  const { data, error } = await supabase
    .from('products')
    .insert([productData])
    .select()
    .single();

  return { data, error };
};

export const updateProduct = async (id: string, productData: Partial<Product>) => {
  const { data, error } = await supabase
    .from('products')
    .update(productData)
    .eq('id', id)
    .select()
    .single();

  return { data, error };
};

export const deleteProduct = async (id: string) => {
  const { error } = await supabase
    .from('products')
    .delete()
    .eq('id', id);

  return { error };
};

export const createHomeHeroImage = async (item: Partial<HomeHeroImage>) => {
  const { data, error } = await supabase
    .from('home_hero_images')
    .insert([item])
    .select()
    .single();
  return { data, error };
};

export const updateHomeHeroImage = async (id: string, item: Partial<HomeHeroImage>) => {
  const { data, error } = await supabase
    .from('home_hero_images')
    .update(item)
    .eq('id', id)
    .select()
    .single();
  return { data, error };
};

export const deleteHomeHeroImage = async (id: string) => {
  const { error } = await supabase
    .from('home_hero_images')
    .delete()
    .eq('id', id);
  return { error };
};

// Image functions
export const getImageUrl = (imagePath: string, transform?: { width?: number; height?: number; quality?: number; format?: 'origin' }): string => {
  if (!imagePath) return '';
  
  let cleanPath = imagePath;
  
  if (cleanPath.startsWith('http')) {
    const urlParts = cleanPath.split('/');
    cleanPath = urlParts[urlParts.length - 1];
  }
  
  cleanPath = cleanPath.replace(/^\/+/, '');
  cleanPath = cleanPath.replace(/^main\//, '');
  cleanPath = cleanPath.replace(/^assets\//, '');
  
  // Use Supabase image transformations if transform options provided
  // Note: Requires image transformations to be enabled in Supabase project settings
  // See: https://supabase.com/docs/guides/storage/serving/image-transformations
  if (transform) {
    const sanitizedTransform: { width?: number; height?: number; quality?: number; format?: 'origin' } | undefined =
      transform
        ? { ...transform, format: transform.format === 'origin' ? 'origin' : undefined }
        : undefined;
    const { data } = supabase.storage
      .from('images')
      .getPublicUrl(cleanPath, sanitizedTransform ? { transform: sanitizedTransform } : undefined);
    return data.publicUrl;
  }
  
  if (cleanPath.includes('/')) {
    return supabase.storage.from('images').getPublicUrl(cleanPath).data.publicUrl;
  } else {
    return supabase.storage.from('images').getPublicUrl(cleanPath).data.publicUrl;
  }
};

// Get optimized thumbnail for grid displays (300x300, quality 75)
export const getImageThumbnail = (imagePath: string): string => {
  return getImageUrl(imagePath, { width: 300, height: 300, quality: 75 });
};

export const uploadImage = async (file: File, filename: string) => {
  const { data, error } = await supabase.storage
    .from('images')
    .upload(filename, file, {
      cacheControl: '3600',
      upsert: false
    });

  return { data, error };
};

export const deleteImage = async (filename: string) => {
  const { error } = await supabase.storage
    .from('images')
    .remove([filename]);

  return { error };
};

// Article mention processing (client-side function, needs 'use client' when used)
export const getAllManufacturers = async (client: SupabaseClient = supabase): Promise<Manufacturer[]> => {
  const { data, error } = await client
    .from('manufacturers')
    .select('*')
    .order('name');

  if (error) {
    console.error('Error fetching manufacturers:', error);
    return [];
  }

  return data || [];
};

export const getAllProducts = async (client: SupabaseClient = supabase): Promise<Product[]> => {
  const { data, error } = await client
    .from('products')
    .select(`
      *,
      categories:product_categories!products_category_id_fkey(id, name, slug),
      manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
    `)
    .eq('published', true)
    .order('title');

  if (error) {
    console.error('Error fetching products:', error);
    return [];
  }

  return data || [];
};

// Helper function to check if a word is likely a real mention vs common word
const isLikelyMention = (text: string, entityName: string, context: string): boolean => {
  const lowerText = text.toLowerCase();
  const lowerEntity = entityName.toLowerCase();
  
  // Skip if entity name is too generic (common words that are also manufacturer names)
  const commonWords = [
    'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
    'insight', 'vision', 'power', 'energy', 'force', 'strength', 'quality', 'value',
    'premium', 'elite', 'master', 'pro', 'expert', 'advanced', 'superior', 'ultimate',
    'reference', 'standard', 'classic', 'modern', 'traditional', 'contemporary',
    'audio', 'sound', 'music', 'speaker', 'amplifier', 'receiver', 'turntable',
    'cable', 'wire', 'connector', 'jack', 'plug', 'adapter', 'converter',
    'spl' // SPL is a manufacturer but also a common abbreviation
  ];
  
  // For very short or common words, require stronger context
  if (commonWords.includes(lowerEntity) || lowerEntity.length <= 3) {
    // Require contextual indicators for common words
    const contextualIndicators = [
      'from', 'by', 'manufactured', 'produced', 'designed', 'created', 'developed',
      'model', 'series', 'line', 'collection', 'brand', 'company', 'manufacturer',
      'speaker', 'amplifier', 'receiver', 'turntable', 'cable', 'system', 'unit',
      'review', 'test', 'evaluation', 'comparison', 'specification', 'feature',
      'announces', 'introduces', 'releases', 'launches', 'presents'
    ];
    
    const hasContextualIndicator = contextualIndicators.some(indicator => 
      context.toLowerCase().includes(indicator.toLowerCase())
    );
    
    // Also check if it's capitalized (proper noun) which suggests it's a brand name
    const isCapitalized = entityName[0] === entityName[0].toUpperCase() && 
                         entityName.slice(1) === entityName.slice(1).toLowerCase();
    
    return hasContextualIndicator || isCapitalized;
  }
  
  // Check for proper capitalization patterns
  const entityWords = entityName.split(' ');
  const hasProperCapitalization = entityWords.some(word => 
    word.length > 1 && word[0] === word[0].toUpperCase()
  );
  
  // For single-word lowercase entities, require context
  if (!hasProperCapitalization && entityWords.length === 1) {
    const contextualIndicators = [
      'from', 'by', 'manufactured', 'produced', 'designed', 'created', 'developed',
      'model', 'series', 'line', 'collection', 'brand', 'company', 'manufacturer'
    ];
    return contextualIndicators.some(indicator => 
      context.toLowerCase().includes(indicator.toLowerCase())
    );
  }
  
  // Check for contextual indicators that suggest it's a real mention
  const contextualIndicators = [
    'from', 'by', 'manufactured', 'produced', 'designed', 'created', 'developed',
    'model', 'series', 'line', 'collection', 'brand', 'company', 'manufacturer',
    'speaker', 'amplifier', 'receiver', 'turntable', 'cable', 'system', 'unit',
    'review', 'test', 'evaluation', 'comparison', 'specification', 'feature',
    'announces', 'introduces', 'releases', 'launches', 'presents'
  ];
  
  const hasContextualIndicator = contextualIndicators.some(indicator => 
    context.toLowerCase().includes(indicator.toLowerCase())
  );
  
  // Check if the entity name appears in a technical/specific context
  const technicalContext = /(model|series|line|system|unit|speaker|amplifier|receiver|product|component)/i;
  const hasTechnicalContext = technicalContext.test(context);
  
  // Check for brand-like patterns (multiple words, proper nouns)
  const isMultiWord = entityWords.length > 1;
  const hasBrandPattern = /^[A-Z][a-z]+(\s+[A-Z][a-z]+)*$/.test(entityName);
  
  // Score the likelihood
  let score = 0;
  if (hasProperCapitalization) score += 2;
  if (hasContextualIndicator) score += 3;
  if (hasTechnicalContext) score += 2;
  if (isMultiWord) score += 2;
  if (hasBrandPattern) score += 2;
  
  // Require a minimum score to consider it a real mention
  return score >= 3;
};

// Helper function to get surrounding context
const getContext = (text: string, matchIndex: number, matchLength: number, contextSize: number = 50): string => {
  const start = Math.max(0, matchIndex - contextSize);
  const end = Math.min(text.length, matchIndex + matchLength + contextSize);
  return text.substring(start, end);
};

const decodeHtmlEntities = (text: string): string => {
  if (!text) return '';
  return text
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&#(\d+);/g, (_, dec) => {
      const code = Number(dec);
      return Number.isNaN(code) ? '' : String.fromCharCode(code);
    })
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => {
      const code = parseInt(hex, 16);
      return Number.isNaN(code) ? '' : String.fromCharCode(code);
    });
};

const stripHtmlTags = (text: string): string => {
  if (!text) return '';
  return text.replace(/<[^>]*>/g, ' ');
};

const normalizeTextForMentions = (text: string): string => {
  return decodeHtmlEntities(stripHtmlTags(text || '')).replace(/\s+/g, ' ').trim();
};

const buildProductSearchTerms = (product: Product): string[] => {
  const terms = new Set<string>();
  if (product.title) {
    terms.add(product.title);
  }

  const manufacturerName = product.manufacturer?.name?.trim();
  if (manufacturerName && product.title) {
    const lowerTitle = product.title.toLowerCase();
    const lowerManufacturer = manufacturerName.toLowerCase();
    if (lowerTitle.startsWith(lowerManufacturer)) {
      const remainder = product.title.slice(manufacturerName.length).trim();
      if (remainder.length > 2) {
        terms.add(remainder);
      }
    }
  }

  if (product.slug) {
    const slugName = product.slug.replace(/-/g, ' ').trim();
    if (slugName.length > 2) {
      terms.add(slugName);
    }
  }

  return Array.from(terms.values());
};

export const processArticleMentions = async (
  content: string,
  title?: string,
  briefDescription?: string,
  supabaseClientOverride?: SupabaseClient
): Promise<{
  processedContent: string;
  mentions: {
    manufacturers: Array<{ name: string; slug: string; count: number }>;
    products: Array<{ title: string; slug: string; count: number }>;
  };
}> => {
  const activeClient = supabaseClientOverride || supabase;
  const [manufacturers, products] = await Promise.all([
    getAllManufacturers(activeClient),
    getAllProducts(activeClient)
  ]);

  const normalizedContent = normalizeTextForMentions(content);
  const normalizedTitle = normalizeTextForMentions(title || '');
  const normalizedBrief = normalizeTextForMentions(briefDescription || '');

  // Combine all text sources for detection
  const searchableText = [
    normalizedTitle,
    normalizedBrief,
    normalizedContent
  ].filter(Boolean).join(' ');

  let processedContent = content;
  const mentions = {
    manufacturers: [] as Array<{ name: string; slug: string; count: number; logo?: string | null }>,
    products: [] as Array<{
      title: string;
      slug: string;
      count: number;
      heroImage?: string | null;
      manufacturerName?: string | null;
      categoryName?: string | null;
      price?: number | null;
      showPrice?: boolean | null;
    }>
  };

  // Process manufacturer mentions with contextual validation
  manufacturers.forEach(manufacturer => {
    if (!manufacturer?.name) {
      return;
    }
    // Check all text sources for mentions (for counting)
    const regex = new RegExp(`\\b${manufacturer.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'gi');
    const allMatches = searchableText.match(regex);
    
    if (allMatches && allMatches.length > 0) {
      // Validate each match with context
      let validMatches = 0;
      const regexForValidation = new RegExp(`\\b${manufacturer.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'gi');
      let validationText = searchableText;
      let matchIndex = 0;
      
      while (true) {
        const match = regexForValidation.exec(validationText);
        if (!match) break;
        
        const context = getContext(validationText, match.index, match[0].length);
        
        if (isLikelyMention(match[0], manufacturer.name, context)) {
          validMatches++;
          
          // Only replace the first valid match in the main content to avoid spam
          if (validMatches === 1) {
            // Check if this match appears in the processed content
            const contentMatch = processedContent.match(
              new RegExp(`\\b${manufacturer.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i')
            );
            if (contentMatch) {
              processedContent = processedContent.replace(
                new RegExp(`\\b${manufacturer.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i'),
                `<a href="/manufacturers/${manufacturer.slug}" class="text-stone-600 hover:text-stone-800 underline decoration-stone-300 hover:decoration-stone-600 transition-colors">${manufacturer.name}</a>`
              );
            }
          }
        }
      }
      
      if (validMatches > 0) {
        mentions.manufacturers.push({
          name: manufacturer.name,
          slug: manufacturer.slug,
          count: validMatches,
          logo: manufacturer.logo || null
        });
      }
    }
  });

  // Process product mentions with contextual validation
  products.forEach(product => {
    if (!product?.title) {
      return;
    }
    
    const searchTerms = buildProductSearchTerms(product);
      let validMatches = 0;
    let linkInserted = false;
    
    searchTerms.forEach(term => {
      if (!term) return;
      const escapedTerm = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`\\b${escapedTerm}\\b`, 'gi');
      const allMatches = searchableText.match(regex);
      
      if (allMatches && allMatches.length > 0) {
        const regexForValidation = new RegExp(`\\b${escapedTerm}\\b`, 'gi');
        let validationText = searchableText;
      
      while (true) {
        const match = regexForValidation.exec(validationText);
        if (!match) break;
        
        const context = getContext(validationText, match.index, match[0].length);
        
          if (isLikelyMention(match[0], term, context)) {
          validMatches++;
          
            if (!linkInserted) {
              const contentRegex = new RegExp(`\\b${escapedTerm}\\b`, 'i');
              if (contentRegex.test(processedContent)) {
              processedContent = processedContent.replace(
                  contentRegex,
                  `<a href="/products/${product.slug}" class="text-stone-600 hover:text-stone-800 underline decoration-stone-300 hover:decoration-stone-600 transition-colors">${match[0]}</a>`
              );
                linkInserted = true;
            }
          }
        }
      }
      }
    });
      
      if (validMatches > 0) {
        mentions.products.push({
          title: product.title,
          slug: product.slug,
        count: validMatches,
        heroImage: product.product_hero_image || null,
        manufacturerName: product.manufacturer?.name || null,
        categoryName: product.categories?.name || null,
        price: product.price ?? null,
        showPrice: product.show_price ?? null
        });
    }
  });

  return { processedContent, mentions };
};

export const getRelatedProducts = async (productId: string, manufacturerId?: string, categoryId?: string): Promise<Product[]> => {
  let query = supabase
    .from('products')
    .select(`
      *,
      categories:product_categories!products_category_id_fkey(id, name, slug),
      manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
    `)
    .neq('id', productId)
    .eq('published', true)
    .limit(6);

  if (manufacturerId && categoryId) {
    query = query.or(`manufacturer_id.eq.${manufacturerId},category_id.eq.${categoryId}`);
  } else if (manufacturerId) {
    query = query.eq('manufacturer_id', manufacturerId);
  } else if (categoryId) {
    query = query.eq('category_id', categoryId);
  } else {
    query = query.eq('featured', true);
  }

  const { data, error } = await query;
  
  if (error) {
    console.error('Error fetching related products:', error);
    return [];
  }
  
  return data || [];
};

const sanitizeStoreHours = (storeHours?: StoreHourEntry[] | null): StoreHourEntry[] => {
  if (!storeHours) return [];
  return storeHours
    .map(entry => ({
      label: entry?.label?.trim() || '',
      value: entry?.value?.trim() || '',
    }))
    .filter(entry => entry.label.length > 0 || entry.value.length > 0);
};

export const getBusinessInfo = async (client: SupabaseClient = supabase): Promise<BusinessInfo | null> => {
  const { data, error } = await client
    .from('site_business_info')
    .select('*')
    .order('updated_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    if (error.code !== 'PGRST116') {
      console.error('Error fetching business info:', error);
    }
    return null;
  }

  if (!data) {
    return null;
  }

  return {
    ...data,
    store_hours: sanitizeStoreHours(data.store_hours as StoreHourEntry[] | null),
  } as BusinessInfo;
};

export const updateBusinessInfo = async (
  payload: Partial<BusinessInfo> & { id?: string },
  client: SupabaseClient = supabase
): Promise<BusinessInfo | null> => {
  if (!payload) {
    throw new Error('No business info payload provided');
  }

  const sanitizedHours = sanitizeStoreHours(payload.store_hours ?? []);
  const { id, ...rest } = payload;
  const upsertPayload = {
    ...rest,
    id,
    store_hours: sanitizedHours,
    updated_at: new Date().toISOString(),
  };

  const { data, error } = await client
    .from('site_business_info')
    .upsert(upsertPayload, { onConflict: 'id' })
    .select('*')
    .single();

  if (error) {
    console.error('Error updating business info:', error);
    throw error;
  }

  return {
    ...data,
    store_hours: sanitizeStoreHours(data.store_hours as StoreHourEntry[] | null),
  } as BusinessInfo;
};




