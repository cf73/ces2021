// This file exports shared types and the client instance
// For server components, import directly from './supabase-server'
// For client components marked with 'use client', import { supabase } from './supabase-client'

export { supabase } from './supabase-client';

// TypeScript Interfaces
export type ProductTopology = 'tube' | 'solid_state' | 'hybrid';
export type ProductAmplifierClass = 'class_a' | 'class_ab' | 'class_d' | 'class_g' | 'class_h';
export type ProductRelationshipNotes = Record<string, string>;

export interface Product {
  id: string;
  title: string;
  slug: string;
  content: string;
  brief_description?: string;
  product_hero_image?: string;
  product_gallery?: string[];
  specs?: string;
  quote?: string;
  quote_attribution?: string;
  reivews_set?: Review[];
  price?: number;
  available_for_demo?: boolean;
  available_to_buy_online?: boolean;
  show_price?: boolean;
  local_only?: boolean;
  featured?: boolean;
  published?: boolean;
  topology?: ProductTopology | null;
  amplifier_class?: ProductAmplifierClass | null;
  special_order_lead_time?: string;
  created_at: string;
  updated_at: string;
  category_id?: string;
  manufacturer_id?: string;
  categories?: ProductCategory;
  manufacturer?: Manufacturer;
  pairs_well_with?: string[];
  also_consider?: string[];
  pairs_notes?: ProductRelationshipNotes | null;
  also_notes?: ProductRelationshipNotes | null;
  pairs_reasoning?: string;
  pairs_cta?: string;
  pairs_helper?: string;
  also_reasoning?: string;
  also_cta?: string;
  also_helper?: string;
  ai_generation_status?: string;
  ai_generation_error?: string;
  ai_last_generated?: string;
}

export interface Review {
  excerpt?: string;
  attribution?: string;
  link?: string;
  date_of_review?: string;
}

export interface ProductCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
  category_description?: string;
  hero_product_id?: string;
}

export interface Manufacturer {
  id: string;
  name: string;
  slug: string;
  description?: string;
  logo?: string;
  website?: string;
  published?: boolean;
}

export interface NewsContentBlock {
  type: 'text' | 'image';
  text?: string; // For text blocks
  photo?: Array<{ url: string; caption?: string }>; // For image blocks
}

export interface News {
  id: string;
  title: string;
  slug: string;
  content: string;
  summary?: string;
  brief_description?: string;
  main_content?: string;
  more_content?: NewsContentBlock[]; // Structured content blocks
  image?: string;
  published?: boolean;
  created_at: string;
  updated_at: string;
  system_category?: string;
  news_date?: string;
}

export interface PreOwned {
  id: string;
  title: string;
  slug: string;
  content: string;
  image?: string;
  images?: string[];
  description?: string;
  your_price?: number;
  new_retail_price?: number;
  hide_your_price?: boolean;
  local_only?: boolean;
  shipping?: number;
  original_accessories?: string;
  published?: boolean;
  created_at: string;
  updated_at: string;
}

export interface Testimonial {
  id: string;
  title: string;
  slug: string;
  content: string;
  author?: string;
  published?: boolean;
  created_at: string;
  updated_at: string;
}

export interface EvergreenCarousel {
  id: string;
  title: string;
  slug: string;
  content: string;
  hero_image?: string;
  published?: boolean;
  created_at: string;
  updated_at: string;
}

export interface HomeHeroImage {
  id: string;
  image: string;
  alt_text?: string;
  credit?: string;
  weight?: number;
  published?: boolean;
  created_at: string;
  updated_at: string;
}

export interface StoreHourEntry {
  label: string;
  value: string;
}

export interface BusinessInfo {
  id: string;
  company_name?: string;
  tagline?: string;
  short_description?: string;
  about_description?: string;
  phone?: string;
  email?: string;
  address_line1?: string;
  address_line2?: string;
  city?: string;
  state?: string;
  postal_code?: string;
  country?: string;
  google_map_url?: string;
  virtual_tour_url?: string;
  store_hours?: StoreHourEntry[];
  special_notice?: string;
  created_at: string;
  updated_at: string;
}

