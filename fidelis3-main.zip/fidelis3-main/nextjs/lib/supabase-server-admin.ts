import { createClient } from '@supabase/supabase-js';

// Server-side Supabase client with secret key (bypasses RLS)
// This should only be used for server-side operations
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseSecretKey = process.env.SUPABASE_SECRET_KEY;

if (!supabaseSecretKey) {
  console.warn('⚠️ SUPABASE_SECRET_KEY not found. Server-side updates may fail due to RLS policies.');
}

export const supabaseAdmin = supabaseUrl && supabaseSecretKey
  ? createClient(supabaseUrl, supabaseSecretKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    })
  : null;

export default supabaseAdmin;
