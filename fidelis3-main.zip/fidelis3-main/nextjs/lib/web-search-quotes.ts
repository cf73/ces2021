import { TavilyClient } from 'tavily';
import Anthropic from '@anthropic-ai/sdk';
import type { Product } from './supabase';
import { DEFAULT_ANTHROPIC_MODEL, ANTHROPIC_QUOTE_MAX_TOKENS } from './anthropic-config';

// Initialize clients only if API keys are available
let anthropic: Anthropic | null = null;
let tavilyClient: TavilyClient | null = null;

if (process.env.ANTHROPIC_API_KEY) {
  anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY,
    dangerouslyAllowBrowser: false,
  });
}

if (process.env.TAVILY_API_KEY) {
  tavilyClient = new TavilyClient({ apiKey: process.env.TAVILY_API_KEY });
}

interface QuoteResult {
  quote: string | null;
  attribution: string | null;
  sourceUrl?: string;
}

/**
 * Search the web for product reviews and extract a compelling quote
 * Only returns a quote if one is found; returns null values if not
 */
export async function searchForProductQuote(product: Product): Promise<QuoteResult> {
  // Skip if clients not initialized
  if (!tavilyClient || !anthropic) {
    console.log('⚠️ Tavily or Anthropic API not configured, skipping web search for quotes');
    return { quote: null, attribution: null };
  }

  try {
    console.log(`🔍 Searching web for reviews of: ${product.manufacturer?.name} ${product.title}`);
    
    // Try multiple search strategies to find quotes
    let searchResults;
    
    // Create a timeout promise
    const timeoutPromise = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Tavily search timeout after 30 seconds')), 30000)
    );
    
    // Strategy 1: Exact product name + review
    const exactQuery = `"${product.manufacturer?.name}" "${product.title}" review`;
    try {
      searchResults = await Promise.race([
        tavilyClient.search({
          query: exactQuery,
          search_depth: 'basic', // Use basic instead of advanced for faster results
          max_results: 10,
          include_answer: false,
          include_raw_content: false, // Disable raw content for faster response
        }),
        timeoutPromise
      ]) as any;
    } catch (timeoutError) {
      console.log('⏱️ Tavily search timed out, trying simpler query...');
      // Try a simpler, faster search
      searchResults = await Promise.race([
        tavilyClient.search({
          query: `${product.manufacturer?.name} ${product.title} review`,
          search_depth: 'basic',
          max_results: 5,
          include_answer: false,
          include_raw_content: false,
        }),
        timeoutPromise
      ]) as any;
    }

    if (!searchResults.results || searchResults.results.length === 0) {
      console.log('❌ No search results found');
      return { quote: null, attribution: null };
    }

    console.log(`✅ Found ${searchResults.results.length} search results`);

    // Prepare content for Claude to analyze
    const reviewContent = searchResults.results
      .map((result: { url: string; title: string; content: string }, index: number) => `
REVIEW ${index + 1}:
Source: ${result.url}
Title: ${result.title}
Content: ${result.content}
---
`)
      .join('\n');

    // Ask Claude to extract the best quote - be more flexible
    const prompt = `You are analyzing audio equipment reviews to find compelling quotes for a high-end audio retailer's website.

PRODUCT INFORMATION:
- Manufacturer: ${product.manufacturer?.name}
- Product: ${product.title}
- Category: ${product.categories?.name}
- Price: $${product.price}

REVIEW SOURCES:
${reviewContent}

YOUR TASK:
Extract ONE compelling, quotable sentence or passage (1-3 sentences) that would make someone interested in this product.

WHAT TO LOOK FOR (in order of preference):
1. Direct praise or notable observations about THIS specific product
2. Comments about the manufacturer's quality or reputation (if product-specific quotes aren't available)
3. Category-level insights that would apply to this product
4. Any positive, credible statement that relates to what this product does

BE FLEXIBLE:
- The quote doesn't have to mention the exact product name if the context is clear
- Manufacturer reputation quotes are acceptable
- Category insights from credible sources are fine
- Focus on finding SOMETHING useful rather than nothing at all

ATTRIBUTION:
- Extract reviewer name and/or publication from the source
- If unclear, use the website name from the URL
- Format as "Name, Publication" or just "Publication"

Return ONLY valid JSON in this exact format:
{
  "quote": "The exact quote text here, or null if absolutely nothing suitable exists",
  "attribution": "Reviewer/Publication Name" or null,
  "sourceUrl": "The URL" or null,
  "confidence": "high" or "medium" or "low"
}

Be generous - if you find anything remotely useful and credible, include it. Only return null if there's truly nothing.`;

    const message = await anthropic.messages.create({
      model: DEFAULT_ANTHROPIC_MODEL,
      max_tokens: ANTHROPIC_QUOTE_MAX_TOKENS,
      temperature: 0.5, // Increased for more creative extraction
      messages: [{
        role: 'user',
        content: prompt
      }]
    });

    // Parse Claude's response
    const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
    console.log('🤖 Claude response:', responseText);

    // Extract JSON from response
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.log('❌ Could not parse JSON from Claude response');
      return { quote: null, attribution: null };
    }

    const result = JSON.parse(jsonMatch[0]);

    // Accept high, medium, or low confidence quotes
    if (result.confidence === 'high' || result.confidence === 'medium' || result.confidence === 'low') {
      console.log(`✅ Found quote with ${result.confidence} confidence`);
      return {
        quote: result.quote,
        attribution: result.attribution,
        sourceUrl: result.sourceUrl
      };
    } else {
      console.log(`⚠️ No suitable quote found (confidence: ${result.confidence})`);
      return { quote: null, attribution: null };
    }

  } catch (error: any) {
    console.error('❌ Error searching for product quote:', error?.message || error);
    
    // Check if it's a timeout or network error
    if (error?.message?.includes('timeout') || error?.code === 'ETIMEDOUT') {
      console.log('⏱️ Tavily API timed out - this is normal for the first request or slow connections');
    } else if (error?.message?.includes('ECONNREFUSED')) {
      console.log('🔌 Cannot connect to Tavily API - check your internet connection');
    } else if (error?.response?.status === 401 || error?.response?.status === 403) {
      console.log('🔑 Tavily API key may be invalid or expired');
    }
    
    return { quote: null, attribution: null };
  }
}

/**
 * Search for and add a quote to a product if it doesn't have one
 * Returns true if a quote was added, false otherwise
 */
export async function ensureProductQuote(product: Product): Promise<boolean> {
  // Skip if product already has a quote
  if (product.quote && product.quote.trim().length > 0) {
    console.log(`✅ Product "${product.title}" already has a quote, skipping web search`);
    return false;
  }

  const quoteResult = await searchForProductQuote(product);

  if (quoteResult.quote && quoteResult.attribution) {
    console.log(`✨ Found quote for "${product.title}": "${quoteResult.quote.substring(0, 100)}..."`);
    return true;
  } else {
    console.log(`⚠️ No suitable quote found for "${product.title}"`);
    return false;
  }
}

