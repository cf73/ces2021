/**
 * Parse TipTap JSON content to HTML with proper paragraph formatting
 * Handles both TipTap JSON format and plain HTML strings
 */
export function parseTipTapContent(content: string | null | undefined): string {
  if (!content) return '';
  
  // If it's already HTML, return as-is (but ensure proper paragraph structure)
  if (typeof content === 'string' && content.trim().startsWith('<')) {
    // Check if it has paragraph tags
    if (content.includes('<p>') || content.includes('<div>')) {
      return content;
    }
    // If it's HTML but no paragraphs, try to format it
    return formatPlainTextToHTML(content);
  }
  
  // Try to parse as JSON (TipTap format)
  try {
    const parsed = JSON.parse(content);
    
    if (Array.isArray(parsed)) {
      return parseTipTapNodes(parsed);
    }
    
    if (typeof parsed === 'object' && parsed.type === 'doc' && parsed.content) {
      return parseTipTapNodes(parsed.content);
    }
  } catch {
    // Not JSON, treat as plain text
    return formatPlainTextToHTML(content);
  }
  
  return content;
}

function parseTipTapNodes(nodes: any[]): string {
  if (!Array.isArray(nodes)) return '';
  
  return nodes.map(node => parseTipTapNode(node)).join('');
}

function parseTipTapNode(node: any): string {
  if (!node || !node.type) return '';
  
  const text = node.text || '';
  let result = text;
  
  // Apply marks (bold, italic, underline, etc.)
  if (node.marks && Array.isArray(node.marks)) {
    node.marks.forEach((mark: any) => {
      if (mark.type === 'bold') result = `<strong>${result}</strong>`;
      if (mark.type === 'italic') result = `<em>${result}</em>`;
      if (mark.type === 'underline') result = `<u>${result}</u>`;
      if (mark.type === 'link' && mark.attrs?.href) {
        result = `<a href="${mark.attrs.href}">${result}</a>`;
      }
    });
  }
  
  // Handle node types
  if (node.type === 'paragraph') {
    const content = node.content ? parseTipTapNodes(node.content) : result;
    return `<p>${content || ''}</p>`;
  }
  
  if (node.type === 'hardBreak') return '<br />';
  
  if (node.type === 'heading' && node.attrs?.level) {
    const content = node.content ? parseTipTapNodes(node.content) : result;
    return `<h${node.attrs.level}>${content}</h${node.attrs.level}>`;
  }
  
  if (node.type === 'bulletList' || node.type === 'orderedList') {
    const tag = node.type === 'orderedList' ? 'ol' : 'ul';
    const content = node.content ? parseTipTapNodes(node.content) : '';
    return `<${tag}>${content}</${tag}>`;
  }
  
  if (node.type === 'listItem') {
    const content = node.content ? parseTipTapNodes(node.content) : result;
    return `<li>${content}</li>`;
  }
  
  if (node.type === 'blockquote') {
    const content = node.content ? parseTipTapNodes(node.content) : result;
    return `<blockquote>${content}</blockquote>`;
  }
  
  // Handle content children recursively
  if (node.content && Array.isArray(node.content)) {
    return parseTipTapNodes(node.content);
  }
  
  return result;
}

function formatPlainTextToHTML(text: string): string {
  if (!text) return '';
  
  // Remove HTML tags if present (but keep structure)
  const cleanText = text.replace(/<[^>]+>/g, '');
  
  // Split by double line breaks to create paragraphs
  const paragraphs = cleanText
    .split(/\n\n+/)
    .filter(para => para.trim().length > 0)
    .map(para => {
      // Replace single line breaks with <br /> within paragraphs
      const formatted = para.trim().replace(/\n/g, '<br />');
      return `<p>${formatted}</p>`;
    });
  
  return paragraphs.join('');
}



