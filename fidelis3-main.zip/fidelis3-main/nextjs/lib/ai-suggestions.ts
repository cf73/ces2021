import Anthropic from '@anthropic-ai/sdk';
import type { Tool } from '@anthropic-ai/sdk/resources/messages/messages';
import type { Product } from './supabase';
import { DEFAULT_ANTHROPIC_MODEL, DEFAULT_ANTHROPIC_MAX_TOKENS, extractToolUseInput, formatAnthropicError } from './anthropic-config';

const PRODUCT_SUGGESTIONS_TOOL = 'save_product_suggestions';

const productSuggestionsToolDefinition: Tool = {
  name: PRODUCT_SUGGESTIONS_TOOL,
  description: 'Return product relationship suggestions and marketing copy for the current product.',
  input_schema: {
    type: 'object',
    properties: {
      pairsWellWith: {
        type: 'array',
        items: { type: 'string' },
        description: 'Product UUIDs that pair well with the current product.',
      },
      pairsNotes: {
        type: 'object',
        additionalProperties: { type: 'string' },
        description: 'Short per-product notes keyed by pairsWellWith UUID.',
      },
      pairsReasoning: { type: 'string' },
      pairsCTA: { type: 'string' },
      pairsHelper: { type: 'string' },
      alsoConsider: {
        type: 'array',
        items: { type: 'string' },
        description: 'Alternative product UUIDs in the same category.',
      },
      alsoNotes: {
        type: 'object',
        additionalProperties: { type: 'string' },
        description: 'Short per-product notes keyed by alsoConsider UUID.',
      },
      alsoReasoning: { type: 'string' },
      alsoCTA: { type: 'string' },
      alsoHelper: { type: 'string' },
      briefDescription: {
        type: 'string',
        description: 'SEO-optimized brief description, 150-250 characters.',
      },
    },
    required: [
      'pairsWellWith',
      'pairsNotes',
      'pairsReasoning',
      'pairsCTA',
      'pairsHelper',
      'alsoConsider',
      'alsoNotes',
      'alsoReasoning',
      'alsoCTA',
      'alsoHelper',
      'briefDescription',
    ],
  },
};

interface RawProductSuggestions {
  pairsWellWith?: string[];
  pairsNotes?: Record<string, unknown>;
  pairsReasoning?: string;
  pairsCTA?: string;
  pairsHelper?: string;
  alsoConsider?: string[];
  alsoNotes?: Record<string, unknown>;
  alsoReasoning?: string;
  alsoCTA?: string;
  alsoHelper?: string;
  briefDescription?: string;
}

// Ensure SDK runs on server side
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
  dangerouslyAllowBrowser: false,
});

interface SuggestionContext {
  currentProduct: Product;
  allProducts: Product[];
  forcedPairsWellWith?: string[];
  forcedAlsoConsider?: string[];
}

interface ProductSuggestions {
  pairsWellWith: string[];
  pairsNotes: Record<string, string>;
  pairsReasoning: string;
  pairsCTA: string;
  pairsHelper: string;
  alsoConsider: string[];
  alsoNotes: Record<string, string>;
  alsoReasoning: string;
  alsoCTA: string;
  alsoHelper: string;
  briefDescription: string;
}

const normalizeRelationshipNotes = (notes: unknown, selectedIds: string[]) => {
  if (!notes || typeof notes !== 'object') return {};

  return selectedIds.reduce<Record<string, string>>((acc, id) => {
    const value = (notes as Record<string, unknown>)[id];
    if (typeof value !== 'string') return acc;

    const note = value.replace(/\s+/g, ' ').trim();
    if (!note) return acc;

    acc[id] = note.slice(0, 140);
    return acc;
  }, {});
};

interface BatchSuggestionContext {
  products: Array<{
    id: string;
    title: string;
    manufacturer?: { name: string };
    categories?: { name: string };
    price?: number;
  }>;
  allProducts: Product[];
}

interface BatchProductSuggestions {
  suggestions: Array<{
    productId: string;
    pairsWellWith: string[];
    pairsReasoning: string;
    alsoConsider: string[];
    alsoReasoning: string;
  }>;
}

export async function generateProductSuggestions({
  currentProduct,
  allProducts,
  forcedPairsWellWith,
  forcedAlsoConsider
}: SuggestionContext): Promise<ProductSuggestions> {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error('ANTHROPIC_API_KEY is not configured. Add it to nextjs/.env.local and restart the dev server to regenerate relationship copy.');
  }

  // Build context for Claude - ALL published products
  const filteredProducts = allProducts.filter(p => p.id !== currentProduct.id && p.published !== false);
  
  // Prioritize same category products for "Also Consider" suggestions
  const sameCategoryProducts = filteredProducts.filter(p => 
    p.categories?.name === currentProduct.categories?.name
  );
  
  // Get other products, excluding same category (for "Good Synergies")
  const otherProducts = filteredProducts.filter(p => 
    p.categories?.name !== currentProduct.categories?.name
  );
  
  // Combine: same category first (for "Also Consider"), then others (for "Good Synergies")
  const prioritizedProducts = [...sameCategoryProducts, ...otherProducts];
  
  // Limit to relevant products to avoid rate limits
  // Prioritize same category and manufacturer, then limit total
  const productList = prioritizedProducts
    .slice(0, 200) // Limit to 200 products to stay under rate limits
    .map(p => ({
      id: p.id,
      title: p.title,
      category: p.categories?.name,
      manufacturer: p.manufacturer?.name,
      price: p.price,
      brief_description: p.brief_description?.substring(0, 150), // Reduced from 200
      content_excerpt: p.content?.substring(0, 150) // Reduced from 300
    }));

  const mapForcedDetails = (ids?: string[]) => {
    if (!ids || ids.length === 0) return [];
    return ids
      .map(id => allProducts.find(p => p.id === id))
      .filter((p): p is Product => Boolean(p))
      .map(p => ({
        id: p.id,
        title: p.title,
        manufacturer: p.manufacturer?.name,
        category: p.categories?.name,
        price: p.price,
        summary: (p.brief_description || p.content || '').substring(0, 200)
      }));
  };

  const forcedPairsDetails = mapForcedDetails(forcedPairsWellWith);
  const forcedAlsoDetails = mapForcedDetails(forcedAlsoConsider);

  // If forced lists are provided, this is a quality control pass - just generate text
  const isQualityControlPass = forcedPairsWellWith || forcedAlsoConsider;
  
  const prompt = `You are a seasoned high-end audio specialist with decades of experience matching components. Your expertise includes understanding power requirements, impedance matching, sonic characteristics (warm/analytical), and system synergies.

${isQualityControlPass ? `
QUALITY CONTROL MODE: You are generating text for a pre-selected product list.
${forcedPairsDetails.length ? `- Use EXACTLY these "Good Synergies" products:\n${JSON.stringify(forcedPairsDetails, null, 2)}` : ''}
${forcedAlsoDetails.length ? `- Use EXACTLY these "Also Consider" products:\n${JSON.stringify(forcedAlsoDetails, null, 2)}` : ''}

Your ONLY job is to generate reasoning, CTA, helper text, and short per-product notes for these EXACT products.
Use the product IDs provided above in your "pairsWellWith" and "alsoConsider" arrays.
` : `
IMPORTANT: For "Also Consider" suggestions, you MUST follow these rules strictly:
1. Same category only (e.g., "Interconnects" → only "Interconnects")
2. Price within 30% range: calculate (current_price × 0.7) to (current_price × 1.3)
3. If no products meet these criteria, return empty "alsoConsider" array

CRITICAL: Use ONLY the exact "id" field from the inventory list (UUID format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx). NEVER use product names, model numbers, or any other identifiers.
`}

CRITICAL: Only reference products that are ACTUALLY in your "pairsWellWith" or "alsoConsider" arrays. NEVER mention products not in the suggested lists.

CURRENT PRODUCT:
- Title: ${currentProduct.title}
- Manufacturer: ${currentProduct.manufacturer?.name}
- Category: ${currentProduct.categories?.name}
- Price: $${currentProduct.price}
- Description: ${currentProduct.brief_description || 'N/A'}
- Details: ${currentProduct.content?.substring(0, 500) || 'N/A'}

AVAILABLE INVENTORY (complete catalog - ${productList.length} products):
${JSON.stringify(productList, null, 2)}

YOUR TASK:

1. **"GOOD SYNERGIES" (MINIMUM 4 products, up to 6 that complement this product)**
   You MUST suggest at least 4 complementary products unless absolutely no logical pairings exist.
   Think like an audiophile building a complete system. Consider:
   - Power matching: Does a speaker need high power or work with low-watt tube amps?
   - Sonic character: Do warm tubes complement analytical speakers? Do forgiving components pair with revealing sources?
   - System building: What components complete a logical audio chain?
   - Technical compatibility: Impedance, sensitivity, output voltage, etc.
   - Price is flexible here - focus on sonic and technical synergy
   
   CRITICAL RULE - NO SAME CATEGORY:
   - NEVER suggest products from the same category as the current product
   - Speakers cannot be paired with other speakers
   - Amplifiers cannot be paired with other amplifiers
   - DACs cannot be paired with other DACs
   - Integrated amplifiers are standalone units - NEVER pair with preamps or power amps
   - Focus on complementary components that complete a system
   
   CRITICAL RULE - ELECTROSTATIC HEADPHONES REQUIRE SPECIAL AMPLIFIERS:
   - If the current product is an electrostatic headphone (detected by keywords like "electrostatic", "Stax", "SR-", manufacturer "Stax", or category "Headphones" with electrostatic characteristics), you MUST follow these rules STRICTLY:
   - NEVER suggest power amplifiers for electrostatic headphones - they are completely incompatible
   - NEVER suggest regular headphone amplifiers (like "Headphone Amplifiers" category) for electrostatic headphones - they are completely incompatible
   - EXCEPTION: Stax headphone amplifiers (like SRM-T8000, SRM-500T, etc.) ARE compatible - Stax manufactures electrostatic equipment and their headphone amps are designed for electrostatic headphones
   - Electrostatic headphones require specialized electrostatic amplifiers/drivers that provide high-voltage bias - regular headphone amps cannot drive them
   - ONLY suggest electrostatic amplifiers/drivers OR Stax headphone amplifiers (products specifically designed for electrostatic headphones, often called "drivers" or "electrostatic amplifiers")
   - If electrostatic amplifiers/drivers or Stax headphone amplifiers are available, they MUST be the PRIMARY recommendations - they are essential, not optional
   - Only after suggesting electrostatic amplifiers/drivers should you consider other components like source equipment, cables, or power conditioning
   - An expert audio sales rep would NEVER suggest a regular headphone amp for electrostatic headphones - this is a fundamental technical incompatibility
   
   CRITICAL RULE - ELECTROSTATIC SPEAKERS REQUIRE SPECIAL AMPLIFIERS:
   - If the current product is an electrostatic speaker (detected by keywords like "electrostatic", "Martin Logan", "Quad", "Sound Lab", "ESL", or category "Speakers" with electrostatic characteristics), you MUST follow these rules STRICTLY:
   - NEVER suggest standard power amplifiers for electrostatic speakers - they are completely incompatible
   - NEVER suggest integrated amplifiers for electrostatic speakers - they are completely incompatible
   - NEVER suggest regular amplifiers of any type for electrostatic speakers - they are completely incompatible
   - Electrostatic speakers require specialized electrostatic driver/amplifier units that provide high-voltage bias - standard amplifiers cannot drive them
   - ONLY suggest electrostatic amplifiers/drivers (products specifically designed for electrostatic speakers, often called "electrostatic drivers", "ESL amplifiers", or "electrostatic power supplies")
   - If electrostatic amplifiers/drivers are available, they MUST be the PRIMARY recommendations - they are essential, not optional
   - Only after suggesting electrostatic amplifiers/drivers should you consider other components like source equipment, cables, or power conditioning
   - An expert audio sales rep would NEVER suggest a standard amplifier for electrostatic speakers - this is a fundamental technical incompatibility
   
   CRITICAL RULE - PLANAR MAGNETIC SPEAKERS (MAGNEPAN) REQUIRE HIGH-CURRENT AMPLIFIERS:
   - If the current product is a planar magnetic speaker (detected by keywords like "Magnepan", "planar", "planar magnetic", or manufacturer "Magnepan"), you MUST follow these rules STRICTLY:
   - NEVER suggest standard integrated amplifiers for planar magnetic speakers - they are incompatible
   - NEVER suggest low-power amplifiers for planar magnetic speakers - they are incompatible
   - Planar magnetic speakers (like Magnepan) have very low impedance (often 4 ohms or less) and low efficiency (typically 83-86dB) - they require HIGH-CURRENT amplifiers specifically designed to handle difficult loads
   - ONLY suggest high-current power amplifiers or high-current integrated amplifiers that are explicitly designed for difficult speaker loads
   - Look for amplifiers with specifications like "high current", "stable into 2 ohms", "doubles power into 4 ohms", or descriptions mentioning ability to drive difficult loads
   - Standard integrated amplifiers (especially those with modest power ratings) CANNOT properly drive planar magnetic speakers - they will sound thin, lack dynamics, and may even damage the amplifier
   - If high-current amplifiers are available, they MUST be the PRIMARY recommendations - they are essential, not optional
   - An expert audio sales rep would NEVER suggest a standard integrated amplifier for planar magnetic speakers - this is a fundamental technical incompatibility
   
   CRITICAL RULE - STANDARD INTEGRATED AMPLIFIERS CANNOT DRIVE PLANAR MAGNETIC SPEAKERS:
   - If the current product is a standard integrated amplifier (not specifically designed for high-current/difficult loads), you MUST follow these rules STRICTLY:
   - NEVER suggest planar magnetic speakers (Magnepan) for standard integrated amplifiers - they are incompatible
   - Standard integrated amplifiers cannot provide the high current required by planar magnetic speakers' low impedance and low efficiency
   - ONLY suggest speakers that are compatible with standard amplification: conventional dynamic speakers with reasonable impedance (8 ohms nominal) and moderate to high efficiency (87dB+)
   - An expert audio sales rep would NEVER suggest Magnepan or other planar magnetic speakers for a standard integrated amplifier - this pairing will result in poor sound quality and potential amplifier damage
   
   CRITICAL RULE - 300B TUBE AMPLIFIERS ARE FOR HORN SPEAKERS:
   - If the current product is a 300B tube amplifier (detected by keywords like "300B", "triode", or amplifier descriptions mentioning 300B tubes), you MUST follow these rules STRICTLY:
   - 300B tube amplifiers are specifically designed for and typically paired with HORN SPEAKERS - this is a classic, proven pairing
   - NEVER suggest aluminum speakers (like Stenheim) for 300B tube amplifiers - aluminum speakers require high current from solid-state amplifiers, not the lower power output of 300B tubes
   - NEVER suggest other non-horn speakers that require high current or high power for 300B tube amplifiers
   - ONLY suggest horn speakers (high efficiency, typically 95dB+ sensitivity) for 300B tube amplifiers
   - Horn speakers are the ideal match for 300B tubes because they can achieve full dynamics and musical expression with the relatively low power output of 300B tubes
   - An expert audio sales rep knows that 300B tube amplifiers and horn speakers are a classic pairing - suggesting aluminum speakers for 300B tubes shows a fundamental misunderstanding of amplifier-speaker matching
   
   CRITICAL RULE - STENHEIM/ALUMINUM SPEAKERS REQUIRE HIGH-POWERED SOLID-STATE AMPLIFIERS:
   - If the current product is a Stenheim speaker or aluminum speaker (detected by keywords like "Stenheim", "aluminum", "alumine", or manufacturer "Stenheim"), you MUST follow these rules STRICTLY:
   - Stenheim/aluminum speakers require HIGH-POWERED SOLID-STATE amplifiers for the current they need - they are not suitable for low-power tube amplifiers like 300B
   - NEVER suggest 300B tube amplifiers for Stenheim/aluminum speakers - these speakers need solid-state current delivery, not tube warmth
   - NEVER suggest low-power tube amplifiers for Stenheim/aluminum speakers - they require substantial power and current
   - ONLY suggest high-powered solid-state amplifiers (typically 100W+ into 8 ohms, with high current capability) for Stenheim/aluminum speakers
   - Look for solid-state power amplifiers or integrated amplifiers with high power ratings and strong current delivery
   - Stenheim/aluminum speakers benefit from the control, speed, and current delivery of solid-state amplification - tube amplifiers (especially low-power ones like 300B) cannot provide the current these speakers need
   - An expert audio sales rep knows that Stenheim speakers pair with high-powered solid-state amplification, not low-power tube amplifiers
   
   CRITICAL RULE - RESPECT SIGNAL CHAIN LOGIC:
   - Analog source products (turntables, phono stages, cartridges, tone arms) should ONLY pair with other analog components, speakers, amplifiers, cables, and power conditioning
   - NEVER suggest digital components (DACs, streamers, CD players) for analog source products
   - Digital source products (DACs, streamers, CD players) should ONLY pair with other digital components, speakers, amplifiers, cables, and power conditioning
   - NEVER suggest analog source components (turntables, phono stages) for digital source products
   - Speakers and amplifiers are neutral—they work with both analog and digital chains
   
   MANUFACTURER PRIORITY RULE:
   - If the current product's manufacturer also makes a component that pairs well with it, prioritize that over similar components from other manufacturers
   - This creates better system coherence and matching aesthetic/engineering philosophy
   
   Examples of good synergies:
   - High-efficiency horn speakers + low-power tube amplifiers
   - Detailed analytical DACs + warm, musical amplifiers
   - High-resolution turntables + precision phono stages
   - Revealing speakers + forgiving source components
   - Same-manufacturer preamp + power amp combinations

2. **"ALSO CONSIDER" (MINIMUM 2 products, up to 4 alternative products)**
   You MUST suggest at least 2 alternatives if any exist in the price range. If fewer than 2 qualify, return what you can find.
   These are direct alternatives in the SAME category with STRICT price matching:
   - Must be EXACTLY the same product category (${currentProduct.categories?.name})
   - Current product price: $${currentProduct.price || 'N/A'}
   - CALCULATE THE EXACT PRICE RANGE: $${currentProduct.price ? Math.round(currentProduct.price * 0.7) : 'N/A'} to $${currentProduct.price ? Math.round(currentProduct.price * 1.3) : 'N/A'}
   - ONLY suggest products whose price falls within $${currentProduct.price ? Math.round(currentProduct.price * 0.7) : 'N/A'}-$${currentProduct.price ? Math.round(currentProduct.price * 1.3) : 'N/A'}
   - DO NOT suggest products outside this range - VERIFY each product's price before including it
   - Should offer similar performance tier but perhaps different sonic signature or features
   - If NO products meet these strict criteria, return EMPTY array for "alsoConsider"

CRITICAL RULES - NO EXCEPTIONS:
- Only use product IDs from the inventory list (exact UUID strings in format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)
- NEVER use product names, model numbers, or any other identifiers - ONLY use the exact "id" field from the inventory
- For "Good Synergies": Focus on characteristics and compatibility, not rigid type rules
- MANUFACTURER PRIORITY: Always prioritize same-manufacturer components over similar ones from other manufacturers
- For "Also Consider": 
  * MUST be same category (e.g., "Interconnects" → only "Interconnects", "Speaker Cables" → only "Speaker Cables")
  * MUST be within 30% price range (calculate: current price × 0.7 to current price × 1.3)
  * If no products meet these criteria, return empty array for "alsoConsider"
- If no logical pairings exist, return empty arrays
- Consider the product descriptions to understand technical characteristics

PRICE CALCULATION EXAMPLE:
- Product costs $3,000 → "Also Consider" must be between $2,100 and $3,900 (30% tolerance)
- Product costs $10,000 → "Also Consider" must be between $7,000 and $13,000 (30% tolerance)

CRITICAL RULES FOR REASONING TEXT:
- NEVER mention price, budget, cost, value, or any financial terms
- NEVER mention price ranges like "$7,000-$13,000" or "acceptable price range"
- Focus ONLY on technical characteristics, sonic qualities, and compatibility
- Explain WHY components work together based on specifications and sound
- Example good reasoning: "These speakers' high efficiency pairs perfectly with low-power tube amplification"
- Example BAD reasoning: "These products occupy similar price points" or "within acceptable price range"

FORBIDDEN PHRASES IN REASONING:
- "price point", "price range", "budget", "cost", "value proposition"
- "acceptable price", "similar pricing", "price tier"
- Any mention of dollar amounts or financial considerations
- "afford", "expensive", "cheap", "premium pricing"

REQUIRED APPROACH:
- Discuss ONLY technical specifications and sonic characteristics
- Explain compatibility based on impedance, power, efficiency, etc.
- Describe sound signatures: warm, analytical, detailed, musical, etc.
- Mention build quality, engineering philosophy, design approach

PER-PRODUCT CARD NOTES:
- Return one short note per product ID in pairsNotes and alsoNotes.
- The keys in pairsNotes MUST exactly match the product IDs in pairsWellWith.
- The keys in alsoNotes MUST exactly match the product IDs in alsoConsider.
- Each note should be 60-90 characters, one sentence fragment, and specific to that product.
- Cards answer "why this specific product is here"; section text explains the broader story.
- For pairsNotes, focus on role, compatibility, voicing, topology, or system-building logic.
- For alsoNotes, focus on the comparison angle: warmer, faster, more spacious, more compact, different topology, different voicing.
- Do not mention price, budget, value, or cost.
- Avoid generic phrases like "great match", "excellent choice", or "high quality option".

3. **BRIEF DESCRIPTION (SEO-optimized, 150-250 characters)**
   Write a compelling, SEO-optimized brief description that:
   - Captures the essence and key selling points of the product
   - Includes relevant keywords naturally (manufacturer, category, key features)
   - Is compelling enough to drive clicks in search results
   - Maintains the premium, sophisticated tone appropriate for high-end audio
   - Focuses on what makes this product special or unique
   - Be concise and impactful, use active voice
   - Highlight technical excellence and sonic characteristics when relevant
   - Avoid generic marketing fluff - make every word count

Return your results by calling the ${PRODUCT_SUGGESTIONS_TOOL} tool. Use exact product UUIDs from the inventory for pairsWellWith and alsoConsider. pairsNotes keys must match pairsWellWith IDs; alsoNotes keys must match alsoConsider IDs.`;

  try {
    const message = await anthropic.messages.create({
      model: DEFAULT_ANTHROPIC_MODEL,
      max_tokens: DEFAULT_ANTHROPIC_MAX_TOKENS,
      tools: [productSuggestionsToolDefinition],
      tool_choice: { type: 'tool', name: PRODUCT_SUGGESTIONS_TOOL },
      messages: [{
        role: 'user',
        content: prompt,
      }],
    });

    if (message.stop_reason === 'max_tokens') {
      throw new Error('AI response was truncated before completion. Please try Flesh Out again.');
    }

    const suggestions = extractToolUseInput<RawProductSuggestions>(
      message.content,
      PRODUCT_SUGGESTIONS_TOOL
    );

    if (!suggestions) {
      throw new Error('AI did not return structured product suggestions. Please try Flesh Out again.');
    }
    
    // Ensure brief description is within limits and has fallback
    const briefDescription = suggestions.briefDescription 
      ? suggestions.briefDescription.substring(0, 300)
      : `${currentProduct.manufacturer?.name || ''} ${currentProduct.title} - ${currentProduct.categories?.name || 'High-end audio component'}`.substring(0, 300);
    
    const pairsWellWith = suggestions.pairsWellWith || [];
    const alsoConsider = suggestions.alsoConsider || [];

    return {
      pairsWellWith,
      pairsNotes: normalizeRelationshipNotes(suggestions.pairsNotes, pairsWellWith),
      pairsReasoning: suggestions.pairsReasoning || '',
      pairsCTA: suggestions.pairsCTA || '',
      pairsHelper: suggestions.pairsHelper || '',
      alsoConsider,
      alsoNotes: normalizeRelationshipNotes(suggestions.alsoNotes, alsoConsider),
      alsoReasoning: suggestions.alsoReasoning || '',
      alsoCTA: suggestions.alsoCTA || '',
      alsoHelper: suggestions.alsoHelper || '',
      briefDescription
    };
  } catch (error) {
    console.error('Error generating AI suggestions:', error);
    throw new Error(formatAnthropicError(error));
  }
}

// Batch processing function for multiple products
export async function generateBatchProductSuggestions({
  products,
  allProducts
}: BatchSuggestionContext): Promise<BatchProductSuggestions> {
  // Build inventory list (shared across all products)
  const productList = allProducts
    .filter(p => p.published !== false)
    .slice(0, 150) // Reduced to 150 for batch processing
    .map(p => ({
      id: p.id,
      title: p.title,
      category: p.categories?.name,
      manufacturer: p.manufacturer?.name,
      price: p.price,
      brief_description: p.brief_description?.substring(0, 200), // First 200 chars for context
      content_excerpt: p.content?.substring(0, 300) // First 300 chars for technical details
    }));

  // Build batch request
  const productsToAnalyze = products.map(p => ({
    id: p.id,
    title: p.title,
    manufacturer: p.manufacturer?.name,
    category: p.categories?.name,
    price: p.price
  }));

  const prompt = `You are a seasoned high-end audio specialist with decades of experience matching components. Your expertise includes understanding power requirements, impedance matching, sonic characteristics (warm/analytical), and system synergies.

IMPORTANT: For "Also Consider" suggestions, you MUST follow these rules strictly:
1. Same category only (e.g., "Interconnects" → only "Interconnects")
2. Price within 30% range: calculate (current_price × 0.7) to (current_price × 1.3)
3. If no products meet these criteria, return empty "alsoConsider" array

CRITICAL: Use ONLY the exact "id" field from the inventory list (UUID format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx). NEVER use product names, model numbers, or any other identifiers.

PRODUCTS TO ANALYZE (${productsToAnalyze.length} products):
${JSON.stringify(productsToAnalyze, null, 2)}

INVENTORY (${productList.length} products):
${JSON.stringify(productList, null, 2)}

TASK:
For EACH product in the "PRODUCTS TO ANALYZE" list:

1. **"GOOD SYNERGIES" (3-6 products that complement this product)**
   Think like an audiophile building a complete system. Consider:
   - Power matching: Does a speaker need high power or work with low-watt tube amps?
   - Sonic character: Do warm tubes complement analytical speakers? Do forgiving components pair with revealing sources?
   - System building: What components complete a logical audio chain?
   - Technical compatibility: Impedance, sensitivity, output voltage, etc.
   - Price is flexible here - focus on sonic and technical synergy

2. **"ALSO CONSIDER" (2-4 alternative products)**
   These are direct alternatives in the SAME category with STRICT price matching:
   - Must be EXACTLY the same product category (e.g., if current is "Interconnects", suggest only other "Interconnects")
   - Must be within 30% of current product price - CALCULATE THIS: for $10,000 product, only suggest $7,000-$13,000 range
   - Should offer similar performance tier but perhaps different sonic signature or features

CRITICAL RULES - NO EXCEPTIONS:
- Only use product IDs from the inventory list (exact UUID strings in format: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)
- NEVER use product names, model numbers, or any other identifiers - ONLY use the exact "id" field from the inventory
- For "Good Synergies": Focus on characteristics and compatibility, not rigid type rules
- MANUFACTURER PRIORITY: Always prioritize same-manufacturer components over similar ones from other manufacturers
- For "Also Consider": 
  * MUST be same category (e.g., "Interconnects" → only "Interconnects", "Speaker Cables" → only "Speaker Cables")
  * MUST be within 30% price range (calculate: current price × 0.7 to current price × 1.3)
  * If no products meet these criteria, return empty array for "alsoConsider"
- If no logical pairings exist, return empty arrays
- Consider the product descriptions to understand technical characteristics

PRICE CALCULATION EXAMPLE:
- Product costs $3,000 → "Also Consider" must be between $2,100 and $3,900 (30% tolerance)
- Product costs $10,000 → "Also Consider" must be between $7,000 and $13,000 (30% tolerance)

Response format (JSON only):
{
  "suggestions": [
    {
      "productId": "uuid-of-product-1",
      "pairsWellWith": ["uuid1", "uuid2", ...],
      "pairsReasoning": "Explain the audiophile logic behind these synergies, noting manufacturer priority when applicable",
      "alsoConsider": ["uuid3", "uuid4", ...],
      "alsoReasoning": "Explain why these alternatives are comparable"
    },
    {
      "productId": "uuid-of-product-2",
      "pairsWellWith": [...],
      "pairsReasoning": "...",
      "alsoConsider": [...],
      "alsoReasoning": "..."
    }
  ]
}`;

  try {
    const message = await anthropic.messages.create({
      model: DEFAULT_ANTHROPIC_MODEL,
      max_tokens: DEFAULT_ANTHROPIC_MAX_TOKENS,
      messages: [{
        role: 'user',
        content: prompt
      }]
    });

    const responseText = message.content[0].type === 'text' 
      ? message.content[0].text 
      : '';
    
    const jsonMatch = responseText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.error('Invalid AI batch response format:', responseText);
      return { suggestions: [] };
    }

    const result = JSON.parse(jsonMatch[0]);
    return {
      suggestions: result.suggestions || []
    };
  } catch (error) {
    console.error('Error generating batch AI suggestions:', error);
    return { suggestions: [] };
  }
}

