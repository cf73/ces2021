import { supabase } from './supabase-client';

export const getAuthHeaders = async (): Promise<Record<string, string>> => {
  const { data, error } = await supabase.auth.getSession();
  if (error) {
    console.error('Failed to read auth session:', error);
  }
  const token = data?.session?.access_token;
  return token ? { Authorization: `Bearer ${token}` } : {};
};
