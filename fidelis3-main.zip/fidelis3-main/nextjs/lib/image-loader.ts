/**
 * Custom Image Loader for Next.js Image Optimization with Supabase Storage
 * 
 * This loader enables Next.js automatic image optimization for Supabase Storage URLs.
 * It supports:
 * - Automatic WebP/AVIF conversion
 * - Responsive image sizing
 * - Quality optimization
 */

interface ImageLoaderProps {
  src: string;
  width: number;
  quality?: number;
}

export default function supabaseImageLoader({ src, width, quality }: ImageLoaderProps): string {
  // If the src is already a full URL (from Supabase), return it as-is
  // Image transformations are handled via the getImageUrl function when needed
  if (src.startsWith('http')) {
    return src;
  }
  
  // For relative paths, return as-is (local images in /public)
  return src;
}

/**
 * Generate a tiny blur placeholder for an image
 * This can be used for the blurDataURL prop in next/image
 */
export function generateBlurDataURL(width = 10, height = 10): string {
  // Create a simple gradient blur placeholder
  const canvas = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:rgb(245,245,244);stop-opacity:1" />
          <stop offset="100%" style="stop-color:rgb(231,229,228);stop-opacity:1" />
        </linearGradient>
      </defs>
      <rect width="${width}" height="${height}" fill="url(#grad)" />
    </svg>
  `;
  
  const base64 = Buffer.from(canvas).toString('base64');
  return `data:image/svg+xml;base64,${base64}`;
}

