'use client';

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { usePathname } from 'next/navigation';

interface EditModeContextType {
  isEditMode: boolean;
  toggleEditMode: (skipConfirmation?: boolean) => void;
  enableEditMode: () => void;
  hasUnsavedChanges: boolean;
  setHasUnsavedChanges: (value: boolean) => void;
  registerChange: (fieldName: string, value: any) => void;
  getChanges: () => Record<string, any>;
  clearChanges: () => void;
  isSaving: boolean;
  setIsSaving: (value: boolean) => void;
  setOriginalValues: (values: Record<string, any>) => void;
}

const EditModeContext = createContext<EditModeContextType | undefined>(undefined);

export const EditModeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isEditMode, setIsEditMode] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [changes, setChanges] = useState<Record<string, any>>({});
  const [originalValues, setOriginalValues] = useState<Record<string, any>>({});
  const [isSaving, setIsSaving] = useState(false);
  const pathname = usePathname();

  const toggleEditMode = useCallback((skipConfirmation = false) => {
    if (!skipConfirmation && isEditMode && hasUnsavedChanges) {
      const confirm = window.confirm(
        'You have unsaved changes. Are you sure you want to exit edit mode? Your changes will be lost.'
      );
      if (!confirm) return;
    }
    
    setIsEditMode(prev => !prev);
    
    if (isEditMode) {
      setChanges({});
      setOriginalValues({});
      setHasUnsavedChanges(false);
    }
  }, [isEditMode, hasUnsavedChanges]);

  const enableEditMode = useCallback(() => {
    setIsEditMode(true);
  }, []);

  // Leave edit mode and clear state when navigating to another page
  useEffect(() => {
    // Don't reset edit mode when navigating to /news/new or /products/new (create new entry)
    if (pathname === '/news/new' || pathname === '/products/new') {
      return;
    }
    setIsEditMode(false);
    setChanges({});
    setOriginalValues({});
    setHasUnsavedChanges(false);
  }, [pathname]);

  const registerChange = useCallback((fieldName: string, value: any) => {
    setChanges(prev => ({
      ...prev,
      [fieldName]: value
    }));

    // New entries (no originals) should mark unsaved as soon as something changes
    if (Object.keys(originalValues).length === 0) {
      setHasUnsavedChanges(true);
      return;
    }

    // If a field wasn't in the original set (e.g., newly added), treat as changed
    if (!(fieldName in originalValues)) {
      setHasUnsavedChanges(true);
      return;
    }

    const originalValue = originalValues[fieldName];

    // Compare values, handling undefined/null cases
    const originalStr = originalValue === undefined || originalValue === null ? '' : JSON.stringify(originalValue);
    const valueStr = value === undefined || value === null ? '' : JSON.stringify(value);
    const hasChanged = originalStr !== valueStr;

    if (hasChanged) {
      setHasUnsavedChanges(true);
    }
  }, [originalValues]);

  const getChanges = useCallback(() => {
    return changes;
  }, [changes]);

  const clearChanges = useCallback(() => {
    setChanges({});
    setOriginalValues({});
    setHasUnsavedChanges(false);
  }, []);

  const handleSetOriginalValues = useCallback((values: Record<string, any>) => {
    setOriginalValues(values);
    // Clear unsaved changes flag when original values are set
    // This ensures we start fresh when entering edit mode
    setHasUnsavedChanges(false);
    setChanges({});
  }, []);

  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (hasUnsavedChanges) {
        e.preventDefault();
        e.returnValue = '';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [hasUnsavedChanges]);

  const value = {
    isEditMode,
    toggleEditMode,
    enableEditMode,
    hasUnsavedChanges,
    setHasUnsavedChanges,
    registerChange,
    getChanges,
    clearChanges,
    isSaving,
    setIsSaving,
    setOriginalValues: handleSetOriginalValues
  };

  return (
    <EditModeContext.Provider value={value}>
      {children}
    </EditModeContext.Provider>
  );
};

export const useEditMode = () => {
  const context = useContext(EditModeContext);
  if (context === undefined) {
    throw new Error('useEditMode must be used within an EditModeProvider');
  }
  return context;
};

