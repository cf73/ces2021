'use client';

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import type { BusinessInfo, StoreHourEntry } from '../lib/supabase';

interface SiteGlobalsContextValue {
  businessInfo: BusinessInfo | null;
  isLoading: boolean;
  error: string | null;
  refreshBusinessInfo: () => Promise<void>;
  setBusinessInfo: (info: BusinessInfo | null) => void;
}

const SiteGlobalsContext = createContext<SiteGlobalsContextValue | undefined>(undefined);

const normalizeBusinessInfo = (info: BusinessInfo | null): BusinessInfo | null => {
  if (!info) return null;
  const normalizedHours = Array.isArray(info.store_hours)
    ? info.store_hours.map((entry: StoreHourEntry) => ({
        label: entry?.label ?? '',
        value: entry?.value ?? '',
      }))
    : [];
  return {
    ...info,
    store_hours: normalizedHours,
  };
};

export function SiteGlobalsProvider({ children }: { children: React.ReactNode }) {
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchBusinessInfo = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/site-globals/business-info', { cache: 'no-store' });
      if (!response.ok) {
        throw new Error('Failed to load site globals.');
      }
      const data = await response.json();
      setBusinessInfo(normalizeBusinessInfo(data));
    } catch (err) {
      console.error('Failed to load business info:', err);
      setError(err instanceof Error ? err.message : 'Unable to load business info.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchBusinessInfo();
  }, [fetchBusinessInfo]);

  const value = useMemo(
    () => ({
      businessInfo,
      isLoading,
      error,
      refreshBusinessInfo: fetchBusinessInfo,
      setBusinessInfo: (info: BusinessInfo | null) => setBusinessInfo(normalizeBusinessInfo(info)),
    }),
    [businessInfo, error, fetchBusinessInfo, isLoading]
  );

  return (
    <SiteGlobalsContext.Provider value={value}>
      {children}
    </SiteGlobalsContext.Provider>
  );
}

export function useSiteGlobals() {
  const context = useContext(SiteGlobalsContext);
  if (!context) {
    throw new Error('useSiteGlobals must be used within a SiteGlobalsProvider');
  }
  return context;
}

