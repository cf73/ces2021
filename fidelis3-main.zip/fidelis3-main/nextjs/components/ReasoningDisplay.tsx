'use client';

import Link from 'next/link';
import { Button } from './ui/Button';
import { formatReasoningText } from '../lib/format-reasoning-text';

interface ReasoningDisplayProps {
  heading: string; // "Why these pair well:" or "Why these alternatives:"
  reasoning: string;
  cta?: string;
  helper?: string;
  ctaHref: string;
  ctaMessage: string;
  showHeader?: boolean;
}

export function ReasoningDisplay({
  heading,
  reasoning,
  cta,
  helper,
  ctaHref,
  ctaMessage,
  showHeader = true,
}: ReasoningDisplayProps) {
  const formatted = formatReasoningText(reasoning);

  return (
    <div className="mt-16 pt-12">
      {/* Subtle section header */}
      {showHeader && (
        <div className="mb-8">
          <div className="flex items-center">
            <div className="flex-grow border-t border-stone-300"></div>
            <div className="mx-4 px-4">
              <span className="text-sm font-medium text-stone-500 tracking-wider uppercase">About These Recommendations</span>
            </div>
            <div className="flex-grow border-t border-stone-300"></div>
          </div>
        </div>
      )}

      {/* Two-column layout with vertical divider */}
      <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
        {/* Left Column: Reasoning */}
        <div className="flex-[2]">
          <h3 className="text-base font-semibold text-stone-900 mb-4">{heading}</h3>
          
          {formatted.hasMultiplePoints ? (
            // Bulleted format for multiple points
            <ul className="space-y-3 text-base leading-relaxed text-stone-700">
              {formatted.sentences.map((sentence, index) => (
                <li key={index} className="flex items-start">
                  <span className="text-stone-400 mr-3 mt-1.5 flex-shrink-0">•</span>
                  <span>{sentence}</span>
                </li>
              ))}
            </ul>
          ) : (
            // Paragraph format for single point
            <div className="prose prose-stone max-w-none">
              <p className="text-base leading-relaxed text-stone-700">
                {formatted.sentences[0] || reasoning}
              </p>
            </div>
          )}
        </div>

        {/* Vertical Divider - hidden on mobile */}
        <div className="hidden lg:block w-px bg-stone-300 flex-shrink-0" />

        {/* Right Column: CTA */}
        {cta && (
          <div className="flex-[1]">
            <h3 className="text-base font-semibold text-stone-900 mb-4">{cta}</h3>
            <div className="space-y-4">
              {helper && (
                <p className="text-base text-stone-600 leading-relaxed">
                  {helper}
                </p>
              )}
              <Button
                href={ctaHref}
                variant="outline-bold"
                size="sm"
              >
                Let's Talk!
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

