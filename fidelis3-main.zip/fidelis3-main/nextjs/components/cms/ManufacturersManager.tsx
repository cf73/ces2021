'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { getAuthHeaders } from '../../lib/auth-headers';

interface ManufacturerSummary {
  id: string;
  name: string;
  slug: string;
  published: boolean;
  product_count: number;
}

type ActionType = 'archive' | 'unarchive' | 'delete';

interface ActionState {
  id: string;
  type: ActionType;
}

export function ManufacturersManager() {
  const [manufacturers, setManufacturers] = useState<ManufacturerSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [actionState, setActionState] = useState<ActionState | null>(null);

  const loadManufacturers = useCallback(async () => {
    setLoading(true);
    setErrorMessage(null);
    try {
      const authHeaders = await getAuthHeaders();
      const response = await fetch('/api/site-globals/manufacturers', {
        headers: authHeaders,
      });
      if (!response.ok) {
        throw new Error('Failed to load manufacturers');
      }
      const data = await response.json();
      setManufacturers(data.manufacturers || []);
    } catch (error) {
      console.error('Failed to fetch manufacturers:', error);
      setErrorMessage('Unable to load manufacturers. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadManufacturers();
  }, [loadManufacturers]);

  const publishedManufacturers = useMemo(
    () => manufacturers.filter((manufacturer) => manufacturer.published !== false),
    [manufacturers]
  );

  const archivedManufacturers = useMemo(
    () => manufacturers.filter((manufacturer) => manufacturer.published === false),
    [manufacturers]
  );

  const isProcessing = (id: string, type: ActionType) =>
    actionState?.id === id && actionState?.type === type;

  const handleArchiveToggle = async (
    manufacturer: ManufacturerSummary,
    nextPublished: boolean
  ) => {
    const productCount = manufacturer.product_count;
    const productCopy =
      productCount === 1 ? '1 linked product' : `${productCount} linked products`;
    const warningText = nextPublished
      ? `This will republish ${productCopy}.`
      : `Archiving will unpublish ${productCopy}.`;

    const confirm = window.confirm(
      `${warningText}\n\nDo you want to ${
        nextPublished ? 'unarchive' : 'archive'
      } ${manufacturer.name}?`
    );

    if (!confirm) return;

    setActionState({ id: manufacturer.id, type: nextPublished ? 'unarchive' : 'archive' });
    setStatusMessage(null);
    setErrorMessage(null);

    try {
      const authHeaders = await getAuthHeaders();
      const response = await fetch(`/api/manufacturers/${manufacturer.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders,
        },
        body: JSON.stringify({ published: nextPublished }),
      });

      if (!response.ok) {
        const data = await response.json().catch(() => null);
        throw new Error(data?.error || 'Failed to update manufacturer.');
      }

      setStatusMessage(
        nextPublished
          ? `${manufacturer.name} has been republished.`
          : `${manufacturer.name} has been archived.`
      );
      await loadManufacturers();
    } catch (error) {
      console.error('Failed to update manufacturer publish state:', error);
      setErrorMessage('Failed to update manufacturer. Please try again.');
    } finally {
      setActionState(null);
    }
  };

  const handlePermanentDelete = async (manufacturer: ManufacturerSummary) => {
    const productCount = manufacturer.product_count;
    const productCopy =
      productCount === 1 ? '1 linked product' : `${productCount} linked products`;
    const confirm = window.confirm(
      `Deleting ${manufacturer.name} will permanently remove ${productCopy}. This cannot be undone.\n\nAre you sure you want to continue?`
    );

    if (!confirm) return;

    setActionState({ id: manufacturer.id, type: 'delete' });
    setStatusMessage(null);
    setErrorMessage(null);

    try {
      const authHeaders = await getAuthHeaders();
      const response = await fetch(`/api/manufacturers/${manufacturer.id}`, {
        method: 'DELETE',
        headers: authHeaders,
      });

      if (!response.ok) {
        const data = await response.json().catch(() => null);
        throw new Error(data?.error || 'Failed to delete manufacturer.');
      }

      setStatusMessage(`${manufacturer.name} has been deleted permanently.`);
      await loadManufacturers();
    } catch (error) {
      console.error('Failed to delete manufacturer:', error);
      setErrorMessage('Failed to delete manufacturer. Please try again.');
    } finally {
      setActionState(null);
    }
  };

  if (loading) {
    return (
      <div className="rounded-2xl border border-stone-100 bg-white/70 px-4 py-6 text-sm text-stone-500">
        Loading manufacturers…
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {(statusMessage || errorMessage) && (
        <div
          className={`rounded-xl border px-4 py-3 text-sm ${
            errorMessage
              ? 'border-red-200 bg-red-50 text-red-700'
              : 'border-emerald-200 bg-emerald-50 text-emerald-700'
          }`}
        >
          {errorMessage || statusMessage}
        </div>
      )}

      <section className="space-y-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.35em] text-stone-500">
            Active manufacturers
          </p>
          <h3 className="text-2xl font-light text-stone-900">Currently live on site</h3>
        </div>

        {publishedManufacturers.length === 0 ? (
          <p className="text-sm text-stone-500">
            No active manufacturers found. Use the archive tab to republish a brand or create a
            new one from the manufacturers page.
          </p>
        ) : (
          <div className="grid gap-4 lg:grid-cols-2">
            {publishedManufacturers.map((manufacturer) => (
              <div
                key={manufacturer.id}
                className="rounded-2xl border border-stone-200 bg-white/80 p-5 shadow-sm"
              >
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-base font-semibold text-stone-900">{manufacturer.name}</p>
                      <p className="text-xs uppercase tracking-[0.3em] text-stone-400">
                        {manufacturer.product_count} linked{' '}
                        {manufacturer.product_count === 1 ? 'product' : 'products'}
                      </p>
                    </div>
                    <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                      Live
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => handleArchiveToggle(manufacturer, false)}
                      disabled={isProcessing(manufacturer.id, 'archive')}
                      className="inline-flex items-center rounded-full border border-stone-300 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.25em] text-stone-700 transition-colors duration-200 hover:bg-stone-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isProcessing(manufacturer.id, 'archive') ? 'Archiving…' : 'Archive'}
                    </button>
                    <Link
                      href={`/manufacturers/${manufacturer.slug}`}
                      className="inline-flex items-center rounded-full border border-stone-900 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.25em] text-stone-900 transition-colors duration-200 hover:bg-stone-900 hover:text-white"
                    >
                      Open Detail
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="space-y-4">
        <div className="flex flex-col gap-2">
          <p className="text-xs font-semibold uppercase tracking-[0.35em] text-stone-500">
            Archived manufacturers
          </p>
          <h3 className="text-2xl font-light text-stone-900">Bring a partner back to life</h3>
          <p className="text-sm text-stone-500">
            Archived brands stay hidden from the public site. Use this section to republish them or
            delete them permanently.
          </p>
        </div>

        {archivedManufacturers.length === 0 ? (
          <p className="text-sm text-stone-500">No archived manufacturers at the moment.</p>
        ) : (
          <div className="grid gap-4 lg:grid-cols-2">
            {archivedManufacturers.map((manufacturer) => (
              <div
                key={manufacturer.id}
                className="rounded-2xl border border-stone-200 bg-white/80 p-5 shadow-sm"
              >
                <div className="flex flex-col gap-3">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-base font-semibold text-stone-900">{manufacturer.name}</p>
                      <p className="text-xs uppercase tracking-[0.3em] text-stone-400">
                        {manufacturer.product_count} linked{' '}
                        {manufacturer.product_count === 1 ? 'product' : 'products'}
                      </p>
                    </div>
                    <span className="rounded-full bg-stone-100 px-3 py-1 text-xs font-semibold text-stone-600">
                      Archived
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => handleArchiveToggle(manufacturer, true)}
                      disabled={isProcessing(manufacturer.id, 'unarchive')}
                      className="inline-flex items-center rounded-full border border-stone-900 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.25em] text-stone-900 transition-colors duration-200 hover:bg-stone-900 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isProcessing(manufacturer.id, 'unarchive') ? 'Restoring…' : 'Unarchive'}
                    </button>
                    <button
                      onClick={() => handlePermanentDelete(manufacturer)}
                      disabled={isProcessing(manufacturer.id, 'delete')}
                      className="inline-flex items-center rounded-full border border-red-300 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.25em] text-red-600 transition-colors duration-200 hover:bg-red-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isProcessing(manufacturer.id, 'delete') ? 'Deleting…' : 'Delete'}
                    </button>
                    <Link
                      href={`/manufacturers/${manufacturer.slug}`}
                      className="inline-flex items-center rounded-full border border-stone-300 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.25em] text-stone-600 transition-colors duration-200 hover:bg-stone-50"
                    >
                      Open Detail
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

