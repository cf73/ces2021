'use client';

import { useState } from 'react';
import type { Product } from '../../lib/supabase';
import { searchProducts, getImageUrl } from '../../lib/supabase-queries';
import { CMSButton } from './CMSButton';

interface ProductSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (productId: string) => void;
  excludeIds: string[];
}

export function ProductSearchModal({ isOpen, onClose, onAdd, excludeIds }: ProductSearchModalProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Product[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  
  const handleSearch = async (q: string) => {
    setQuery(q);
    if (q.length < 2) {
      setResults([]);
      return;
    }
    
    setLoading(true);
    try {
      const products = await searchProducts(q);
      setResults(products.filter(p => !excludeIds.includes(p.id)));
    } catch (error) {
      console.error('Error searching products:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleAdd = () => {
    if (selectedId) {
      onAdd(selectedId);
      setQuery('');
      setResults([]);
      setSelectedId(null);
      onClose();
    }
  };
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/20" onClick={onClose} />
      <div className="relative w-full max-w-2xl rounded-[32px] border border-white/40 bg-white/70 p-8 shadow-[0_45px_120px_rgba(15,15,15,0.5)] backdrop-blur-2xl max-h-[80vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-4 mb-6">
          <div>
            <h3 className="text-2xl font-semibold text-stone-900">Search Products</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-full border border-stone-200/60 bg-white/60 p-2 text-stone-500 hover:bg-white"
          >
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="relative mb-6">
          <input
            type="text"
            value={query}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Search by product name or manufacturer..."
            className="w-full rounded-2xl border border-white/60 bg-white/80 px-5 py-3 pr-12 text-base shadow-inner shadow-white/40 focus:border-stone-900 focus:outline-none"
            autoFocus
          />
          {query.length > 0 && (
            <button
              type="button"
              onClick={() => handleSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full border border-stone-200/60 bg-white/70 p-1 text-stone-500 hover:bg-white focus:outline-none focus:ring-2 focus:ring-stone-400"
              aria-label="Clear search"
            >
              <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>
        
        {loading && (
          <div className="text-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-stone-600 mx-auto"></div>
          </div>
        )}
        
        <div className="space-y-3 mb-8 max-h-96 overflow-y-auto pr-1">
          {!loading && results.map(product => (
            <button
              key={product.id}
              onClick={() => setSelectedId(product.id)}
              className={`w-full rounded-2xl border-2 transition-all text-left flex items-center gap-4 px-4 py-3 backdrop-blur ${
                selectedId === product.id 
                  ? 'border-stone-900 bg-white/90'
                  : 'border-white/80 bg-white/60 hover:border-stone-500 hover:bg-white/80'
              }`}
            >
              {product.product_hero_image && (
                <img 
                  src={getImageUrl(product.product_hero_image)} 
                  alt={product.title}
                  className="w-16 h-16 object-cover rounded"
                />
              )}
              <div>
                <div className="font-medium">{product.title}</div>
                <div className="text-sm text-stone-600">{product.manufacturer?.name}</div>
              </div>
            </button>
          ))}
        </div>
        
        <div className="flex gap-2 justify-end">
          <CMSButton variant="ghost" onClick={onClose}>
            Cancel
          </CMSButton>
          <CMSButton variant="primary" onClick={handleAdd} disabled={!selectedId}>
            Add Product
          </CMSButton>
        </div>
      </div>
    </div>
  );
}

