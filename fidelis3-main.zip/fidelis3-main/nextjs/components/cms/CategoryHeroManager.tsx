'use client';

import Image from 'next/image';
import { useEffect, useMemo, useState } from 'react';
import { updateCategoryHeroProduct, getImageUrl } from '../../lib/supabase-queries';
import { PlusIcon, PencilSquareIcon, TrashIcon, CheckIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { getAuthHeaders } from '../../lib/auth-headers';

interface CategoryHeroManagerProps {
  onClose?: () => void;
}

interface HeroCategory {
  id: string;
  name: string;
  hero_product_id?: string | null;
}

interface HeroProduct {
  id: string;
  title: string;
  slug: string;
  product_hero_image?: string | null;
  category_id?: string | null;
}

interface ApiResponse {
  categories: HeroCategory[];
  products: HeroProduct[];
}

interface CategoryOption extends HeroCategory {
  products: HeroProduct[];
}

export function CategoryHeroManager({ onClose }: CategoryHeroManagerProps) {
  const [categories, setCategories] = useState<HeroCategory[]>([]);
  const [products, setProducts] = useState<HeroProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [creating, setCreating] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renamingValue, setRenamingValue] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const authHeaders = await getAuthHeaders();
      const response = await fetch('/api/site-globals/category-heroes', {
        headers: authHeaders,
      });
      if (!response.ok) {
        throw new Error('Failed to load category data');
      }
      const data: ApiResponse = await response.json();
      setCategories(data.categories);
      setProducts(data.products);
    } catch (error) {
      console.error('Failed to load category hero data:', error);
      setStatusMessage('Failed to load category data. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const categoryOptions: CategoryOption[] = useMemo(() => {
    return categories.map(category => ({
      ...category,
      products: products.filter(
        product => product.category_id === category.id && product.product_hero_image
      ),
    }));
  }, [categories, products]);

  const handleSelection = async (categoryId: string, productId: string | null) => {
    // Optimistically update to avoid scroll resets
    setCategories(prev =>
      prev.map(category =>
        category.id === categoryId
          ? { ...category, hero_product_id: productId || null }
          : category
      )
    );

    const previousValue =
      categories.find(category => category.id === categoryId)?.hero_product_id || null;

    try {
      setUpdating(categoryId);
      await updateCategoryHeroProduct(categoryId, productId);
    } catch (error) {
      console.error('Failed to update category hero product:', error);
      setStatusMessage('Failed to update category hero image.');
      // Revert optimistic update on failure
      setCategories(prev =>
        prev.map(category =>
          category.id === categoryId
            ? { ...category, hero_product_id: previousValue }
            : category
        )
      );
    } finally {
      setUpdating(null);
      setTimeout(() => setStatusMessage(null), 4000);
    }
  };

  const handleCreate = async (event: React.FormEvent) => {
    event.preventDefault();
    if (!newCategoryName.trim()) return;
    try {
      setCreating(true);
      const authHeaders = await getAuthHeaders();
      const response = await fetch('/api/site-globals/category-heroes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({ name: newCategoryName.trim() }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to create category');
      setNewCategoryName('');
      setStatusMessage('Category created.');
      await loadData();
    } catch (error) {
      console.error(error);
      setStatusMessage('Failed to create category.');
    } finally {
      setCreating(false);
      setTimeout(() => setStatusMessage(null), 4000);
    }
  };

  const handleRename = async (categoryId: string) => {
    if (!renamingValue.trim()) return;
    try {
      setUpdating(categoryId);
      const authHeaders = await getAuthHeaders();
      const response = await fetch('/api/site-globals/category-heroes', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({ id: categoryId, name: renamingValue.trim() }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to rename category');
      setRenamingId(null);
      setRenamingValue('');
      setStatusMessage('Category renamed.');
      await loadData();
    } catch (error) {
      console.error(error);
      setStatusMessage('Failed to rename category.');
    } finally {
      setUpdating(null);
      setTimeout(() => setStatusMessage(null), 4000);
    }
  };

  const handleDelete = async (categoryId: string) => {
    const confirm = window.confirm(
      'Delete this category? Products attached to it will lose their category reference.'
    );
    if (!confirm) return;
    try {
      setDeletingId(categoryId);
      const authHeaders = await getAuthHeaders();
      const response = await fetch('/api/site-globals/category-heroes', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({ id: categoryId }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Failed to delete category');
      setStatusMessage('Category deleted.');
      await loadData();
    } catch (error) {
      console.error(error);
      setStatusMessage((error as Error).message || 'Failed to delete category.');
    } finally {
      setDeletingId(null);
      setTimeout(() => setStatusMessage(null), 4000);
    }
  };

  if (loading) {
    return (
      <div className="rounded-lg border border-stone-200 bg-white/80 px-4 py-6 text-sm text-stone-600">
        Loading categories…
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      <form
        onSubmit={handleCreate}
        className="rounded-2xl border border-dashed border-stone-300 bg-white/70 p-4 shadow-sm"
      >
        <label className="text-xs font-semibold uppercase tracking-wide text-stone-500">
          Add a category
        </label>
        <div className="mt-2 flex flex-col gap-3 sm:flex-row">
          <input
            type="text"
            value={newCategoryName}
            onChange={(e) => setNewCategoryName(e.target.value)}
            placeholder="e.g., Digital Sources"
            className="flex-1 rounded-lg border border-stone-300 bg-white px-3 py-2 text-sm focus:border-stone-500 focus:outline-none"
            disabled={creating}
          />
          <button
            type="submit"
            disabled={creating}
            className="inline-flex items-center justify-center rounded-lg bg-stone-900 px-4 py-2 text-sm font-medium text-white shadow hover:bg-stone-800 disabled:opacity-40"
          >
            <PlusIcon className="mr-2 h-4 w-4" />
            Add
          </button>
        </div>
      </form>

      {statusMessage && (
        <div className="rounded-lg border border-stone-200 bg-stone-50 px-3 py-2 text-xs text-stone-700">
          {statusMessage}
        </div>
      )}

      <div className="grid max-h-[55vh] gap-4 overflow-y-auto pr-1 sm:grid-cols-2">
        {categoryOptions.map(category => {
          const selectedProduct = category.products.find(product => product.id === category.hero_product_id);
          const previewImage = selectedProduct?.product_hero_image
            ? getImageUrl(selectedProduct.product_hero_image)
            : null;

          return (
            <div
              key={category.id}
              className="flex flex-col rounded-2xl border border-stone-200 bg-white shadow-sm"
            >
              <div className="relative h-40 w-full overflow-hidden rounded-t-2xl bg-stone-100">
                {previewImage ? (
                  <Image
                    src={previewImage}
                    alt={selectedProduct?.title || 'Hero preview'}
                    fill
                    className="object-cover"
                  />
                ) : (
                  <div className="flex h-full w-full flex-col items-center justify-center text-stone-400">
                    <svg className="h-10 w-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={1.5}
                        d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                    <p className="mt-2 text-xs font-medium text-stone-400">No hero image</p>
                  </div>
                )}
                {selectedProduct && (
                  <div className="absolute bottom-3 left-3 rounded-full bg-white/80 px-3 py-1 text-xs font-medium text-stone-700 shadow">
                    {selectedProduct.title}
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-3 p-4">
                <div className="flex items-start justify-between gap-2">
                  {renamingId === category.id ? (
                    <div className="flex w-full items-center gap-2">
                      <input
                        value={renamingValue}
                        onChange={(e) => setRenamingValue(e.target.value)}
                        className="flex-1 rounded-lg border border-stone-300 px-3 py-2 text-sm focus:border-stone-500 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() => handleRename(category.id)}
                        className="inline-flex items-center rounded-md bg-emerald-600 p-2 text-white hover:bg-emerald-500"
                      >
                        <CheckIcon className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setRenamingId(null);
                          setRenamingValue('');
                        }}
                        className="inline-flex items-center rounded-md border border-stone-300 p-2 text-stone-500 hover:bg-stone-50"
                      >
                        <XMarkIcon className="h-4 w-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <div>
                        <p className="text-base font-semibold text-stone-900">{category.name}</p>
                        <p className="text-xs text-stone-500">
                          {category.products.length} product{category.products.length === 1 ? '' : 's'} with hero imagery
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            setRenamingId(category.id);
                            setRenamingValue(category.name);
                          }}
                          className="rounded-md border border-stone-200 p-2 text-stone-500 hover:bg-stone-50"
                        >
                          <PencilSquareIcon className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(category.id)}
                          disabled={deletingId === category.id}
                          className="rounded-md border border-stone-200 p-2 text-stone-500 hover:bg-stone-50 disabled:opacity-40"
                        >
                          <TrashIcon className="h-4 w-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>

                <div>
                  <label className="mb-1 block text-xs font-semibold uppercase tracking-wide text-stone-500">
                    Hero product
                  </label>
                  <select
                    value={category.hero_product_id || ''}
                    onChange={(e) => handleSelection(category.id, e.target.value || null)}
                    disabled={updating === category.id || category.products.length === 0}
                    className="w-full rounded-lg border border-stone-300 bg-white px-3 py-2 text-sm focus:border-stone-500 focus:outline-none"
                  >
                    <option value="">Automatic selection</option>
                    {category.products.map(product => (
                      <option key={product.id} value={product.id}>
                        {product.title}
                      </option>
                    ))}
                  </select>
                  {category.products.length === 0 && (
                    <p className="mt-1 text-[11px] text-stone-500">
                      Add a published product with a hero image to this category to enable manual selection.
                    </p>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {onClose && (
        <button
          onClick={onClose}
          className="inline-flex items-center justify-center rounded-md border border-stone-300 px-3 py-2 text-xs font-medium text-stone-700 hover:bg-white"
        >
          Close
        </button>
      )}
    </div>
  );
}

