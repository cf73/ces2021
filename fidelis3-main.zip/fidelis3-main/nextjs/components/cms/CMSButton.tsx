'use client';

import React from 'react';

interface CMSButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  type?: 'button' | 'submit' | 'reset';
  onClick?: () => void;
  disabled?: boolean;
  fullWidth?: boolean;
  className?: string;
}

export const CMSButton: React.FC<CMSButtonProps> = ({
  children,
  variant = 'primary',
  type = 'button',
  onClick,
  disabled = false,
  fullWidth = false,
  className = '',
}) => {
  const baseClasses =
    'inline-flex h-10 items-center justify-center rounded-md px-4 text-sm font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-1';

  const variantClasses: Record<typeof variant, string> = {
    primary: 'bg-stone-900 text-white hover:bg-stone-800 focus:ring-stone-500 shadow-sm',
    secondary: 'bg-white/60 text-stone-800 hover:bg-white focus:ring-stone-400 shadow-sm',
    outline: 'border border-stone-300 text-stone-700 bg-white/70 hover:bg-white focus:ring-stone-400',
    ghost: 'text-stone-600 hover:text-stone-900 hover:bg-white/30 focus:ring-stone-400',
    danger: 'bg-red-600 text-white hover:bg-red-500 focus:ring-red-500',
  };

  const disabledClasses = disabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer';
  const widthClasses = fullWidth ? 'w-full' : '';

  const classes = [baseClasses, variantClasses[variant], disabledClasses, widthClasses, className]
    .filter(Boolean)
    .join(' ');

  return (
    <button type={type} className={classes} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
};







