'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence, Reorder } from 'framer-motion';
import { PlusIcon, PhotoIcon, DocumentTextIcon, XMarkIcon, ArrowUpIcon, ArrowDownIcon, ArrowUpTrayIcon } from '@heroicons/react/24/outline';
import { supabase } from '../../lib/supabase';
import { getImageUrl } from '../../lib/supabase-queries';
import type { NewsContentBlock } from '../../lib/supabase';

interface ContentBlockEditorProps {
  blocks: NewsContentBlock[];
  onChange: (blocks: NewsContentBlock[]) => void;
  folder?: string;
}

export function ContentBlockEditor({ blocks, onChange, folder = 'news' }: ContentBlockEditorProps) {
  const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);
  const [uploadingBlockIndex, setUploadingBlockIndex] = useState<number | null>(null);

  const handleAddBlock = (type: 'text' | 'image') => {
    const newBlock: NewsContentBlock = 
      type === 'text' 
        ? { type: 'text', text: '' }
        : { type: 'image', photo: [] };
    
    onChange([...blocks, newBlock]);
    setIsAddMenuOpen(false);
  };

  const handleRemoveBlock = (index: number) => {
    const newBlocks = blocks.filter((_, i) => i !== index);
    onChange(newBlocks);
  };

  const handleMoveBlock = (index: number, direction: 'up' | 'down') => {
    const newBlocks = [...blocks];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex < 0 || targetIndex >= newBlocks.length) return;
    
    [newBlocks[index], newBlocks[targetIndex]] = [newBlocks[targetIndex], newBlocks[index]];
    onChange(newBlocks);
  };

  const handleTextChange = (index: number, text: string) => {
    const newBlocks = [...blocks];
    if (newBlocks[index].type === 'text') {
      newBlocks[index] = { ...newBlocks[index], text };
      onChange(newBlocks);
    }
  };

  const handleCaptionChange = (index: number, caption: string) => {
    const newBlocks = [...blocks];
    if (newBlocks[index].type === 'image' && newBlocks[index].photo) {
      // Update caption for all photos in this block
      const updatedPhotos = newBlocks[index].photo!.map(photo => ({
        ...photo,
        caption
      }));
      newBlocks[index] = { ...newBlocks[index], photo: updatedPhotos };
      onChange(newBlocks);
    }
  };

  const handleImageUpload = async (index: number, files: FileList) => {
    if (!files.length) return;
    
    const block = blocks[index];
    if (block.type !== 'image') return;

    setUploadingBlockIndex(index);

    try {
      const uploadPromises = Array.from(files).map(async (file) => {
        // Validate file
        if (!file.type.startsWith('image/')) {
          throw new Error(`${file.name} is not an image file`);
        }
        if (file.size > 5 * 1024 * 1024) {
          throw new Error(`${file.name} is too large (max 5MB)`);
        }

        // Generate unique filename
        const timestamp = Date.now();
        const randomString = Math.random().toString(36).substring(2, 15);
        const extension = file.name.split('.').pop();
        const filename = `${timestamp}-${randomString}.${extension}`;
        const path = folder ? `${folder}/${filename}` : filename;

        // Upload to Supabase
        const { data, error } = await supabase.storage
          .from('images')
          .upload(path, file);

        if (error) throw error;

        return {
          url: getImageUrl(data.path),
          caption: block.photo?.[0]?.caption
        };
      });

      const uploadedImages = await Promise.all(uploadPromises);
      
      // Add to existing photos in this block
      const newBlocks = [...blocks];
      newBlocks[index] = {
        ...newBlocks[index],
        photo: [...(block.photo || []), ...uploadedImages]
      };
      onChange(newBlocks);
    } catch (error: any) {
      console.error('Upload error:', error);
      alert(`Upload failed: ${error.message}`);
    } finally {
      setUploadingBlockIndex(null);
    }
  };

  const handleRemoveImage = (blockIndex: number, photoIndex: number) => {
    const newBlocks = [...blocks];
    const block = newBlocks[blockIndex];
    
    if (block.type === 'image' && block.photo) {
      block.photo = block.photo.filter((_, i) => i !== photoIndex);
      onChange(newBlocks);
    }
  };

  return (
    <div className="space-y-4">
      <AnimatePresence mode="popLayout">
        {blocks.map((block, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, x: -100 }}
            className="relative group"
          >
            <div className="absolute -left-12 top-4 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={() => handleMoveBlock(index, 'up')}
                disabled={index === 0}
                className="p-1 rounded bg-white border border-stone-200 hover:bg-stone-50 disabled:opacity-30 disabled:cursor-not-allowed"
                title="Move up"
              >
                <ArrowUpIcon className="h-3 w-3 text-stone-600" />
              </button>
              <button
                onClick={() => handleMoveBlock(index, 'down')}
                disabled={index === blocks.length - 1}
                className="p-1 rounded bg-white border border-stone-200 hover:bg-stone-50 disabled:opacity-30 disabled:cursor-not-allowed"
                title="Move down"
              >
                <ArrowDownIcon className="h-3 w-3 text-stone-600" />
              </button>
              <button
                onClick={() => handleRemoveBlock(index)}
                className="p-1 rounded bg-red-50 border border-red-200 hover:bg-red-100 text-red-600"
                title="Remove block"
              >
                <XMarkIcon className="h-3 w-3" />
              </button>
            </div>

            <div className="bg-white/60 backdrop-blur-sm rounded-xl border border-stone-200/50 shadow-sm p-6">
              {block.type === 'text' ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2 text-sm font-medium text-stone-700">
                      <DocumentTextIcon className="h-4 w-4" />
                      Text Block
                    </div>
                  </div>
                  <textarea
                    value={block.text || ''}
                    onChange={(e) => handleTextChange(index, e.target.value)}
                    placeholder="Enter text content... (HTML is supported)"
                    className="w-full min-h-[150px] px-4 py-3 rounded-lg border border-stone-200 focus:border-stone-400 focus:ring-2 focus:ring-stone-200 transition-all resize-y font-sans text-[15px] leading-relaxed"
                  />
                  <p className="text-xs text-stone-500 mt-2">
                    Tip: You can use HTML tags like &lt;p&gt;, &lt;strong&gt;, &lt;em&gt;, &lt;a&gt;, etc.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2 text-sm font-medium text-stone-700">
                      <PhotoIcon className="h-4 w-4" />
                      Image Block
                    </div>
                  </div>

                  {/* Image Grid */}
                  {block.photo && block.photo.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                      {block.photo.map((img, photoIndex) => (
                        <div key={photoIndex} className="relative group/img aspect-video">
                          <img
                            src={img.url}
                            alt={img.caption || ''}
                            className="w-full h-full object-cover rounded-lg border border-stone-200"
                          />
                          <button
                            onClick={() => handleRemoveImage(index, photoIndex)}
                            className="absolute top-2 right-2 p-1 rounded-full bg-red-500 text-white opacity-0 group-hover/img:opacity-100 transition-opacity shadow-md hover:bg-red-600"
                            title="Remove image"
                          >
                            <XMarkIcon className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Caption (shared by all images in block) */}
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-stone-700">
                      Caption <span className="text-stone-400 font-normal">(applies to all images in this block)</span>
                    </label>
                    <input
                      type="text"
                      value={block.photo?.[0]?.caption || ''}
                      onChange={(e) => handleCaptionChange(index, e.target.value)}
                      placeholder="Enter image caption..."
                      className="w-full px-4 py-2 rounded-lg border border-stone-200 focus:border-stone-400 focus:ring-2 focus:ring-stone-200 transition-all"
                    />
                  </div>

                  {/* Upload Button */}
                  <div className="relative">
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={(e) => e.target.files && handleImageUpload(index, e.target.files)}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                      disabled={uploadingBlockIndex === index}
                    />
                    <div className="flex items-center justify-center px-4 py-3 text-sm font-medium bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg border border-stone-300 transition-all cursor-pointer">
                      {uploadingBlockIndex === index ? (
                        <>
                          <ArrowUpTrayIcon className="h-4 w-4 mr-2 animate-pulse" />
                          Uploading...
                        </>
                      ) : (
                        <>
                          <ArrowUpTrayIcon className="h-4 w-4 mr-2" />
                          Add Images
                        </>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Add Block Button */}
      <div className="relative">
        <button
          onClick={() => setIsAddMenuOpen(!isAddMenuOpen)}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium text-stone-700 bg-white hover:bg-stone-50 border-2 border-dashed border-stone-300 hover:border-stone-400 rounded-xl transition-all"
        >
          <PlusIcon className="h-4 w-4" />
          Add Content Block
        </button>

        <AnimatePresence>
          {isAddMenuOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 z-40"
                onClick={() => setIsAddMenuOpen(false)}
              />
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute left-0 right-0 top-full mt-2 bg-white rounded-xl border border-stone-200 shadow-lg overflow-hidden z-50"
              >
                <button
                  onClick={() => handleAddBlock('text')}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-stone-50 transition-colors text-left"
                >
                  <DocumentTextIcon className="h-5 w-5 text-stone-600" />
                  <div>
                    <div className="font-medium text-stone-900">Text Block</div>
                    <div className="text-xs text-stone-500">Add paragraphs, formatted text</div>
                  </div>
                </button>
                <button
                  onClick={() => handleAddBlock('image')}
                  className="w-full flex items-center gap-3 px-4 py-3 hover:bg-stone-50 transition-colors text-left border-t border-stone-100"
                >
                  <PhotoIcon className="h-5 w-5 text-stone-600" />
                  <div>
                    <div className="font-medium text-stone-900">Image Block</div>
                    <div className="text-xs text-stone-500">Add one or more images with caption</div>
                  </div>
                </button>
              </motion.div>
            </>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}


