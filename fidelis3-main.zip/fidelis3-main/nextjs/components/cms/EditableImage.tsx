'use client';

import React, { useState } from 'react';
import { useEditMode } from '../../contexts/EditModeContext';
import { getImageUrl } from '../../lib/supabase-queries';
import { supabase } from '../../lib/supabase';

interface EditableImageProps {
  value: string | null | undefined;
  fieldName: string;
  alt?: string;
  className?: string;
  folder?: string;
  recordId?: string; // For new records, this will be 'new' or similar
}

export const EditableImage: React.FC<EditableImageProps> = ({
  value,
  fieldName,
  alt = '',
  className = '',
  folder = 'products',
  recordId
}) => {
  const { isEditMode, registerChange } = useEditMode();
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [currentImagePath, setCurrentImagePath] = useState<string | null>(value || null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  // Update local state when prop changes (e.g., after save)
  React.useEffect(() => {
    setCurrentImagePath(value || null);
  }, [value]);

  const handleClearImage = () => {
    setCurrentImagePath(null);
    registerChange(fieldName, null);
    setUploadError(null);
    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Clear any previous errors
    setUploadError(null);

    // Validate file type (allow only common raster formats; block SVG)
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/avif', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
      setUploadError('Please select a JPG, PNG, WebP, AVIF, or GIF image');
      return;
    }

    // Validate file size (max 5MB)
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      setUploadError('Image size must be less than 5MB');
      return;
    }

    setUploading(true);
    setUploadProgress(0);

    try {
      // Generate unique filename
      const fileExt = file.name.split('.').pop();
      const timestamp = Date.now();
      const randomStr = Math.random().toString(36).substring(7);
      const fileName = `${timestamp}-${randomStr}.${fileExt}`;
      const filePath = `${folder}/${fileName}`;

      // Upload to Supabase storage
      const { data, error } = await supabase.storage
        .from('images')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) {
        throw error;
      }

      // Register the storage path (not the full URL)
      registerChange(fieldName, filePath);
      setCurrentImagePath(filePath); // Update local preview
      setUploadProgress(100);
      
      // Clear upload state after a brief delay
      setTimeout(() => {
        setUploading(false);
        setUploadProgress(0);
      }, 1000);

    } catch (error: any) {
      console.error('Error uploading image:', error);
      setUploadError(error.message || 'Failed to upload image');
      setUploading(false);
      setUploadProgress(0);
    }
  };

  if (!isEditMode) {
    if (!currentImagePath) return null;
    return (
      <img
        src={getImageUrl(currentImagePath)}
        alt={alt}
        className={className}
      />
    );
  }

  return (
    <div className="space-y-3">
      {currentImagePath && (
        <div className="relative group">
          <img
            src={getImageUrl(currentImagePath)}
            alt={alt}
            className={`${className} border-4 border-amber-400 rounded`}
            style={{
              boxShadow: '0 0 20px rgba(250, 204, 21, 0.15)'
            }}
          />
          {uploading && (
            <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center rounded">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-2">
                  <svg className="animate-spin h-16 w-16 text-amber-600" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                </div>
                <p className="text-sm font-medium text-stone-900">Uploading...</p>
                {uploadProgress > 0 && (
                  <p className="text-xs text-stone-600 mt-1">{uploadProgress}%</p>
                )}
              </div>
            </div>
          )}
          {!uploading && (
            <button
              onClick={handleClearImage}
              className="absolute top-2 right-2 p-2 bg-red-600 hover:bg-red-700 text-white rounded-full shadow-lg transition-all duration-200 opacity-0 group-hover:opacity-100 focus:opacity-100"
              title="Remove image"
              type="button"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>
      )}
      
      {!currentImagePath && !uploading && (
        <div 
          className="bg-white/40 backdrop-blur-sm border border-stone-200/50 rounded-xl p-10 transition-all duration-200 hover:bg-white/60 hover:border-stone-300/60"
          style={{
            boxShadow: '0 4px 16px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.6)'
          }}
        >
          <div className="text-center">
            <svg className="w-16 h-16 mx-auto mb-4 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p className="text-base font-medium text-stone-800 mb-2">No image uploaded</p>
            <p className="text-sm text-stone-600">Choose a file below to upload</p>
          </div>
        </div>
      )}

      {!currentImagePath && uploading && (
        <div 
          className="bg-white/60 backdrop-blur-md border border-stone-200/50 rounded-xl p-10"
          style={{
            boxShadow: '0 8px 24px rgba(0, 0, 0, 0.06), inset 0 1px 0 rgba(255, 255, 255, 0.7)'
          }}
        >
          <div className="text-center">
            <div className="w-16 h-16 mx-auto mb-4">
              <svg className="animate-spin h-16 w-16 text-stone-700" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-15" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            </div>
            <p className="text-base font-medium text-stone-900 mb-1">Uploading image...</p>
            {uploadProgress > 0 && (
              <p className="text-sm text-stone-600">{uploadProgress}%</p>
            )}
          </div>
        </div>
      )}

      <div 
        className="bg-white/30 backdrop-blur-sm border border-stone-200/50 rounded-xl p-5 transition-all duration-200 hover:bg-white/50 hover:border-stone-300/60"
        style={{
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.03), inset 0 1px 0 rgba(255, 255, 255, 0.5)'
        }}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          disabled={uploading}
          className="block w-full text-sm text-stone-700 
            file:mr-4 file:py-3 file:px-6 file:rounded-lg file:border-0 
            file:text-sm file:font-medium 
            file:bg-stone-900 file:text-white 
            hover:file:bg-stone-800 
            file:cursor-pointer file:transition-all file:duration-200
            file:shadow-sm hover:file:shadow-md
            disabled:opacity-50 disabled:cursor-not-allowed 
            file:disabled:cursor-not-allowed file:disabled:bg-stone-400"
        />
        <p className="mt-3 text-xs text-stone-600 leading-relaxed">
          Maximum file size: 5MB • Supported formats: JPG, PNG, GIF, WebP
        </p>
      </div>

      {uploadError && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <div className="flex items-start gap-2">
            <svg className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
            <div>
              <p className="text-sm font-medium text-red-900">Upload failed</p>
              <p className="text-xs text-red-700 mt-1">{uploadError}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

