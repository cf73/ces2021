'use client';

import React from 'react';
import type { Manufacturer, ProductCategory } from '../../lib/supabase';
import { EditableSelect } from './EditableSelect';
import { useEditMode } from '../../contexts/EditModeContext';

interface RelationalSelectProps {
  selectedManufacturerId?: string | null;
  selectedCategoryId?: string | null;
  manufacturers: Manufacturer[];
  categories: ProductCategory[];
  manufacturerDisplayValue?: string;
  manufacturerDisplayLink?: string;
  categoryDisplayValue?: string;
  categoryDisplayLink?: string;
}

export function RelationalSelect({
  selectedManufacturerId,
  selectedCategoryId,
  manufacturers,
  categories,
  manufacturerDisplayValue,
  manufacturerDisplayLink,
  categoryDisplayValue,
  categoryDisplayLink
}: RelationalSelectProps) {
  const { isEditMode } = useEditMode();
  
  return (
    <>
      {/* Manufacturer Dropdown - Only in Edit Mode */}
      {isEditMode && (
        <div className="mb-4">
          <EditableSelect
            value={selectedManufacturerId}
            fieldName="manufacturer_id"
            options={manufacturers.map(m => ({ value: m.id, label: m.name }))}
            label="Manufacturer"
            required
            displayValue={manufacturerDisplayValue}
            displayLink={manufacturerDisplayLink}
            displayClassName="inline-flex items-center px-6 py-4 bg-white border-2 border-stone-900 text-stone-900 font-medium tracking-wide uppercase hover:bg-stone-900 hover:text-white transition-all duration-300 rounded-md whitespace-nowrap"
          />
        </div>
      )}
      
      {/* Category Dropdown - Only in Edit Mode (view mode handled separately) */}
      {isEditMode && (
        <div>
          <EditableSelect
            value={selectedCategoryId}
            fieldName="category_id"
            options={categories.map(c => ({ value: c.id, label: c.name }))}
            label="Product Category"
            required
            displayValue={categoryDisplayValue}
            displayLink={categoryDisplayLink}
            displayClassName="inline-flex items-center px-6 py-4 bg-white border-2 border-stone-900 text-stone-900 font-medium tracking-wide uppercase hover:bg-stone-900 hover:text-white transition-all duration-300 rounded-md whitespace-nowrap"
          />
        </div>
      )}
    </>
  );
}
