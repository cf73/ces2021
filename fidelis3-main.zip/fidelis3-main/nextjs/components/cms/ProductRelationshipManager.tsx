'use client';

import { useEffect, useState } from 'react';
import type { Product } from '../../lib/supabase';
import { searchProducts } from '../../lib/supabase-queries';
import { getImageUrl } from '../../lib/supabase-queries';
import { ProductChip } from './ProductChip';
import { getAuthHeaders } from '../../lib/auth-headers';

interface ProductRelationshipManagerProps {
  currentProduct: Product;
  initialPairsWellWith: string[];
  initialAlsoConsider: string[];
  onUpdate: (pairs: string[], also: string[]) => void;
}

interface AISuggestions {
  pairsWellWith: string[];
  alsoConsider: string[];
  reasoning: string;
}

export function ProductRelationshipManager({
  currentProduct,
  initialPairsWellWith,
  initialAlsoConsider,
  onUpdate
}: ProductRelationshipManagerProps) {
  const [pairsWellWith, setPairsWellWith] = useState<string[]>(initialPairsWellWith);
  const [alsoConsider, setAlsoConsider] = useState<string[]>(initialAlsoConsider);
  const [aiSuggestions, setAiSuggestions] = useState<AISuggestions | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [activeSearch, setActiveSearch] = useState<'pairs' | 'also' | null>(null);

  // Load AI suggestions on mount
  useEffect(() => {
    loadAiSuggestions();
  }, [currentProduct.id]);

  const loadAiSuggestions = async () => {
    setLoading(true);
    try {
      console.log('🤖 Fetching AI suggestions for product:', currentProduct.id);
      const authHeaders = await getAuthHeaders();
      const response = await fetch('/api/ai-suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({ productId: currentProduct.id })
      });
      
      console.log('🤖 Response status:', response.status);
      const data = await response.json();
      console.log('🤖 Response data:', data);
      
      if (response.ok) {
        setAiSuggestions(data);
      } else {
        console.error('🤖 API returned error:', data);
        setAiSuggestions({
          pairsWellWith: [],
          alsoConsider: [],
          reasoning: data.error || 'Failed to generate suggestions'
        });
      }
    } catch (error) {
      console.error('🤖 Failed to load AI suggestions:', error);
      setAiSuggestions({
        pairsWellWith: [],
        alsoConsider: [],
        reasoning: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.length < 2) {
      setSearchResults([]);
      return;
    }
    
    try {
      const products = await searchProducts(query);
      setSearchResults(products.filter(p => p.id !== currentProduct.id));
    } catch (error) {
      console.error('Error searching products:', error);
    }
  };

  const addProduct = (productId: string, type: 'pairs' | 'also') => {
    if (type === 'pairs') {
      const updated = [...pairsWellWith, productId];
      setPairsWellWith(updated);
      onUpdate(updated, alsoConsider);
    } else {
      const updated = [...alsoConsider, productId];
      setAlsoConsider(updated);
      onUpdate(pairsWellWith, updated);
    }
    setSearchQuery('');
    setSearchResults([]);
    setActiveSearch(null);
  };

  const removeProduct = (productId: string, type: 'pairs' | 'also') => {
    if (type === 'pairs') {
      const updated = pairsWellWith.filter(id => id !== productId);
      setPairsWellWith(updated);
      onUpdate(updated, alsoConsider);
    } else {
      const updated = alsoConsider.filter(id => id !== productId);
      setAlsoConsider(updated);
      onUpdate(pairsWellWith, updated);
    }
  };

  return (
    <div className="space-y-8 bg-stone-50 rounded-2xl p-6 border border-stone-200">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-medium text-stone-900">Product Relationships</h3>
        <button
          onClick={loadAiSuggestions}
          disabled={loading}
          className="px-4 py-2 bg-stone-900 text-white rounded-lg hover:bg-stone-800 disabled:opacity-50 flex items-center gap-2 transition-colors duration-200"
        >
          {loading ? (
            <>
              <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating...
            </>
          ) : (
            <>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
              Refresh AI Suggestions
            </>
          )}
        </button>
      </div>

      {/* Pairs Well With Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-lg font-medium text-stone-900">Good Synergies</h4>
          {aiSuggestions?.pairsWellWith && aiSuggestions.pairsWellWith.length > 0 && (
            <span className="text-sm text-stone-600">
              {aiSuggestions.pairsWellWith.filter(id => !pairsWellWith.includes(id)).length} AI suggestions
            </span>
          )}
        </div>
        
        {/* Search bar */}
        <div className="relative">
          <input
            type="text"
            value={activeSearch === 'pairs' ? searchQuery : ''}
            onFocus={() => setActiveSearch('pairs')}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Search products to add..."
            className="w-full border border-stone-300 rounded-lg px-4 py-2 pr-10 focus:ring-2 focus:ring-stone-500 focus:border-transparent"
          />
          <svg className="absolute right-3 top-2.5 w-5 h-5 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          
          {/* Search results dropdown */}
          {activeSearch === 'pairs' && searchResults.length > 0 && (
            <div className="absolute z-10 mt-1 w-full bg-white border border-stone-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
              {searchResults.map(product => (
                <button
                  key={product.id}
                  onClick={() => addProduct(product.id, 'pairs')}
                  className="w-full px-4 py-2 text-left hover:bg-stone-50 flex items-center gap-3 transition-colors duration-200"
                >
                  {product.product_hero_image && (
                    <img 
                      src={getImageUrl(product.product_hero_image)} 
                      alt={product.title}
                      className="w-10 h-10 object-cover rounded"
                    />
                  )}
                  <div>
                    <div className="font-medium">{product.title}</div>
                    <div className="text-sm text-stone-600">
                      {product.manufacturer?.name}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Current pairs */}
        <div className="flex flex-wrap gap-2">
          {pairsWellWith.map(productId => (
            <ProductChip
              key={productId}
              productId={productId}
              onRemove={() => removeProduct(productId, 'pairs')}
            />
          ))}
          {pairsWellWith.length === 0 && (
            <p className="text-sm text-stone-500">No products added yet. Use the search above or AI suggestions below.</p>
          )}
        </div>

        {/* AI Suggestions */}
        {aiSuggestions?.pairsWellWith && aiSuggestions.pairsWellWith.length > 0 && (
          <div className="border-t border-stone-300 pt-4">
            <div className="text-sm font-medium text-stone-600 mb-2 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
              AI Suggestions
            </div>
            <div className="flex flex-wrap gap-2">
              {aiSuggestions.pairsWellWith
                .filter(id => !pairsWellWith.includes(id))
                .map(productId => (
                  <ProductChip
                    key={productId}
                    productId={productId}
                    variant="suggestion"
                    onAdd={() => addProduct(productId, 'pairs')}
                  />
                ))}
            </div>
          </div>
        )}
      </div>

      {/* Also Consider Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="text-lg font-medium text-stone-900">Also Consider</h4>
          {aiSuggestions?.alsoConsider && aiSuggestions.alsoConsider.length > 0 && (
            <span className="text-sm text-stone-600">
              {aiSuggestions.alsoConsider.filter(id => !alsoConsider.includes(id)).length} AI suggestions
            </span>
          )}
        </div>
        
        {/* Search bar */}
        <div className="relative">
          <input
            type="text"
            value={activeSearch === 'also' ? searchQuery : ''}
            onFocus={() => setActiveSearch('also')}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder="Search products to add..."
            className="w-full border border-stone-300 rounded-lg px-4 py-2 pr-10 focus:ring-2 focus:ring-stone-500 focus:border-transparent"
          />
          <svg className="absolute right-3 top-2.5 w-5 h-5 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          
          {/* Search results dropdown */}
          {activeSearch === 'also' && searchResults.length > 0 && (
            <div className="absolute z-10 mt-1 w-full bg-white border border-stone-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
              {searchResults.map(product => (
                <button
                  key={product.id}
                  onClick={() => addProduct(product.id, 'also')}
                  className="w-full px-4 py-2 text-left hover:bg-stone-50 flex items-center gap-3 transition-colors duration-200"
                >
                  {product.product_hero_image && (
                    <img 
                      src={getImageUrl(product.product_hero_image)} 
                      alt={product.title}
                      className="w-10 h-10 object-cover rounded"
                    />
                  )}
                  <div>
                    <div className="font-medium">{product.title}</div>
                    <div className="text-sm text-stone-600">
                      {product.manufacturer?.name}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Current also consider */}
        <div className="flex flex-wrap gap-2">
          {alsoConsider.map(productId => (
            <ProductChip
              key={productId}
              productId={productId}
              onRemove={() => removeProduct(productId, 'also')}
            />
          ))}
          {alsoConsider.length === 0 && (
            <p className="text-sm text-stone-500">No products added yet. Use the search above or AI suggestions below.</p>
          )}
        </div>

        {/* AI Suggestions */}
        {aiSuggestions?.alsoConsider && aiSuggestions.alsoConsider.length > 0 && (
          <div className="border-t border-stone-300 pt-4">
            <div className="text-sm font-medium text-stone-600 mb-2 flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
              AI Suggestions
            </div>
            <div className="flex flex-wrap gap-2">
              {aiSuggestions.alsoConsider
                .filter(id => !alsoConsider.includes(id))
                .map(productId => (
                  <ProductChip
                    key={productId}
                    productId={productId}
                    variant="suggestion"
                    onAdd={() => addProduct(productId, 'also')}
                  />
                ))}
            </div>
          </div>
        )}
      </div>

      {aiSuggestions?.reasoning && (
        <div className="text-sm text-stone-600 bg-stone-100 rounded-lg p-4">
          <strong>AI Reasoning:</strong> {aiSuggestions.reasoning}
        </div>
      )}
    </div>
  );
}

