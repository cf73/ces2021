'use client';

import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { getImageUrl, getImageThumbnail } from '../../lib/supabase-queries';
import { motion, AnimatePresence } from 'framer-motion';

interface StorageFile {
  name: string;
  id: string;
  updated_at: string;
  created_at: string;
  last_accessed_at: string;
  metadata: {
    eTag: string;
    size: number;
    mimetype: string;
    cacheControl: string;
    lastModified: string;
    contentLength: number;
    httpStatusCode: number;
  };
}

interface ImageWithType extends StorageFile {
  type: string;
  fullPath: string;
  isProtected?: boolean;
  usedIn?: string[];
  isArchived?: boolean;
  originalPath?: string; // For archived images, stores the original path before archiving
}

const IMAGE_TYPES = [
  { id: 'all', label: 'All Images', color: 'stone' },
  { id: 'archived', label: 'Archive', color: 'orange' },
  { id: 'in-use', label: 'In Use', color: 'emerald' },
  { id: 'unused', label: 'Not In Use', color: 'gray' },
  { id: 'home-hero', label: 'Homepage Heroes', color: 'rose' },
  { id: 'products', label: 'Product Images', color: 'blue' },
  { id: 'news', label: 'News Images', color: 'green' },
  { id: 'manufacturers', label: 'Manufacturer Logos', color: 'purple' },
  { id: 'categories', label: 'Category Heroes', color: 'amber' },
  { id: 'pre-owned', label: 'Pre-Owned Images', color: 'cyan' },
] as const;

export function ImageLibraryManager() {
  const [images, setImages] = useState<ImageWithType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedImage, setSelectedImage] = useState<ImageWithType | null>(null);
  const [deletingImage, setDeletingImage] = useState<string | null>(null);
  const [selectedImages, setSelectedImages] = useState<Set<string>>(new Set());
  const [batchDeleting, setBatchDeleting] = useState(false);
  const [loadedImages, setLoadedImages] = useState<Set<string>>(new Set());
  const [displayLimit, setDisplayLimit] = useState(100);
  const [showFilterMenu, setShowFilterMenu] = useState(false);

  // Helper function to extract image paths from content fields (markdown/HTML)
  const extractImagesFromContent = (content: string): string[] => {
    if (!content) return [];
    
    const imagePaths: string[] = [];
    
    // Match markdown images: ![alt](path)
    const markdownRegex = /!\[.*?\]\((.*?)\)/g;
    let match;
    while ((match = markdownRegex.exec(content)) !== null) {
      if (match[1]) imagePaths.push(match[1]);
    }
    
    // Match HTML img tags: <img src="path">
    const htmlRegex = /<img[^>]+src=["']([^"']+)["']/g;
    while ((match = htmlRegex.exec(content)) !== null) {
      if (match[1]) imagePaths.push(match[1]);
    }
    
    // Clean paths (remove full URLs, keep only storage paths)
    return imagePaths.map(path => {
      // Extract just the filename/path from full URLs
      if (path.includes('supabase') || path.includes('http')) {
        const parts = path.split('/');
        // Try to find the images bucket part
        const imagesIndex = parts.findIndex(p => p === 'images');
        if (imagesIndex >= 0 && imagesIndex < parts.length - 1) {
          return parts.slice(imagesIndex + 1).join('/');
        }
        // Otherwise just take the last part
        return parts[parts.length - 1];
      }
      return path.replace(/^\/+/, '');
    }).filter(path => path && !path.startsWith('http'));
  };

  useEffect(() => {
    loadImages();
  }, []);

  // Clear selection when filter changes
  useEffect(() => {
    setSelectedImages(new Set());
    setLoadedImages(new Set());
    setDisplayLimit(100); // Reset display limit when filter changes
  }, [selectedType]);

  const loadImages = async () => {
    setLoading(true);
    setError(null);

    try {
      // Query database to find all image references
      // Note: We query ALL records (published + unpublished) to catch all images in storage
      const [
        homeHeroImagesResult,
        productsResult,
        newsResult,
        manufacturersResult,
        preOwnedResult,
        categoriesResult,
        testimonialsResult,
        evergreenCarouselsResult
      ] = await Promise.all([
        supabase.from('home_hero_images').select('image').eq('published', true).limit(1000),
        supabase.from('products').select('id, title, product_hero_image, product_gallery, content').limit(1000),
        supabase.from('news').select('title, image, content, main_content, more_content').limit(1000),
        // Query ALL manufacturers (published + unpublished) to catch all logo images
        supabase.from('manufacturers').select('id, title, logo, published').order('title').limit(1000),
        supabase.from('pre_owned').select('*').limit(1000),
        supabase.from('product_categories').select('*').limit(1000),
        supabase.from('testimonials').select('content').limit(1000),
        supabase.from('evergreen_carousels').select('hero_image, content').limit(1000)
      ]);

      // Handle errors gracefully
      if (homeHeroImagesResult.error) console.warn('Error fetching home hero images:', homeHeroImagesResult.error);
      if (productsResult.error) console.warn('Error fetching products:', productsResult.error);
      if (newsResult.error) console.warn('Error fetching news:', newsResult.error);
      if (manufacturersResult.error) console.warn('Error fetching manufacturers:', manufacturersResult.error);
      if (preOwnedResult.error) console.warn('Error fetching pre-owned:', preOwnedResult.error);
      if (categoriesResult.error) console.warn('Error fetching categories:', categoriesResult.error);
      if (testimonialsResult.error) console.warn('Error fetching testimonials:', testimonialsResult.error);
      if (evergreenCarouselsResult.error) console.warn('Error fetching evergreen carousels (table may not exist):', evergreenCarouselsResult.error);

      // Extract data (default to empty arrays if error)
      const homeHeroImages = homeHeroImagesResult.data || [];
      const products = productsResult.data || [];
      const news = newsResult.data || [];
      const manufacturers = manufacturersResult.data || [];
      const preOwned = preOwnedResult.data || [];
      const categories = categoriesResult.data || [];
      const testimonials = testimonialsResult.data || [];
      const evergreenCarousels = evergreenCarouselsResult.data || [];

      // Helper to extract just the filename from any path format
      const getFilename = (path: string): string => {
        if (!path) return '';
        const cleanPath = path.replace(/^\/+/, '').replace(/^assets\//, '');
        return cleanPath.split('/').pop() || cleanPath;
      };

      // Build maps by filename (not full path) for robust matching
      // Map from filename -> { type, usedIn[], isProtected }
      const filenameToUsage = new Map<string, { type: string; usedIn: string[]; isProtected: boolean }>();

      // Helper to add an image usage by filename
      const addUsage = (imagePath: string, type: string, label: string, isProtected: boolean = false) => {
        if (!imagePath) return;
        const filename = getFilename(imagePath);
        if (!filename) return;

        const existing = filenameToUsage.get(filename) || { type, usedIn: [], isProtected };
        existing.usedIn.push(label);
        if (isProtected) existing.isProtected = true;
        if (!existing.isProtected) existing.type = type;
        filenameToUsage.set(filename, existing);
      };

      // Home hero images (protected)
      homeHeroImages?.forEach(record => {
        if (record.image) {
          addUsage(record.image, 'home-hero', 'Homepage Hero', true);
        }
      });

      // Product images
      products?.forEach((product: any) => {
        const productLabel = product.title ? `Product: ${product.title}` : 'Product';
        
        if (product.product_hero_image) {
          addUsage(product.product_hero_image, 'products', productLabel);
        }
        if (product.product_gallery && Array.isArray(product.product_gallery)) {
          product.product_gallery.forEach((img: string) => {
            if (img) {
              addUsage(img, 'products', `${productLabel} Gallery`);
            }
          });
        }
        // Check content for embedded images
        if (product.content) {
          const contentImages = extractImagesFromContent(product.content);
          contentImages.forEach(img => {
            addUsage(img, 'products', `${productLabel} Content`);
          });
        }
      });

      // News images
      news?.forEach((article: any) => {
        const newsLabel = article.title ? `News: ${article.title}` : 'News';
        
        if (article.image) {
          addUsage(article.image, 'news', newsLabel);
        }
        // Check content fields for embedded images
        [article.content, article.main_content].forEach(content => {
          if (content) {
            const contentImages = extractImagesFromContent(content);
            contentImages.forEach(img => {
              addUsage(img, 'news', `${newsLabel} Content`);
            });
          }
        });
        
        // Check more_content blocks for images
        if (article.more_content && Array.isArray(article.more_content)) {
          article.more_content.forEach((block: any, blockIndex: number) => {
            // Text blocks might have embedded images
            if (block.type === 'text' && block.text) {
              const blockImages = extractImagesFromContent(block.text);
              blockImages.forEach(img => {
                addUsage(img, 'news', `${newsLabel} More Content`);
              });
            }
            // Image blocks have direct image URLs
            if (block.type === 'image' && block.photo && Array.isArray(block.photo)) {
              block.photo.forEach((img: any) => {
                if (img.url) {
                  addUsage(img.url, 'news', `${newsLabel} Gallery`);
                }
              });
            }
          });
        }
      });

      // Manufacturer logos - direct mapping from database record to filename
      manufacturers?.forEach((manufacturer: any) => {
        if (manufacturer.logo) {
          const mfgLabel = manufacturer.title ? `Manufacturer: ${manufacturer.title}` : 'Manufacturer';
          addUsage(manufacturer.logo, 'manufacturers', mfgLabel);
        }
      });

      // Pre-owned images
      preOwned?.forEach((item: any) => {
        const preOwnedLabel = item.title ? `Pre-Owned: ${item.title}` : 'Pre-Owned';
        
        if (item.hero_image) {
          addUsage(item.hero_image, 'pre-owned', preOwnedLabel);
        }
        if (item.images && Array.isArray(item.images)) {
          item.images.forEach((img: string) => {
            if (img) {
              addUsage(img, 'pre-owned', `${preOwnedLabel} Gallery`);
            }
          });
        }
        // Check content for embedded images
        if (item.content) {
          const contentImages = extractImagesFromContent(item.content);
          contentImages.forEach(img => {
            addUsage(img, 'pre-owned', `${preOwnedLabel} Content`);
          });
        }
      });

      // Category hero images - cross-reference with products
      categories?.forEach((category: any) => {
        if (category.hero_product_id) {
          const heroProduct = products?.find((p: any) => p.id === category.hero_product_id);
          if (heroProduct?.product_hero_image) {
            const catLabel = category.name ? `Category Hero: ${category.name}` : 'Category Hero';
            addUsage(heroProduct.product_hero_image, 'categories', catLabel);
          }
        }
      });

      // Testimonials (content field only)
      testimonials?.forEach((testimonial: any) => {
        if (testimonial.content) {
          const contentImages = extractImagesFromContent(testimonial.content);
          contentImages.forEach(img => {
            addUsage(img, 'other', 'Testimonial');
          });
        }
      });

      // Evergreen carousels
      evergreenCarousels?.forEach((carousel: any) => {
        if (carousel.hero_image) {
          addUsage(carousel.hero_image, 'other', 'Evergreen Carousel');
        }
        if (carousel.content) {
          const contentImages = extractImagesFromContent(carousel.content);
          contentImages.forEach(img => {
            addUsage(img, 'other', 'Carousel Content');
          });
        }
      });

      // Log statistics for debugging
      const manufacturersWithLogos = manufacturers.filter((m: any) => m.logo);
      const publishedManufacturers = manufacturers.filter((m: any) => m.published !== false);
      const publishedManufacturersWithLogos = manufacturersWithLogos.filter((m: any) => m.published !== false);
      const categoriesWithHeroes = categories.filter((c: any) => c.hero_product_id);
      
      console.group('📊 IMAGE LIBRARY STATISTICS');
      console.log('Database Records Fetched:', {
        homeHeroImages: homeHeroImages.length,
        products: products.length,
        productsWithHeroImages: products.filter((p: any) => p.product_hero_image).length,
        news: news.length,
        preOwned: preOwned.length,
        categories: categories.length,
        categoriesWithHeroProducts: categoriesWithHeroes.length,
        testimonials: testimonials.length,
        evergreenCarousels: evergreenCarousels.length,
      });
      
      const manufacturersWithoutLogos = manufacturers.filter((m: any) => !m.logo);
      
      console.group('🏭 MANUFACTURERS BREAKDOWN');
      console.log('Total manufacturers in database:', manufacturers.length);
      console.log('Published manufacturers:', publishedManufacturers.length);
      console.log('✅ Manufacturers WITH logos:', manufacturersWithLogos.length);
      console.log('❌ Manufacturers WITHOUT logos:', manufacturersWithoutLogos.length);
      console.log('Published manufacturers with logos:', publishedManufacturersWithLogos.length);
      console.log('---');
      console.table(manufacturersWithLogos.map((m: any) => ({
        Title: m.title,
        Published: m.published !== false ? '✓' : '✗',
        Logo: m.logo,
        Filename: getFilename(m.logo)
      })));
      
      if (manufacturersWithoutLogos.length > 0) {
        console.log('⚠️ Manufacturers WITHOUT logos (these won\'t appear in the filter):', 
          manufacturersWithoutLogos.map((m: any) => m.title).join(', ')
        );
      }
      console.groupEnd();
      
      console.log('Mapped Filenames by Type:', {
        totalUniqueFilenames: filenameToUsage.size,
        homeHero: Array.from(filenameToUsage.values()).filter(u => u.type === 'home-hero').length,
        products: Array.from(filenameToUsage.values()).filter(u => u.type === 'products').length,
        news: Array.from(filenameToUsage.values()).filter(u => u.type === 'news').length,
        manufacturers: Array.from(filenameToUsage.values()).filter(u => u.type === 'manufacturers').length,
        categories: Array.from(filenameToUsage.values()).filter(u => u.type === 'categories').length,
        preOwned: Array.from(filenameToUsage.values()).filter(u => u.type === 'pre-owned').length,
      });
      
      console.log('Category Heroes Sample:', categoriesWithHeroes.slice(0, 5).map((c: any) => {
        const heroProduct = products.find((p: any) => p.id === c.hero_product_id);
        return {
          category: c.name,
          productTitle: heroProduct?.title,
          heroImage: heroProduct?.product_hero_image,
          filename: heroProduct?.product_hero_image ? getFilename(heroProduct.product_hero_image) : null
        };
      }));
      
      console.groupEnd();

      // List all files in the images bucket (with pagination for large buckets)
      const allImages: ImageWithType[] = [];
      let offset = 0;
      const limit = 1000;
      let hasMoreFiles = true;
      
      // Scan root-level files with pagination
      while (hasMoreFiles) {
        const { data: files, error: listError } = await supabase.storage
          .from('images')
          .list('', {
            limit,
            offset,
            sortBy: { column: 'created_at', order: 'desc' },
          });

        if (listError) {
          console.error('Error listing root files:', listError);
          break;
        }

        if (!files || files.length === 0) {
          hasMoreFiles = false;
          break;
        }

        // Add root-level images (excluding folders)
        files.forEach(file => {
          if (file.name && !file.name.includes('.emptyFolderPlaceholder') && file.id && file.name !== '.archive') {
            const filename = getFilename(file.name);
            const usage = filenameToUsage.get(filename);
            
            allImages.push({
              name: file.name,
              id: file.id || '',
              updated_at: file.updated_at || '',
              created_at: file.created_at || '',
              last_accessed_at: file.last_accessed_at || '',
              metadata: {
                eTag: file.metadata?.eTag || '',
                size: file.metadata?.size || 0,
                mimetype: file.metadata?.mimetype || '',
                cacheControl: file.metadata?.cacheControl || '',
                lastModified: file.metadata?.lastModified || '',
                contentLength: file.metadata?.contentLength || 0,
                httpStatusCode: file.metadata?.httpStatusCode || 200,
              },
              type: usage?.type || 'other',
              fullPath: file.name,
              isProtected: usage?.isProtected || false,
              usedIn: usage?.usedIn || [],
              isArchived: false
            });
          }
        });

        // Check if there might be more files
        if (files.length < limit) {
          hasMoreFiles = false;
        } else {
          offset += limit;
        }
      }
      
      // Scan subfolder files
      for (const folder of ['products', 'news', 'manufacturers', 'categories', 'pre-owned']) {
        const { data: folderFiles, error: folderError } = await supabase.storage
          .from('images')
          .list(folder, {
            limit: 1000,
            offset: 0,
            sortBy: { column: 'created_at', order: 'desc' },
          });

        if (!folderError && folderFiles) {
          folderFiles.forEach(file => {
            if (file.name && !file.name.includes('.emptyFolderPlaceholder')) {
              const fullPath = `${folder}/${file.name}`;
              const filename = getFilename(file.name);
              const usage = filenameToUsage.get(filename);
              
              allImages.push({
                name: file.name,
                id: file.id || '',
                updated_at: file.updated_at || '',
                created_at: file.created_at || '',
                last_accessed_at: file.last_accessed_at || '',
                metadata: {
                  eTag: file.metadata?.eTag || '',
                  size: file.metadata?.size || 0,
                  mimetype: file.metadata?.mimetype || '',
                  cacheControl: file.metadata?.cacheControl || '',
                  lastModified: file.metadata?.lastModified || '',
                  contentLength: file.metadata?.contentLength || 0,
                  httpStatusCode: file.metadata?.httpStatusCode || 200,
                },
                type: usage?.type || folder,
                fullPath,
                isProtected: usage?.isProtected || false,
                usedIn: usage?.usedIn || [],
                isArchived: false
              });
            }
          });
        }
      }

      // Scan .archive folder for archived images
      const { data: archiveFiles } = await supabase.storage
        .from('images')
        .list('.archive', {
          limit: 1000,
          offset: 0,
          sortBy: { column: 'created_at', order: 'desc' },
        });

      if (archiveFiles) {
        for (const file of archiveFiles) {
          if (file.name && !file.name.includes('.emptyFolderPlaceholder') && file.id) {
            // Extract original folder from filename if it was stored (e.g., "products-123.jpg")
            const fullPath = `.archive/${file.name}`;
            
            allImages.push({
              name: file.name,
              id: file.id || '',
              updated_at: file.updated_at || '',
              created_at: file.created_at || '',
              last_accessed_at: file.last_accessed_at || '',
              metadata: {
                eTag: file.metadata?.eTag || '',
                size: file.metadata?.size || 0,
                mimetype: file.metadata?.mimetype || '',
                cacheControl: file.metadata?.cacheControl || '',
                lastModified: file.metadata?.lastModified || '',
                contentLength: file.metadata?.contentLength || 0,
                httpStatusCode: file.metadata?.httpStatusCode || 200,
              },
              type: 'archived',
              fullPath,
              isProtected: false,
              usedIn: [],
              isArchived: true,
              originalPath: file.name
            });
          }
        }
      }

      console.log('🖼️ Image categorization complete:', {
        totalImages: allImages.length,
        byType: {
          'home-hero': allImages.filter(i => i.type === 'home-hero').length,
          'products': allImages.filter(i => i.type === 'products').length,
          'news': allImages.filter(i => i.type === 'news').length,
          'manufacturers': allImages.filter(i => i.type === 'manufacturers').length,
          'categories': allImages.filter(i => i.type === 'categories').length,
          'pre-owned': allImages.filter(i => i.type === 'pre-owned').length,
          'other': allImages.filter(i => i.type === 'other').length,
        },
        protected: allImages.filter(i => i.isProtected).length,
        inUse: allImages.filter(i => i.usedIn && i.usedIn.length > 0).length
      });

      setImages(allImages);
    } catch (err: any) {
      console.error('Error loading images:', err);
      setError(err.message || 'Failed to load images');
    } finally {
      setLoading(false);
    }
  };

  const handleArchiveImage = async (image: ImageWithType) => {
    if (image.isProtected) {
      alert(`This image cannot be archived because it is currently being used:\n\n${image.usedIn?.join(', ')}\n\nPlease remove it from these locations first.`);
      return;
    }

    const warningMessage = image.usedIn && image.usedIn.length > 0
      ? `Warning: This image is currently being used in:\n${image.usedIn.join(', ')}\n\nArchiving it will break these references. Are you sure you want to archive "${image.name}"?`
      : `Archive "${image.name}"? You can restore it later from the Archive tab.`;

    if (!confirm(warningMessage)) {
      return;
    }

    setDeletingImage(image.fullPath);

    try {
      // Move to .archive folder
      const archivePath = `.archive/${image.name}`;
      
      const { error: moveError } = await supabase.storage
        .from('images')
        .move(image.fullPath, archivePath);

      if (moveError) throw moveError;

      // Update local state to reflect archive
      setImages(prev => prev.map(img => 
        img.fullPath === image.fullPath 
          ? { ...img, fullPath: archivePath, isArchived: true, originalPath: image.fullPath, type: 'archived' }
          : img
      ));
      setSelectedImage(null);
    } catch (err: any) {
      console.error('Error archiving image:', err);
      alert(`Failed to archive image: ${err.message}`);
    } finally {
      setDeletingImage(null);
    }
  };

  const handleRestoreImage = async (image: ImageWithType) => {
    if (!image.isArchived || !image.originalPath) return;

    if (!confirm(`Restore "${image.name}" to its original location?`)) {
      return;
    }

    setDeletingImage(image.fullPath);

    try {
      const { error: moveError } = await supabase.storage
        .from('images')
        .move(image.fullPath, image.originalPath);

      if (moveError) throw moveError;

      // Reload images to refresh categorization
      await loadImages();
      setSelectedImage(null);
    } catch (err: any) {
      console.error('Error restoring image:', err);
      alert(`Failed to restore image: ${err.message}`);
    } finally {
      setDeletingImage(null);
    }
  };

  const handlePermanentDeleteImage = async (image: ImageWithType) => {
    if (!image.isArchived) {
      alert('Only archived images can be permanently deleted. Archive the image first.');
      return;
    }

    if (!confirm(`⚠️ PERMANENT DELETE\n\nThis will permanently delete "${image.name}" from storage. This action CANNOT be undone.\n\nAre you absolutely sure?`)) {
      return;
    }

    setDeletingImage(image.fullPath);

    try {
      const { error: deleteError } = await supabase.storage
        .from('images')
        .remove([image.fullPath]);

      if (deleteError) throw deleteError;

      // Remove from local state
      setImages(prev => prev.filter(img => img.fullPath !== image.fullPath));
      setSelectedImage(null);
    } catch (err: any) {
      console.error('Error permanently deleting image:', err);
      alert(`Failed to permanently delete image: ${err.message}`);
    } finally {
      setDeletingImage(null);
    }
  };

  const handleBatchArchive = async () => {
    const count = selectedImages.size;
    if (count === 0) return;

    // Check for protected or archived images
    const imagesToArchive = images.filter(img => selectedImages.has(img.fullPath));
    const protectedImages = imagesToArchive.filter(img => img.isProtected);
    const alreadyArchived = imagesToArchive.filter(img => img.isArchived);

    if (protectedImages.length > 0) {
      alert(`Cannot archive ${protectedImages.length} protected ${protectedImages.length === 1 ? 'image' : 'images'}:\n\n${protectedImages.map(img => `${img.name} (used in ${img.usedIn?.join(', ')})`).join('\n')}\n\nPlease deselect these images first.`);
      return;
    }

    if (alreadyArchived.length > 0) {
      alert(`${alreadyArchived.length} selected ${alreadyArchived.length === 1 ? 'image is' : 'images are'} already archived. Please deselect them.`);
      return;
    }

    const usedImages = imagesToArchive.filter(img => img.usedIn && img.usedIn.length > 0);
    
    let warningMessage = `Archive ${count} ${count === 1 ? 'image' : 'images'}?`;
    
    if (usedImages.length > 0) {
      warningMessage += `\n\n⚠️ Warning: ${usedImages.length} ${usedImages.length === 1 ? 'image is' : 'images are'} currently being used and archiving may cause broken images.`;
    }
    
    warningMessage += '\n\nYou can restore archived images later from the Archive tab.';

    if (!confirm(warningMessage)) {
      return;
    }

    setBatchDeleting(true);

    try {
      // Move each image to .archive folder
      const movePromises = imagesToArchive.map(async (img) => {
        const archivePath = `.archive/${img.name}`;
        const { error } = await supabase.storage
          .from('images')
          .move(img.fullPath, archivePath);
        
        if (error) throw error;
        return { originalPath: img.fullPath, archivePath };
      });

      await Promise.all(movePromises);

      // Update local state
      setImages(prev => prev.map(img => {
        if (selectedImages.has(img.fullPath)) {
          return {
            ...img,
            fullPath: `.archive/${img.name}`,
            isArchived: true,
            originalPath: img.fullPath,
            type: 'archived'
          };
        }
        return img;
      }));
      
      setSelectedImages(new Set());
    } catch (err: any) {
      console.error('Error archiving images:', err);
      alert(`Failed to archive images: ${err.message}`);
      // Reload to ensure state is accurate
      await loadImages();
    } finally {
      setBatchDeleting(false);
    }
  };

  const handleBatchPermanentDelete = async () => {
    const count = selectedImages.size;
    if (count === 0) return;

    const imagesToDelete = images.filter(img => selectedImages.has(img.fullPath));
    const notArchived = imagesToDelete.filter(img => !img.isArchived);

    if (notArchived.length > 0) {
      alert('Only archived images can be permanently deleted. Please archive images first.');
      return;
    }

    if (!confirm(`⚠️ PERMANENT DELETE\n\nThis will permanently delete ${count} ${count === 1 ? 'image' : 'images'} from storage.\n\nThis action CANNOT be undone and these images cannot be recovered.\n\nAre you absolutely sure?`)) {
      return;
    }

    setBatchDeleting(true);

    try {
      const pathsToDelete = Array.from(selectedImages);
      const { error: deleteError } = await supabase.storage
        .from('images')
        .remove(pathsToDelete);

      if (deleteError) throw deleteError;

      // Remove from local state
      setImages(prev => prev.filter(img => !selectedImages.has(img.fullPath)));
      setSelectedImages(new Set());
    } catch (err: any) {
      console.error('Error permanently deleting images:', err);
      alert(`Failed to permanently delete images: ${err.message}`);
    } finally {
      setBatchDeleting(false);
    }
  };

  const handleBatchRestore = async () => {
    const count = selectedImages.size;
    if (count === 0) return;

    const imagesToRestore = images.filter(img => selectedImages.has(img.fullPath));
    const notArchived = imagesToRestore.filter(img => !img.isArchived || !img.originalPath);

    if (notArchived.length > 0) {
      alert('Can only restore archived images.');
      return;
    }

    if (!confirm(`Restore ${count} ${count === 1 ? 'image' : 'images'} to ${count === 1 ? 'its' : 'their'} original ${count === 1 ? 'location' : 'locations'}?`)) {
      return;
    }

    setBatchDeleting(true);

    try {
      // Move each image back to original location
      const movePromises = imagesToRestore.map(async (img) => {
        if (!img.originalPath) throw new Error(`No original path for ${img.name}`);
        
        const { error } = await supabase.storage
          .from('images')
          .move(img.fullPath, img.originalPath);
        
        if (error) throw error;
      });

      await Promise.all(movePromises);

      // Reload images to refresh categorization
      await loadImages();
      setSelectedImages(new Set());
    } catch (err: any) {
      console.error('Error restoring images:', err);
      alert(`Failed to restore images: ${err.message}`);
      // Reload to ensure state is accurate
      await loadImages();
    } finally {
      setBatchDeleting(false);
    }
  };

  const toggleImageSelection = (imagePath: string) => {
    setSelectedImages(prev => {
      const newSet = new Set(prev);
      if (newSet.has(imagePath)) {
        newSet.delete(imagePath);
      } else {
        newSet.add(imagePath);
      }
      return newSet;
    });
  };

  const toggleSelectAll = () => {
    // Only select non-protected images
    const selectableImages = filteredImages.filter(img => !img.isProtected);
    if (selectedImages.size === selectableImages.length && selectableImages.length > 0) {
      setSelectedImages(new Set());
    } else {
      setSelectedImages(new Set(selectableImages.map(img => img.fullPath)));
    }
  };

  const clearSelection = () => {
    setSelectedImages(new Set());
  };

  const filteredImages = (() => {
    if (selectedType === 'all') return images.filter(img => !img.isArchived);
    if (selectedType === 'archived') return images.filter(img => img.isArchived);
    if (selectedType === 'in-use') return images.filter(img => !img.isArchived && img.usedIn && img.usedIn.length > 0);
    if (selectedType === 'unused') return images.filter(img => !img.isArchived && (!img.usedIn || img.usedIn.length === 0));
    return images.filter(img => !img.isArchived && img.type === selectedType);
  })();

  const displayedImages = filteredImages.slice(0, displayLimit);
  const hasMoreImages = filteredImages.length > displayLimit;

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <svg className="animate-spin h-12 w-12 text-stone-600 mx-auto mb-3" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="text-sm text-stone-600">Loading images...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center max-w-md">
          <svg className="w-12 h-12 text-red-500 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <p className="text-sm text-red-700 font-medium mb-2">Failed to load images</p>
          <p className="text-xs text-stone-600 mb-4">{error}</p>
          <button
            onClick={loadImages}
            className="px-4 py-2 bg-stone-900 text-white text-sm rounded-lg hover:bg-stone-800 transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header with stats and filters */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-medium text-stone-900">Image Library</h3>
            <p className="text-sm text-stone-600 mt-0.5">
              {filteredImages.length} {filteredImages.length === 1 ? 'image' : 'images'}
              {selectedType !== 'all' && ` in ${IMAGE_TYPES.find(t => t.id === selectedType)?.label}`}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={loadImages}
              disabled={batchDeleting}
              className="px-3 py-2 text-sm font-medium text-stone-700 bg-white/60 backdrop-blur-sm border border-stone-200/50 rounded-lg hover:bg-white/80 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
              style={{
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.6)'
              }}
            >
              <svg className="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Refresh
            </button>
          </div>
        </div>

        {/* Unused images warning (shown below header) */}
        {selectedType === 'unused' && filteredImages.length > 0 && (
          <div className="mb-4 bg-amber-50 border border-amber-200 rounded-lg p-3">
            <div className="flex items-start gap-2 mb-2">
              <svg className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              <div className="flex-1">
                <p className="text-sm font-semibold text-amber-900 mb-1">Unused Images Detected</p>
                <p className="text-xs text-amber-800 leading-relaxed">
                  These images were not found in the database. They may be safe to delete, but please review carefully. 
                  Our detection scans: explicit image fields, product galleries, content fields (markdown/HTML), and all major tables.
                </p>
                <div className="flex items-center gap-3 mt-2">
                  <button
                    onClick={() => {
                      const unusedImages = filteredImages.filter(img => !img.isProtected);
                      setSelectedImages(new Set(unusedImages.map(img => img.fullPath)));
                    }}
                    disabled={batchDeleting}
                    className="text-xs font-semibold text-red-700 hover:text-red-800 underline disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
                  >
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Select all unused images
                  </button>
                  <span className="text-xs text-amber-700">Then use batch delete below</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Batch actions bar */}
        {selectedImages.size > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mb-4 p-4 bg-stone-900 text-white rounded-xl flex items-center justify-between shadow-lg"
          >
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium">
                {selectedImages.size} {selectedImages.size === 1 ? 'image' : 'images'} selected
              </span>
              <button
                onClick={clearSelection}
                disabled={batchDeleting}
                className="text-xs text-white/70 hover:text-white transition-colors disabled:opacity-50"
              >
                Clear selection
              </button>
            </div>
            <div className="flex items-center gap-2">
              {selectedType === 'archived' ? (
                <>
                  <button
                    onClick={handleBatchRestore}
                    disabled={batchDeleting}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    {batchDeleting ? (
                      <>
                        <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Restoring...
                      </>
                    ) : (
                      <>
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                        </svg>
                        Restore Selected
                      </>
                    )}
                  </button>
                  <button
                    onClick={handleBatchPermanentDelete}
                    disabled={batchDeleting}
                    className="px-4 py-2 bg-red-700 hover:bg-red-800 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                  >
                    {batchDeleting ? (
                      <>
                        <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Deleting...
                      </>
                    ) : (
                      <>
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                        Delete Forever
                      </>
                    )}
                  </button>
                </>
              ) : (
                <button
                  onClick={handleBatchArchive}
                  disabled={batchDeleting}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {batchDeleting ? (
                    <>
                      <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Archiving...
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                      </svg>
                      Archive Selected
                    </>
                  )}
                </button>
              )}
            </div>
          </motion.div>
        )}

        {/* Filter dropdown and Select All */}
        <div className="flex items-center justify-between gap-4">
          <div className="relative">
            <button
              onClick={() => setShowFilterMenu(!showFilterMenu)}
              disabled={batchDeleting}
              className="flex items-center gap-2 px-4 py-2.5 bg-white/60 backdrop-blur-sm border border-stone-200/50 rounded-lg hover:bg-white/80 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
              style={{
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.6)'
              }}
            >
              <svg className="w-4 h-4 text-stone-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
              </svg>
              <span className="text-sm font-medium text-stone-900">
                {IMAGE_TYPES.find(t => t.id === selectedType)?.label || 'All Images'}
              </span>
              <span className="text-xs text-stone-500">({filteredImages.length})</span>
              <svg className={`w-4 h-4 text-stone-500 transition-transform ${showFilterMenu ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>

            {/* Filter dropdown menu */}
            <AnimatePresence>
              {showFilterMenu && (
                <>
                  {/* Backdrop */}
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setShowFilterMenu(false)}
                  />
                  
                  {/* Menu */}
                  <motion.div
                    initial={{ opacity: 0, y: -10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -10, scale: 0.95 }}
                    transition={{ duration: 0.15 }}
                    className="absolute top-full left-0 mt-2 w-64 bg-white/80 backdrop-blur-xl border border-stone-200/50 rounded-xl shadow-xl z-50 overflow-hidden"
                    style={{
                      boxShadow: '0 8px 32px rgba(0, 0, 0, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.7)'
                    }}
                  >
                    <div className="p-2">
                      {IMAGE_TYPES.map(type => {
                        const count = (() => {
                          if (type.id === 'all') return images.filter(img => !img.isArchived).length;
                          if (type.id === 'archived') return images.filter(img => img.isArchived).length;
                          if (type.id === 'in-use') return images.filter(img => !img.isArchived && img.usedIn && img.usedIn.length > 0).length;
                          if (type.id === 'unused') return images.filter(img => !img.isArchived && (!img.usedIn || img.usedIn.length === 0)).length;
                          return images.filter(img => !img.isArchived && img.type === type.id).length;
                        })();

                        return (
                          <button
                            key={type.id}
                            onClick={() => {
                              setSelectedType(type.id);
                              setShowFilterMenu(false);
                            }}
                            disabled={batchDeleting}
                            className={`w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                              selectedType === type.id
                                ? 'bg-stone-900 text-white shadow-sm'
                                : 'text-stone-700 hover:bg-white/60'
                            }`}
                          >
                            <span>{type.label}</span>
                            <span className={`text-xs ${
                              selectedType === type.id ? 'text-white/70' : 'text-stone-500'
                            }`}>
                              {count}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          {filteredImages.length > 0 && (
            <label className="flex items-center gap-2 px-3 py-2 bg-white/60 backdrop-blur-sm border border-stone-200/50 rounded-lg hover:bg-white/80 transition-all cursor-pointer shadow-sm"
              style={{
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.6)'
              }}
            >
              <input
                type="checkbox"
                checked={(() => {
                  const selectableImages = filteredImages.filter(img => !img.isProtected);
                  return selectedImages.size === selectableImages.length && selectableImages.length > 0;
                })()}
                onChange={toggleSelectAll}
                disabled={batchDeleting}
                className="w-4 h-4 text-stone-900 border-stone-300 rounded focus:ring-stone-500 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              />
              <span className="text-sm font-medium text-stone-700">
                Select All{filteredImages.some(img => img.isProtected) && ' (unprotected)'}
              </span>
            </label>
          )}
        </div>
      </div>

      {/* Image grid - optimized with lazy loading and blur placeholders */}
      {filteredImages.length === 0 ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center max-w-md">
            <svg className="w-16 h-16 text-stone-300 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p className="text-sm font-medium text-stone-700">No images found</p>
            <p className="text-xs text-stone-500 mt-1 leading-relaxed">
              {selectedType === 'all' 
                ? 'Upload images through the CMS to see them here'
                : selectedType === 'unused'
                ? 'Excellent! All images in storage are referenced in your database (products, news, homepage, etc.) and appear to be in use.'
                : selectedType === 'in-use'
                ? 'No images found with active database references.'
                : `No images in ${IMAGE_TYPES.find(t => t.id === selectedType)?.label}`
              }
            </p>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto" style={{ willChange: 'scroll-position' }}>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 pb-6">
            {displayedImages.map(image => {
              const isSelected = selectedImages.has(image.fullPath);
              return (
                <motion.div
                  key={image.fullPath}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className={`group relative aspect-square bg-stone-100 rounded-lg overflow-hidden cursor-pointer border-2 transition-all hover:shadow-md ${
                    isSelected 
                      ? 'border-stone-900 ring-2 ring-stone-900 ring-offset-2' 
                      : 'border-stone-200 hover:border-stone-300'
                  }`}
                  onClick={() => setSelectedImage(image)}
                >
                  {!loadedImages.has(image.fullPath) && (
                    <div className="absolute inset-0 bg-stone-200 animate-pulse" />
                  )}
                  <img
                    src={getImageThumbnail(image.fullPath)}
                    alt={image.name}
                    loading="lazy"
                    decoding="async"
                    onLoad={() => {
                      setLoadedImages(prev => {
                        const next = new Set(prev);
                        next.add(image.fullPath);
                        return next;
                      });
                    }}
                    className={`w-full h-full object-cover transition-all duration-300 group-hover:scale-105 ${
                      loadedImages.has(image.fullPath) ? 'opacity-100' : 'opacity-0'
                    }`}
                    style={{
                      contentVisibility: 'auto',
                    }}
                  />
                  
                  {/* Selection checkbox */}
                  {!image.isProtected && (
                    <div 
                      className="absolute top-2 left-2 z-10"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleImageSelection(image.fullPath);
                      }}
                    >
                      <label className="flex items-center justify-center w-6 h-6 bg-white rounded-md shadow-lg cursor-pointer hover:bg-stone-50 transition-colors">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}}
                          disabled={batchDeleting}
                          className="w-4 h-4 text-stone-900 border-stone-300 rounded focus:ring-stone-500 cursor-pointer disabled:opacity-50"
                        />
                      </label>
                    </div>
                  )}

                  {/* Archived badge */}
                  {image.isArchived && (
                    <div className="absolute top-2 left-2 z-10 px-2 py-1 bg-amber-600 text-white text-[10px] font-bold rounded-md shadow-lg flex items-center gap-1">
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                      </svg>
                      ARCHIVED
                    </div>
                  )}

                  {/* Protected badge */}
                  {image.isProtected && (
                    <div className="absolute top-2 left-2 z-10 px-2 py-1 bg-rose-600 text-white text-[10px] font-bold rounded-md shadow-lg flex items-center gap-1">
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                      </svg>
                      PROTECTED
                    </div>
                  )}

                  {/* Usage badge */}
                  {!image.isArchived && !image.isProtected && image.usedIn && image.usedIn.length > 0 && (
                    <div className="absolute top-2 right-2 z-10 px-2 py-1 bg-emerald-500 text-white text-[10px] font-bold rounded-md shadow-lg">
                      IN USE
                    </div>
                  )}

                  {/* Unused badge (only show in "unused" filter view) */}
                  {selectedType === 'unused' && !image.isArchived && !image.isProtected && (!image.usedIn || image.usedIn.length === 0) && (
                    <div className="absolute top-2 right-2 z-10 px-2 py-1 bg-stone-400 text-white text-[10px] font-bold rounded-md shadow-lg">
                      UNUSED
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                    <div className="absolute bottom-0 left-0 right-0 p-3">
                      <p className="text-xs font-medium text-white truncate">{image.name}</p>
                      <p className="text-[10px] text-white/80 mt-0.5">
                        {formatFileSize(image.metadata?.size || 0)}
                      </p>
                    </div>
                  </div>
                  {deletingImage === image.fullPath && (
                    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center">
                      <svg className="animate-spin h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
          
          {/* Load More Button */}
          {hasMoreImages && (
            <div className="flex justify-center py-6 border-t border-stone-200">
              <button
                onClick={() => setDisplayLimit(prev => prev + 100)}
                className="px-6 py-3 bg-white border border-stone-200 rounded-lg hover:bg-stone-50 transition-colors text-sm font-medium text-stone-700 flex items-center gap-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
                Load More ({filteredImages.length - displayLimit} remaining)
              </button>
            </div>
          )}
        </div>
      )}

      {/* Image detail modal */}
      <AnimatePresence>
        {selectedImage && (
          <>
            <motion.div
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[10000]"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedImage(null)}
            />
            <motion.div
              className="fixed inset-0 z-[10001] flex items-center justify-center p-4"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-stone-200 px-6 py-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-xs uppercase tracking-wider text-stone-400">
                        {IMAGE_TYPES.find(t => t.id === selectedImage.type)?.label || 'Other'}
                      </p>
                      {selectedImage.isArchived && (
                        <span className="px-2 py-0.5 bg-amber-600 text-white text-[10px] font-bold rounded flex items-center gap-1">
                          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                          </svg>
                          ARCHIVED
                        </span>
                      )}
                      {selectedImage.isProtected && (
                        <span className="px-2 py-0.5 bg-rose-600 text-white text-[10px] font-bold rounded flex items-center gap-1">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                          </svg>
                          PROTECTED
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-medium text-stone-900 truncate">{selectedImage.name}</h3>
                  </div>
                  <button
                    onClick={() => setSelectedImage(null)}
                    className="ml-4 p-2 rounded-full hover:bg-stone-100 transition-colors"
                  >
                    <svg className="w-5 h-5 text-stone-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>

                {/* Image preview */}
                <div className="flex-1 overflow-auto p-6">
                  <div className="bg-stone-50 rounded-lg p-4 mb-6">
                    <img
                      src={getImageUrl(selectedImage.fullPath)}
                      alt={selectedImage.name}
                      className="max-w-full max-h-[50vh] mx-auto rounded-lg shadow-lg"
                    />
                  </div>

                  {/* Metadata */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-xs uppercase tracking-wider text-stone-500 mb-1">File Size</p>
                      <p className="text-stone-900">{formatFileSize(selectedImage.metadata?.size || 0)}</p>
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-wider text-stone-500 mb-1">Type</p>
                      <p className="text-stone-900">{selectedImage.metadata?.mimetype || 'Unknown'}</p>
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-wider text-stone-500 mb-1">Uploaded</p>
                      <p className="text-stone-900">{formatDate(selectedImage.created_at)}</p>
                    </div>
                    <div>
                      <p className="text-xs uppercase tracking-wider text-stone-500 mb-1">Last Modified</p>
                      <p className="text-stone-900">{formatDate(selectedImage.updated_at)}</p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-xs uppercase tracking-wider text-stone-500 mb-1">Storage Path</p>
                      <p className="text-stone-900 font-mono text-xs bg-stone-100 px-2 py-1 rounded">
                        {selectedImage.fullPath}
                      </p>
                    </div>
                    <div className="col-span-2">
                      <p className="text-xs uppercase tracking-wider text-stone-500 mb-1">Usage Status</p>
                      {selectedImage.usedIn && selectedImage.usedIn.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {selectedImage.usedIn.map((usage, index) => (
                            <span
                              key={index}
                              className={`px-2 py-1 text-xs font-medium rounded ${
                                selectedImage.isProtected
                                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                                  : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              }`}
                            >
                              {usage}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <div className="bg-stone-100 border border-stone-200 rounded px-3 py-2">
                          <p className="text-sm text-stone-700">
                            <svg className="w-4 h-4 inline mr-1.5 text-stone-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            Not currently used on the site
                          </p>
                          <p className="text-xs text-stone-600 mt-1">This image can be safely deleted if no longer needed.</p>
                        </div>
                      )}
                    </div>
                    {selectedImage.isArchived && (
                      <div className="col-span-2">
                        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                          <div className="flex items-start gap-2">
                            <svg className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                            </svg>
                            <div>
                              <p className="text-sm font-semibold text-amber-900">Archived Image</p>
                              <p className="text-xs text-amber-700 mt-1">
                                This image is in the archive and cannot be displayed on the site. You can restore it to make it available again, or permanently delete it to free up storage space.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    {selectedImage.isProtected && (
                      <div className="col-span-2">
                        <div className="bg-rose-50 border border-rose-200 rounded-lg p-3">
                          <div className="flex items-start gap-2">
                            <svg className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                            </svg>
                            <div>
                              <p className="text-sm font-semibold text-rose-900">Protected Image</p>
                              <p className="text-xs text-rose-700 mt-1">
                                This image cannot be archived as it is actively being used. Remove it from the locations listed above to enable archiving.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="border-t border-stone-200 px-6 py-4 flex items-center justify-between">
                  <a
                    href={getImageUrl(selectedImage.fullPath)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 text-sm font-medium text-stone-700 bg-white border border-stone-200 rounded-lg hover:bg-stone-50 transition-colors"
                  >
                    <svg className="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                    Open Original
                  </a>
                  
                  <div className="flex items-center gap-2">
                    {selectedImage.isArchived ? (
                      <>
                        <button
                          onClick={() => handleRestoreImage(selectedImage)}
                          disabled={deletingImage === selectedImage.fullPath}
                          className="px-4 py-2 text-sm font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {deletingImage === selectedImage.fullPath ? (
                            <>
                              <svg className="animate-spin w-4 h-4 inline mr-2" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Restoring...
                            </>
                          ) : (
                            <>
                              <svg className="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6" />
                              </svg>
                              Restore
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => handlePermanentDeleteImage(selectedImage)}
                          disabled={deletingImage === selectedImage.fullPath}
                          className="px-4 py-2 text-sm font-medium text-white bg-red-700 rounded-lg hover:bg-red-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {deletingImage === selectedImage.fullPath ? (
                            <>
                              <svg className="animate-spin w-4 h-4 inline mr-2" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Deleting Forever...
                            </>
                          ) : (
                            <>
                              <svg className="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                              </svg>
                              Delete Forever
                            </>
                          )}
                        </button>
                      </>
                    ) : selectedImage.isProtected ? (
                      <button
                        disabled
                        className="px-4 py-2 text-sm font-medium text-stone-400 bg-stone-100 rounded-lg cursor-not-allowed"
                        title="Cannot delete protected images"
                      >
                        <svg className="w-4 h-4 inline mr-2" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                        </svg>
                        Protected - Cannot Archive
                      </button>
                    ) : (
                      <button
                        onClick={() => handleArchiveImage(selectedImage)}
                        disabled={deletingImage === selectedImage.fullPath}
                        className="px-4 py-2 text-sm font-medium text-white bg-amber-600 rounded-lg hover:bg-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {deletingImage === selectedImage.fullPath ? (
                          <>
                            <svg className="animate-spin w-4 h-4 inline mr-2" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Archiving...
                          </>
                        ) : (
                          <>
                            <svg className="w-4 h-4 inline mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" />
                            </svg>
                            Archive
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}








