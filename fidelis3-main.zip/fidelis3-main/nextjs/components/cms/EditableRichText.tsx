'use client';

import React from 'react';
import { useEditMode } from '../../contexts/EditModeContext';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Link from '@tiptap/extension-link';
import Underline from '@tiptap/extension-underline';
import { motion } from 'framer-motion';
import { sanitizeHTML } from '../../lib/sanitize';
import { parseTipTapContent } from '../../lib/parse-tiptap-content';

interface EditableRichTextProps {
  value: string;
  fieldName: string;
  placeholder?: string;
  className?: string;
  minHeight?: string;
}

export const EditableRichText: React.FC<EditableRichTextProps> = ({
  value,
  fieldName,
  placeholder = 'Start typing...',
  className = '',
  minHeight = '200px'
}) => {
  const { isEditMode, registerChange } = useEditMode();

  const extensions = React.useMemo(
    () => [
      // Ensure StarterKit doesn't register built-in link/underline variants that would duplicate our custom ones
      StarterKit.configure({ ...( { link: false, underline: false } as any) }),
      Underline,
      Link.configure({
        openOnClick: false,
        HTMLAttributes: {
          class: 'text-blue-600 underline hover:text-blue-800',
        },
      }),
    ],
    []
  );

  const editor = useEditor({
    extensions,
    content: value || '',
    editable: isEditMode,
    immediatelyRender: false,
    onUpdate: ({ editor }) => {
      registerChange(fieldName, editor.getHTML());
    },
  });

  React.useEffect(() => {
    if (editor && value !== editor.getHTML()) {
      editor.commands.setContent(value || '');
    }
  }, [value, editor]);

  React.useEffect(() => {
    if (editor) {
      editor.setEditable(isEditMode);
    }
  }, [isEditMode, editor]);

  if (!editor) {
    return null;
  }

  if (!isEditMode) {
    // Parse TipTap JSON or plain text to properly formatted HTML
    const parsedHTML = parseTipTapContent(value);
    // Sanitize HTML to prevent XSS attacks
    const sanitizedHTML = sanitizeHTML(parsedHTML);
    
    return (
      <div 
        className={className}
        dangerouslySetInnerHTML={{ __html: sanitizedHTML }}
      />
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-2"
    >
      <div className="flex flex-wrap gap-2 p-3 bg-white/40 backdrop-blur-sm border border-stone-200/50 rounded-t-md" style={{
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.5)'
      }}>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleBold().run()}
          className={`px-4 py-2 text-sm font-semibold rounded-md transition-all duration-200 ${
            editor.isActive('bold') 
              ? 'bg-stone-900 text-white shadow-sm' 
              : 'bg-white/60 text-stone-700 hover:bg-white/80 border border-stone-200/50'
          }`}
        >
          B
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleItalic().run()}
          className={`px-4 py-2 text-sm italic rounded-md transition-all duration-200 ${
            editor.isActive('italic') 
              ? 'bg-stone-900 text-white shadow-sm' 
              : 'bg-white/60 text-stone-700 hover:bg-white/80 border border-stone-200/50'
          }`}
        >
          I
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleUnderline().run()}
          className={`px-4 py-2 text-sm underline rounded-md transition-all duration-200 ${
            editor.isActive('underline') 
              ? 'bg-stone-900 text-white shadow-sm' 
              : 'bg-white/60 text-stone-700 hover:bg-white/80 border border-stone-200/50'
          }`}
        >
          U
        </button>
            <button
              type="button"
              onClick={() => editor.chain().focus().toggleBulletList().run()}
              className={`px-4 py-2 text-sm font-semibold rounded-md transition-all duration-200 ${
                editor.isActive('bulletList') 
                  ? 'bg-stone-900 text-white shadow-sm' 
                  : 'bg-white/60 text-stone-700 hover:bg-white/80 border border-stone-200/50'
              }`}
            >
              • List
            </button>
            <button
              type="button"
              onClick={() => editor.chain().focus().toggleOrderedList().run()}
              className={`px-4 py-2 text-sm font-semibold rounded-md transition-all duration-200 ${
                editor.isActive('orderedList') 
                  ? 'bg-stone-900 text-white shadow-sm' 
                  : 'bg-white/60 text-stone-700 hover:bg-white/80 border border-stone-200/50'
              }`}
            >
              1. List
            </button>
      </div>
      <EditorContent 
        editor={editor} 
        className={`cms-editable-field rounded-b-lg p-4 ${className}`}
        style={{ minHeight }}
      />
    </motion.div>
  );
};

