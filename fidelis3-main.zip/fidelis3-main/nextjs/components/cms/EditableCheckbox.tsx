'use client';

import React from 'react';
import { useEditMode } from '../../contexts/EditModeContext';
import { motion } from 'framer-motion';

interface EditableCheckboxProps {
  value: boolean;
  fieldName: string;
  label: string;
  description?: string;
  className?: string;
}

export const EditableCheckbox: React.FC<EditableCheckboxProps> = ({
  value,
  fieldName,
  label,
  description,
  className = ''
}) => {
  const { isEditMode, registerChange } = useEditMode();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    registerChange(fieldName, e.target.checked);
  };

  if (!isEditMode) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`p-4 bg-white/40 backdrop-blur-sm border border-stone-200/50 rounded-md ${className}`}
      style={{
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.5)'
      }}
    >
      <div className="flex items-start space-x-3">
      <input
        type="checkbox"
        id={fieldName}
        defaultChecked={value}
        onChange={handleChange}
          className="mt-1 h-5 w-5 text-stone-900 bg-white border-2 border-stone-300 rounded focus:ring-2 focus:ring-stone-400 focus:ring-offset-2 focus:ring-offset-white/60 cursor-pointer"
      />
      <div className="flex-1">
          <label htmlFor={fieldName} className="block text-sm font-semibold text-stone-900 tracking-wide uppercase mb-1 cursor-pointer">
          {label}
        </label>
        {description && (
            <p className="text-xs text-stone-600 leading-relaxed">{description}</p>
        )}
        </div>
      </div>
    </motion.div>
  );
};

