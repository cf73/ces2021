'use client';

import React, { useState } from 'react';
import { useEditMode } from '../../contexts/EditModeContext';
import { motion } from 'framer-motion';

interface EditableToggleProps {
  value: boolean;
  fieldName: string;
  label: string;
  description?: string;
  onLabel?: string;
  offLabel?: string;
  className?: string;
  onChange?: (value: boolean) => void;
}

export const EditableToggle: React.FC<EditableToggleProps> = ({
  value,
  fieldName,
  label,
  description,
  onLabel = 'On',
  offLabel = 'Off',
  className = '',
  onChange
}) => {
  const { isEditMode, registerChange } = useEditMode();
  const [isToggled, setIsToggled] = useState(value);

  const handleToggle = () => {
    const newValue = !isToggled;
    setIsToggled(newValue);
    
    if (onChange) {
      onChange(newValue);
    } else {
      registerChange(fieldName, newValue);
    }
  };

  // Sync with prop changes
  React.useEffect(() => {
    setIsToggled(value);
  }, [value]);

  if (!isEditMode) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3 }}
      className={`p-4 bg-white/40 backdrop-blur-sm border border-stone-200/50 rounded-lg ${className}`}
      style={{
        boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.5)'
      }}
    >
      <div className="flex items-center justify-between gap-4">
        <div className="flex-1">
          <label className="block text-sm font-semibold text-stone-900 tracking-wide uppercase mb-1">
            {label}
          </label>
          {description && (
            <p className="text-xs text-stone-600 leading-relaxed">{description}</p>
          )}
        </div>
        
        <button
          type="button"
          onClick={handleToggle}
          className={`
            relative inline-flex h-6 w-12 items-center rounded-full transition-all duration-300 ease-out flex-shrink-0
            focus:outline-none focus:ring-2 focus:ring-stone-400 focus:ring-offset-2 focus:ring-offset-white/60
            ${isToggled 
              ? 'bg-stone-900 shadow-sm' 
              : 'bg-stone-200 shadow-inner'
            }
          `}
          aria-label={`Toggle ${label}`}
        >
          <span
            className={`
              inline-block h-4 w-4 transform rounded-full transition-all duration-300 ease-out
              ${isToggled 
                ? 'translate-x-7 bg-white shadow-md' 
                : 'translate-x-1 bg-white shadow-sm'
              }
            `}
          />
        </button>
      </div>
    </motion.div>
  );
};

