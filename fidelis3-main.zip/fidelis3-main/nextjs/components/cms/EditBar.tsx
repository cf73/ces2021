'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { useEditMode } from '../../contexts/EditModeContext';
import { useAuth } from '../../contexts/AuthContext';

interface EditBarProps {
  onSave?: () => Promise<void>;
  onCancel?: () => void;
  onTogglePublish?: (published: boolean) => Promise<void>;
  onDelete?: () => void;
  isPublished?: boolean;
  className?: string;
  onGenerateAI?: () => Promise<void>;
  isGeneratingAI?: boolean;
  aiGenerationError?: string | null;
  aiSuccessData?: {
    goodSynergies: number;
    alsoConsider: number;
    timestamp: string;
  } | null;
  onOpenSEO?: () => void;
  productId?: string;
  createNewHref?: string;
  createNewLabel?: string;
  forceDisableSave?: boolean;
  saveDisabledReason?: string;
  saveLabel?: string;
  savingLabel?: string;
  disableGenerateAI?: boolean;
  generateAIDisabledReason?: string;
  forceConfirmOnCancel?: boolean;
  cancelConfirmMessage?: string;
}

export const EditBar: React.FC<EditBarProps> = ({
  onSave,
  onCancel,
  onTogglePublish,
  onDelete,
  isPublished = true,
  className = '',
  onGenerateAI,
  isGeneratingAI = false,
  aiGenerationError,
  aiSuccessData,
  onOpenSEO,
  productId,
  createNewHref,
  createNewLabel = 'Create New',
  forceDisableSave = false,
  saveDisabledReason,
  saveLabel = 'Save',
  savingLabel = 'Saving...',
  disableGenerateAI = false,
  generateAIDisabledReason,
  forceConfirmOnCancel = false,
  cancelConfirmMessage
}) => {
  const { user } = useAuth();
  const {
    isEditMode,
    toggleEditMode,
    hasUnsavedChanges,
    clearChanges,
    isSaving
  } = useEditMode();

  const [localPublished, setLocalPublished] = useState(isPublished);
  const [showInfoPopover, setShowInfoPopover] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);

  useEffect(() => {
    setLocalPublished(isPublished);
  }, [isPublished]);

  const [isTogglingPublish, setIsTogglingPublish] = useState(false);
  const hasPageSpecificActions = Boolean(onSave || onTogglePublish || onOpenSEO || onGenerateAI || onDelete);

  // Countdown timer for AI generation
  useEffect(() => {
    if (isGeneratingAI && countdown === null) {
      // Start countdown at 60 seconds
      setCountdown(60);
    } else if (!isGeneratingAI) {
      // Reset countdown when generation completes
      setCountdown(null);
    }
  }, [isGeneratingAI]);

  // Decrement countdown every second
  useEffect(() => {
    if (countdown !== null && countdown > 0) {
      const timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  if (!user) return null;

  const handleSave = async () => {
    if (onSave) {
      await onSave();
      toggleEditMode(true);
    }
  };

  const handleCancel = () => {
    if (forceConfirmOnCancel || hasUnsavedChanges) {
      const confirm = window.confirm(
        cancelConfirmMessage || 'Are you sure you want to cancel? All unsaved changes will be lost.'
      );

      if (!confirm) return;
    }
    
    clearChanges();
    if (onCancel) {
      onCancel();
    }
    toggleEditMode(true);
  };

  const handleTogglePublish = async () => {
    if (!onTogglePublish) return;

    const action = localPublished ? 'unpublish' : 'publish';
    const confirm = window.confirm(
      `Are you sure you want to ${action} this content? ${
        localPublished
          ? 'It will be hidden from the public site.'
          : 'It will become visible on the public site.'
      }`
    );

    if (!confirm) return;

    setIsTogglingPublish(true);
    try {
      await onTogglePublish(!localPublished);
      setLocalPublished(!localPublished);
    } finally {
      setIsTogglingPublish(false);
    }
  };

  // If createNewHref is provided, show a "Create New" button instead of edit mode toggle
  if (createNewHref && !isEditMode) {
  return (
    <motion.div
        initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
      transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
        className={`fixed bottom-6 left-6 z-[200] w-[280px] ${className}`}
    >
        <div 
          className="px-4 py-4 rounded-xl flex flex-col gap-3 bg-white/60 backdrop-blur-xl border border-stone-200/50 shadow-lg"
          style={{
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.6)'
          }}
        >
          <Link
            href={createNewHref}
            className="w-full inline-flex items-center justify-center px-4 py-2.5 text-sm font-medium bg-stone-900 text-white hover:bg-stone-800 transition-all duration-200 rounded-md shadow-sm"
              >
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
            {createNewLabel}
          </Link>
        </div>
      </motion.div>
    );
  }

  return (
    <>
      {/* Compact Edit Mode Toggle - When Closed */}
      {!isEditMode && (
              <motion.button
          initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
                onClick={() => toggleEditMode()}
          className="fixed bottom-6 left-6 z-[200] w-12 h-12 bg-stone-900 text-white rounded-md shadow-lg hover:shadow-xl hover:bg-stone-800 transition-all duration-200 flex items-center justify-center group"
          aria-label="Open edit mode"
              >
                <svg 
            className="w-5 h-5 transition-transform duration-200 group-hover:rotate-12" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" 
                  />
                </svg>
              </motion.button>
      )}

      {/* Full Edit Bar - When Open */}
      {isEditMode && (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 20 }}
        transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
        className={`fixed bottom-6 left-6 z-[200] w-[280px] ${className}`}
      >
      <div 
        className="px-4 py-4 rounded-xl flex flex-col gap-3 bg-white/60 backdrop-blur-xl border border-stone-200/50 shadow-lg"
        style={{
          boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.6)'
        }}
      >
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
          className="flex flex-col gap-3"
        >
              {/* Section 2: Primary Actions */}
              {hasPageSpecificActions ? (
              <div className="flex flex-col gap-2">
                {/* Unsaved Changes Indicator */}
                <AnimatePresence>
                    {hasUnsavedChanges && !isSaving && onSave && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                      className="flex items-center justify-center text-xs font-medium text-stone-600 py-1"
              >
                      <span className="w-2 h-2 bg-stone-400 rounded-full mr-2 animate-pulse"></span>
                      Unsaved Changes
                    </motion.div>
                  )}
                </AnimatePresence>
                
                  {onSave && (
                <button
                  onClick={handleSave}
                  disabled={isSaving || !hasUnsavedChanges || forceDisableSave}
                  title={forceDisableSave ? saveDisabledReason || 'Resolve pending requirements before saving' : undefined}
                  className="w-full inline-flex items-center justify-center px-4 py-2.5 text-sm font-medium bg-stone-900 text-white hover:bg-stone-800 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed rounded-md shadow-sm"
                >
                  {isSaving ? (
                    <>
                      <svg className="animate-spin mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      {savingLabel}
                    </>
                  ) : (
                    <>
                      <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {saveLabel}
                    </>
                  )}
                </button>
                  )}
                
                  {onCancel && (
                <button
                  onClick={handleCancel}
                  disabled={isSaving}
                  className="w-full inline-flex items-center justify-center px-4 py-2 text-sm font-medium bg-white/40 backdrop-blur-sm border border-stone-300 text-stone-700 hover:bg-white/60 hover:border-stone-400 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed rounded-md"
                >
                  Cancel
                </button>
                  )}
                </div>
              ) : (
                <div className="rounded-lg border border-dashed border-stone-300 bg-white/40 px-3 py-2 text-xs text-stone-500">
                  No inline edit controls on this page. Use the global tools below.
              </div>
              )}

              {/* Section 3: Content Tools */}
              {(onGenerateAI || onOpenSEO) && (
              <div className="flex flex-col gap-2 pt-3 border-t border-stone-200/50">
                {/* Flesh Out Button with Info */}
                {onGenerateAI && (
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={onGenerateAI}
                        disabled={isGeneratingAI || disableGenerateAI}
                        title={disableGenerateAI ? generateAIDisabledReason : undefined}
                        className="flex-1 inline-flex items-center justify-center px-4 py-2.5 text-sm font-medium bg-stone-900 text-white hover:bg-stone-800 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed rounded-md shadow-sm"
                      >
                        {isGeneratingAI ? (
                          <>
                            <svg className="animate-spin mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Generating{countdown !== null ? ` (${countdown}s)` : '...'}
                          </>
                        ) : (
                          <>
                            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                            </svg>
                            Flesh Out
                          </>
                        )}
                      </button>
                      
                      {/* Info Icon */}
                      <button
                        onClick={() => setShowInfoPopover(!showInfoPopover)}
                        className="inline-flex items-center justify-center w-8 h-8 rounded-md bg-white/40 backdrop-blur-sm border border-stone-300 text-stone-600 hover:bg-white/60 hover:border-stone-400 transition-all duration-200"
                        title="What does this generate?"
                      >
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                        </svg>
                      </button>
                    </div>

                    {/* Success/Error Status Display */}
                    <AnimatePresence mode="wait">
                      {aiSuccessData && (
                        <motion.div
                          key="success"
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          transition={{ duration: 0.3 }}
                          className="flex flex-col gap-1 px-3 py-2 bg-green-100 border border-green-300 rounded-lg"
                        >
                          <div className="flex items-center gap-2">
                            <svg className="w-4 h-4 text-green-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                            </svg>
                            <p className="text-xs font-semibold text-green-900">Generated!</p>
                          </div>
                          <p className="text-xs text-green-700">
                            {aiSuccessData.goodSynergies} synergies, {aiSuccessData.alsoConsider} alternatives
                          </p>
                        </motion.div>
                      )}
                      {aiGenerationError && !aiSuccessData && (
                        <motion.div
                          key="error"
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          transition={{ duration: 0.3 }}
                          className="flex flex-col gap-1 px-3 py-2 bg-red-100 border border-red-300 rounded-lg"
                        >
                          <div className="flex items-center gap-2">
                            <svg className="w-4 h-4 text-red-600 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                            </svg>
                            <p className="text-xs font-semibold text-red-900">Failed</p>
                          </div>
                          <p className="text-xs text-red-700">{aiGenerationError}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {/* SEO Button */}
                {onOpenSEO && (
                  <button
                    onClick={onOpenSEO}
                    className="w-full inline-flex items-center justify-center px-4 py-2 text-sm font-medium bg-white/40 backdrop-blur-sm border border-stone-300 text-stone-700 hover:bg-white/60 hover:border-stone-400 transition-all duration-200 rounded-md"
                  >
                    <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    SEO
                  </button>
                )}
              </div>
              )}

              {/* Section 4: Meta Controls */}
              {onTogglePublish && (
              <div className="flex flex-col gap-2 pt-3 border-t border-stone-200/50">
                {/* Published Toggle */}
                <div className="flex items-center justify-between px-2 py-1">
                  <span className="text-xs font-medium uppercase tracking-wide text-stone-600">
                    {localPublished ? 'Published' : 'Draft'}
                  </span>
                  <button
                    onClick={handleTogglePublish}
                    disabled={isTogglingPublish}
                    className={`
                      relative inline-flex h-6 w-12 items-center rounded-full transition-all duration-300 ease-out
                      focus:outline-none focus:ring-2 focus:ring-stone-400 focus:ring-offset-2 focus:ring-offset-white/60
                      disabled:opacity-40 disabled:cursor-not-allowed
                      ${localPublished 
                        ? 'bg-stone-900 shadow-sm' 
                        : 'bg-stone-200 shadow-inner'
                      }
                    `}
                    aria-label={localPublished ? 'Unpublish' : 'Publish'}
                  >
                    <span
                      className={`
                        inline-block h-4 w-4 transform rounded-full transition-all duration-300 ease-out
                        ${localPublished 
                          ? 'translate-x-7 bg-white shadow-md' 
                          : 'translate-x-1 bg-white shadow-sm'
                        }
                      `}
                    />
                  </button>
                </div>

                {/* Delete Button */}
                {onDelete && (
                  <button
                    onClick={onDelete}
                    disabled={isSaving}
                    className="w-full inline-flex items-center justify-center px-3 py-1.5 text-xs font-medium bg-stone-700 text-white hover:bg-stone-800 transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed rounded-md"
                    title="Delete"
                  >
                    <svg className="w-3 h-3 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                    Delete
                  </button>
                )}
              </div>
              )}
        </motion.div>
      </div>
      </motion.div>
      )}

      {/* Info Popover - Positioned to the right of EditBar, bottom-aligned */}
      <AnimatePresence>
        {showInfoPopover && onGenerateAI && isEditMode && (
          <motion.div
            initial={{ opacity: 0, x: -10, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -10, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="fixed left-[calc(1.5rem+280px+0.75rem)] bottom-6 w-80 bg-white/80 backdrop-blur-xl rounded-lg shadow-xl border border-stone-200/50 p-4 z-[201]"
            style={{
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.6)'
            }}
          >
            <div className="text-sm text-stone-700">
              <p className="font-semibold text-stone-900 mb-2">This will generate:</p>
              <ul className="space-y-1.5">
                <li className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>SEO-optimized brief description</span>
                </li>
                <li className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>"Good Synergies" product pairings with reasoning</span>
                </li>
                <li className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>"Also Consider" alternative products</span>
                </li>
                <li className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Custom CTAs and helper text</span>
                </li>
                <li className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                  <span>Web search for professional reviews & quotes (if quote is empty)</span>
                </li>
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

