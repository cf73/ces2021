'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useEditMode } from '../../contexts/EditModeContext';

interface EditableTextProps {
  value: string;
  fieldName: string;
  fieldType?: 'text' | 'textarea' | 'number';
  placeholder?: string;
  className?: string;
  rows?: number;
  required?: boolean;
  onChange?: (value: string) => void;
}

export const EditableText: React.FC<EditableTextProps> = ({
  value,
  fieldName,
  fieldType = 'text',
  placeholder = '',
  className = '',
  rows = 4,
  required = false,
  onChange
}) => {
  const { isEditMode, registerChange } = useEditMode();
  const [localValue, setLocalValue] = useState(value);
  const [isFocused, setIsFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  useEffect(() => {
    setLocalValue(value);
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    setLocalValue(newValue);
    registerChange(fieldName, newValue);
    if (onChange) {
      onChange(newValue);
    }
  };

  const handleFocus = () => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  if (!isEditMode) {
    return (
      <div className={className}>
        {fieldType === 'textarea' ? (
          <div className="whitespace-pre-wrap">{value || placeholder}</div>
        ) : (
          <span>{value || placeholder}</span>
        )}
      </div>
    );
  }

  const baseInputClasses = `
    w-full px-3 py-2 
    cms-editable-field
    rounded
    transition-all duration-200
    ${required && !localValue ? 'opacity-70' : ''}
  `;

  return (
    <div className="relative group">
      <AnimatePresence>
        {!isFocused && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute -top-2 -right-2 z-10 pointer-events-none"
          >
            <div 
              className="rounded-full p-1 shadow-md"
              style={{
                background: 'linear-gradient(135deg, rgba(250, 204, 21, 0.95) 0%, rgba(253, 224, 71, 0.95) 100%)'
              }}
            >
              <svg className="w-3 h-3" fill="none" stroke="rgb(113, 63, 18)" viewBox="0 0 24 24">
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" 
                />
              </svg>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {fieldType === 'textarea' ? (
        <textarea
          ref={inputRef as React.RefObject<HTMLTextAreaElement>}
          value={localValue}
          onChange={handleChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          placeholder={placeholder}
          rows={rows}
          required={required}
          className={`${baseInputClasses} ${className} resize-y min-h-[100px]`}
        />
      ) : (
        <input
          ref={inputRef as React.RefObject<HTMLInputElement>}
          type={fieldType}
          value={localValue}
          onChange={handleChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          placeholder={placeholder}
          required={required}
          className={`${baseInputClasses} ${className}`}
        />
      )}

      {required && !localValue && (
        <p className="mt-1 text-xs text-red-600">This field is required</p>
      )}
    </div>
  );
};

