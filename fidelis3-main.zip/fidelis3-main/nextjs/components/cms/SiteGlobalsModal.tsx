'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CategoryHeroManager } from './CategoryHeroManager';
import { BusinessInfoManager } from './BusinessInfoManager';
import { ManufacturersManager } from './ManufacturersManager';
import { ImageLibraryManager } from './ImageLibraryManager';
import { createPortal } from 'react-dom';
import { Squares2X2Icon, BuildingStorefrontIcon, BuildingOffice2Icon, PhotoIcon } from '@heroicons/react/24/outline';

interface SiteGlobalsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const tabs = [
  { id: 'categories', label: 'Category Hero Images', icon: Squares2X2Icon },
  { id: 'business', label: 'Business Info', icon: BuildingStorefrontIcon },
  { id: 'manufacturers', label: 'Manufacturers', icon: BuildingOffice2Icon },
  { id: 'images', label: 'Image Library', icon: PhotoIcon },
] as const;

export function SiteGlobalsModal({ isOpen, onClose }: SiteGlobalsModalProps) {
  const [activeTab, setActiveTab] = useState<(typeof tabs)[number]['id']>('categories');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    return () => setMounted(false);
  }, []);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const renderTabContent = useMemo(() => {
    if (activeTab === 'categories') {
      return (
        <div className="h-full overflow-y-auto pr-4">
          <CategoryHeroManager />
        </div>
      );
    }

    if (activeTab === 'business') {
      return (
        <div className="h-full overflow-y-auto pr-4">
          <BusinessInfoManager />
        </div>
      );
    }

    if (activeTab === 'manufacturers') {
      return (
        <div className="h-full overflow-y-auto pr-4">
          <ManufacturersManager />
        </div>
      );
    }

    if (activeTab === 'images') {
      return (
        <div className="h-full pr-4">
          <ImageLibraryManager />
        </div>
      );
    }

    return null;
  }, [activeTab]);

  return mounted
    ? createPortal(
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="fixed inset-0 z-[9998] bg-black/40 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className="fixed inset-0 z-[9999] flex items-end justify-center sm:items-center"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 40 }}
            transition={{ duration: 0.25 }}
          >
            <div className="flex w-full max-w-5xl flex-col overflow-hidden rounded-t-3xl bg-white shadow-2xl sm:rounded-3xl">
              <div className="flex items-center justify-between border-b border-stone-200 px-6 py-4">
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-stone-400">Site globals</p>
                  <h2 className="text-2xl font-light text-stone-900">Manage global content</h2>
                </div>
                <button
                  onClick={onClose}
                  className="rounded-full border border-stone-200 bg-white p-2 text-stone-500 hover:bg-stone-50"
                >
                  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              <div className="flex h-[70vh] flex-col sm:flex-row">
                <div className="w-full border-b border-stone-100 p-4 sm:w-64 sm:border-b-0 sm:border-r">
                  <nav className="space-y-1">
                    {tabs.map(tab => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-medium ${
                          activeTab === tab.id
                            ? 'bg-white text-stone-900 shadow border border-stone-200'
                            : 'text-stone-600 hover:bg-stone-50 border border-transparent'
                        }`}
                      >
                        <tab.icon className="h-5 w-5" />
                        <span>{tab.label}</span>
                      </button>
                    ))}
                  </nav>
                </div>

                <div className="flex-1 overflow-hidden p-6">{renderTabContent}</div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>,
    document.body
  )
    : null;
}

