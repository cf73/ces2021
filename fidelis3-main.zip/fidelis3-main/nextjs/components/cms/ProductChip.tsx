'use client';

import { useEffect, useState } from 'react';
import type { Product } from '../../lib/supabase';
import { getProductById } from '../../lib/supabase-queries';
import { getImageUrl } from '../../lib/supabase-queries';

interface ProductChipProps {
  productId: string;
  variant?: 'default' | 'suggestion';
  onRemove?: () => void;
  onAdd?: () => void;
}

export function ProductChip({ 
  productId, 
  variant = 'default',
  onRemove,
  onAdd 
}: ProductChipProps) {
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    
    getProductById(productId)
      .then(p => {
        if (isMounted) {
          setProduct(p);
          setLoading(false);
        }
      })
      .catch(err => {
        console.error('Error loading product for chip:', err);
        if (isMounted) {
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [productId]);

  if (loading) {
    return (
      <div className="animate-pulse bg-stone-200 h-10 w-32 rounded-full" />
    );
  }

  if (!product) {
    return null;
  }

  return (
    <div 
      className={`flex items-center gap-2 px-3 py-2 rounded-full text-sm transition-all duration-200 ${
        variant === 'suggestion' 
          ? 'border border-amber-400 hover:bg-yellow-100' 
          : 'bg-stone-200 border border-stone-300 hover:bg-stone-300'
      }`}
      style={variant === 'suggestion' ? {
        background: 'linear-gradient(135deg, rgba(254, 252, 232, 0.8) 0%, rgba(254, 249, 195, 0.8) 100%)'
      } : undefined}
    >
      {product.product_hero_image && (
        <img 
          src={getImageUrl(product.product_hero_image)} 
          alt={product.title}
          className="w-6 h-6 rounded-full object-cover"
        />
      )}
      <span className="font-medium">{product.title}</span>
      {onRemove && (
        <button
          onClick={onRemove}
          className="ml-1 text-stone-600 hover:text-stone-900 transition-colors duration-200"
          title="Remove"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      )}
      {onAdd && (
        <button
          onClick={onAdd}
          className="ml-1 text-amber-900 hover:text-amber-950 transition-colors duration-200"
          title="Add"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
        </button>
      )}
    </div>
  );
}

