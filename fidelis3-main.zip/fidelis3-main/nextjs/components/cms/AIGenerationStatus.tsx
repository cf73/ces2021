'use client';

import React from 'react';

interface AIGenerationStatusProps {
  status?: string;
  error?: string;
  lastGenerated?: string;
  pairsCount?: number;
  alsoCount?: number;
}

export function AIGenerationStatus({ 
  status, 
  error, 
  lastGenerated,
  pairsCount = 0,
  alsoCount = 0
}: AIGenerationStatusProps) {
  if (!status) {
    return (
      <div className="fixed bottom-4 right-4 z-50 bg-stone-100 border border-stone-300 rounded-lg p-4 max-w-sm shadow-lg">
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0">
            <svg className="w-5 h-5 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div className="flex-1">
            <h4 className="text-sm font-medium text-stone-900 mb-1">AI Status</h4>
            <p className="text-xs text-stone-600">No AI generation attempted yet</p>
          </div>
        </div>
      </div>
    );
  }

  const getStatusColor = () => {
    switch (status) {
      case 'success': return 'bg-green-50 border-green-200';
      case 'failed': return 'bg-red-50 border-red-200';
      case 'generating': return 'bg-blue-50 border-blue-200';
      default: return 'bg-stone-100 border-stone-300';
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'success':
        return (
          <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        );
      case 'failed':
        return (
          <svg className="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        );
      case 'generating':
        return (
          <svg className="w-5 h-5 text-blue-600 animate-spin" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        );
      default:
        return null;
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'success': return 'AI Generated Successfully';
      case 'failed': return 'AI Generation Failed';
      case 'generating': return 'Generating AI Suggestions...';
      default: return 'Unknown Status';
    }
  };

  return (
    <div className={`fixed bottom-4 right-4 z-50 border rounded-lg p-4 max-w-sm shadow-lg ${getStatusColor()}`}>
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0">
          {getStatusIcon()}
        </div>
        <div className="flex-1">
          <h4 className="text-sm font-medium text-stone-900 mb-1">{getStatusText()}</h4>
          
          {status === 'success' && (
            <div className="text-xs text-stone-600 space-y-1">
              <p>Good Synergies: {pairsCount} products</p>
              <p>Also Consider: {alsoCount} products</p>
              {lastGenerated && (
                <p className="text-stone-500 mt-2">
                  Generated: {new Date(lastGenerated).toLocaleString()}
                </p>
              )}
            </div>
          )}
          
          {status === 'failed' && error && (
            <div className="text-xs text-red-700 mt-1">
              <p className="font-medium mb-1">Error:</p>
              <p className="font-mono text-[10px] bg-red-100 p-2 rounded">{error}</p>
            </div>
          )}
          
          {status === 'generating' && (
            <p className="text-xs text-blue-700">
              This may take 30-60 seconds. Page will update when complete.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

