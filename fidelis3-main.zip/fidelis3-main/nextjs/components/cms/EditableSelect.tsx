'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useEditMode } from '../../contexts/EditModeContext';
import { motion } from 'framer-motion';

interface SelectOption {
  value: string;
  label: string;
}

interface EditableSelectProps {
  value: string | null | undefined;
  fieldName: string;
  options: SelectOption[];
  placeholder?: string;
  required?: boolean;
  label?: string;
  className?: string;
  displayValue?: string;
  displayClassName?: string;
  displayLink?: string;
  onChange?: (value: string) => void;
  showAddNewOption?: boolean;
  addNewLabel?: string;
  onAddNew?: () => void;
}

export const EditableSelect: React.FC<EditableSelectProps> = ({
  value,
  fieldName,
  options,
  placeholder = 'Select an option',
  required = false,
  label,
  className = '',
  displayValue,
  displayClassName = '',
  displayLink,
  onChange,
  showAddNewOption = false,
  addNewLabel = 'Select different option...',
  onAddNew
}) => {
  const { isEditMode, registerChange } = useEditMode();
  const [selectedValue, setSelectedValue] = useState(value || '');

  useEffect(() => {
    setSelectedValue(value || '');
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newValue = e.target.value;
    
    // Check if user selected "Add new" option
    if (newValue === '__ADD_NEW__' && onAddNew) {
      onAddNew();
      // Reset to current value
      e.target.value = selectedValue;
      return;
    }
    
    setSelectedValue(newValue);
    
    if (onChange) {
      onChange(newValue);
    } else {
    registerChange(fieldName, newValue || null);
    }
  };

  if (!isEditMode) {
    if (displayLink && displayValue) {
      return (
        <Link href={displayLink} className={displayClassName}>
          {displayValue}
        </Link>
      );
    }
    return displayValue ? (
      <div className={displayClassName}>{displayValue}</div>
    ) : null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.3 }}
      className="space-y-2"
    >
      {label && (
        <label className="block text-sm font-semibold text-stone-900 tracking-wide uppercase mb-2">
          {label}
          {required && <span className="text-stone-500 ml-1">*</span>}
        </label>
      )}
      <select
        value={selectedValue}
        onChange={handleChange}
        required={required}
        className={`w-full px-4 py-3 cms-editable-select rounded-md text-stone-900 font-medium ${className}`}
      >
        <option value="" className="bg-white text-stone-400 italic py-2">{placeholder}</option>
        {options.map((option) => (
          <option key={option.value} value={option.value} className="bg-white text-stone-900 py-2">
            {option.label}
          </option>
        ))}
      </select>
    </motion.div>
  );
};

