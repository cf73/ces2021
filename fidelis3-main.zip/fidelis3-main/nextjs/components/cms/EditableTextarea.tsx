'use client';

import React, { useEffect, useRef } from 'react';
import { useEditMode } from '../../contexts/EditModeContext';
import { motion } from 'framer-motion';

interface EditableTextareaProps {
  value: string;
  fieldName: string;
  placeholder?: string;
  required?: boolean;
  rows?: number;
  className?: string;
  maxLength?: number;
  autoGrow?: boolean;
}

export const EditableTextarea: React.FC<EditableTextareaProps> = ({
  value,
  fieldName,
  placeholder = '',
  required = false,
  rows = 3,
  className = '',
  maxLength,
  autoGrow = true
}) => {
  const { isEditMode, registerChange } = useEditMode();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    registerChange(fieldName, e.target.value);
    if (autoGrow && textareaRef.current) {
      // Auto-resize textarea to fit content
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  };

  // Auto-resize on mount and when value changes
  useEffect(() => {
    if (autoGrow && textareaRef.current && isEditMode) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [value, isEditMode, autoGrow]);

  if (!isEditMode) {
    return <div className={className}>{value}</div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="relative"
    >
      <textarea
        ref={textareaRef}
        defaultValue={value}
        onChange={handleChange}
        placeholder={placeholder}
        required={required}
        rows={rows}
        maxLength={maxLength}
        className={`w-full px-4 py-3 cms-editable-field rounded-lg resize-none overflow-hidden ${className}`}
        style={{
          minHeight: autoGrow ? `${rows * 1.5}rem` : undefined
        }}
      />
      {maxLength && (
        <div className="absolute bottom-2 right-2 text-xs text-stone-400 bg-white px-1 rounded">
          {value?.length || 0}/{maxLength}
        </div>
      )}
    </motion.div>
  );
};

