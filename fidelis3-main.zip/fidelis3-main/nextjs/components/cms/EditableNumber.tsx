'use client';

import React from 'react';
import { useEditMode } from '../../contexts/EditModeContext';
import { motion } from 'framer-motion';

interface EditableNumberProps {
  value: number | null | undefined;
  fieldName: string;
  placeholder?: string;
  required?: boolean;
  min?: number;
  max?: number;
  step?: number;
  prefix?: string;
  suffix?: string;
  className?: string;
  displayClassName?: string;
}

export const EditableNumber: React.FC<EditableNumberProps> = ({
  value,
  fieldName,
  placeholder = '',
  required = false,
  min,
  max,
  step = 1,
  prefix = '',
  suffix = '',
  className = '',
  displayClassName = ''
}) => {
  const { isEditMode, registerChange } = useEditMode();

  const handleChange = (cleanedValue: string) => {
    // Remove formatting and parse
    const numValue = cleanedValue === '' ? null : parseFloat(cleanedValue);
    registerChange(fieldName, isNaN(numValue as number) ? null : numValue);
  };

  if (!isEditMode) {
    // Use currency formatting if prefix is $, otherwise use number formatting
    const formattedValue = value !== null && value !== undefined 
      ? (prefix === '$' 
          ? new Intl.NumberFormat('en-US', {
              style: 'currency',
              currency: 'USD',
            }).format(value)
          : value.toLocaleString('en-US', { 
              minimumFractionDigits: step && step < 1 ? 2 : 0,
              maximumFractionDigits: step && step < 1 ? 2 : 0,
            }))
      : '';
    
    return (
      <div className={displayClassName}>
        {prefix === '$' ? formattedValue : `${prefix}${formattedValue}${suffix}`}
      </div>
    );
  }

  // Format value for display in edit mode
  const formatValueForDisplay = (val: number | null | undefined): string => {
    if (val === null || val === undefined) return '';
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: step && step < 1 ? 2 : 0,
      maximumFractionDigits: step && step < 1 ? 2 : 0,
    }).format(val);
  };

  const formattedDisplayValue = formatValueForDisplay(value);

  return (
    <div className="relative inline-block">
      {prefix && (
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-700 font-medium pointer-events-none z-10">
          {prefix}
        </span>
      )}
      <input
        type="text"
        inputMode="decimal"
        defaultValue={formattedDisplayValue}
        onChange={(e) => {
          // Remove formatting (commas, dollar signs) and parse
          const cleaned = e.target.value.replace(/[^0-9.]/g, '');
          handleChange(cleaned);
        }}
        onBlur={(e) => {
          // Re-format on blur
          const cleaned = e.target.value.replace(/[^0-9.]/g, '');
          const numValue = cleaned === '' ? null : parseFloat(cleaned);
          if (numValue !== null && !isNaN(numValue)) {
            e.target.value = formatValueForDisplay(numValue);
          }
        }}
        placeholder={placeholder}
        required={required}
        min={min}
        max={max}
        className={`px-4 py-3 ${prefix ? 'pl-8' : ''} ${suffix ? 'pr-8' : ''} cms-editable-field rounded-md ${className}`}
      />
      {suffix && (
        <span className="absolute right-4 top-1/2 -translate-y-1/2 text-stone-700 font-medium pointer-events-none z-10">
          {suffix}
        </span>
      )}
    </div>
  );
};

