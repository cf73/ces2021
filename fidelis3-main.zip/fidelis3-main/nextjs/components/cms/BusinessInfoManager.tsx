'use client';

import { useEffect, useMemo, useState } from 'react';
import { useSiteGlobals } from '../../contexts/SiteGlobalsContext';
import type { BusinessInfo, StoreHourEntry } from '../../lib/supabase';
import { getAuthHeaders } from '../../lib/auth-headers';
import { Button } from '../ui/Button';

interface FormState {
  id?: string;
  company_name: string;
  tagline: string;
  short_description: string;
  about_description: string;
  phone: string;
  email: string;
  address_line1: string;
  address_line2: string;
  city: string;
  state: string;
  postal_code: string;
  country: string;
  google_map_url: string;
  virtual_tour_url: string;
  store_hours: StoreHourEntry[];
  special_notice: string;
}

const defaultFormState: FormState = {
  company_name: '',
  tagline: '',
  short_description: '',
  about_description: '',
  phone: '',
  email: '',
  address_line1: '',
  address_line2: '',
  city: '',
  state: '',
  postal_code: '',
  country: 'US',
  google_map_url: '',
  virtual_tour_url: '',
  store_hours: [],
  special_notice: '',
};

const mapBusinessInfoToForm = (info: BusinessInfo | null): FormState => {
  if (!info) {
    return { ...defaultFormState };
  }
  return {
    id: info.id,
    company_name: info.company_name || '',
    tagline: info.tagline || '',
    short_description: info.short_description || '',
    about_description: info.about_description || '',
    phone: info.phone || '',
    email: info.email || '',
    address_line1: info.address_line1 || '',
    address_line2: info.address_line2 || '',
    city: info.city || '',
    state: info.state || '',
    postal_code: info.postal_code || '',
    country: info.country || 'US',
    google_map_url: info.google_map_url || '',
    virtual_tour_url: info.virtual_tour_url || '',
    store_hours: Array.isArray(info.store_hours) ? info.store_hours : [],
    special_notice: info.special_notice || '',
  };
};

export function BusinessInfoManager() {
  const { businessInfo, setBusinessInfo, refreshBusinessInfo } = useSiteGlobals();
  const [formState, setFormState] = useState<FormState>(() => mapBusinessInfoToForm(businessInfo));
  const [saving, setSaving] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  useEffect(() => {
    setFormState(mapBusinessInfoToForm(businessInfo));
  }, [businessInfo?.id]);

  const hasChanges = useMemo(() => {
    if (!businessInfo) {
      return JSON.stringify(formState) !== JSON.stringify(defaultFormState);
    }
    return JSON.stringify(formState) !== JSON.stringify(mapBusinessInfoToForm(businessInfo));
  }, [businessInfo, formState]);

  const handleFieldChange = (field: keyof FormState, value: string) => {
    setFormState(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleHourChange = (index: number, key: keyof StoreHourEntry, value: string) => {
    setFormState(prev => {
      const nextHours = [...prev.store_hours];
      nextHours[index] = {
        ...nextHours[index],
        [key]: value,
      };
      return {
        ...prev,
        store_hours: nextHours,
      };
    });
  };

  const addStoreHour = () => {
    setFormState(prev => ({
      ...prev,
      store_hours: [...prev.store_hours, { label: '', value: '' }],
    }));
  };

  const removeStoreHour = (index: number) => {
    setFormState(prev => ({
      ...prev,
      store_hours: prev.store_hours.filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSaving(true);
    setStatusMessage(null);
    try {
      const authHeaders = await getAuthHeaders();
      const response = await fetch('/api/site-globals/business-info', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify(formState),
      });
      if (!response.ok) {
        throw new Error('Failed to update business info.');
      }
      const data = await response.json();
      setBusinessInfo(data);
      setStatusMessage('Business info updated.');
    } catch (error) {
      console.error('Failed to save business info:', error);
      setStatusMessage('Failed to save. Please try again.');
    } finally {
      setSaving(false);
      setTimeout(() => setStatusMessage(null), 4000);
    }
  };

  const handleReset = () => {
    setFormState(mapBusinessInfoToForm(businessInfo));
    setStatusMessage('Reverted unsaved changes.');
    setTimeout(() => setStatusMessage(null), 4000);
  };

  return (
    <form className="space-y-8" onSubmit={handleSubmit}>
      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            Company Name
          </label>
          <input
            type="text"
            value={formState.company_name}
            onChange={e => handleFieldChange('company_name', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="Fidelis"
          />
        </div>
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            Tagline
          </label>
          <input
            type="text"
            value={formState.tagline}
            onChange={e => handleFieldChange('tagline', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="Music For Life"
          />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            Phone
          </label>
          <input
            type="text"
            value={formState.phone}
            onChange={e => handleFieldChange('phone', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="603-880-4434"
          />
        </div>
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            Email
          </label>
          <input
            type="email"
            value={formState.email}
            onChange={e => handleFieldChange('email', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="hello@example.com"
          />
        </div>
      </div>

      <div className="space-y-3">
        <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
          Short Description
        </label>
        <textarea
          value={formState.short_description}
          onChange={e => handleFieldChange('short_description', e.target.value)}
          rows={3}
          className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
          placeholder="A concise summary used in footers and contact blurbs."
        />
      </div>

      <div className="space-y-3">
        <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
          About Description
        </label>
        <textarea
          value={formState.about_description}
          onChange={e => handleFieldChange('about_description', e.target.value)}
          rows={4}
          className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
          placeholder="Long-form description for the contact/about page."
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            Address Line 1
          </label>
          <input
            type="text"
            value={formState.address_line1}
            onChange={e => handleFieldChange('address_line1', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="460 Amherst Street"
          />
        </div>
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            Address Line 2
          </label>
          <input
            type="text"
            value={formState.address_line2}
            onChange={e => handleFieldChange('address_line2', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="Suite, Building, etc."
          />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            City
          </label>
          <input
            type="text"
            value={formState.city}
            onChange={e => handleFieldChange('city', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="Nashua"
          />
        </div>
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            State
          </label>
          <input
            type="text"
            value={formState.state}
            onChange={e => handleFieldChange('state', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="NH"
          />
        </div>
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            Postal Code
          </label>
          <input
            type="text"
            value={formState.postal_code}
            onChange={e => handleFieldChange('postal_code', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="03063"
          />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            Map Embed URL
          </label>
          <input
            type="url"
            value={formState.google_map_url}
            onChange={e => handleFieldChange('google_map_url', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="https://www.google.com/maps..."
          />
        </div>
        <div className="space-y-3">
          <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
            Virtual Tour Embed URL
          </label>
          <input
            type="url"
            value={formState.virtual_tour_url}
            onChange={e => handleFieldChange('virtual_tour_url', e.target.value)}
            className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
            placeholder="https://www.google.com/maps/embed?... "
          />
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">Store Hours</p>
            <p className="text-xs text-stone-500">Display order matches how entries appear on the site.</p>
          </div>
          <button
            type="button"
            onClick={addStoreHour}
            className="rounded-full border border-dashed border-stone-300 px-4 py-2 text-xs font-semibold uppercase tracking-[0.25em] text-stone-600 hover:bg-white"
          >
            Add Row
          </button>
        </div>

        {formState.store_hours.length === 0 && (
          <div className="rounded-2xl border border-dashed border-stone-200 bg-stone-50 px-4 py-3 text-sm text-stone-500">
            No store hours added yet.
          </div>
        )}

        <div className="space-y-3">
          {formState.store_hours.map((entry, index) => (
            <div key={`hour-${index}`} className="grid gap-3 md:grid-cols-[2fr,3fr,auto] items-center">
              <input
                type="text"
                value={entry.label}
                onChange={e => handleHourChange(index, 'label', e.target.value)}
                placeholder="Tuesday - Friday"
                className="rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
              />
              <input
                type="text"
                value={entry.value}
                onChange={e => handleHourChange(index, 'value', e.target.value)}
                placeholder="10:00 AM - 6:00 PM"
                className="rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => removeStoreHour(index)}
                className="rounded-full border border-stone-200 px-4 py-2 text-xs font-semibold uppercase tracking-[0.25em] text-stone-600 hover:bg-white"
              >
                Remove
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        <label className="text-xs font-semibold uppercase tracking-[0.25em] text-stone-500">
          Special Notice
        </label>
        <textarea
          value={formState.special_notice}
          onChange={e => handleFieldChange('special_notice', e.target.value)}
          rows={3}
          className="w-full rounded-xl border border-stone-200 bg-white/80 px-4 py-3 text-sm focus:border-stone-500 focus:outline-none"
          placeholder="Holiday closures, limited hours, etc."
        />
      </div>

      {statusMessage && (
        <div className="rounded-xl border border-stone-200 bg-white/70 px-4 py-3 text-sm text-stone-600">
          {statusMessage}
        </div>
      )}

      <div className="flex flex-wrap gap-3">
        <Button
          type="submit"
          variant="primary"
          size="md"
          disabled={saving || !hasChanges}
          aria-disabled={saving || !hasChanges}
        >
          {saving ? 'Saving…' : 'Save changes'}
        </Button>
        <Button
          type="button"
          variant="outline-bold"
          size="md"
          disabled={saving || !hasChanges}
          onClick={handleReset}
        >
          Reset
        </Button>
      </div>
    </form>
  );
}

