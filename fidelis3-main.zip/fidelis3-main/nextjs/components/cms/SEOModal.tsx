'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useEditMode } from '../../contexts/EditModeContext';

interface SEOModalProps {
  isOpen: boolean;
  onClose: () => void;
  briefDescription: string;
}

export const SEOModal: React.FC<SEOModalProps> = ({
  isOpen,
  onClose,
  briefDescription
}) => {
  const { registerChange } = useEditMode();
  const [localValue, setLocalValue] = useState(briefDescription);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Update local value when prop changes
  useEffect(() => {
    setLocalValue(briefDescription);
  }, [briefDescription]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current && isOpen) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  }, [localValue, isOpen]);

  // Handle ESC key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [isOpen, onClose]);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    setLocalValue(newValue);
    registerChange('brief_description', newValue);
    
    // Auto-resize
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[300]"
            onClick={onClose}
          />

          {/* Modal */}
          <div className="fixed inset-0 z-[301] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.3, ease: [0.25, 0.46, 0.45, 0.94] }}
              className="bg-white/60 backdrop-blur-xl border border-stone-200/50 rounded-xl shadow-lg w-full max-w-2xl max-h-[90vh] overflow-hidden"
              style={{
                boxShadow: '0 8px 32px rgba(0, 0, 0, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.6)'
              }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="px-6 py-4 border-b border-stone-200/50 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-stone-900 tracking-wide uppercase">SEO Settings</h2>
                  <p className="text-xs text-stone-600 mt-1">
                    Manage search engine optimization content
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-white/40 rounded-md transition-colors duration-200"
                  aria-label="Close"
                >
                  <svg className="w-5 h-5 text-stone-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>

              {/* Content */}
              <div className="px-6 py-6 overflow-y-auto max-h-[calc(90vh-180px)]">
                <div className="space-y-4">
                  {/* Label */}
                  <div>
                    <label className="block text-sm font-semibold text-stone-900 tracking-wide uppercase mb-1">
                      Brief Description
                    </label>
                    <p className="text-xs text-stone-600 mb-3">
                      AI-generated description for search results and previews (shown on listing pages)
                    </p>
                  </div>

                  {/* Textarea */}
                  <div className="relative">
                    <textarea
                      ref={textareaRef}
                      value={localValue}
                      onChange={handleChange}
                      placeholder="Enter a brief description for SEO purposes..."
                      maxLength={300}
                      rows={4}
                      className="w-full px-4 py-3 cms-editable-field rounded-md focus:outline-none transition-all duration-200 resize-none text-stone-900"
                      style={{
                        minHeight: '100px'
                      }}
                    />
                    {/* Character count */}
                    <div className="absolute bottom-3 right-3 text-xs text-stone-500 bg-white/60 backdrop-blur-sm px-2 py-1 rounded-md">
                      {localValue?.length || 0}/300
                    </div>
                  </div>

                  {/* Note */}
                  <div className="flex items-start gap-3 p-4 bg-white/40 backdrop-blur-sm border border-stone-200/50 rounded-md">
                    <svg className="w-4 h-4 text-stone-600 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                    <p className="text-xs text-stone-700 leading-relaxed">
                      This field is automatically generated by AI but can be manually edited. Changes will be saved when you click the main Save button.
                    </p>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="px-6 py-4 border-t border-stone-200/50 flex justify-end">
                <button
                  onClick={onClose}
                  className="px-6 py-2 bg-stone-900 text-white rounded-md hover:bg-stone-800 transition-all duration-200 font-medium shadow-sm"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
};

