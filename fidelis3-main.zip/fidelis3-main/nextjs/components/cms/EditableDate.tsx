'use client';

import React, { useState, useEffect } from 'react';
import { useEditMode } from '../../contexts/EditModeContext';

interface EditableDateProps {
  value?: string | null;
  fieldName: string;
  label?: string;
  required?: boolean;
  className?: string;
  displayClassName?: string;
}

export const EditableDate: React.FC<EditableDateProps> = ({
  value,
  fieldName,
  label,
  required = false,
  className = '',
  displayClassName = '',
}) => {
  const { isEditMode, registerChange } = useEditMode();
  const [localValue, setLocalValue] = useState(value || '');

  useEffect(() => {
    setLocalValue(value || '');
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setLocalValue(newValue);
    registerChange(fieldName, newValue);
  };

  const formatDisplayDate = (dateString?: string | null) => {
    if (!dateString) return 'No date set';
    
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
      });
    } catch {
      return dateString;
    }
  };

  if (!isEditMode) {
    return (
      <div className={displayClassName || className}>
        {formatDisplayDate(value)}
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {label && (
        <label className="block text-sm font-medium text-stone-700">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      <input
        type="date"
        value={localValue}
        onChange={handleChange}
        required={required}
        className={`w-full px-4 py-2 border border-stone-300 rounded-md focus:ring-2 focus:ring-stone-500 focus:border-transparent ${className}`}
      />
    </div>
  );
};

