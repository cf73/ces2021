'use client';

import React, { useEffect, useRef, useState } from 'react';
import { useEditMode } from '../../contexts/EditModeContext';
import { getImageUrl } from '../../lib/supabase-queries';
import { supabase } from '../../lib/supabase';

interface EditableImageGalleryProps {
  value: string[] | null | undefined;
  fieldName: string;
  folder?: string;
  maxImages?: number;
}

export const EditableImageGallery: React.FC<EditableImageGalleryProps> = ({
  value,
  fieldName,
  folder = 'products',
  maxImages = 10
}) => {
  const { isEditMode, registerChange } = useEditMode();
  const [currentImages, setCurrentImages] = useState<string[]>(value || []);
  const [uploadingCount, setUploadingCount] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setCurrentImages(value || []);
  }, [value]);

  const uploadFiles = async (files: File[]) => {
    if (!files.length) return;
    setUploadError(null);

    const availableSlots = Math.max(0, maxImages - currentImages.length);
    if (availableSlots === 0) {
      setUploadError(`Maximum of ${maxImages} images reached.`);
      return;
    }

    const filesToUpload = files.slice(0, availableSlots);
    setUploadingCount(filesToUpload.length);

    for (const file of filesToUpload) {
      try {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/avif', 'image/gif'];
        if (!allowedTypes.includes(file.type)) {
          setUploadError('Please upload JPG, PNG, WebP, AVIF, or GIF images.');
          continue;
        }

        const maxSize = 5 * 1024 * 1024;
        if (file.size > maxSize) {
          setUploadError('Each image must be less than 5MB.');
          continue;
        }

        const fileExt = file.name.split('.').pop() || 'jpg';
        const timestamp = Date.now();
        const randomStr = Math.random().toString(36).substring(7);
        const fileName = `${timestamp}-${randomStr}.${fileExt}`;
        const filePath = `${folder}/${fileName}`;

        const { error } = await supabase.storage
          .from('images')
          .upload(filePath, file, {
            cacheControl: '3600',
            upsert: false
          });

        if (error) {
          throw error;
        }

        setCurrentImages(prev => {
          const updated = [...prev, filePath].slice(0, maxImages);
          registerChange(fieldName, updated);
          return updated;
        });
      } catch (error: any) {
        console.error('Error uploading image:', error);
        setUploadError(error.message || 'Failed to upload image.');
      } finally {
        setUploadingCount(prev => Math.max(0, prev - 1));
      }
    }
  };

  const handleFilesChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    await uploadFiles(files);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDrop = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files || []);
    if (!files.length) return;
    await uploadFiles(files);
  };

  const handleRemoveImage = (imagePath: string) => {
    setCurrentImages(prev => {
      const updated = prev.filter(img => img !== imagePath);
      registerChange(fieldName, updated);
      return updated;
    });
  };

  if (!isEditMode) {
    if (!currentImages.length) return null;
    return (
      <div className="grid grid-cols-4 gap-2">
        {currentImages.map((img, idx) => (
          <img
            key={idx}
            src={getImageUrl(img)}
            alt={`Gallery image ${idx + 1}`}
            className="w-full h-24 object-cover rounded"
          />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {currentImages.length > 0 && (
        <div className="grid grid-cols-4 gap-2">
          {currentImages.map((img, idx) => (
            <div key={idx} className="relative group">
              <img
                src={getImageUrl(img)}
                alt={`Gallery ${idx + 1}`}
                className="w-full h-24 object-cover rounded border-4 border-amber-400"
                style={{
                  boxShadow: '0 0 20px rgba(250, 204, 21, 0.15)'
                }}
              />
              <button
                onClick={() => handleRemoveImage(img)}
                className="absolute top-1 right-1 p-1.5 bg-red-600 hover:bg-red-700 text-white rounded-full shadow-lg transition-all duration-200 opacity-0 group-hover:opacity-100 focus:opacity-100"
                title="Remove image"
                type="button"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      )}

      <div
        className={`flex items-center justify-between gap-4 rounded-xl border border-dashed px-6 py-6 transition-colors ${
          isDragging ? 'border-amber-500 bg-amber-50/60' : 'border-stone-300 bg-white/60'
        }`}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        role="button"
        tabIndex={0}
      >
        <div>
          <p className="text-sm font-medium text-stone-800">Drop images here or click to upload</p>
          <p className="text-xs text-stone-500">Max {maxImages} images · JPG, PNG, WebP, AVIF, GIF · 5MB each</p>
        </div>
        <span className="inline-flex items-center px-3 py-1.5 rounded-md bg-amber-500 text-amber-950 text-xs font-semibold">
          Choose Files
        </span>
      </div>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFilesChange}
        className="hidden"
      />
      {uploadingCount > 0 && (
        <p className="text-xs text-stone-600">Uploading {uploadingCount} image{uploadingCount > 1 ? 's' : ''}...</p>
      )}
      {uploadError && (
        <p className="text-xs text-red-600">{uploadError}</p>
      )}
      <p className="text-xs text-stone-600">
        {currentImages.length}/{maxImages} images
      </p>
    </div>
  );
};

