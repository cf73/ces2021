'use client';

/**
 * @preserve-visual-language
 * DO NOT MODIFY: Functionality, data handling, or business logic
 * Only modify: Visual styling, layout, and user experience
 *
 * Card Component System - Refined Midcentury Modern Design
 * Unified card system for all card types across the site
 */

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { getImageUrl } from '../../lib/supabase-queries';
import { generateBlurDataURL } from '../../lib/image-loader';
import MiniProductGallery from '../MiniProductGallery';

// Generate true Apple squircle path using superellipse formula
const generateSquirclePath = (size: number = 100, cornerRadius: number = 24) => {
  const points: string[] = [];
  const steps = 360;
  const a = size / 2;
  const b = size / 2;
  const n = 4.8;
  
  for (let i = 0; i <= steps; i++) {
    const angle = (2 * Math.PI * i) / steps;
    const cosAngle = Math.cos(angle);
    const sinAngle = Math.sin(angle);
    
    const x = a * Math.sign(cosAngle) * Math.pow(Math.abs(cosAngle), 2/n);
    const y = b * Math.sign(sinAngle) * Math.pow(Math.abs(sinAngle), 2/n);
    
    const scaledX = x + size/2;
    const scaledY = y + size/2;
    
    if (i === 0) {
      points.push(`M ${scaledX} ${scaledY}`);
    } else {
      points.push(`L ${scaledX} ${scaledY}`);
    }
  }
  points.push('Z');
  return points.join(' ');
};

export interface CardProps {
  children: React.ReactNode;
  variant?: 'default' | 'product' | 'news' | 'manufacturer' | 'category' | 'featured' | 'value';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  onClick?: () => void;
  href?: string;
  as?: React.ElementType;
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'default',
  size = 'md',
  className = '',
  onClick,
  href,
  as: Component = 'div'
}) => {
  const baseClasses = 'rounded-xl shadow-sm hover:shadow-lg transition-all duration-200 ease-out overflow-hidden cursor-pointer';
  
  const variants = {
    default: 'bg-white',
    product: 'bg-[#f4f0ed] hover:bg-[#e8e4e1]',
    news: 'bg-white hover:shadow-xl',
    manufacturer: 'bg-white/50 hover:bg-white/80 shadow-none hover:shadow-none border-0',
    category: 'bg-white hover:shadow-xl transform hover:-translate-y-2 group',
    featured: 'bg-gradient-to-br from-stone-600 to-stone-700 text-white',
    value: 'bg-white text-center'
  };
  
  const sizes = {
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8'
  };
  
  const classes = [
    variant === 'manufacturer' ? 'rounded-xl transition-all duration-200 ease-out overflow-hidden cursor-pointer' : baseClasses,
    variants[variant],
    sizes[size],
    className
  ].filter(Boolean).join(' ');
  
  const content = (
    <Component className={classes} onClick={onClick}>
      {children}
    </Component>
  );
  
  if (href) {
    return (
      <Link href={href} className="block transition-all duration-150 active:scale-[0.98] active:opacity-75">
        {content}
      </Link>
    );
  }
  
  return content;
};

// Specialized card components for different use cases
export interface ProductCardProps {
  product: {
    id: string;
    title: string;
    slug: string;
    price?: number;
    show_price?: boolean;
    special_order_lead_time?: string;
    manufacturer?: string | { name: string };
    product_hero_image?: string;
    categories?: { name: string };
    featured?: boolean;
  };
  showBadges?: boolean;
  showPrice?: boolean;
  showCategory?: boolean;
  showManufacturer?: boolean;
  className?: string;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  showBadges = true,
  showPrice = true,
  showCategory = true,
  showManufacturer = true,
  className = ''
}) => {
  const router = useRouter();
  
  const handleMouseEnter = () => {
    router.prefetch(`/products/${product.slug}`);
  };

  return (
    <div 
      className={`group flex h-full flex-col cursor-pointer transition-all duration-300 ease-in-out hover:scale-[1.01] active:scale-[0.99] active:opacity-90 ${className}`}
      onMouseEnter={handleMouseEnter}
    >
      {/* Product Image - Square card with TRUE Apple squircle */}
      <div 
        className="product-card-image transition-all duration-300 ease-out aspect-square mb-1 relative"
        style={{
          backgroundColor: '#f4f0ed',
          backgroundImage: `
            radial-gradient(120% 120% at 50% 35%, rgba(244,240,234,0.35) 0%, rgba(254,252,250,0) 65%)
          `,
          backgroundRepeat: 'no-repeat',
          maskImage: `url("data:image/svg+xml,${encodeURIComponent(`
            <svg viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'>
              <path d='${generateSquirclePath(100, 38)}' fill='white'/>
            </svg>
          `)}")`,
          maskSize: '100% 100%',
          maskRepeat: 'no-repeat',
          WebkitMaskImage: `url("data:image/svg+xml,${encodeURIComponent(`
            <svg viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'>
              <path d='${generateSquirclePath(100, 38)}' fill='white'/>
            </svg>
          `)}")`,
          WebkitMaskSize: '100% 100%',
          WebkitMaskRepeat: 'no-repeat',
          boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.03), 0 6px 16px rgba(0,0,0,0.03)'
        }}
      >
        {product.product_hero_image ? (
          <Image
            src={getImageUrl(product.product_hero_image)}
            alt={product.title}
            fill
            className="object-contain mix-blend-multiply p-4"
            sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw"
            quality={85}
            placeholder="blur"
            blurDataURL={generateBlurDataURL()}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <svg className="h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
        )}
      </div>
      
      {/* Product Content */}
      <div className="flex flex-1 flex-col items-center pt-1 text-center">
        <h3 className="flex h-[2.5rem] items-center justify-center overflow-hidden text-base font-semibold text-stone-900 leading-tight">
          {product.title}
        </h3>
        
        <div className="mt-0.5 flex min-h-[1rem] items-center justify-center">
          {showManufacturer && product.manufacturer ? (
            <p className="text-xs text-stone-600">{typeof product.manufacturer === 'string' ? product.manufacturer : product.manufacturer.name}</p>
          ) : (
            <span className="invisible text-xs">Manufacturer</span>
          )}
        </div>
        
        <div className="mt-0.5 flex min-h-[1.25rem] items-center justify-center">
          {showPrice && product.show_price !== false ? (
            product.price ? (
              <p className="text-sm font-semibold text-stone-900">${product.price.toLocaleString()}</p>
            ) : (
              <p className="text-sm font-medium text-stone-600">Contact for Price</p>
            )
          ) : (
            <span className="invisible text-sm font-semibold">Price</span>
          )}
        </div>
        
        <div className="mt-0.5 flex min-h-[3.25rem] items-start justify-center">
          {showBadges && (showCategory && product.categories || product.featured || product.special_order_lead_time) ? (
            <div className="flex flex-wrap gap-1 justify-center">
              {showCategory && product.categories && (
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-stone-200 text-stone-700">
                  {product.categories.name}
                </span>
              )}
              {product.special_order_lead_time && (
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-amber-100 text-amber-900">
                  Special order · {product.special_order_lead_time}
                </span>
              )}
              {product.featured && (
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-stone-800 text-white">
                  Featured
                </span>
              )}
            </div>
          ) : (
            <span className="invisible text-xs font-medium">Badge</span>
          )}
        </div>
      </div>
    </div>
  );
};

export interface NewsCardProps {
  article: {
    id: string;
    title: string;
    summary?: string;
    brief_description?: string;
    image?: string;
    news_date?: string;
    slug?: string;
  };
  className?: string;
}

export const NewsCard: React.FC<NewsCardProps> = ({
  article,
  className = ''
}) => {
  return (
    <div className={`h-full flex flex-col bg-warm-beige rounded-xl overflow-hidden transition-colors duration-300 group hover:bg-[#f4f0ed] ${className}`}>
      {article.image && (
        <div className="aspect-[5/4] overflow-hidden relative">
          <Image
            src={getImageUrl(article.image)}
            alt={article.title}
            fill
            className="object-cover transition-all duration-700 group-hover:scale-105 group-hover:brightness-110 mix-blend-multiply"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            quality={85}
            placeholder="blur"
            blurDataURL={generateBlurDataURL()}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        </div>
      )}
      
      <div className="flex-grow space-y-4 p-6">
        {article.news_date && (
          <div className="relative pl-4">
            <div className="text-xs text-stone-500 font-medium tracking-[0.15em] uppercase">
              {new Date(article.news_date).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
              })}
            </div>
            <div className="absolute left-0 top-0 bottom-0 w-1 bg-amber-400 rounded-full"></div>
          </div>
        )}
        
        <h3 className="text-2xl lg:text-3xl font-light text-stone-900 leading-[1.2] group-hover:text-stone-700 transition-colors duration-300 tracking-[-0.02em] line-clamp-2">
          {article.title}
        </h3>
        
        {(article.summary || article.brief_description) && (
          <p className="text-stone-600 text-sm leading-[1.6] line-clamp-3 font-light">
            {article.summary || article.brief_description}
          </p>
        )}
        
        <div className="pt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <span className="text-xs text-stone-500 font-medium tracking-wider uppercase">
            Read More
          </span>
        </div>
      </div>
    </div>
  );
};

export interface ManufacturerCardProps {
  manufacturer: {
    id: string;
    name: string;
    logo?: string;
    description?: string;
  };
  className?: string;
}

export const ManufacturerCard: React.FC<ManufacturerCardProps> = ({
  manufacturer,
  className = ''
}) => {
  return (
    <Card variant="manufacturer" className={className}>
      <div className="p-6 text-center">
        {manufacturer.logo ? (
          <div className="relative h-32 sm:h-20 mx-auto">
            <Image
              src={getImageUrl(manufacturer.logo)}
              alt={manufacturer.name}
              fill
              className="object-contain mix-blend-multiply transition-opacity"
              sizes="(max-width: 640px) 128px, 80px"
              quality={85}
              placeholder="blur"
              blurDataURL={generateBlurDataURL()}
            />
          </div>
        ) : (
          <div className="h-32 w-32 sm:h-20 sm:w-20 mx-auto rounded-lg flex items-center justify-center">
            <svg className="h-16 w-16 sm:h-10 sm:w-10 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
          </div>
        )}
      </div>
    </Card>
  );
};

export interface CategoryCardProps {
  category: {
    id: string;
    name: string;
    description?: string;
    heroImage?: string;
    productCount?: number;
  };
  className?: string;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({ category, className = '' }) => {
  return (
    <div className={`group cursor-pointer transition-all duration-300 ease-in-out hover:scale-[1.01] flex flex-col h-full ${className}`}>
      <div 
        className="bg-[#f4f0ed] hover:bg-[#e8e4e1] transition-all duration-200 ease-out aspect-square mb-1 relative"
        style={{
          maskImage: `url("data:image/svg+xml,${encodeURIComponent(`
            <svg viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'>
              <path d='${generateSquirclePath(100, 38)}' fill='white'/>
            </svg>
          `)}")`,
          maskSize: '100% 100%',
          maskRepeat: 'no-repeat',
          WebkitMaskImage: `url("data:image/svg+xml,${encodeURIComponent(`
            <svg viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'>
              <path d='${generateSquirclePath(100, 38)}' fill='white'/>
            </svg>
          `)}")`,
          WebkitMaskSize: '100% 100%',
          WebkitMaskRepeat: 'no-repeat'
        }}
      >
        {category.heroImage ? (
          <Image
            src={getImageUrl(category.heroImage)}
            alt={category.name}
            fill
            className="object-contain mix-blend-multiply p-4"
            sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw"
            quality={85}
            placeholder="blur"
            blurDataURL={generateBlurDataURL()}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-stone-400">
            <svg className="h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
          </div>
        )}
      </div>
      
      <div className="flex flex-col flex-grow pt-1">
        <h3 className="text-base font-semibold text-stone-900 leading-tight text-center">{category.name}</h3>
      </div>
    </div>
  );
};

export interface ValueCardProps {
  value: {
    icon: string;
    title: string;
    description: string;
  };
  className?: string;
}

export const ValueCard: React.FC<ValueCardProps> = ({
  value,
  className = ''
}) => {
  return (
    <Card variant="value" size="lg" className={className}>
      <div className="text-center">
        <div className="text-4xl mb-4">{value.icon}</div>
        <h3 className="text-xl font-semibold text-stone-900 mb-4">
          {value.title}
        </h3>
        <p className="text-stone-600">
          {value.description}
        </p>
      </div>
    </Card>
  );
};

// PreOwned card
export interface PreOwnedCardProps {
  item: {
    id: string;
    title: string;
    description?: string;
    images?: string[];
    your_price?: number;
    new_retail_price?: number;
    hide_your_price?: boolean;
    local_only?: boolean;
    shipping?: number;
    original_accessories?: string;
    updated_at: string;
    published?: boolean;
  };
  className?: string;
  index?: number;
  isVisible?: boolean;
  showStatusBadge?: boolean;
}

export const PreOwnedCard: React.FC<PreOwnedCardProps> = ({
  item,
  className = '',
  index = 0,
  isVisible = true,
  showStatusBadge = false
}) => {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const calculateSavings = (yourPrice: number, retailPrice: number) => {
    const savings = retailPrice - yourPrice;
    const percentage = (savings / retailPrice) * 100;
    return { savings, percentage };
  };

  const savings = item.your_price && item.new_retail_price 
    ? calculateSavings(item.your_price, item.new_retail_price)
    : null;

  // Generate a consistent subtle random rotation for each card based on its ID
  const getCardRotation = (id: string) => {
    // Use the ID to generate a consistent "random" rotation between -1 and 1 degrees
    const hash = id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const rotation = ((hash % 200) - 100) / 100; // Range: -1 to 1
    return rotation;
  };

  const cardRotation = getCardRotation(item.id);
  // Create a subtle hover rotation (add 0.8 degree shift)
  const hoverRotation = cardRotation + (cardRotation > 0 ? 0.8 : -0.8);

  // Calculate staggered animation delay (faster now)
  const animationDelay = index * 80; // 80ms between each card

  return (
    <div 
      className={`group cursor-pointer transition-all duration-400 ease-out relative ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
      } ${className}`}
      style={{ 
        transitionDelay: `${animationDelay}ms`
      }}
    >
      {showStatusBadge && (
        <div className="absolute top-3 left-3 z-50 pointer-events-none">
          <span className={`inline-flex items-center px-2.5 py-1.5 rounded-full text-xs font-medium backdrop-blur-sm shadow-sm ${
            item.published === false
              ? 'bg-amber-100/90 text-amber-900'
              : 'bg-emerald-100/90 text-emerald-900'
          }`}>
            {item.published === false ? 'Unpublished' : 'Published'}
          </span>
        </div>
      )}
      {/* Image Section - Clean Product Gallery */}
      {item.images && item.images.length > 0 && (
        <div className="mb-3 relative">
          <MiniProductGallery 
            images={item.images} 
            itemTitle={item.title}
            itemId={item.id}
          />
          {/* Local pickup badge */}
          {item.local_only && (
            <div className="absolute top-3 right-3 z-10">
              <span className="inline-flex items-center px-2.5 py-1.5 rounded-full text-xs font-medium bg-white/90 backdrop-blur-sm text-stone-800 shadow-sm">
                Local Pickup
              </span>
            </div>
          )}
        </div>
      )}
      
      {/* Content Section - Centered */}
      <div className="space-y-3 text-center pb-4">
        {/* Title */}
        <h3 className="text-base font-medium text-stone-900 leading-tight line-clamp-2 min-h-[2.5rem] tracking-wide group-hover:text-stone-700 transition-colors">
          {item.title}
        </h3>
        
        {/* Pricing Section */}
        {item.your_price && !item.hide_your_price && (
          <div className="space-y-2">
            <div className="flex items-center justify-center gap-3">
              <span className="text-2xl font-light text-stone-900">
                {formatPrice(item.your_price)}
              </span>
              {item.new_retail_price && (
                <span className="text-sm text-stone-500 line-through">
                  {formatPrice(item.new_retail_price)}
                </span>
              )}
            </div>
            
            {/* Savings Info */}
            {savings && (
              <div className="flex items-center justify-center gap-2">
                <span className="text-stone-600 font-medium text-sm">
                  Save {formatPrice(savings.savings)} ({savings.percentage.toFixed(0)}% off)
                </span>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};

