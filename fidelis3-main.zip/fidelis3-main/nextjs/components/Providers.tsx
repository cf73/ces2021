'use client';

import React from 'react';
import { AuthProvider } from '../contexts/AuthContext';
import { EditModeProvider } from '../contexts/EditModeContext';
import { CategoriesProvider } from '../contexts/CategoriesContext';
import { SiteGlobalsProvider } from '../contexts/SiteGlobalsContext';

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <EditModeProvider>
        <CategoriesProvider>
          <SiteGlobalsProvider>
            {children}
          </SiteGlobalsProvider>
        </CategoriesProvider>
      </EditModeProvider>
    </AuthProvider>
  );
}

