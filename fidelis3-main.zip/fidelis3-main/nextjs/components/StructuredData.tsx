/**
 * Structured Data Component
 * Injects JSON-LD structured data into the page head for SEO
 */

import React from 'react';

interface StructuredDataProps {
  data: object | object[];
}

export const StructuredData: React.FC<StructuredDataProps> = ({ data }) => {
  // Convert array of schemas or single schema to script tag
  const schemas = Array.isArray(data) ? data : [data];
  
  return (
    <>
      {schemas.map((schema, index) => (
        <script
          key={index}
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(schema, null, 0) // Minified JSON
          }}
        />
      ))}
    </>
  );
};

