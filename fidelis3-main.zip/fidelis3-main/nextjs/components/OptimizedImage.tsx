/**
 * Optimized Image Component
 * 
 * A wrapper around Next.js Image component that provides:
 * - Automatic optimization (WebP/AVIF conversion)
 * - Lazy loading
 * - Blur placeholders
 * - Proper aspect ratios
 * - Error handling with fallback
 */

'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { generateBlurDataURL } from '../lib/image-loader';

interface OptimizedImageProps {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  fill?: boolean;
  className?: string;
  priority?: boolean;
  sizes?: string;
  objectFit?: 'contain' | 'cover' | 'fill' | 'none' | 'scale-down';
  quality?: number;
  onLoad?: () => void;
  onClick?: () => void;
}

export const OptimizedImage: React.FC<OptimizedImageProps> = ({
  src,
  alt,
  width,
  height,
  fill = false,
  className = '',
  priority = false,
  sizes,
  objectFit = 'cover',
  quality = 85,
  onLoad,
  onClick,
}) => {
  const [imageError, setImageError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const handleLoad = () => {
    setIsLoading(false);
    onLoad?.();
  };

  const handleError = () => {
    console.warn(`Failed to load image: ${src}`);
    setImageError(true);
    setIsLoading(false);
  };

  // Fallback for broken images
  if (imageError) {
    return (
      <div 
        className={`flex items-center justify-center bg-stone-100 ${className}`}
        style={fill ? {} : { width, height }}
      >
        <svg
          className="w-1/3 h-1/3 text-stone-300"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={1.5}
            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
          />
        </svg>
      </div>
    );
  }

  const imageProps: any = {
    src,
    alt,
    className: `${className} ${isLoading ? 'blur-sm' : 'blur-0'} transition-all duration-300`,
    onLoad: handleLoad,
    onError: handleError,
    quality,
    onClick,
  };

  if (fill) {
    imageProps.fill = true;
    imageProps.style = { objectFit };
    if (sizes) {
      imageProps.sizes = sizes;
    } else {
      // Default responsive sizes for fill images
      imageProps.sizes = '(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw';
    }
  } else {
    if (width) imageProps.width = width;
    if (height) imageProps.height = height;
    if (sizes) imageProps.sizes = sizes;
  }

  // Add blur placeholder for better UX
  if (!priority) {
    imageProps.placeholder = 'blur';
    imageProps.blurDataURL = generateBlurDataURL();
  }

  // Priority loading for above-the-fold images
  if (priority) {
    imageProps.priority = true;
  }

  return <Image {...imageProps} />;
};

export default OptimizedImage;

