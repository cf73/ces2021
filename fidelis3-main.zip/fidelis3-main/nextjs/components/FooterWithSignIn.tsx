'use client';

import React, { useState } from 'react';
import { Footer } from './Footer';
import { SignIn } from './SignIn';

export const FooterWithSignIn: React.FC = () => {
  const [isSignInOpen, setIsSignInOpen] = useState(false);

  return (
    <>
      <SignIn isOpen={isSignInOpen} onClose={() => setIsSignInOpen(false)} />
      <Footer onSignInClick={() => setIsSignInOpen(true)} />
    </>
  );
};

