'use client';

import React, { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { MapPinIcon, PhoneIcon, EnvelopeIcon } from '@heroicons/react/24/outline';
import { useAuth } from '../contexts/AuthContext';
import { SiteGlobalsModal } from './cms/SiteGlobalsModal';
import { useSiteGlobals } from '../contexts/SiteGlobalsContext';

interface FooterProps {
  onSignInClick?: () => void;
}

const Footer: React.FC<FooterProps> = ({ onSignInClick }) => {
  const { user, signOut } = useAuth();
  const [isGlobalsOpen, setIsGlobalsOpen] = useState(false);
  const { businessInfo } = useSiteGlobals();
  const fallbackHours = [
    { label: 'Tuesday-Friday', value: '10:00 AM - 6:00 PM' },
    { label: 'Saturday', value: '10:00 AM - 4:00 PM' },
    { label: 'Sunday', value: 'Closed' },
    { label: 'Monday', value: 'By Appointment' },
  ];

  const hours = businessInfo?.store_hours?.length ? businessInfo.store_hours : fallbackHours;
  const specialNotice = businessInfo?.special_notice?.trim();
  const companyName = businessInfo?.company_name || 'Fidelis';
  const tagline = (businessInfo?.tagline || companyName).toUpperCase();
  const description =
    businessInfo?.short_description ||
    "America's premiere importer and distributor of high-end audio gear. Decades of relationships with the world's finest manufacturers, because we believe in Music For Life.";

  const addressLine1 = businessInfo?.address_line1 || '460 Amherst Street';
  const addressLine2 = businessInfo?.address_line2 || '';
  const locality = [businessInfo?.city || 'Nashua', businessInfo?.state || 'NH', businessInfo?.postal_code || '03063']
    .filter(Boolean)
    .join(', ');

  const phoneDisplay = businessInfo?.phone || '603-880-4434';
  const phoneDigits = phoneDisplay.replace(/\D/g, '');
  const phoneHref = phoneDigits ? `tel:${phoneDigits.length === 10 ? `+1${phoneDigits}` : phoneDigits}` : undefined;
  const email = businessInfo?.email || 'marc@fidelisav.com';

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (err) {
      console.error('Sign out failed', err);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        duration: 0.6
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: [0.4, 0, 0.2, 1] as const
      }
    }
  };

  const footerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const footer = footerRef.current;
    if (!footer) return;

    const updateRevealHeight = () => {
      const height = footer.offsetHeight;
      document.documentElement.style.setProperty('--footer-reveal-height', `${height}px`);
    };

    updateRevealHeight();

    const observer = new ResizeObserver(updateRevealHeight);
    observer.observe(footer);
    window.addEventListener('resize', updateRevealHeight);

    return () => {
      observer.disconnect();
      window.removeEventListener('resize', updateRevealHeight);
    };
  }, [specialNotice, hours.length, description]);

  return (
    <footer ref={footerRef} className="fixed bottom-0 left-0 right-0 overflow-hidden z-0">
      {/* Sophisticated Background with Subtle Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-stone-900 via-stone-800 to-stone-900"></div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
      {/* Warm Cream Pinstripe Pattern */}
      <div 
        className="absolute inset-0"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent 0px, transparent 1px, rgba(254,252,250,0.04) 1px, rgba(254,252,250,0.04) 2px, transparent 2px, transparent 4px)'
        }}
      ></div>
      
      {/* Minimalist Footer Content */}
      <div className="relative">
        <div className="py-12 lg:px-[88px] md:py-20 px-6 md:px-0">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 lg:gap-12"
          >
            {/* Brand Section */}
            <motion.div variants={itemVariants} className="lg:col-span-2">
              <div className="space-y-4 md:space-y-6">
                <div>
                  <h2 className="text-3xl font-light text-white tracking-[0.2em]">
                    {tagline}
                  </h2>
                </div>

                <p className="text-stone-400 leading-relaxed max-w-md">
                  {description}
                </p>
                
                {/* Store Hours */}
                <div className="space-y-2">
                  <h3 className="text-white font-medium tracking-wide text-sm">Store Hours</h3>
                  <div className="text-sm text-stone-400 space-y-1">
                    {hours.map((entry, idx) => (
                      <div key={`${entry.label}-${idx}`}>
                        {entry.label}
                        {entry.value ? `: ${entry.value}` : ''}
                      </div>
                    ))}
                  </div>
                </div>

                {specialNotice && (
                  <div className="space-y-2 pt-2">
                    <h3 className="text-white font-medium tracking-wide text-sm">Special Notice</h3>
                    <p className="text-sm text-stone-400 leading-relaxed whitespace-pre-line max-w-md">
                      {specialNotice}
                    </p>
                  </div>
                )}
              </div>
            </motion.div>

            {/* Contact Information */}
            <motion.div variants={itemVariants}>
              <div className="space-y-4">
                <h3 className="text-white font-medium tracking-wide">Visit Us</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <MapPinIcon className="h-4 w-4 text-stone-500 mt-0.5 flex-shrink-0" />
                    <div className="text-sm text-stone-300">
                      {addressLine1}
                      {addressLine2 && (
                        <>
                          <br />
                          {addressLine2}
                        </>
                      )}
                      <br />
                      {locality}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <PhoneIcon className="h-4 w-4 text-stone-500 flex-shrink-0" />
                    {phoneHref ? (
                    <a 
                      href={phoneHref} 
                      className="text-sm text-stone-300 hover:text-white transition-colors duration-300 cursor-pointer"
                    >
                        {phoneDisplay}
                    </a>
                    ) : (
                      <span className="text-sm text-stone-300">{phoneDisplay}</span>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <EnvelopeIcon className="h-4 w-4 text-stone-500 flex-shrink-0" />
                  <a 
                    href={`mailto:${email}`} 
                    className="text-sm text-stone-300 hover:text-white transition-colors duration-300 cursor-pointer"
                  >
                      {email}
                    </a>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* Quick Links - Desktop Only */}
            <motion.div variants={itemVariants} className="hidden lg:block">
              <div className="space-y-4">
                <h3 className="text-white font-medium tracking-wide">Quick Links</h3>
                <nav className="space-y-3">
                  {[
                    { to: "/products", label: "All Products" },
                    { to: "/manufacturers", label: "Manufacturers" },
                    { to: "/pre-owned", label: "Pre-Owned" },
                    { to: "/news", label: "News & Events" },
                    { to: "/contact", label: "Contact & Demo" }
                  ].map((item) => (
                    <Link
                      key={item.to}
                      href={item.to}
                      prefetch={true}
                      className="block text-sm text-stone-400 hover:text-white transition-colors duration-300 cursor-pointer"
                    >
                      {item.label}
                    </Link>
                  ))}
                </nav>
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Minimalist Bottom Bar */}
        <div className="relative border-t border-white/10">
          <div className="lg:px-[88px] md:px-0">
            <div className="py-4 md:py-6 flex flex-col sm:flex-row justify-between items-center gap-3 md:gap-4">
              <p className="text-sm text-stone-400">© 2025 Fidelis. All rights reserved.</p>
              
              <div className="flex items-center gap-6 text-sm">
                {!user ? (
                  <button
                    onClick={onSignInClick}
                    className="text-stone-400 hover:text-white transition-colors duration-300 cursor-pointer"
                  >
                    Sign In
                  </button>
                ) : (
                  <>
                    <button
                      onClick={() => setIsGlobalsOpen(true)}
                      className="text-stone-400 hover:text-white transition-colors duration-300 cursor-pointer"
                    >
                      Site Globals
                    </button>
                    <button 
                      onClick={handleSignOut} 
                      className="text-stone-400 hover:text-white transition-colors duration-300 cursor-pointer"
                    >
                      Sign Out
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <SiteGlobalsModal isOpen={isGlobalsOpen} onClose={() => setIsGlobalsOpen(false)} />
    </footer>
  );
};

export { Footer };

