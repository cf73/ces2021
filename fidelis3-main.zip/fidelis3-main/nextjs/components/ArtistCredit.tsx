'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface ArtistCreditProps {
  artistName?: string;
  className?: string;
  isMobile?: boolean;
  expandUpward?: boolean;
}

const ArtistCredit: React.FC<ArtistCreditProps> = ({ 
  artistName,
  className = '',
  isMobile = false,
  expandUpward = false,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className={`relative ${className}`}>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="group"
      >
        {/* Main credit line - always visible */}
        <div className="flex items-center space-x-2 text-white/80 text-xs sm:text-xs font-light tracking-wide">
          <div className="w-1 h-1 bg-amber-400 rounded-full opacity-60" />
          <span>
            {artistName ? (
              <>
                Featuring <span className="font-medium text-white/90">{artistName}</span>
              </>
            ) : (
              'Celebrating the artists who inspire us'
            )}
          </span>
        </div>

        {/* Expandable content trigger */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="mt-1 text-white/60 hover:text-white/80 active:text-white/90 transition-colors duration-300 text-xs font-light tracking-wider uppercase focus:outline-none focus:text-white/80 touch-manipulation py-1"
          aria-expanded={isExpanded}
          aria-label="Show more information about our artist features"
        >
          <div className="flex items-center space-x-1">
            <span>More</span>
            <motion.svg
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.3 }}
              className="w-3 h-3"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </motion.svg>
          </div>
        </button>

        {/* Expanded content */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0, y: -10 }}
              animate={{ opacity: 1, height: 'auto', y: 0 }}
              exit={{ opacity: 0, height: 0, y: -10 }}
              transition={{ 
                duration: 0.4, 
                ease: [0.25, 0.46, 0.45, 0.94],
                height: { duration: 0.3 }
              }}
              className={`overflow-hidden ${
                isMobile
                  ? 'mt-0'
                  : expandUpward
                    ? 'absolute bottom-full left-0 mb-2 w-max max-w-xs sm:max-w-sm'
                    : 'mt-3'
              }`}
            >
              <div className={`${
                isMobile 
                  ? 'bg-stone-800/90 border-t border-stone-700 p-4 space-y-4' 
                  : 'backdrop-blur-md bg-black/40 rounded-lg border border-white/10 p-3 sm:p-4 space-y-3 max-w-xs sm:max-w-sm'
              }`}>
                {/* Artist appreciation */}
                <div className={`text-white/85 leading-relaxed ${
                  isMobile ? 'text-sm' : 'text-xs'
                }`}>
                  <p className="mb-2">
                    The musicians featured in our gallery represent the passion and artistry that drives our love for high-fidelity audio. 
                    Their work ignites the same dedication to sonic excellence that we bring to every component we curate.
                  </p>
                  <p>
                    Many of these recordings are available in our extensive vinyl and CD collections in-store, 
                    where their full sonic potential can be experienced through the systems we've carefully selected.
                  </p>
                </div>

                {/* Legal notice */}
                <div className={`pt-3 ${
                  isMobile ? 'border-t border-stone-600' : 'border-t border-white/10'
                }`}>
                  <p className={`text-white/60 leading-relaxed ${
                    isMobile ? 'text-sm' : 'text-xs'
                  }`}>
                    <span className="font-medium text-white/70">Fair Use Notice:</span> We believe our use of these images constitutes fair use under copyright law for educational and promotional purposes. 
                    If you are a copyright holder and believe otherwise, please{' '}
                    <a 
                      href="/contact" 
                      className="text-amber-400/80 hover:text-amber-400 transition-colors duration-300 underline decoration-amber-400/40 hover:decoration-amber-400"
                    >
                      contact us
                    </a>{' '}
                    and we will address your concerns promptly.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default ArtistCredit;
export { ArtistCredit };

