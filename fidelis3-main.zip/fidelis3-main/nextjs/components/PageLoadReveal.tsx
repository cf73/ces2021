'use client';

/**
 * PageLoadReveal Component
 * 
 * Ensures smooth page reveals by waiting for critical content to load
 * before displaying the page to the user. Prevents jarring layout shifts
 * and partial content rendering.
 */

import React, { useState, useEffect, ReactNode } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { getRandomMusicalMessage } from '../utils/musicalLoadingMessages';

interface PageLoadRevealProps {
  children: ReactNode;
  /**
   * Minimum time to show loading spinner (prevents flash of loading state)
   */
  minimumLoadTime?: number;
  /**
   * Maximum time to wait before forcing reveal (prevents infinite loading)
   */
  maxWaitTime?: number;
  /**
   * Number of critical images that must load before revealing
   */
  criticalImageCount?: number;
  /**
   * External loading state (e.g., from data fetching)
   */
  isLoading?: boolean;
  /**
   * Callback when page is ready to be revealed
   */
  onReady?: () => void;
}

export const PageLoadReveal: React.FC<PageLoadRevealProps> = ({
  children,
  minimumLoadTime = 300,
  maxWaitTime = 5000,
  criticalImageCount = 0,
  isLoading = false,
  onReady,
}) => {
  const [imagesLoaded, setImagesLoaded] = useState(0);
  const [minimumTimePassed, setMinimumTimePassed] = useState(false);
  const [maxTimePassed, setMaxTimePassed] = useState(false);
  const [loadingMessage] = useState(getRandomMusicalMessage());
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [showSpinner, setShowSpinner] = useState(isLoading); // Show spinner immediately if loading on mount
  const [isInitialRender, setIsInitialRender] = useState(true);

  // Track initial render
  useEffect(() => {
    setIsInitialRender(false);
  }, []);

  // Minimum time timer
  useEffect(() => {
    const timer = setTimeout(() => {
      setMinimumTimePassed(true);
    }, minimumLoadTime);
    return () => clearTimeout(timer);
  }, [minimumLoadTime]);

  // Maximum time failsafe
  useEffect(() => {
    const timer = setTimeout(() => {
      setMaxTimePassed(true);
    }, maxWaitTime);
    return () => clearTimeout(timer);
  }, [maxWaitTime]);

  // Fade out effect when loading starts (skip on initial render)
  useEffect(() => {
    if (isLoading) {
      // On initial render, show spinner immediately without fade-out
      if (isInitialRender) {
        setShowSpinner(true);
      } else {
        // On subsequent navigations, fade out content first
        setIsFadingOut(true);
        // After fade-out completes (300ms), show spinner
        const timer = setTimeout(() => {
          setShowSpinner(true);
          setIsFadingOut(false);
        }, 300);
        return () => clearTimeout(timer);
      }
    } else {
      // Reset states when loading completes
      setShowSpinner(false);
      setIsFadingOut(false);
    }
  }, [isLoading, isInitialRender]);

  // Check if all conditions are met for page reveal
  const allImagesLoaded = criticalImageCount === 0 || imagesLoaded >= criticalImageCount;
  const isReady = 
    minimumTimePassed && 
    !isLoading && 
    (allImagesLoaded || maxTimePassed);

  useEffect(() => {
    if (isReady) {
      onReady?.();
    }
  }, [isReady, onReady]);

  // Provide context for child components to register image loads
  useEffect(() => {
    const handleImageLoad = () => {
      setImagesLoaded(prev => prev + 1);
    };

    // Listen for custom image load events
    window.addEventListener('criticalImageLoaded', handleImageLoad);
    return () => window.removeEventListener('criticalImageLoaded', handleImageLoad);
  }, []);

  return (
    <>
      {/* Loading Spinner - Only show when explicitly loading */}
      <AnimatePresence mode="wait">
        {showSpinner && (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-[#fffcf9] z-[9999] flex items-center justify-center"
            style={{ 
              position: 'fixed',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
              className="text-center"
            >
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-stone-600 mx-auto mb-4"></div>
              <p className="text-stone-600 animate-pulse">{loadingMessage}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Page Content - Fade out when loading starts, fade in when ready */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ 
          opacity: (isFadingOut || !isReady) ? 0 : 1 
        }}
        transition={{ 
          duration: isFadingOut ? 0.3 : 0.5,
          delay: (!isFadingOut && isReady) ? 0.1 : 0,
          ease: isFadingOut ? 'easeIn' : 'easeOut'
        }}
        style={{ pointerEvents: isReady ? 'auto' : 'none' }}
      >
        {children}
      </motion.div>
    </>
  );
};

/**
 * Hook to notify PageLoadReveal when a critical image has loaded
 */
export const useCriticalImageLoad = () => {
  const notifyImageLoaded = () => {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('criticalImageLoaded'));
    }
  };

  return { notifyImageLoaded };
};

export default PageLoadReveal;

