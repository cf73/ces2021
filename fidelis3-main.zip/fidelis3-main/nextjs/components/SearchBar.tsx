'use client';

import React, { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { searchAll, SearchResult } from '../lib/supabase-queries';
import { getImageUrl } from '../lib/supabase-queries';

interface SearchBarProps {
  variant?: 'light' | 'dark'; // For different navbar states
  isMobile?: boolean;
  onClose?: () => void; // For mobile overlay
}

export const SearchBar: React.FC<SearchBarProps> = ({ 
  variant = 'light',
  isMobile = false,
  onClose
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  // Debounced search with 500ms delay
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (query.length >= 2) {
        setLoading(true);
        try {
          const searchResults = await searchAll(query);
          setResults(searchResults);
          setIsOpen(true);
          setSelectedIndex(-1); // Reset selection on new results
        } catch (error) {
          console.error('Search error:', error);
        } finally {
          setLoading(false);
        }
      } else {
        setResults([]);
        setIsOpen(false);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [query]);

  // Close dropdown and collapse when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        if (!isMobile) {
          setIsExpanded(false);
          setQuery('');
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMobile]);

  // Focus input when expanded
  useEffect(() => {
    if (isExpanded && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isExpanded]);

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen || results.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => 
          prev < results.length - 1 ? prev + 1 : prev
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && results[selectedIndex]) {
          const result = results[selectedIndex];
          router.push(result.url);
          handleResultClick();
        }
        break;
      case 'Escape':
        setIsOpen(false);
        inputRef.current?.blur();
        break;
    }
  };

  const handleResultClick = () => {
    setIsOpen(false);
    setQuery('');
    setResults([]);
    setSelectedIndex(-1);
    if (onClose) onClose();
  };

  // Group results by type
  const groupedResults = results.reduce((acc, result, index) => {
    if (!acc[result.type]) acc[result.type] = [];
    acc[result.type].push({ ...result, originalIndex: index });
    return acc;
  }, {} as Record<string, (SearchResult & { originalIndex: number })[]>);

  const typeLabels = {
    product: 'Products',
    news: 'News',
    'pre-owned': 'Pre-Owned',
    manufacturer: 'Manufacturers'
  };

  // Mobile: always show full input
  if (isMobile) {
    return (
      <div ref={searchRef} className="relative w-full">
        <div className="relative flex items-center w-full">
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Search..."
            className="w-full px-4 py-2 pr-10 rounded-lg bg-stone-900/10 text-stone-900 placeholder-stone-500 border border-stone-200/50 backdrop-blur-md focus:outline-none focus:ring-2 focus:ring-stone-400/30 transition-all duration-200"
          />
          <svg 
            className="absolute right-3 w-5 h-5 text-stone-500"
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>
        {/* Results Dropdown for mobile */}
        {isOpen && (
          <div className="absolute top-full mt-2 w-full bg-white rounded-lg shadow-2xl border border-stone-200 max-h-[80vh] overflow-y-auto z-50">
            {loading ? (
              <div className="p-8 text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-stone-600 mx-auto"></div>
              </div>
            ) : results.length === 0 ? (
              <div className="p-8 text-center text-stone-500">
                No results found for "{query}"
              </div>
            ) : (
              <div className="p-2">
                {Object.entries(groupedResults).map(([type, items]) => (
                  <div key={type} className="mb-4 last:mb-0">
                    <h3 className="px-3 py-2 text-xs font-semibold text-stone-500 uppercase tracking-wide">
                      {typeLabels[type as keyof typeof typeLabels]}
                    </h3>
                    {items.map((result) => (
                      <Link
                        key={result.id}
                        href={result.url}
                        onClick={handleResultClick}
                        className={`
                          flex items-center gap-3 p-3 rounded-lg transition-colors
                          ${selectedIndex === result.originalIndex 
                            ? 'bg-stone-100' 
                            : 'hover:bg-stone-50'
                          }
                        `}
                      >
                        {result.image && (
                          <img
                            src={getImageUrl(result.image)}
                            alt={result.title}
                            className="w-12 h-12 object-cover rounded flex-shrink-0"
                          />
                        )}
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-stone-900 mb-1">
                            {result.title}
                          </h4>
                          {result.description && (
                            <p className="text-sm text-stone-600 line-clamp-2">
                              {result.description}
                            </p>
                          )}
                        </div>
                      </Link>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div ref={searchRef} className="relative">
      {!isExpanded ? (
        /* Icon-only state */
        <button
          onClick={() => setIsExpanded(true)}
          className={`
            inline-flex items-center justify-center p-2 rounded-lg
            ${variant === 'dark' 
              ? 'text-white/80 hover:text-white hover:bg-white/10' 
              : 'text-stone-700 hover:text-stone-900 hover:bg-stone-900/5'
            }
            transition-all duration-200
          `}
          aria-label="Search"
        >
          <svg 
            className="w-5 h-5"
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </button>
      ) : (
        /* Expanded state with input */
        <div className="relative flex items-center w-64 lg:w-80">
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Search..."
          className={`
            w-full px-4 py-2 pr-10 rounded-lg
            ${variant === 'dark' 
              ? 'bg-white/10 text-white placeholder-white/60 border border-white/20' 
              : 'bg-stone-900/10 text-stone-900 placeholder-stone-500 border border-stone-200/50'
            }
            backdrop-blur-md
            focus:outline-none focus:ring-2 focus:ring-stone-400/30
            transition-all duration-200
          `}
        />
        <svg 
          className={`absolute right-3 w-5 h-5 ${variant === 'dark' ? 'text-white/60' : 'text-stone-500'}`}
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </div>
      )}

      {/* Results Dropdown - Only show when expanded, right-aligned */}
      {isExpanded && isOpen && (
        <div className="absolute top-full mt-2 right-0 bg-white rounded-lg shadow-2xl border border-stone-200 max-h-[80vh] overflow-y-auto z-50 w-[500px]">
          {loading ? (
            <div className="p-8 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-stone-600 mx-auto"></div>
            </div>
          ) : results.length === 0 ? (
            <div className="p-8 text-center text-stone-500">
              No results found for "{query}"
            </div>
          ) : (
            <div className="p-2">
              {Object.entries(groupedResults).map(([type, items]) => (
                <div key={type} className="mb-4 last:mb-0">
                  <h3 className="px-3 py-2 text-xs font-semibold text-stone-500 uppercase tracking-wide">
                    {typeLabels[type as keyof typeof typeLabels]}
                  </h3>
                  {items.map((result) => (
                    <Link
                      key={result.id}
                      href={result.url}
                      onClick={handleResultClick}
                      className={`
                        flex items-center gap-3 p-3 rounded-lg transition-colors
                        ${selectedIndex === result.originalIndex 
                          ? 'bg-stone-100' 
                          : 'hover:bg-stone-50'
                        }
                      `}
                    >
                      {result.image && (
                        <img
                          src={getImageUrl(result.image)}
                          alt={result.title}
                          className="w-12 h-12 object-cover rounded flex-shrink-0"
                        />
                      )}
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-stone-900 mb-1">
                          {result.title}
                        </h4>
                        {result.description && (
                          <p className="text-sm text-stone-600 line-clamp-2">
                            {result.description}
                          </p>
                        )}
                      </div>
                    </Link>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

