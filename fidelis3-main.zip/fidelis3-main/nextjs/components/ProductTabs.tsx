'use client';

import React, { useState, useEffect } from 'react';
import type { Product, Review } from '../lib/supabase';
import { useEditMode } from '../contexts/EditModeContext';
import { EditableRichText } from './cms/EditableRichText';
import { EditableText } from './cms/EditableText';
import { EditableTextarea } from './cms/EditableTextarea';

// Helper function to detect if content contains HTML tags
const containsHtmlTags = (content: string): boolean => {
  return /<[^>]+>/g.test(content);
};

// Helper function to clean HTML content and convert to readable text
const cleanHtmlContent = (htmlString: string): string => {
  if (!htmlString) return '';
  
  // If it doesn't contain HTML tags, return as-is
  if (!containsHtmlTags(htmlString)) {
    return htmlString;
  }
  
  return htmlString
    // Convert HTML lists to bullet points
    .replace(/<ul[^>]*>/gi, '')
    .replace(/<\/ul>/gi, '\n')
    .replace(/<li[^>]*>/gi, '• ')
    .replace(/<\/li>/gi, '\n')
    
    // Convert headings
    .replace(/<h[1-6][^>]*>/gi, '\n## ')
    .replace(/<\/h[1-6]>/gi, '\n\n')
    
    // Convert paragraphs and line breaks
    .replace(/<p[^>]*>/gi, '')
    .replace(/<\/p>/gi, '\n\n')
    .replace(/<br[^>]*\/?>/gi, '\n')
    
    // Remove all other HTML tags
    .replace(/<[^>]*>/g, '')
    
    // Clean up whitespace and entities
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    
    // Clean up excessive whitespace
    .replace(/\n\s*\n\s*\n/g, '\n\n') // Multiple line breaks to double
    .replace(/^\s+|\s+$/g, '') // Trim start/end
    .replace(/[ \t]+/g, ' '); // Multiple spaces to single
};

// Helper function to extract text from Statamic content structure
const extractTextFromStatamicContent = (content: any): string => {
  if (!content) return '';
  
  if (typeof content === 'string') {
    return content;
  }
  
  if (Array.isArray(content)) {
    return content.map(item => {
      const text = extractTextFromStatamicContent(item);
      
      // Handle different content types with appropriate formatting
      if (item && item.type) {
        switch (item.type) {
          case 'paragraph':
            return text ? text + '\n\n' : '';
          case 'heading':
            return text ? `## ${text}\n\n` : '';
          case 'bullet_list':
          case 'bulletList':
            return text ? text + '\n\n' : '';
          case 'list_item':
            return text ? `• ${text}\n` : '';
          case 'hardBreak':
          case 'hard_break':
            return '\n';
          default:
            return text;
        }
      }
      return text;
    }).join('').replace(/\n\n$/, ''); // Remove trailing line breaks
  }
  
  if (typeof content === 'object') {
    if (content.type === 'paragraph' && content.content) {
      return extractTextFromStatamicContent(content.content);
    }
    
    if (content.type === 'heading' && content.content) {
      return extractTextFromStatamicContent(content.content);
    }
    
    if ((content.type === 'bullet_list' || content.type === 'bulletList') && content.content) {
      return extractTextFromStatamicContent(content.content);
    }
    
    if (content.type === 'list_item' && content.content) {
      return extractTextFromStatamicContent(content.content);
    }
    
    if (content.type === 'hardBreak' || content.type === 'hard_break') {
      return '\n';
    }
    
    if (content.text) {
      return content.text;
    }
    
    if (content.content) {
      return extractTextFromStatamicContent(content.content);
    }
    
    // Try to find text in any property
    for (const key in content) {
      if (content[key] && typeof content[key] === 'object') {
        const text = extractTextFromStatamicContent(content[key]);
        if (text) return text;
      }
    }
  }
  
  return '';
};

interface ProductTabsProps {
  product: Product;
}

// Helper function to check if product has any tab content
export const hasTabContent = (product: Product): boolean => {
  // Parse description to check if it has actual content
  const parseDescription = (description: any): string => {
    if (!description) return '';
    
    if (typeof description === 'string') {
      try {
        const parsed = JSON.parse(description);
        if (Array.isArray(parsed)) {
          return extractTextFromStatamicContent(parsed);
        }
      } catch {
        // Not JSON, might be HTML or clean text - clean only if it has HTML
        return cleanHtmlContent(description);
      }
    }
    
    return extractTextFromStatamicContent(description);
  };

  const cleanDescription = parseDescription(product.content);
  
  // Parse specs to check if they have actual content
  const parseSpecsForCheck = (specs: any): string => {
    if (!specs) return '';
    
    if (typeof specs === 'string') {
      try {
        const parsed = JSON.parse(specs);
        if (Array.isArray(parsed)) {
          return extractTextFromStatamicContent(parsed);
        }
      } catch {
        // Not JSON, might be HTML - clean it up
        return cleanHtmlContent(specs);
      }
    }
    
    return extractTextFromStatamicContent(specs);
  };

  const cleanSpecs = parseSpecsForCheck(product.specs);
  
  let reviews: Review[] = [];
  try {
    if (product.reivews_set) {
      // Check if it's already an array or needs to be parsed
      const reviewsData = typeof product.reivews_set === 'string' 
        ? JSON.parse(product.reivews_set) 
        : product.reivews_set;
      
      if (Array.isArray(reviewsData)) {
        reviews = reviewsData.map((review: any) => ({
          excerpt: extractTextFromStatamicContent(review.excerpt),
          attribution: review.attribution,
          date_of_review: review.date_of_review,
          link: review.link
        })).filter(review => review.excerpt || review.attribution);
      }
    }
  } catch (error) {
    console.warn('Error parsing reviews:', error);
  }
  
  return !!(cleanDescription || cleanSpecs || reviews.length > 0);
};

export const ProductTabs: React.FC<ProductTabsProps> = ({ product }) => {
  const { isEditMode, registerChange } = useEditMode();
  // Parse description from Statamic Bard content
  const parseDescription = (description: any): string => {
    if (!description) return '';
    
    // If it's already a plain string, return it
    if (typeof description === 'string') {
      // Check if it looks like JSON
      try {
        const parsed = JSON.parse(description);
        if (Array.isArray(parsed)) {
          return extractTextFromStatamicContent(parsed);
        }
      } catch {
        // Not JSON, might be HTML or clean text - clean only if it has HTML
        return cleanHtmlContent(description);
      }
    }
    
    // If it's already an object or array, extract text
    return extractTextFromStatamicContent(description);
  };

  // Parse specs from Statamic Bard content
  const parseSpecs = (specs: any): string => {
    if (!specs) return '';
    
    if (typeof specs === 'string') {
      // Check if it looks like JSON/Statamic content
      try {
        const parsed = JSON.parse(specs);
        if (Array.isArray(parsed)) {
          return extractTextFromStatamicContent(parsed);
        }
      } catch {
        // Not JSON, might be HTML - clean it up
        return cleanHtmlContent(specs);
      }
    }
    
    // If it's already an object or array, extract text
    return extractTextFromStatamicContent(specs);
  };

  // Parse reviews from Statamic structure
  const parseReviews = (reviews: any): Review[] => {
    if (!reviews) return [];
    
    // Check if it's already an array or needs to be parsed
    const reviewsData = typeof reviews === 'string' 
      ? (() => {
          try {
            return JSON.parse(reviews);
          } catch {
            return [];
          }
        })()
      : reviews;
    
    if (Array.isArray(reviewsData)) {
      return reviewsData.map((review: any) => {
        // Extract the actual content from nested Statamic structure
        let excerptText = '';
        if (review.excerpt && Array.isArray(review.excerpt)) {
          // Look for paragraph content in the excerpt array
          review.excerpt.forEach((item: any) => {
            if (item.type === 'paragraph' && item.content && Array.isArray(item.content)) {
              item.content.forEach((textItem: any) => {
                if (textItem.type === 'text' && textItem.text) {
                  excerptText += textItem.text + ' ';
                }
              });
            }
          });
        }
        
        return {
          ...review,
          excerpt: excerptText.trim() || review.excerpt || ''
        };
      });
    }
    
    return [];
  };

  const reviews = React.useMemo(() => parseReviews(product.reivews_set), [product.reivews_set]);
  const [editableReviews, setEditableReviews] = useState<Review[]>([]);
  const cleanDescription = parseDescription(product.content);
  const cleanSpecs = parseSpecs(product.specs);

  useEffect(() => {
    if (isEditMode) {
      setEditableReviews(
        reviews.length > 0
          ? reviews
          : [
              {
                excerpt: '',
                attribution: '',
                link: '',
                date_of_review: '',
              } as Review,
            ]
      );
    } else {
      setEditableReviews([]);
    }
  }, [isEditMode, product.id, reviews.length]);

  const handleReviewFieldChange = (index: number, field: keyof Review, value: string) => {
    setEditableReviews((prev) => {
      const next = [...prev];
      next[index] = { ...(next[index] || {}), [field]: value } as Review;
      registerChange('reivews_set', next);
      return next;
    });
  };

  const handleReviewRemove = (index: number) => {
    setEditableReviews((prev) => {
      const next = prev.filter((_, i) => i !== index);
      registerChange('reivews_set', next);
      return next;
    });
  };

  const addReview = () => {
    setEditableReviews((prev) => {
      const next = [...prev, { excerpt: '', attribution: '', link: '', date_of_review: '' } as Review];
      registerChange('reivews_set', next);
      return next;
    });
  };

  const displayReviews = isEditMode ? editableReviews : reviews;

  const allTabs = [
    { 
      id: 'description', 
      label: 'Description', 
      content: cleanDescription,
      hasContent: !!cleanDescription,
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      )
    },
    { 
      id: 'specs', 
      label: 'Specifications', 
      content: cleanSpecs,
      hasContent: !!cleanSpecs,
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01" />
        </svg>
      )
    },
    { 
      id: 'reviews', 
      label: 'Reviews', 
      content: displayReviews,
      hasContent: displayReviews.length > 0,
      icon: (
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
        </svg>
      )
    }
  ];

  // Filter to only show tabs that have content
  const tabs = isEditMode ? allTabs : allTabs.filter(tab => tab.hasContent);

  // Determine initial active tab - use the first available tab
  const getInitialActiveTab = (): 'description' | 'specs' | 'reviews' => {
    if (tabs.length === 0) return 'description'; // fallback if no tabs
    return tabs[0].id as 'description' | 'specs' | 'reviews';
  };

  const [activeTab, setActiveTab] = useState<'description' | 'specs' | 'reviews'>(getInitialActiveTab());

  // Reset to first tab when product changes (e.g., navigating between products)
  useEffect(() => {
    setActiveTab(getInitialActiveTab());
  }, [product.id]); // Reset when product ID changes

  // If no tabs have content, don't render the component
  if (tabs.length === 0) {
    return null;
  }

  const renderReviewsSection = () => {
    if (isEditMode) {
      return (
        <div className="space-y-6">
          {displayReviews.map((review: Review, index: number) => (
            <div key={index} className="space-y-3 bg-white/60 border border-stone-200 rounded-xl p-4">
              <div className="flex justify-between items-start">
                <div className="text-sm font-semibold text-stone-800">Review {index + 1}</div>
                {displayReviews.length > 1 && (
                  <button
                    type="button"
                    onClick={() => handleReviewRemove(index)}
                    className="text-xs font-semibold text-red-600 hover:text-red-700"
                  >
                    Remove
                  </button>
                )}
              </div>
              <div>
                <label className="block text-sm font-semibold text-stone-700 mb-2">Excerpt</label>
                <textarea
                  value={review.excerpt || ''}
                  onChange={(e) => handleReviewFieldChange(index, 'excerpt', e.target.value)}
                  className="w-full rounded-md border border-stone-200 bg-white px-3 py-2 text-stone-800 focus:outline-none focus:ring-2 focus:ring-stone-400"
                  rows={4}
                  placeholder="Add a review excerpt..."
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-sm font-semibold text-stone-700 mb-1">Attribution</label>
                  <input
                    value={review.attribution || ''}
                    onChange={(e) => handleReviewFieldChange(index, 'attribution', e.target.value)}
                    className="w-full rounded-md border border-stone-200 bg-white px-3 py-2 text-stone-800 focus:outline-none focus:ring-2 focus:ring-stone-400"
                    placeholder="Reviewer / Publication"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-stone-700 mb-1">Link</label>
                  <input
                    value={review.link || ''}
                    onChange={(e) => handleReviewFieldChange(index, 'link', e.target.value)}
                    className="w-full rounded-md border border-stone-200 bg-white px-3 py-2 text-stone-800 focus:outline-none focus:ring-2 focus:ring-stone-400"
                    placeholder="https://example.com/review"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-stone-700 mb-1">Date</label>
                  <input
                    type="date"
                    value={review.date_of_review || ''}
                    onChange={(e) => handleReviewFieldChange(index, 'date_of_review', e.target.value)}
                    className="w-full rounded-md border border-stone-200 bg-white px-3 py-2 text-stone-800 focus:outline-none focus:ring-2 focus:ring-stone-400"
                  />
                </div>
              </div>
            </div>
          ))}
          <button
            type="button"
            onClick={addReview}
            className="inline-flex items-center justify-center px-4 py-2 text-sm font-semibold text-stone-700 bg-white border border-dashed border-stone-300 rounded-md hover:border-stone-400 transition-colors"
          >
            Add Review
          </button>
        </div>
      );
    }

    return (
      <div className="space-y-12">
        {displayReviews.map((review: Review, index: number) => (
          <div key={index} className="relative">
            {review.excerpt && (
              <div className="bg-warm-white rounded-2xl p-8 shadow-sm border border-stone-100 mb-8 relative transform hover:shadow-md transition-shadow duration-300">
                <div className="absolute top-0 left-0 w-1 h-16 bg-stone-300 rounded-l-2xl"></div>
                
                <blockquote className="text-lg font-normal text-stone-700 leading-relaxed mb-6">
                  {review.excerpt}
                </blockquote>
                
                <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-6 space-y-2 sm:space-y-0 text-stone-600 pt-4 border-t border-stone-100">
                  {review.attribution && (
                    <cite className="text-base font-semibold not-italic text-stone-800 tracking-wide">
                      {review.attribution}
                    </cite>
                  )}
                  {review.date_of_review && (
                    <div className="flex items-center space-x-2">
                      <div className="w-1 h-1 bg-stone-400 rounded-full hidden sm:block"></div>
                      <span className="text-stone-500 text-sm font-medium tracking-wider uppercase">
                        {new Date(review.date_of_review).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        })}
                      </span>
                    </div>
                  )}
                  {review.link && (
                    <a
                      href={review.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center space-x-2 px-4 py-2 bg-stone-800 text-white rounded-full hover:bg-stone-900 transition-colors duration-200 text-sm font-light"
                    >
                      <span>Read Full Review</span>
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                      </svg>
                    </a>
                  )}
                </div>
              </div>
            )}
            
            {!review.excerpt && (
              <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-6 space-y-2 sm:space-y-0 text-stone-600">
                {review.attribution && (
                  <cite className="text-base font-semibold not-italic text-stone-800 tracking-wide">
                    {review.attribution}
                  </cite>
                )}
                {review.date_of_review && (
                  <div className="flex items-center space-x-2">
                    <div className="w-1 h-1 bg-stone-400 rounded-full hidden sm:block"></div>
                    <span className="text-stone-500 text-sm font-medium tracking-wider uppercase">
                      {new Date(review.date_of_review).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric'
                      })}
                    </span>
                  </div>
                )}
                {review.link && (
                  <a
                    href={review.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-2 px-4 py-2 bg-stone-800 text-white rounded-full hover:bg-stone-900 transition-colors duration-200 text-sm font-light"
                  >
                    <span>Read Full Review</span>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                  </a>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Mobile: Horizontal Tabs */}
      <div className="md:hidden">
        {/* Mobile Tab Navigation */}
        <div className="flex overflow-x-auto mb-8 border-b border-stone-200 -mx-4 px-4">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            
            return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as 'description' | 'specs' | 'reviews')}
                className={`flex-shrink-0 flex items-center space-x-2 px-4 py-3 relative transition-all duration-300 ${
                  isActive 
                    ? 'text-stone-900' 
                    : 'text-stone-600'
                }`}
              >
                <div className={`transition-all duration-300 ${
                  isActive 
                    ? 'text-stone-700' 
                    : 'text-stone-400'
                }`}>
                  {tab.icon}
                </div>
                <span className={`text-sm font-medium whitespace-nowrap ${
                  isActive 
                    ? 'text-stone-900' 
                    : 'text-stone-600'
                }`}>
              {tab.label}
                </span>
                
                {/* Active State Underline */}
                {isActive && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-stone-600" />
                )}
            </button>
            );
          })}
      </div>

        {/* Mobile Content Area */}
        <div className="pb-8">
          {activeTab === 'description' && (
            <div>
              <EditableRichText
                value={product.content || ''}
                fieldName="content"
                placeholder="Add a detailed product description..."
                minHeight="300px"
                className="text-base leading-relaxed text-stone-700"
              />
            </div>
          )}

          {activeTab === 'specs' && (
            <div>
              <EditableRichText
                value={product.specs || ''}
                fieldName="specs"
                placeholder="Add product specifications..."
                minHeight="300px"
                className="text-base leading-relaxed text-stone-700"
              />
            </div>
          )}

          {activeTab === 'reviews' && (
            <div>{renderReviewsSection()}</div>
          )}
          </div>
        </div>

      {/* Desktop: Vertical Tabs (Preserve Original Design) */}
      <div className="hidden md:block">
        <div className="flex min-h-[400px]">
          {/* Clean Vertical Tab Navigation */}
          <div className="w-48 flex flex-col mr-16">
            {tabs.map((tab, index) => {
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as 'description' | 'specs' | 'reviews')}
                  className={`py-6 text-left transition-all duration-300 relative group cursor-pointer ${
                    isActive 
                      ? 'text-stone-900' 
                      : 'text-stone-600 hover:text-stone-800'
                  }`}
                >
                  {/* Just Icon and Label */}
                  <div className="flex items-center space-x-3">
                    <div className={`transition-all duration-300 transform ${
                      isActive 
                        ? 'text-stone-700' 
                        : 'text-stone-400 group-hover:text-stone-600 group-hover:scale-110'
                    }`}>
                      {tab.icon}
                    </div>
                    <span className={`text-base font-medium tracking-wide transition-all duration-300 ${
                      isActive 
                        ? 'text-stone-900' 
                        : 'text-stone-600 group-hover:text-stone-800 group-hover:tracking-wider'
                    }`}>
                      {tab.label}
                    </span>
                  </div>
                  
                  {/* Active State Underline */}
                  {isActive && (
                    <div className="absolute bottom-2 left-0 right-0 h-px bg-stone-400 transition-all duration-300" />
                  )}
                  
                  {/* Hover State Underline Preview */}
                  {!isActive && (
                    <div className="absolute bottom-2 left-0 right-0 h-px bg-stone-300 transition-all duration-300 transform scale-x-0 group-hover:scale-x-75 origin-left" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Clean Vertical Divider */}
          <div className="relative mr-16">
            <div className="absolute inset-y-0 left-0 w-px bg-stone-300"></div>
          </div>

          {/* Desktop Content Area - Flat on page */}
          <div className="flex-1">
            {activeTab === 'description' && (
              <div>
                <EditableRichText
                  value={product.content || ''}
                  fieldName="content"
                  placeholder="Add a detailed product description..."
                  minHeight="300px"
                  className="prose prose-lg prose-stone max-w-none text-base leading-relaxed text-stone-700 space-y-6"
                />
              </div>
            )}

            {activeTab === 'specs' && (
              <div>
                <EditableRichText
                  value={product.specs || ''}
                  fieldName="specs"
                  placeholder="Add product specifications..."
                  minHeight="300px"
                  className="prose prose-lg prose-stone max-w-none text-base leading-relaxed text-stone-700 space-y-4 whitespace-pre-wrap"
                />
              </div>
            )}

            {activeTab === 'reviews' && (
              <div>{renderReviewsSection()}</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

