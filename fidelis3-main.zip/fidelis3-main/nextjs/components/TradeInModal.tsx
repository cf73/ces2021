'use client';

import React, { useState, useEffect } from 'react';
import { Button } from './ui/Button';

interface TradeInModalProps {
  open: boolean;
  onClose: () => void;
  defaultSubject?: string;
  defaultMessage?: string;
  source?: string;
}

export function TradeInModal({ open, onClose, defaultSubject = 'Trade-In Inquiry', defaultMessage = '', source = 'trade-modal' }: TradeInModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState(defaultMessage);
  const [company, setCompany] = useState('');
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) {
      setStatus('idle');
      setError('');
      setMessage(defaultMessage);
      setCompany('');
    }
  }, [open, defaultMessage]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!name.trim() || !emailRegex.test(email)) {
      setStatus('error');
      setError('Please add your name and a valid email.');
      return;
    }
    setStatus('submitting');
    setError('');

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          subject: defaultSubject,
          message,
          source,
          company,
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data.error || 'Failed to submit. Please try again.');
      }
      setStatus('success');
      setName('');
      setEmail('');
      setMessage(defaultMessage);
      setCompany('');
    } catch (err) {
      console.error('Trade-in modal submit error:', err);
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
      <div role="dialog" aria-modal="true" aria-labelledby="trade-in-modal-title" className="relative w-full max-w-xl rounded-2xl bg-white shadow-2xl border border-stone-200 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-200 bg-stone-50">
          <h3 id="trade-in-modal-title" className="text-lg font-semibold text-stone-900">Trade-In / System Consultation</h3>
          <button
            onClick={onClose}
            className="text-stone-500 hover:text-stone-800 transition-colors"
            aria-label="Close trade-in modal"
          >
            ✕
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <input
            type="text"
            name="company"
            value={company}
            onChange={(e) => setCompany(e.target.value)}
            tabIndex={-1}
            autoComplete="off"
            aria-hidden="true"
            className="hidden"
          />
          <div className="space-y-2">
            <label className="text-sm font-medium text-stone-700">Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-stone-500 focus:border-stone-500"
              placeholder="Your name"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-stone-700">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-stone-500 focus:border-stone-500"
              placeholder="you@example.com"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-stone-700">Gear & Details</label>
            <textarea
              rows={6}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-stone-300 focus:outline-none focus:ring-2 focus:ring-stone-500 focus:border-stone-500"
              placeholder="Tell us what you have and what you're looking for..."
            />
          </div>
          {status === 'error' && error && (
            <p className="text-sm text-red-600">{error}</p>
          )}
          {status === 'success' && (
            <p className="text-sm text-emerald-700">Thanks—your request was sent.</p>
          )}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-stone-600 hover:text-stone-900"
            >
              Cancel
            </button>
            <Button type="submit" variant="primary" size="md" disabled={status === 'submitting'}>
              {status === 'submitting' ? 'Sending...' : 'Send Request'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
