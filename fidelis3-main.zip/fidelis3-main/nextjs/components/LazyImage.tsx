'use client';

/**
 * LazyImage Component - Now powered by Next.js Image Optimization
 * 
 * Provides automatic:
 * - WebP/AVIF conversion
 * - Responsive image sizing
 * - Blur placeholders
 * - Lazy loading
 * - Error handling
 */

import React, { useState } from 'react';
import Image from 'next/image';
import { generateBlurDataURL } from '../lib/image-loader';

interface LazyImageProps {
  src: string;
  alt: string;
  className?: string;
  placeholder?: string;
  onLoad?: () => void;
  onError?: () => void;
  width?: number;
  height?: number;
  fill?: boolean;
  priority?: boolean;
  sizes?: string;
  quality?: number;
}

const LazyImage: React.FC<LazyImageProps> = ({
  src,
  alt,
  className = '',
  placeholder,
  onLoad,
  onError,
  width,
  height,
  fill = true,
  priority = false,
  sizes,
  quality = 85,
}) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  const handleLoad = () => {
    setIsLoaded(true);
    onLoad?.();
  };

  const handleError = () => {
    setHasError(true);
    onError?.();
  };

  // Render a native <img> for Supabase URLs to avoid Next/Image loader issues
  const isSupabaseImage = src.includes('supabase.co/storage');

  // Error state
  if (hasError) {
    return (
      <div className={`bg-gray-100 flex items-center justify-center text-gray-400 ${className}`}>
        <svg className="w-12 h-12" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
        </svg>
      </div>
    );
  }

  // If Supabase image, use native img to bypass any Next/Image domain/loader issues
  if (isSupabaseImage) {
    return (
      <img
        src={src}
        alt={alt}
        className={`transition-opacity duration-300 ${
          isLoaded ? 'opacity-100' : 'opacity-0'
        } ${className}`}
        onLoad={handleLoad}
        onError={handleError}
        loading={priority ? 'eager' : 'lazy'}
        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
      />
    );
  }

  const imageProps: any = {
    src,
    alt,
    className: `transition-opacity duration-300 ${
      isLoaded ? 'opacity-100' : 'opacity-0'
    } ${className}`,
    onLoad: handleLoad,
    onError: handleError,
    quality,
    // Skip Next.js optimization for Supabase images to avoid loader/url issues
    unoptimized: true
  };

  if (fill) {
    imageProps.fill = true;
    imageProps.style = { objectFit: 'cover' };
    imageProps.sizes = sizes || '(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw';
  } else {
    if (width) imageProps.width = width;
    if (height) imageProps.height = height;
    if (sizes) imageProps.sizes = sizes;
  }

  // Add blur placeholder
  if (!priority && !placeholder) {
    imageProps.placeholder = 'blur';
    imageProps.blurDataURL = generateBlurDataURL();
  } else if (placeholder) {
    imageProps.placeholder = 'blur';
    imageProps.blurDataURL = placeholder;
  }

  if (priority) {
    imageProps.priority = true;
  }

  return <Image {...imageProps} />;
};

export default LazyImage;

