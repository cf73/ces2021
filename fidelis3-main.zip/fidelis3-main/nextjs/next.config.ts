import type { NextConfig } from "next";

const isDev = process.env.NODE_ENV !== "production";

const prodCsp = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' https://www.paypal.com https://www.paypalobjects.com https://www.sandbox.paypal.com https://*.supabase.co",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: https: blob:",
  "font-src 'self' data:",
  "connect-src 'self' https://*.supabase.co https://www.paypal.com https://www.sandbox.paypal.com wss://*.supabase.co",
  "frame-src 'self' https://www.paypal.com https://www.sandbox.paypal.com https://www.google.com https://maps.google.com",
  "media-src 'self' https://*.supabase.co",
  "worker-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'self'",
  "upgrade-insecure-requests"
].join("; ");

// Looser CSP for local dev to allow React Refresh (inline/eval) and inline styles
const devCsp = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.paypal.com https://www.paypalobjects.com https://www.sandbox.paypal.com https://*.supabase.co",
  "style-src 'self' 'unsafe-inline' 'unsafe-inline'",
  "img-src 'self' data: https: blob:",
  "font-src 'self' data:",
  "connect-src 'self' https://*.supabase.co https://www.paypal.com https://www.sandbox.paypal.com wss://*.supabase.co",
  "frame-src 'self' https://www.paypal.com https://www.sandbox.paypal.com https://www.google.com https://maps.google.com",
  "media-src 'self' https://*.supabase.co",
  "worker-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'self'",
  "upgrade-insecure-requests"
].join("; ");

const nextConfig: NextConfig = {
  // Enable React strict mode for better error detection
  reactStrictMode: true,
  
  // Compress responses
  compress: true,
  
  // Security headers
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          // Security headers
          {
            key: 'X-DNS-Prefetch-Control',
            value: 'on'
          },
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=63072000; includeSubDomains; preload'
          },
          {
            key: 'X-Frame-Options',
            value: 'SAMEORIGIN'
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff'
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block'
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin'
          },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()'
          },
          // Content Security Policy
          {
            key: 'Content-Security-Policy',
            value: isDev ? devCsp : prodCsp
          }
        ]
      }
    ];
  },
  
  images: {
    // Use custom loader for Supabase Storage image optimization
    loader: 'custom',
    loaderFile: './lib/image-loader.ts',
    // Allow images from Supabase Storage
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.supabase.co',
        pathname: '/storage/v1/object/public/**',
      },
    ],
    // Image formats to support (Next.js will automatically use WebP/AVIF when supported)
    formats: ['image/avif', 'image/webp'],
    // Device sizes for responsive images
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    // Image sizes for the 'sizes' prop
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    // Supported quality values
    qualities: [75, 85, 90, 95],
    // Minimize CLS by requiring explicit width/height
    dangerouslyAllowSVG: true,
    contentDispositionType: 'attachment',
    contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;",
  },
  
  // Performance optimizations
  experimental: {
    // Enable optimized CSS loading
    optimizeCss: true,
    // Enable React optimized loading
    optimizePackageImports: ['@heroicons/react', 'framer-motion', 'gsap', 'swiper'],
  },
};

export default nextConfig;
