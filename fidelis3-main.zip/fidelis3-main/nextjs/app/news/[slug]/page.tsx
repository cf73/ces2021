import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getNewsBySlug, getNews, processArticleMentions } from '../../../lib/supabase-queries';
import NewsDetailClient from './NewsDetailClient';
import supabaseAdmin from '../../../lib/supabase-server-admin';

// Enable ISR with 1 hour revalidation - on-demand revalidation handles updates
export const revalidate = 3600;

// Pre-render all news pages at build time (plus handle 'new' for creating articles)
export async function generateStaticParams() {
  try {
    const articles = await getNews();
    return articles.map((article) => ({
      slug: article.slug,
    }));
  } catch (error) {
    console.error('Error generating static params for news:', error);
    return [];
  }
}

// Generate metadata for SEO
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  // Handle 'new' article creation route
  if (slug === 'new') {
    return {
      title: 'Create New Article | Fidelis AV',
      description: 'Create a new news article',
    };
  }

  try {
    const article = await getNewsBySlug(slug);
    
    if (!article) {
      return {
        title: 'Article Not Found | Fidelis AV',
      };
    }

    return {
      title: `${article.title} | Fidelis AV News`,
      description: article.summary || article.brief_description || article.content?.substring(0, 155) || '',
      openGraph: {
        title: article.title,
        description: article.summary || article.brief_description || '',
        images: article.image ? [
          {
            url: article.image,
            width: 1200,
            height: 630,
            alt: article.title,
          },
        ] : [],
      },
      twitter: {
        card: 'summary_large_image',
        title: article.title,
        description: article.summary || article.brief_description || '',
        images: article.image ? [article.image] : [],
      },
    };
  } catch (error) {
    console.error('Error generating metadata:', error);
    return {
      title: 'News | Fidelis AV',
    };
  }
}

// Server Component - fetches initial data for ISR
export default async function NewsDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  // Handle 'new' article creation route
  if (slug === 'new') {
    return <NewsDetailClient initialArticle={null} slug="new" />;
  }

  try {
    // Fetch initial article data server-side
    const initialArticle = await getNewsBySlug(slug);
    
    if (!initialArticle) {
      notFound();
    }

    let initialProcessedContent: string | undefined = undefined;
    let initialMentions:
      | {
          manufacturers: Array<{ name: string; slug: string; count: number }>;
          products: Array<{ title: string; slug: string; count: number }>;
        }
      | undefined = undefined;

    if (supabaseAdmin && (initialArticle.main_content || initialArticle.content)) {
      try {
        const contentToProcess = initialArticle.main_content || initialArticle.content || '';
        const { processedContent, mentions } = await processArticleMentions(
          contentToProcess,
          initialArticle.title,
          initialArticle.brief_description || initialArticle.summary,
          supabaseAdmin
        );
        initialProcessedContent = processedContent;
        initialMentions = mentions;
      } catch (error) {
        console.error('Error processing article mentions:', error);
      }
    }

    // Pass initial data to client component
    return (
      <NewsDetailClient
        initialArticle={initialArticle}
        slug={slug}
        initialProcessedContent={initialProcessedContent}
        initialMentions={initialMentions}
      />
    );
  } catch (error) {
    console.error('Error loading article:', error);
    notFound();
  }
}
