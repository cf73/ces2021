'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useAuth } from '../../../contexts/AuthContext';
import { useEditMode } from '../../../contexts/EditModeContext';
import { getNewsBySlug, getAdjacentNews, getImageUrl } from '../../../lib/supabase-queries';
import { supabase } from '../../../lib/supabase';
import type { News } from '../../../lib/supabase';
import { getRandomMusicalMessage } from '../../../utils/musicalLoadingMessages';
import { Section, Container } from '../../../components/ui';
import { Header } from '../../../components/Header';
import { FooterWithSignIn } from '../../../components/FooterWithSignIn';
import { slugify } from '../../../lib/utils';
import { generateBlurDataURL } from '../../../lib/image-loader';
import { PageLoadReveal } from '../../../components/PageLoadReveal';
import { EditBar } from '../../../components/cms/EditBar';
import { EditableText } from '../../../components/cms/EditableText';
import { EditableTextarea } from '../../../components/cms/EditableTextarea';
import { EditableDate } from '../../../components/cms/EditableDate';
import { EditableImage } from '../../../components/cms/EditableImage';
import { EditableRichText } from '../../../components/cms/EditableRichText';
import { ContentBlockEditor } from '../../../components/cms/ContentBlockEditor';
import { DeleteConfirmation } from '../../../components/DeleteConfirmation';
import { StructuredData } from '../../../components/StructuredData';
import { generateArticleSchema, generateBreadcrumbSchema } from '../../../lib/structured-data';
import { getAuthHeaders } from '../../../lib/auth-headers';
import { sanitizeHTML } from '../../../lib/sanitize';

interface MentionList {
  manufacturers: Array<{ name: string; slug: string; count: number; logo?: string | null }>;
  products: Array<{
    title: string;
    slug: string;
    count: number;
    heroImage?: string | null;
    manufacturerName?: string | null;
    categoryName?: string | null;
    price?: number | null;
    showPrice?: boolean | null;
  }>;
}

interface NewsDetailClientProps {
  initialArticle: News | null;
  slug: string;
  initialProcessedContent?: string;
  initialMentions?: MentionList;
}

export default function NewsDetailClient({ initialArticle, slug, initialProcessedContent, initialMentions }: NewsDetailClientProps) {
  const router = useRouter();
  const { user } = useAuth();
  const { isEditMode, toggleEditMode, enableEditMode, getChanges, clearChanges, setIsSaving, setOriginalValues, registerChange } = useEditMode();
  const hasForcedEditRef = React.useRef(false);
  const formatProductPrice = useCallback((priceValue?: number | null, showPrice?: boolean | null) => {
    if (!priceValue || !showPrice) return 'Contact for price';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(priceValue);
  }, []);
  
  const [article, setArticle] = useState<News | null>(initialArticle);
  const [adjacentArticles, setAdjacentArticles] = useState<{ previous: News | null; next: News | null }>({ previous: null, next: null });
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const defaultMentions: MentionList = { manufacturers: [], products: [] };
  const [processedContent, setProcessedContent] = useState<string>(
    initialProcessedContent || initialArticle?.main_content || initialArticle?.content || ''
  );
  const [mentions, setMentions] = useState<MentionList>(initialMentions || defaultMentions);
  const [isRefreshingMentions, setIsRefreshingMentions] = useState(false);
  const [mentionsError, setMentionsError] = useState<string | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [editBarKey, setEditBarKey] = useState(0);

  // Parse more_content if it's a JSON string
  const parsedMoreContent = useMemo(() => {
    if (!article?.more_content) return null;
    if (Array.isArray(article.more_content)) return article.more_content;
    
    // If it's a string, parse it
    if (typeof article.more_content === 'string') {
      try {
        const parsed = JSON.parse(article.more_content);
        return Array.isArray(parsed) ? parsed : null;
      } catch (error) {
        console.error('Error parsing more_content:', error);
        return null;
      }
    }
    
    return null;
  }, [article?.more_content]);

  // Handle "new" slug for creating new articles
  const isNewArticle = slug === 'new';

  // Automatically enable edit mode immediately for new articles
  useEffect(() => {
    if (!isNewArticle) return;
    if (isEditMode) return; // Already in edit mode
    enableEditMode();
  }, [isNewArticle, isEditMode, enableEditMode]);

  // If new article, create empty template
  useEffect(() => {
    if (isNewArticle && !article) {
      const emptyArticle: News = {
        id: 'new',
        title: '',
        slug: '',
        content: '',
        main_content: '',
        summary: '',
        brief_description: '',
        image: '',
        published: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        news_date: new Date().toISOString().split('T')[0],
      };
      setArticle(emptyArticle);
    }
  }, [isNewArticle, article]);

  // Load article data when edit mode is toggled
  const loadArticle = async () => {
    if (!slug || slug === 'new') return;
    
    try {
      setLoading(true);
      const data = await getNewsBySlug(slug);
      if (data) {
        setEditBarKey(prev => prev + 1);
        setArticle(data);
        
        // Load adjacent articles
        const adjacent = await getAdjacentNews(data.id);
        setAdjacentArticles(adjacent);
        
        // Process content for mentions (including title and brief description)
      }
    } catch (error) {
      console.error('Error loading article:', error);
    } finally {
      setLoading(false);
    }
  };

  const refreshMentions = useCallback(
    async (overrides?: { content?: string; title?: string; briefDescription?: string }) => {
      if (!article && !overrides?.content) {
        return;
      }

      const payload = {
        content: overrides?.content ?? article?.main_content ?? article?.content ?? '',
        title: overrides?.title ?? article?.title ?? '',
        briefDescription:
          overrides?.briefDescription ?? article?.brief_description ?? article?.summary ?? '',
      };

      if (!payload.content) {
        return;
      }

      setIsRefreshingMentions(true);
      setMentionsError(null);

      try {
        const authHeaders = await getAuthHeaders();
        const response = await fetch('/api/news/mentions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...authHeaders },
          body: JSON.stringify(payload),
        });

        if (!response.ok) {
          throw new Error('Failed to refresh mentions');
        }

        const data = await response.json();
        setProcessedContent(data.processedContent || payload.content);
        setMentions(data.mentions || defaultMentions);
      } catch (error) {
        console.error('Failed to refresh mentions:', error);
        setMentionsError('Unable to refresh mentions right now. Please try again.');
      } finally {
        setIsRefreshingMentions(false);
      }
    },
    [article]
  );

  // Refetch when edit mode is toggled and set original values
  useEffect(() => {
    if (isEditMode && !isNewArticle && article) {
      // Set original values for comparison
      setOriginalValues({
        title: article.title,
        content: article.content,
        main_content: article.main_content,
        summary: article.summary,
        brief_description: article.brief_description,
        image: article.image,
        news_date: article.news_date,
        system_category: article.system_category
      });
      loadArticle();
    }
  }, [isEditMode]);

  // Load adjacent articles and process content on mount
  useEffect(() => {
    if (initialArticle && !isNewArticle) {
      const loadData = async () => {
        const adjacent = await getAdjacentNews(initialArticle.id);
        setAdjacentArticles(adjacent);
        
      };
      
      loadData();
    }
  }, [initialArticle?.id]);

  useEffect(() => {
    if (initialProcessedContent) {
      setProcessedContent(initialProcessedContent);
    } else if (article?.main_content || article?.content) {
      setProcessedContent(article.main_content || article.content || '');
    }
  }, [initialProcessedContent, article?.id, article?.main_content, article?.content]);

  useEffect(() => {
    setMentions(initialMentions || defaultMentions);
  }, [initialMentions]);

  useEffect(() => {
    if (!initialMentions && article && (article.main_content || article.content)) {
      refreshMentions();
    }
  }, [article?.id, article?.main_content, article?.content, initialMentions, refreshMentions]);

  const handleSave = async () => {
    if (!article) return;

    setIsSaving(true);
    try {
      const changes = getChanges();

      if (Object.keys(changes).length === 0 && !isNewArticle) {
        console.log('No changes to save');
        setIsSaving(false);
        return;
      }

      // If title changed, also update slug
      const dataToSave = { ...changes };
      if (changes.title) {
        dataToSave.slug = slugify(changes.title);
      }

      // Serialize more_content to JSON string if it exists and hasn't been serialized yet
      // (registerChange already serializes it, so only serialize if it's still an array)
      if (article.more_content && Array.isArray(article.more_content) && !changes.more_content) {
        dataToSave.more_content = JSON.stringify(article.more_content) as any;
      }

      // Add updated_at timestamp
      dataToSave.updated_at = new Date().toISOString();

      if (isNewArticle) {
        // Create new article
        const more_content_serialized = article.more_content && Array.isArray(article.more_content) && article.more_content.length > 0
          ? JSON.stringify(article.more_content)
          : null;

        const newArticleData = {
          title: dataToSave.title || article.title || 'Untitled Article',
          slug: dataToSave.slug || slugify(dataToSave.title || article.title || 'untitled-article'),
          content: dataToSave.content || article.content || '',
          main_content: dataToSave.main_content || article.main_content || '',
          more_content: more_content_serialized,
          summary: dataToSave.summary || article.summary || '',
          brief_description: dataToSave.brief_description || article.brief_description || '',
          image: dataToSave.image || article.image || '',
          news_date: dataToSave.news_date || article.news_date || new Date().toISOString().split('T')[0],
          // Publish by default on create unless explicitly set otherwise
          published: dataToSave.published !== undefined ? dataToSave.published : true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };

        const { data: newData, error: createError } = await supabase
          .from('news')
          .insert([newArticleData])
          .select()
          .single();

        if (createError) {
          console.error('Error creating article:', createError);
          alert('Failed to create article. Please try again.');
          return;
        }

        if (newData) {
          console.log('✅ Article created successfully:', newData);
          clearChanges();
          // Redirect to the new article
          router.push(`/news/${newData.slug}`);
        }
      } else {
        // Update existing article
        const { data: updateData, error: updateError } = await supabase
          .from('news')
          .update(dataToSave)
          .eq('id', article.id)
          .select();

        if (updateError) {
          console.error('Error saving article:', updateError);
          alert('Failed to save changes. Please try again.');
          return;
        }

        if (!updateData || updateData.length === 0) {
          console.error('Update returned no data');
          alert('Failed to update article. Please refresh and try again.');
          return;
        }

        console.log('✅ Article updated successfully:', updateData[0]);
        
        // Reload article data
        const { data: updatedArticle, error: reloadError } = await supabase
          .from('news')
          .select('*')
          .eq('id', article.id)
          .single();
        
        if (reloadError) {
          console.error('Error reloading article:', reloadError);
        } else if (updatedArticle) {
          setEditBarKey(prev => prev + 1);
          setArticle(updatedArticle);
          await refreshMentions({
            content: updatedArticle.main_content || updatedArticle.content || '',
            title: updatedArticle.title,
            briefDescription: updatedArticle.brief_description || updatedArticle.summary,
          });
        }
        
        clearChanges();
      }
      
      console.log('✅ Article saved successfully');
    } catch (error) {
      console.error('Error saving article:', error);
      alert('Failed to save changes. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    if (isNewArticle) {
      router.push('/news');
    } else {
      loadArticle();
    }
  };

  const handleTogglePublish = async (published: boolean) => {
    if (!article || isNewArticle) return;
    
    try {
      const { data: updateResult, error } = await supabase
        .from('news')
        .update({ published })
        .eq('id', article.id)
        .select();
      
      if (error) {
        console.error('Error updating publish status:', error);
        alert('Failed to update publish status. Please try again.');
        return;
      }
      
      const { data: updatedArticle, error: reloadError } = await supabase
        .from('news')
        .select('*')
        .eq('id', article.id)
        .single();
      
      if (reloadError) {
        console.error('Error reloading article:', reloadError);
      } else if (updatedArticle) {
        console.log(`✅ Article ${published ? 'published' : 'unpublished'} successfully`);
        setArticle(updatedArticle);
      }
    } catch (error) {
      console.error('Error toggling publish status:', error);
      alert('Failed to update publish status. Please try again.');
    }
  };

  const handleDelete = async () => {
    if (!article || isNewArticle) return;
    
    setDeleteLoading(true);
    try {
      const { error } = await supabase
        .from('news')
        .delete()
        .eq('id', article.id);
        
      if (error) {
        console.error('Error deleting article:', error);
        alert('Failed to delete article. Please try again.');
        return;
      }
      
      console.log('✅ Article deleted successfully');
      router.push('/news');
    } catch (error) {
      console.error('Error deleting article:', error);
      alert('Failed to delete article. Please try again.');
    } finally {
      setDeleteLoading(false);
      setIsDeleteModalOpen(false);
    }
  };

  const openImageModal = (imagePath: string) => {
    setSelectedImage(imagePath);
    setIsImageModalOpen(true);
  };

  const closeImageModal = () => {
    setIsImageModalOpen(false);
    setSelectedImage(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-warm-white">
        <Header />
        <div className="min-h-screen bg-warm-white py-12">
          <div className="container-custom text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">{getRandomMusicalMessage()}</p>
          </div>
        </div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen bg-warm-white">
        <Header />
        <div className="min-h-screen bg-warm-white py-12">
          <div className="container-custom text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Article Not Found</h1>
            <p className="text-gray-600 mb-6">The news article you're looking for doesn't exist.</p>
            <Link href="/news" className="btn-primary">
              Back to News
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Generate structured data for SEO
  const articleSchema = article ? generateArticleSchema(article) : null;
  const breadcrumbSchema = article ? generateBreadcrumbSchema([
    { name: 'Home', url: 'https://fidelisav.com' },
    { name: 'News', url: 'https://fidelisav.com/news' },
    { name: article.title, url: `https://fidelisav.com/news/${article.slug}` }
  ]) : null;

  return (
    <PageLoadReveal isLoading={loading} minimumLoadTime={200} maxWaitTime={3000}>
      {/* SEO Structured Data */}
      {articleSchema && <StructuredData data={[articleSchema, breadcrumbSchema].filter(Boolean)} />}
      
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="min-h-screen bg-warm-cream pt-24 footer-scroll-reveal"
      >
        <div className="relative z-10 bg-warm-cream">
          <Header />
          <main id="main-content">

          {/* Edit Bar */}
          {user && (
            <EditBar
              key={`editbar-${editBarKey}`}
              onSave={handleSave}
              onCancel={handleCancel}
              onTogglePublish={isNewArticle ? undefined : handleTogglePublish}
              onDelete={isNewArticle ? undefined : () => setIsDeleteModalOpen(true)}
              isPublished={article.published !== false}
            />
          )}

          {/* Hero Section - Editorial Style */}
          <Section variant="hero" background="custom" customBackground="bg-warm-beige" className="-mt-4">
            <Container size="6xl">
              <div className="max-w-4xl">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                >
                  {/* Date with accent bar */}
                  <div className="relative pl-4 mb-6">
                    <EditableDate
                      value={article.news_date}
                      fieldName="news_date"
                      label="Publication Date"
                      displayClassName="text-xs text-stone-500 font-medium tracking-[0.15em] uppercase"
                    />
                    <div className="absolute left-0 top-0 bottom-0 w-1 bg-amber-400 rounded-full"></div>
                  </div>

                  {/* Title */}
                  <EditableText
                    value={article.title}
                    fieldName="title"
                    fieldType="text"
                    placeholder="Article Title"
                    required
                    className="text-4xl lg:text-5xl xl:text-6xl font-light text-stone-900 leading-tight tracking-wide mb-6"
                  />

                  {/* Summary/Brief Description */}
                  <div className="prose prose-stone prose-lg max-w-none text-stone-700 leading-relaxed">
                    <EditableTextarea
                      value={article.summary || article.brief_description || ''}
                      fieldName="summary"
                      placeholder="Article summary or excerpt (appears in listings and meta descriptions)"
                      rows={3}
                      className="text-xl leading-relaxed font-light"
                    />
                  </div>
                </motion.div>
              </div>
            </Container>
          </Section>

          {/* Article Image - Overlapping Design */}
          <div className="relative -mt-16 mb-4">
            <Container size="6xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="max-w-4xl mx-auto relative z-10"
              >
                <div className="bg-warm-beige rounded-xl overflow-hidden shadow-lg">
                  <EditableImage
                    value={article.image}
                    fieldName="image"
                    alt={article.title}
                    className="w-full h-auto object-cover"
                    folder="news"
                    recordId={article.id}
                  />
                </div>
              </motion.div>
            </Container>
          </div>

          {/* Article Content */}
          <Section background="custom" customBackground="bg-warm-cream">
            <Container size="6xl">
              <div className="max-w-4xl mx-auto">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                >
                  {isEditMode ? (
                  <>
                    <EditableRichText
                      value={article.main_content || article.content || ''}
                      fieldName="main_content"
                      placeholder="Write your article content here..."
                      className="prose prose-stone prose-lg max-w-none prose-p:mb-6 prose-p:leading-[1.75] prose-p:text-[17px] prose-headings:font-light prose-headings:tracking-wide prose-headings:mb-4 prose-h2:text-3xl prose-h2:mt-10 prose-h2:mb-6 prose-h3:text-2xl prose-h3:mt-8 prose-h3:mb-4 prose-strong:font-medium prose-a:text-stone-700 prose-a:underline-offset-4 prose-ul:my-6 prose-ol:my-6 prose-li:my-2 prose-li:leading-relaxed prose-blockquote:my-8 prose-blockquote:pl-6 prose-blockquote:border-l-4 prose-blockquote:border-stone-300 prose-blockquote:italic prose-hr:my-10"
                    />
                    
                    {/* Additional Content Blocks Editor */}
                    <div className="mt-12 pt-12 border-t-2 border-stone-200">
                      <h3 className="text-lg font-medium text-stone-900 mb-4">Additional Content</h3>
                      <p className="text-sm text-stone-600 mb-6">Add text and images below the main article content</p>
                      <ContentBlockEditor
                        blocks={parsedMoreContent || []}
                        onChange={(blocks) => {
                          const updatedArticle = {
                            ...article,
                            more_content: blocks as any
                          };
                          setArticle(updatedArticle);
                          // Register change with EditMode context to enable save button
                          registerChange('more_content', JSON.stringify(blocks));
                        }}
                        folder="news"
                      />
                    </div>
                  </>
                  ) : (
                    <>
                      <div
                        className="prose prose-stone prose-lg max-w-none prose-p:mb-6 prose-p:leading-[1.75] prose-p:text-[17px] prose-headings:font-light prose-headings:tracking-wide prose-headings:mb-4 prose-h2:text-3xl prose-h2:mt-10 prose-h2:mb-6 prose-h3:text-2xl prose-h3:mt-8 prose-h3:mb-4 prose-strong:font-medium prose-a:text-stone-700 prose-a:underline-offset-4 prose-ul:my-6 prose-ol:my-6 prose-li:my-2 prose-li:leading-relaxed prose-blockquote:my-8 prose-blockquote:pl-6 prose-blockquote:border-l-4 prose-blockquote:border-stone-300 prose-blockquote:italic prose-hr:my-10"
                        dangerouslySetInnerHTML={{ __html: sanitizeHTML(processedContent || article.main_content || article.content || '') }}
                      />

                      {/* More Content Blocks */}
                      {parsedMoreContent && parsedMoreContent.length > 0 && (
                    <div className="mt-8 space-y-8">
                      {parsedMoreContent.map((block, index) => {
                        if (block.type === 'text' && block.text) {
                          return (
                            <div
                              key={`text-${index}`}
                              className="prose prose-stone prose-lg max-w-none prose-p:mb-6 prose-p:leading-[1.75] prose-p:text-[17px]"
                              dangerouslySetInnerHTML={{ __html: sanitizeHTML(block.text) }}
                            />
                          );
                        }
                        
                        if (block.type === 'image' && block.photo && Array.isArray(block.photo)) {
                          return (
                            <div key={`image-${index}`} className="space-y-6">
                              {block.photo.map((img: { url: string; caption?: string }, imgIndex: number) => (
                                <figure key={`photo-${index}-${imgIndex}`} className="not-prose">
                                  <img
                                    src={img.url}
                                    alt={img.caption || ''}
                                    className="w-full rounded-lg shadow-md"
                                  />
                                  {img.caption && (
                                    <figcaption className="mt-3 text-sm text-stone-600 max-w-2xl">
                                      {img.caption}
                                    </figcaption>
                                  )}
                                </figure>
                              ))}
                            </div>
                          );
                        }
                        
                        return null;
                      })}
                    </div>
                  )}
                    </>
                  )}
                </motion.div>
              </div>
            </Container>
          </Section>

          {/* Mentions Section */}
          {(mentions.manufacturers.length > 0 || mentions.products.length > 0 || user) && (
            <Section background="custom" customBackground="bg-warm-beige">
              <Container size="6xl">
                <div className="max-w-4xl mx-auto">
                  <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                    <h3 className="text-2xl font-light text-stone-900 tracking-wide">Featured in this article</h3>
                    {user && (
                      <button
                        onClick={() => refreshMentions()}
                        disabled={isRefreshingMentions}
                        className="inline-flex items-center justify-center rounded-full border border-stone-300 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-stone-700 transition-colors duration-200 hover:bg-white disabled:cursor-not-allowed disabled:opacity-60"
                      >
                        {isRefreshingMentions ? 'Refreshing…' : 'Refresh mentions'}
                      </button>
                    )}
                  </div>
                  {mentionsError && (
                    <p className="mb-4 text-sm text-red-500">{mentionsError}</p>
                  )}
                  
                  {mentions.manufacturers.length === 0 && mentions.products.length === 0 ? (
                    <p className="text-sm text-stone-500">
                      No mentions detected yet. Refresh after editing to pull in linked manufacturers and products.
                    </p>
                  ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {mentions.manufacturers.length > 0 && (
                      <div>
                        <h4 className="text-sm font-medium text-stone-600 uppercase tracking-wider mb-4">Manufacturers</h4>
                        <div className="space-y-2">
                          {mentions.manufacturers.map((manufacturer) => (
                            <Link
                              key={manufacturer.slug}
                              href={`/manufacturers/${manufacturer.slug}`}
                                className="flex items-center gap-3 rounded-lg bg-white p-3 hover:shadow-md transition-shadow duration-300"
                            >
                                <div className="h-12 w-12 rounded-full bg-stone-100 flex items-center justify-center overflow-hidden">
                                  {manufacturer.logo ? (
                                    <Image
                                      src={getImageUrl(manufacturer.logo)}
                                      alt={`${manufacturer.name} logo`}
                                      width={48}
                                      height={48}
                                      className="h-12 w-12 object-contain"
                                    />
                                  ) : (
                                    <span className="text-sm font-semibold text-stone-500">
                                      {manufacturer.name.charAt(0)}
                                    </span>
                                  )}
                                </div>
                                <div className="flex-1">
                                  <p className="text-stone-900 font-medium">{manufacturer.name}</p>
                                  <p className="text-stone-500 text-sm">
                                    {manufacturer.count} mention{manufacturer.count > 1 ? 's' : ''}
                                  </p>
                                </div>
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}

                    {mentions.products.length > 0 && (
                      <div>
                        <h4 className="text-sm font-medium text-stone-600 uppercase tracking-wider mb-4">Products</h4>
                        <div className="space-y-2">
                          {mentions.products.map((product) => (
                            <Link
                              key={product.slug}
                              href={`/products/${product.slug}`}
                                className="flex items-center gap-4 rounded-2xl bg-white p-4 hover:shadow-lg transition-shadow duration-300 border border-stone-100"
                              >
                                <div className="h-20 w-28 rounded-2xl bg-stone-100 flex items-center justify-center overflow-hidden">
                                  {product.heroImage ? (
                                    <Image
                                      src={getImageUrl(product.heroImage)}
                                      alt={product.title}
                                      width={160}
                                      height={120}
                                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                                    />
                                  ) : (
                                    <span className="text-sm font-semibold text-stone-500">
                                      {product.title.charAt(0)}
                                    </span>
                                  )}
                                </div>
                                <div className="flex-1 space-y-1">
                                  <div className="flex flex-wrap items-center gap-2 text-xs font-medium uppercase tracking-[0.2em] text-stone-500">
                                    {product.manufacturerName && <span>{product.manufacturerName}</span>}
                                    {product.manufacturerName && product.categoryName && <span className="text-stone-300">•</span>}
                                    {product.categoryName && <span className="tracking-[0.15em] text-stone-400">{product.categoryName}</span>}
                                  </div>
                                  <p className="text-lg font-semibold text-stone-900 leading-tight">
                                    {product.title}
                                  </p>
                                  <div className="flex items-center justify-between text-sm text-stone-500">
                                    <span className="font-medium text-stone-800">
                                      {formatProductPrice(product.price, product.showPrice)}
                                    </span>
                                    <span>
                                      {product.count} mention{product.count > 1 ? 's' : ''}
                                    </span>
                                  </div>
                                </div>
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  )}
                </div>
              </Container>
            </Section>
          )}

          {/* Article Navigation */}
          {!isNewArticle && (adjacentArticles.previous || adjacentArticles.next) && (
            <Section background="custom" customBackground="bg-warm-beige" className="border-t border-amber-200/30">
              <Container size="6xl">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                  className="grid grid-cols-1 md:grid-cols-2 gap-8"
                >
                  {/* Previous Article */}
                  {adjacentArticles.previous && (
                    <Link
                      href={`/news/${adjacentArticles.previous.slug || slugify(adjacentArticles.previous.title)}`}
                      className="group block bg-warm-white rounded-xl transition-all duration-300 overflow-hidden hover:bg-stone-50"
                    >
                      <div className="flex flex-col md:flex-row h-full">
                        {/* Image */}
                        <div className="md:w-1/3 relative overflow-hidden h-48 md:h-auto md:min-h-[200px]">
                          {adjacentArticles.previous.image ? (
                            <Image
                              src={getImageUrl(adjacentArticles.previous.image)}
                              alt={adjacentArticles.previous.title}
                              fill
                              className="object-cover transition-transform duration-300 group-hover:scale-105"
                              sizes="(max-width: 768px) 100vw, 33vw"
                            />
                          ) : (
                            <div className="w-full h-full bg-gradient-to-br from-stone-100 to-stone-200 flex items-center justify-center">
                              <svg className="h-12 w-12 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                              </svg>
                            </div>
                          )}
                        </div>
                        
                        {/* Content */}
                        <div className="md:w-2/3 p-6 flex flex-col justify-between">
                          <div className="space-y-4">
                            <div className="flex items-center text-xs text-stone-500 font-medium tracking-wider uppercase">
                              <svg className="w-3 h-3 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                              </svg>
                              Previous Article
                            </div>
                            
                            {adjacentArticles.previous.news_date && (
                              <div className="relative pl-4">
                                <div className="text-xs text-stone-500 font-medium tracking-[0.15em] uppercase">
                                  {new Date(adjacentArticles.previous.news_date).toLocaleDateString('en-US', {
                                    year: 'numeric',
                                    month: 'short',
                                    day: 'numeric'
                                  })}
                                </div>
                                <div className="absolute left-0 top-0 bottom-0 w-1 bg-amber-400 rounded-full"></div>
                              </div>
                            )}
                            
                            <h3 className="text-lg font-light text-stone-900 line-clamp-2 group-hover:text-stone-700 transition-colors tracking-wide leading-tight">
                              {adjacentArticles.previous.title}
                            </h3>
                            
                            {(adjacentArticles.previous.summary || adjacentArticles.previous.brief_description) && (
                              <p className="text-stone-600 text-sm line-clamp-2 leading-relaxed font-light">
                                {adjacentArticles.previous.summary || adjacentArticles.previous.brief_description}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    </Link>
                  )}

                  {/* Next Article */}
                  {adjacentArticles.next && (
                    <Link
                      href={`/news/${adjacentArticles.next.slug || slugify(adjacentArticles.next.title)}`}
                      className="group block bg-warm-white rounded-xl transition-all duration-300 overflow-hidden hover:bg-stone-50"
                    >
                      <div className="flex flex-col md:flex-row h-full">
                        {/* Image */}
                        <div className="md:w-1/3 relative overflow-hidden h-48 md:h-auto md:min-h-[200px]">
                          {adjacentArticles.next.image ? (
                            <Image
                              src={getImageUrl(adjacentArticles.next.image)}
                              alt={adjacentArticles.next.title}
                              fill
                              className="object-cover transition-transform duration-300 group-hover:scale-105"
                              sizes="(max-width: 768px) 100vw, 33vw"
                            />
                          ) : (
                            <div className="w-full h-full bg-gradient-to-br from-stone-100 to-stone-200 flex items-center justify-center">
                              <svg className="h-12 w-12 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                              </svg>
                            </div>
                          )}
                        </div>
                        
                        {/* Content */}
                        <div className="md:w-2/3 p-6 flex flex-col justify-between">
                          <div className="space-y-4">
                            <div className="flex items-center text-xs text-stone-500 font-medium tracking-wider uppercase">
                              Next Article
                              <svg className="w-3 h-3 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                              </svg>
                            </div>
                            
                            {adjacentArticles.next.news_date && (
                              <div className="relative pl-4">
                                <div className="text-xs text-stone-500 font-medium tracking-[0.15em] uppercase">
                                  {new Date(adjacentArticles.next.news_date).toLocaleDateString('en-US', {
                                    year: 'numeric',
                                    month: 'short',
                                    day: 'numeric'
                                  })}
                                </div>
                                <div className="absolute left-0 top-0 bottom-0 w-1 bg-amber-400 rounded-full"></div>
                              </div>
                            )}
                            
                            <h3 className="text-lg font-light text-stone-900 line-clamp-2 group-hover:text-stone-700 transition-colors tracking-wide leading-tight">
                              {adjacentArticles.next.title}
                            </h3>
                            
                            {(adjacentArticles.next.summary || adjacentArticles.next.brief_description) && (
                              <p className="text-stone-600 text-sm line-clamp-2 leading-relaxed font-light">
                                {adjacentArticles.next.summary || adjacentArticles.next.brief_description}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    </Link>
                  )}
                </motion.div>
              </Container>
            </Section>
          )}

          {/* Back to News Link */}
          <Section background="custom" customBackground="bg-warm-cream">
            <Container size="6xl">
              <div className="max-w-4xl mx-auto text-center">
                <Link
                  href="/news"
                  className="inline-flex items-center text-stone-600 hover:text-stone-900 font-medium transition-colors duration-300 tracking-wide"
                >
                  <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                  Back to All News
                </Link>
              </div>
            </Container>
          </Section>

          {/* Image Modal */}
          {isImageModalOpen && selectedImage && (
            <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50" onClick={closeImageModal}>
              <div className="relative w-full h-full max-w-4xl p-4 flex items-center justify-center">
                <div className="relative w-full h-full">
                  <Image
                    src={getImageUrl(selectedImage)}
                    alt={article.title}
                    fill
                    className="object-contain"
                    sizes="100vw"
                    quality={95}
                  />
                </div>
                <button
                  onClick={closeImageModal}
                  className="absolute top-4 right-4 text-white hover:text-gray-300"
                >
                  <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
          )}

          {/* Delete Confirmation Modal */}
          {!isNewArticle && (
            <DeleteConfirmation
              isOpen={isDeleteModalOpen}
              onClose={() => setIsDeleteModalOpen(false)}
              onConfirm={handleDelete}
              title="Delete Article"
              message={`Are you sure you want to delete "${article.title}"? This action cannot be undone.`}
              loading={deleteLoading}
            />
          )}
          </main>
        </div>

        {/* Footer */}
        <FooterWithSignIn />
      </motion.div>
    </PageLoadReveal>
  );
}

