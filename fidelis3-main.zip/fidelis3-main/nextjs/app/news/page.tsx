import React from 'react';
import { getNews } from '../../lib/supabase-queries';
import { Header } from '../../components/Header';
import { FooterWithSignIn } from '../../components/FooterWithSignIn';
import { NewsListClient } from './NewsListClient';
import type { Metadata } from 'next';

// Revalidate every hour (3600 seconds) - on-demand revalidation handles updates
export const revalidate = 3600;

export const metadata: Metadata = {
  title: 'News & Events | Fidelis',
  description: 'Stay updated with the latest news, events, and product releases from Fidelis.',
};

export default async function NewsPage() {
  // Fetch news data at build time (for SEO and initial load)
  const news = await getNews();

  return (
    <div className="min-h-screen pt-24 footer-scroll-reveal">
      <div className="relative z-10 bg-warm-white">
        <Header />
        
        <main id="main-content">
          <NewsListClient initialNews={news} />
        </main>
      </div>
      
      <FooterWithSignIn />
    </div>
  );
}
