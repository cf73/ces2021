'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '../../contexts/AuthContext';
import { getNews } from '../../lib/supabase-queries';
import type { News } from '../../lib/supabase';
import { Section, Container } from '../../components/ui';
import { NewsCard } from '../../components/ui/Card';
import { slugify } from '../../lib/utils';
import { EditBar } from '../../components/cms/EditBar';

interface NewsListClientProps {
  initialNews: News[];
}

export function NewsListClient({ initialNews }: NewsListClientProps) {
  const { user } = useAuth();
  const [news, setNews] = useState<News[]>(initialNews);
  const [subscribeEmail, setSubscribeEmail] = useState('');
  const [subscribeStatus, setSubscribeStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [subscribeError, setSubscribeError] = useState('');

  // Refresh data when in CMS mode
  useEffect(() => {
    if (user) {
      const refreshNews = async () => {
        try {
          const data = await getNews();
          setNews(data);
        } catch (error) {
          console.error('Error refreshing news:', error);
        }
      };
      refreshNews();
    }
  }, [user]);

  const handleSubscribe = async () => {
    const email = subscribeEmail.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
      setSubscribeStatus('error');
      setSubscribeError('Please enter a valid email address.');
      return;
    }

    setSubscribeStatus('submitting');
    setSubscribeError('');

    try {
      const response = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, source: 'news-sidebar' }),
      });

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || 'Failed to subscribe. Please try again.');
      }

      setSubscribeStatus('success');
      setSubscribeEmail('');
    } catch (err) {
      console.error('Newsletter signup error:', err);
      setSubscribeStatus('error');
      setSubscribeError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    }
  };

  return (
    <>
      {/* CMS Widget with Create New Functionality */}
      {user && (
        <EditBar
          createNewHref="/news/new"
          createNewLabel="Create Article"
        />
      )}
      {/* Hero Section */}
      <Section variant="hero" background="custom" customBackground="bg-warm-beige" className="-mt-4">
        <Container size="6xl">
          <div className="max-w-4xl">
            <h1 className="text-4xl lg:text-5xl xl:text-6xl font-light text-stone-900 leading-tight tracking-wide mb-6">News & Updates</h1>
            <div className="prose prose-stone prose-lg max-w-none text-stone-700 leading-relaxed">
              <p>
                New gear arrivals, listening events, and insights from decades in high-end audio. We share what we think matters—no fluff, just what's worth your time.
              </p>
            </div>
          </div>
        </Container>
      </Section>

      {/* Two Column Layout: News Grid + Newsletter */}
      <Section variant="default" background="custom" customBackground="bg-[#fffcf9]">
        <Container size="6xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Main News Grid */}
            <div className="lg:col-span-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {news.map((article) => (
                  <Link key={article.id} href={`/news/${article.slug || slugify(article.title)}`} className="block h-full">
                    <NewsCard article={article} className="h-full" />
                  </Link>
                ))}
              </div>
            </div>

            {/* Newsletter Signup Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-32">
                <div className="bg-warm-white rounded-xl p-6 border border-amber-200/30">
                  <div className="flex items-center mb-4">
                    <div className="bg-warm-white pr-4">
                      <span className="text-sm font-medium text-stone-700 tracking-wider uppercase">Stay Updated</span>
                    </div>
                    <div className="flex-grow border-t border-stone-300"></div>
                  </div>
                  <p className="text-stone-600 text-sm leading-relaxed mb-6">
                    Get updates when we receive new shipments, host listening sessions, or have insights worth sharing.
                  </p>
                  <div className="space-y-3">
                    <input
                      type="email"
                      placeholder="Enter your email"
                      value={subscribeEmail}
                      onChange={(e) => {
                        setSubscribeEmail(e.target.value);
                        if (subscribeStatus !== 'idle') {
                          setSubscribeStatus('idle');
                          setSubscribeError('');
                        }
                      }}
                      className="w-full px-4 py-3 bg-white border border-stone-300 rounded-lg text-stone-900 placeholder-stone-500 focus:outline-none focus:ring-2 focus:ring-stone-500 focus:border-stone-500 transition-all duration-300"
                    />
                    <button
                      className="w-full px-6 py-3 bg-stone-900 hover:bg-stone-800 text-white font-medium rounded-lg transition-all duration-300 disabled:opacity-60"
                      disabled={subscribeStatus === 'submitting'}
                      onClick={handleSubscribe}
                    >
                      {subscribeStatus === 'submitting' ? 'Submitting...' : 'Keep Me Posted'}
                    </button>
                    {subscribeStatus === 'success' && (
                      <p className="text-sm text-emerald-700">Thanks—you're on the list.</p>
                    )}
                    {subscribeStatus === 'error' && subscribeError && (
                      <p className="text-sm text-red-600">{subscribeError}</p>
                    )}
                  </div>
                  <p className="text-xs text-stone-500 mt-3">
                    We respect your privacy. Unsubscribe anytime.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Container>
      </Section>
    </>
  );
}
