import { MetadataRoute } from 'next';
import { getAllProducts, getNews, getPreOwned, getManufacturers } from '../lib/supabase-queries';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = 'https://fidelisav.com';
  
  try {
    // Fetch all content
    const [products, news, preOwned, manufacturers] = await Promise.all([
      getAllProducts(),
      getNews(),
      getPreOwned(),
      getManufacturers()
    ]);

    // Static pages
    const staticPages = [
      {
        url: baseUrl,
        lastModified: new Date(),
        changeFrequency: 'weekly' as const,
        priority: 1,
      },
      {
        url: `${baseUrl}/about`,
        lastModified: new Date(),
        changeFrequency: 'monthly' as const,
        priority: 0.8,
      },
      {
        url: `${baseUrl}/contact`,
        lastModified: new Date(),
        changeFrequency: 'monthly' as const,
        priority: 0.8,
      },
      {
        url: `${baseUrl}/products`,
        lastModified: new Date(),
        changeFrequency: 'weekly' as const,
        priority: 0.9,
      },
      {
        url: `${baseUrl}/products/list`,
        lastModified: new Date(),
        changeFrequency: 'weekly' as const,
        priority: 0.9,
      },
      {
        url: `${baseUrl}/news`,
        lastModified: new Date(),
        changeFrequency: 'weekly' as const,
        priority: 0.8,
      },
      {
        url: `${baseUrl}/pre-owned`,
        lastModified: new Date(),
        changeFrequency: 'daily' as const,
        priority: 0.9,
      },
      {
        url: `${baseUrl}/manufacturers`,
        lastModified: new Date(),
        changeFrequency: 'monthly' as const,
        priority: 0.8,
      },
    ];

    // Product pages
    const productPages = products.map((product) => ({
      url: `${baseUrl}/products/${product.slug}`,
      lastModified: new Date(product.updated_at || product.created_at),
      changeFrequency: 'weekly' as const,
      priority: 0.8,
    }));

    // News pages
    const newsPages = news.map((article) => ({
      url: `${baseUrl}/news/${article.slug}`,
      lastModified: new Date(article.updated_at || article.created_at),
      changeFrequency: 'monthly' as const,
      priority: 0.6,
    }));

    // Pre-owned pages
    const preOwnedPages = preOwned.map((item) => ({
      url: `${baseUrl}/pre-owned/${item.slug || item.id}`,
      lastModified: new Date(item.updated_at || item.created_at),
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    }));

    // Manufacturer pages
    const manufacturerPages = manufacturers.map((manufacturer) => ({
      url: `${baseUrl}/manufacturers/${manufacturer.slug}`,
      changeFrequency: 'monthly' as const,
      priority: 0.7,
    }));

    return [
      ...staticPages,
      ...productPages,
      ...newsPages,
      ...preOwnedPages,
      ...manufacturerPages,
    ];
  } catch (error) {
    console.error('Error generating sitemap:', error);
    // Return minimal sitemap on error
    return [
      {
        url: baseUrl,
        lastModified: new Date(),
        changeFrequency: 'weekly',
        priority: 1,
      },
    ];
  }
}

