'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '../../contexts/AuthContext';
import { getProductCategories, getProductsWithCategories } from '../../lib/supabase-queries';
import type { ProductCategory, Product } from '../../lib/supabase';
import { Section, Container, CategoryCard } from '../../components/ui';
import { Header } from '../../components/Header';
import { FooterWithSignIn } from '../../components/FooterWithSignIn';
import { PageLoadReveal } from '../../components/PageLoadReveal';
import { EditBar } from '../../components/cms/EditBar';

interface CategoryWithHero extends ProductCategory {
  heroImage?: string;
  productCount?: number;
}

export default function ProductsPage() {
  const { user } = useAuth();
  const [categories, setCategories] = useState<CategoryWithHero[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadCategories = async () => {
      try {
        const [categoriesData, productsData] = await Promise.all([
          getProductCategories(),
          getProductsWithCategories(),
        ]);

        // Enhance categories with hero images and product counts
        const enhancedCategories = categoriesData.map(category => {
          const categoryProducts = productsData.filter(product =>
            product.categories?.id === category.id
          );

          let heroProduct = null;

          if (category.hero_product_id) {
            heroProduct = categoryProducts.find(
              product => product.id === category.hero_product_id && product.product_hero_image
            ) || null;
          }

          if (!heroProduct) {
            heroProduct = categoryProducts.find(product => product.product_hero_image) || null;
          }

          return {
            ...category,
            heroImage: heroProduct?.product_hero_image,
            productCount: categoryProducts.length,
          };
        });

        setCategories(enhancedCategories);
      } catch (error) {
        console.error('Error loading categories:', error);
      } finally {
        setLoading(false);
      }
    };

    loadCategories();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-warm-cream pt-24 footer-scroll-reveal">
        <div className="relative z-10 bg-warm-cream">
          <Header />
          <div className="flex items-center justify-center py-20">
            <Container>
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-stone-600 mx-auto"></div>
                <p className="mt-4 text-stone-600">Loading categories...</p>
              </div>
            </Container>
          </div>
        </div>
        <FooterWithSignIn />
      </div>
    );
  }

  return (
    <>
      <PageLoadReveal isLoading={loading} minimumLoadTime={200} maxWaitTime={3000}>
        <div className="min-h-screen bg-warm-cream pt-24 footer-scroll-reveal">
        <div className="relative z-10 bg-warm-cream">
          <Header />
          {user && (
            <EditBar
              createNewHref="/products/new?returnTo=/products"
              createNewLabel="Add Product"
            />
          )}
        
        <main id="main-content">
        {/* Hero Section */}
        <Section variant="hero" background="custom" customBackground="bg-warm-beige" className="-mt-4">
          <Container size="6xl">
            <div className="max-w-4xl">
              <h1 className="text-4xl lg:text-5xl xl:text-6xl font-light text-stone-900 leading-tight tracking-wide mb-6">Product Categories</h1>
              <div className="prose prose-stone prose-lg max-w-none text-stone-700 leading-relaxed">
                <p className="mb-6">
                  We organize our inventory by component type to help you find what you need. Each category represents decades of experience in what works and what doesn't.
                </p>
                <p>
                  Whether you're starting fresh or upgrading specific components, these categories reflect how we think about building great audio systems.
                </p>
              </div>
            </div>
          </Container>
        </Section>

        {/* Categories Grid - refined layout */}
        <Section variant="default" background="custom" customBackground="bg-[#fffcf9]">
          <Container size="6xl">
            <div className="grid gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {categories.map((category) => (
                <Link
                  key={category.id}
                  href={`/products/list?category=${category.id}`}
                  className="block h-full"
                >
                  <CategoryCard category={category} className="h-full" />
                </Link>
              ))}
            </div>

          </Container>
        </Section>

        {/* Consultation CTA */}
        <Section variant="default" background="custom" customBackground="bg-warm-beige">
          <Container size="6xl">
            <div className="text-center space-y-4">
              <p className="text-xs font-semibold uppercase tracking-[0.35em] text-stone-500">
                Need a second set of ears?
              </p>
              <h2 className="text-3xl font-light text-stone-900">
                Want help building a new system or refining what you already own?
              </h2>
              <p className="text-base text-stone-600 max-w-3xl mx-auto">
                Tell us where you’re starting and we’ll map out next steps—fresh builds, thoughtful upgrades, or a full-system rethink.
              </p>
              <Link
                href="/contact"
                className="inline-flex items-center justify-center rounded-full border border-stone-900 px-8 py-3 text-sm font-semibold uppercase tracking-[0.25em] text-stone-900 transition-colors duration-200 hover:bg-stone-900 hover:text-white"
              >
                Contact Us
              </Link>
            </div>
          </Container>
        </Section>
        </main>
      </div>
      
        </div>
      </PageLoadReveal>
      <FooterWithSignIn />
    </>
  );
}
