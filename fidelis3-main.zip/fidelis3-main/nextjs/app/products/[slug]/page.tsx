import { Metadata } from 'next';
import { Suspense } from 'react';
import { notFound } from 'next/navigation';
import { getProductBySlug, getAllProducts } from '../../../lib/supabase-queries';
import { ensureProductRelationships } from '../../../lib/generate-relationships-server';
import ProductDetailClient from './ProductDetailClient';

// Enable ISR with 1 hour revalidation - on-demand revalidation handles updates
export const revalidate = 3600;

// Pre-render all product pages at build time
export async function generateStaticParams() {
  try {
    const products = await getAllProducts();
    return products.map((product) => ({
      slug: product.slug,
    }));
  } catch (error) {
    console.error('Error generating static params for products:', error);
    return [];
  }
}

// Generate metadata for SEO
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;

  if (slug === 'new') {
    return {
      title: 'New Product | Fidelis AV',
      description: 'Create a new product.',
    };
  }
  try {
    const product = await getProductBySlug(slug, false); // Don't include unpublished for SEO
    
    if (!product) {
      return {
        title: 'Product Not Found | Fidelis AV',
      };
    }

    return {
      title: `${product.title} ${product.manufacturer?.name ? `by ${product.manufacturer.name}` : ''} | Fidelis AV`,
      description: product.brief_description || `${product.title} - High-end audio equipment available at Fidelis AV`,
      openGraph: {
        title: product.title,
        description: product.brief_description || '',
        images: product.product_hero_image ? [
          {
            url: product.product_hero_image,
            width: 1200,
            height: 630,
            alt: product.title,
          },
        ] : [],
      },
      twitter: {
        card: 'summary_large_image',
        title: product.title,
        description: product.brief_description || `${product.title} - High-end audio equipment`,
        images: product.product_hero_image ? [product.product_hero_image] : [],
      },
    };
  } catch (error) {
    console.error('Error generating metadata:', error);
    return {
      title: 'Product | Fidelis AV',
    };
  }
}

// Server Component - fetches initial data for ISR
export default async function ProductDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams?: Promise<Record<string, string | undefined>>;
}) {
  const [{ slug }, search] = await Promise.all([
    params,
    searchParams || Promise.resolve({} as Record<string, string | undefined>),
  ]);
  const initialManufacturerId = search?.manufacturer;
  const initialCategoryId = search?.category;
  const preview = search?.preview === '1';
  try {
    if (slug === 'new') {
      return (
        <Suspense fallback={null}>
          <ProductDetailClient
            initialProduct={null}
            slug={slug}
            initialManufacturerId={initialManufacturerId}
            initialCategoryId={initialCategoryId}
          />
        </Suspense>
      );
    }
    // Fetch initial product data server-side (published products only for SEO)
    const initialProduct = await getProductBySlug(slug, preview);
    
    if (!initialProduct) {
      notFound();
    }

    // AI generation now handled by batch script (npm run generate-relationships)
    // This ensures full catalog access and controlled rate limiting
    // Auto-generation disabled to prevent rate limit errors
    
    // Uncomment below to re-enable on-demand generation (not recommended due to rate limits):
    /*
    console.log(`🚀 Triggering background AI generation for ${initialProduct.title}`);
    getAllProducts().then(allProducts => {
      ensureProductRelationships(initialProduct, allProducts).catch(err => {
        console.error('Background AI generation failed:', err);
      });
    });
    */

    // Pass initial data to client component immediately
    return (
      <Suspense fallback={null}>
        <ProductDetailClient
          initialProduct={initialProduct}
          slug={slug}
          initialManufacturerId={initialManufacturerId}
          initialCategoryId={initialCategoryId}
        />
      </Suspense>
    );
  } catch (error) {
    console.error('Error loading product:', error);
    notFound();
  }
}
