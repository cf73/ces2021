'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { useAuth } from '../../../contexts/AuthContext';
import { useEditMode } from '../../../contexts/EditModeContext';
import { getProductBySlug, deleteProduct, getProductsByIds, getImageUrl, getManufacturers, getProductCategories } from '../../../lib/supabase-queries';
import { supabase } from '../../../lib/supabase';
import type { Product, Manufacturer, ProductCategory, ProductTopology, ProductAmplifierClass } from '../../../lib/supabase';
import { generateBlurDataURL } from '../../../lib/image-loader';
import { EditBar } from '../../../components/cms/EditBar';
import { SEOModal } from '../../../components/cms/SEOModal';
import { EditableText } from '../../../components/cms/EditableText';
import { EditableTextarea } from '../../../components/cms/EditableTextarea';
import { EditableNumber } from '../../../components/cms/EditableNumber';
import { EditableCheckbox } from '../../../components/cms/EditableCheckbox';
import { EditableToggle } from '../../../components/cms/EditableToggle';
import { EditableSelect } from '../../../components/cms/EditableSelect';
import { EditableImage } from '../../../components/cms/EditableImage';
import { ProductSearchModal } from '../../../components/cms/ProductSearchModal';
import { DeleteConfirmation } from '../../../components/DeleteConfirmation';
import { ProductTabs, hasTabContent } from '../../../components/ProductTabs';
import { ProductCard } from '../../../components/ui/Card';
import { Button } from '../../../components/ui/Button';
import { Header } from '../../../components/Header';
import { FooterWithSignIn } from '../../../components/FooterWithSignIn';
import { ReasoningDisplay } from '../../../components/ReasoningDisplay';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import { getRandomMusicalMessage } from '../../../utils/musicalLoadingMessages';
import { PageLoadReveal } from '../../../components/PageLoadReveal';
import { StructuredData } from '../../../components/StructuredData';
import { generateProductSchema, generateBreadcrumbSchema } from '../../../lib/structured-data';
import { formatReasoningText } from '../../../lib/format-reasoning-text';
import { slugify } from '../../../lib/utils';
import { TradeInModal } from '../../../components/TradeInModal';
import { getAuthHeaders } from '../../../lib/auth-headers';

interface ProductDetailClientProps {
  initialProduct: Product | null;
  slug: string;
  initialManufacturerId?: string;
  initialCategoryId?: string;
}

type RelationshipCopyState = {
  needsRegeneration: boolean;
  hasManualEdits: boolean;
};

type RelationshipSectionsToRefresh = {
  pairs: boolean;
  also: boolean;
};

const TOPOLOGY_OPTIONS: Array<{ value: ProductTopology; label: string }> = [
  { value: 'tube', label: 'Tube' },
  { value: 'solid_state', label: 'Solid State' },
  { value: 'hybrid', label: 'Hybrid' },
];

const AMPLIFIER_CLASS_OPTIONS: Array<{ value: ProductAmplifierClass; label: string }> = [
  { value: 'class_a', label: 'Class A' },
  { value: 'class_ab', label: 'Class AB' },
  { value: 'class_d', label: 'Class D' },
  { value: 'class_g', label: 'Class G' },
  { value: 'class_h', label: 'Class H' },
];

const AMPLIFIER_CATEGORY_SLUGS = new Set([
  'integrated-amplifiers',
  'power-amplifiers',
  'pre-amps',
  'phonostage',
  'headphone-amplifiers',
]);

const isAmplifierCategory = (category?: Pick<ProductCategory, 'slug'> | null) =>
  Boolean(category?.slug && AMPLIFIER_CATEGORY_SLUGS.has(category.slug));

const getOptionLabel = <T extends string>(
  options: Array<{ value: T; label: string }>,
  value?: T | null
) => options.find(option => option.value === value)?.label;

const normalizeRelationshipNotes = (notes?: Record<string, string> | null) => {
  if (!notes || typeof notes !== 'object') return {};

  return Object.entries(notes).reduce<Record<string, string>>((acc, [id, value]) => {
    if (typeof value !== 'string') return acc;
    const note = value.replace(/\s+/g, ' ');
    if (note.trim()) acc[id] = note;
    return acc;
  }, {});
};

const pruneRelationshipNotes = (
  notes: Record<string, string>,
  selectedIds: string[]
) => selectedIds.reduce<Record<string, string>>((acc, id) => {
  if (notes[id]) acc[id] = notes[id];
  return acc;
}, {});

const normalizeReasoningField = (text?: string | null): string => {
  if (!text) return '';
  if (text.includes('\n')) {
    return text.trim();
  }
  const formatted = formatReasoningText(text);
  if (formatted.sentences.length > 0) {
    return formatted.sentences.join('\n');
  }
  return text.trim();
};

const withNormalizedReasoning = (product: Product | null): Product | null => {
  if (!product) return product;
  return {
    ...product,
    pairs_reasoning: normalizeReasoningField(product.pairs_reasoning),
    also_reasoning: normalizeReasoningField(product.also_reasoning)
  };
};

export default function ProductDetailClient({ initialProduct, slug, initialManufacturerId, initialCategoryId }: ProductDetailClientProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user } = useAuth();
  const { isEditMode, getChanges, clearChanges, setIsSaving, setOriginalValues, registerChange, enableEditMode } = useEditMode();
  const [product, setProduct] = useState<Product | null>(withNormalizedReasoning(initialProduct));
  const [pairsWellWithProducts, setPairsWellWithProducts] = useState<Product[]>([]);
  const [alsoConsiderProducts, setAlsoConsiderProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('Loading product...');
  const [relatedLoading, setRelatedLoading] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [editBarKey, setEditBarKey] = useState(0);
  const [manufacturers, setManufacturers] = useState<Manufacturer[]>([]);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [showPairsModal, setShowPairsModal] = useState(false);
  const [showAlsoModal, setShowAlsoModal] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [aiGenerationError, setAiGenerationError] = useState<string | null>(null);
  const [isSEOModalOpen, setIsSEOModalOpen] = useState(false);
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);
  const [aiSuccessData, setAiSuccessData] = useState<{
    goodSynergies: number;
    alsoConsider: number;
    timestamp: string;
  } | null>(null);
  const [overlayCountdown, setOverlayCountdown] = useState<{ pairs: number | null; also: number | null }>({
    pairs: null,
    also: null
  });
  const [pairsCopyState, setPairsCopyState] = useState<RelationshipCopyState>({
    needsRegeneration: false,
    hasManualEdits: false
  });
  const [alsoCopyState, setAlsoCopyState] = useState<RelationshipCopyState>({
    needsRegeneration: false,
    hasManualEdits: false
  });
  const [regeneratingSection, setRegeneratingSection] = useState<'pairs' | 'also' | null>(null);
  const [isRefreshingCopyForSave, setIsRefreshingCopyForSave] = useState(false);
  const [relationshipErrors, setRelationshipErrors] = useState<{ pairs?: string; also?: string }>({});
  const [isPairsManualEditing, setIsPairsManualEditing] = useState(false);
  const [isAlsoManualEditing, setIsAlsoManualEditing] = useState(false);
  const isNewProduct = slug === 'new';
  const prefillManufacturerId = searchParams?.get('manufacturer') || initialManufacturerId;
  const prefillCategoryId = searchParams?.get('category') || initialCategoryId;
  const returnToParam = searchParams?.get('returnTo');
  const fallbackReturnTo = returnToParam ? decodeURIComponent(returnToParam) : '/products';

  const pendingChanges = getChanges();
  const showPriceToggle = (pendingChanges.show_price ?? product?.show_price ?? false);
  const homeDemoAvailable = (pendingChanges.available_for_demo ?? product?.available_for_demo ?? false);
  const specialOrderLeadTime = pendingChanges.special_order_lead_time ?? product?.special_order_lead_time ?? '';
  const currentPairsList = (pendingChanges.pairs_well_with ?? product?.pairs_well_with ?? []) as string[];
  const currentAlsoList = (pendingChanges.also_consider ?? product?.also_consider ?? []) as string[];
  const pairsNotesValue = pruneRelationshipNotes(
    normalizeRelationshipNotes((pendingChanges.pairs_notes ?? product?.pairs_notes ?? {}) as Record<string, string>),
    currentPairsList
  );
  const alsoNotesValue = pruneRelationshipNotes(
    normalizeRelationshipNotes((pendingChanges.also_notes ?? product?.also_notes ?? {}) as Record<string, string>),
    currentAlsoList
  );
  const pairsReasoningValue = pendingChanges.pairs_reasoning ?? product?.pairs_reasoning ?? '';
  const pairsCTAValue = pendingChanges.pairs_cta ?? product?.pairs_cta ?? '';
  const pairsHelperValue = pendingChanges.pairs_helper ?? product?.pairs_helper ?? '';
  const alsoReasoningValue = pendingChanges.also_reasoning ?? product?.also_reasoning ?? '';
  const alsoCTAValue = pendingChanges.also_cta ?? product?.also_cta ?? '';
  const alsoHelperValue = pendingChanges.also_helper ?? product?.also_helper ?? '';
  const selectedCategoryId = pendingChanges.category_id ?? product?.category_id;
  const selectedCategory = categories.find(c => c.id === selectedCategoryId) || (
    selectedCategoryId === product?.category_id ? product?.categories : undefined
  );
  const isAmplifierProduct = isAmplifierCategory(selectedCategory);
  const topologyValue = (pendingChanges.topology ?? product?.topology ?? null) as ProductTopology | null;
  const amplifierClassValue = (pendingChanges.amplifier_class ?? product?.amplifier_class ?? null) as ProductAmplifierClass | null;
  const topologyLabel = getOptionLabel(TOPOLOGY_OPTIONS, topologyValue);
  const amplifierClassLabel = getOptionLabel(AMPLIFIER_CLASS_OPTIONS, amplifierClassValue);
  const topologyFilterHref = selectedCategoryId && topologyValue
    ? `/products/list?category=${selectedCategoryId}&topology=${topologyValue}`
    : undefined;
  const amplifierClassFilterHref = selectedCategoryId && amplifierClassValue
    ? `/products/list?category=${selectedCategoryId}&amplifier_class=${amplifierClassValue}`
    : undefined;

  useEffect(() => {
    // Reset regeneration state when product changes
    // Don't auto-detect missing copy as that would trigger for migrated Statamic products
    // Regeneration state should only be set when user manually changes products in edit mode
    setPairsCopyState({
      needsRegeneration: false,
      hasManualEdits: false
    });
    setAlsoCopyState({
      needsRegeneration: false,
      hasManualEdits: false
    });
    setRelationshipErrors({});
  }, [product?.id, product?.updated_at]);

  useEffect(() => {
    if (!isEditMode) {
      setIsPairsManualEditing(false);
      setIsAlsoManualEditing(false);
    }
  }, [isEditMode]);

  // Initialize blank product when creating new
  useEffect(() => {
    if (!isNewProduct || product) return;
    const empty: Product = {
      id: 'new',
      title: '',
      slug: '',
      brief_description: '',
      description: '',
      specs: '',
      content: '',
      price: 0,
      show_price: true,
      available_for_demo: false,
      available_to_buy_online: false,
      product_hero_image: '',
      product_gallery: [],
      reivews_set: [],
      manufacturer_id: prefillManufacturerId || null,
      category_id: prefillCategoryId || null,
      product_categories: prefillCategoryId ? [prefillCategoryId] : [],
      topology: null,
      amplifier_class: null,
      pairs_well_with: [],
      also_consider: [],
      pairs_notes: {},
      also_notes: {},
      published: true,
      system_category: 'source',
      created_at: '',
      updated_at: '',
    } as Product;
    setProduct(empty);
    enableEditMode();
  }, [isNewProduct, product, prefillCategoryId, prefillManufacturerId, enableEditMode]);

  // Handler for demo availability toggle - updates both fields
  const handleDemoToggle = (value: boolean) => {
    registerChange('available_for_demo', value);
    registerChange('local_only', !value);
  };

  // Handler for AI generation
  const handleGenerateAI = async () => {
    if (!product) return;
    
    setIsGeneratingAI(true);
    setAiGenerationError(null);
    setAiSuccessData(null); // Clear any previous success message
    
    try {
      // Call the API route in dry-run mode to generate suggestions without saving
      const authHeaders = await getAuthHeaders();
      const response = await fetch('/api/generate-product-relationships', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders,
        },
        body: JSON.stringify({
          productId: product.id,
          dryRun: true, // Generate without saving - changes will be tracked
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to generate AI suggestions');
      }

      const data = await response.json();
      
      if (!data.success || !data.preview) {
        throw new Error('Failed to generate AI suggestions');
      }

      const preview = data.preview;
      
      // Update local product state with AI-generated content
      const updatedProduct = {
        ...product,
        pairs_well_with: preview.pairs_well_with,
        also_consider: preview.also_consider,
        pairs_notes: preview.pairs_notes ?? {},
        also_notes: preview.also_notes ?? {},
        pairs_reasoning: preview.pairs_reasoning,
        pairs_cta: preview.pairs_cta,
        pairs_helper: preview.pairs_helper,
        also_reasoning: preview.also_reasoning,
        also_cta: preview.also_cta,
        also_helper: preview.also_helper,
        ...(preview.brief_description && { brief_description: preview.brief_description }),
        ...(preview.quote && { quote: preview.quote }),
        ...(preview.quote_attribution && { quote_attribution: preview.quote_attribution }),
      };
      
      setProduct(withNormalizedReasoning(updatedProduct));
      
      // Register all changes in EditModeContext so they're tracked and can be saved/cancelled
      registerChange('pairs_well_with', preview.pairs_well_with);
      registerChange('also_consider', preview.also_consider);
      registerChange('pairs_notes', preview.pairs_notes ?? {});
      registerChange('also_notes', preview.also_notes ?? {});
      registerChange('pairs_reasoning', preview.pairs_reasoning);
      registerChange('pairs_cta', preview.pairs_cta);
      registerChange('pairs_helper', preview.pairs_helper);
      registerChange('also_reasoning', preview.also_reasoning);
      registerChange('also_cta', preview.also_cta);
      registerChange('also_helper', preview.also_helper);
      if (preview.brief_description) {
        registerChange('brief_description', preview.brief_description);
      }
      if (preview.quote) {
        registerChange('quote', preview.quote);
      }
      if (preview.quote_attribution) {
        registerChange('quote_attribution', preview.quote_attribution);
      }
      
      // Load the actual product objects for the generated relationships so they display immediately
      setRelatedLoading(true);
      try {
        if (preview.pairs_well_with && preview.pairs_well_with.length > 0) {
          const pairsProducts = await getProductsByIds(preview.pairs_well_with);
          setPairsWellWithProducts(pairsProducts);
        } else {
          setPairsWellWithProducts([]);
        }
        
        if (preview.also_consider && preview.also_consider.length > 0) {
          const alsoProducts = await getProductsByIds(preview.also_consider);
          setAlsoConsiderProducts(alsoProducts);
        } else {
          setAlsoConsiderProducts([]);
        }
      } catch (error) {
        console.error('Error loading generated products:', error);
      } finally {
        setRelatedLoading(false);
      }
      
      // Set success data with counts and timestamp
      setAiSuccessData({
        goodSynergies: preview.pairs_well_with?.length || 0,
        alsoConsider: preview.also_consider?.length || 0,
        timestamp: new Date().toLocaleString()
      });
      setPairsCopyState({ needsRegeneration: false, hasManualEdits: false });
      setAlsoCopyState({ needsRegeneration: false, hasManualEdits: false });
      setRelationshipErrors({});

      // Auto-clear success message after 10 seconds
      setTimeout(() => setAiSuccessData(null), 10000);
      
    } catch (error) {
      console.error('Error generating AI suggestions:', error);
      setAiGenerationError(error instanceof Error ? error.message : 'Failed to generate AI suggestions');
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const loadProduct = async () => {
    if (!slug) return;
    
    try {
      setLoading(true);
      // Include unpublished products when user is authenticated (for editing)
      const productData = await getProductBySlug(slug, !!user);
      if (productData) {
        // Auto-repair garbled content if detected
        if (productData.content && typeof productData.content === 'string') {
          try {
            const parsed = JSON.parse(productData.content);
            // Check if it's double-stringified
            if (typeof parsed === 'string') {
              const doubleParsed = JSON.parse(parsed);
              console.log('🔧 Detected and auto-repairing double-stringified content');
              // Update in database
              await supabase
                .from('products')
                .update({ content: doubleParsed })
                .eq('id', productData.id);
              // Update local state with repaired content
              productData.content = doubleParsed;
            }
          } catch (e) {
            // Not JSON or not double-stringified, ignore
          }
        }
        
        setEditBarKey(prev => prev + 1);
        setProduct(withNormalizedReasoning(productData));
      }
      
      // Load cross-referenced products
      if (productData) {
        setRelatedLoading(true);
        
        // Load pairs_well_with products
        if (productData.pairs_well_with && productData.pairs_well_with.length > 0) {
          const pairsProducts = await getProductsByIds(productData.pairs_well_with);
          setPairsWellWithProducts(pairsProducts);
        }
        
        // Load also_consider products
        if (productData.also_consider && productData.also_consider.length > 0) {
          const alsoProducts = await getProductsByIds(productData.also_consider);
          setAlsoConsiderProducts(alsoProducts);
        }
        
        setRelatedLoading(false);
      }
    } catch (error) {
      console.error('Error loading product:', error);
    } finally {
      setLoading(false);
    }
  };

  // When edit mode is toggled, refetch fresh data from Supabase and set original values
  useEffect(() => {
    if (isEditMode && product) {
      // Set original values for comparison
      setOriginalValues({
        title: product.title,
        brief_description: product.brief_description,
        content: product.content,
        quote: product.quote,
        quote_attribution: product.quote_attribution,
        specs: product.specs,
        price: product.price,
        show_price: product.show_price,
        special_order_lead_time: product.special_order_lead_time,
        available_for_demo: product.available_for_demo,
        available_to_buy_online: product.available_to_buy_online,
        local_only: product.local_only,
        featured: product.featured,
        product_hero_image: product.product_hero_image,
        product_gallery: product.product_gallery,
        manufacturer_id: product.manufacturer_id,
        category_id: product.category_id,
        topology: product.topology,
        amplifier_class: product.amplifier_class,
        pairs_well_with: product.pairs_well_with,
        also_consider: product.also_consider,
        pairs_notes: product.pairs_notes,
        also_notes: product.also_notes,
        pairs_reasoning: product.pairs_reasoning,
        pairs_cta: product.pairs_cta,
        pairs_helper: product.pairs_helper,
        also_reasoning: product.also_reasoning,
        also_cta: product.also_cta,
        also_helper: product.also_helper,
        reivews_set: product.reivews_set
      });
      loadProduct();
    }
  }, [isEditMode]);

  // Countdown for regenerate overlay (20s)
  useEffect(() => {
    const anyActive = overlayCountdown.pairs !== null || overlayCountdown.also !== null;
    if (!anyActive) return;
    const timer = setInterval(() => {
      setOverlayCountdown(prev => ({
        pairs: prev.pairs !== null && prev.pairs > 0 ? prev.pairs - 1 : prev.pairs,
        also: prev.also !== null && prev.also > 0 ? prev.also - 1 : prev.also
      }));
    }, 1000);
    return () => clearInterval(timer);
  }, [overlayCountdown.pairs, overlayCountdown.also]);

  // Load related products on mount
  useEffect(() => {
    if (initialProduct) {
      setRelatedLoading(true);
      
      const loadRelated = async () => {
        try {
          // Load pairs_well_with products
          if (initialProduct.pairs_well_with && initialProduct.pairs_well_with.length > 0) {
            console.log('🔍 Loading pairs_well_with products:', initialProduct.pairs_well_with);
            const pairsProducts = await getProductsByIds(initialProduct.pairs_well_with);
            console.log('✅ Loaded pairs products:', pairsProducts.length);
            setPairsWellWithProducts(pairsProducts);
          }
          
          // Load also_consider products
          if (initialProduct.also_consider && initialProduct.also_consider.length > 0) {
            console.log('🔍 Loading also_consider products:', initialProduct.also_consider);
            const alsoProducts = await getProductsByIds(initialProduct.also_consider);
            console.log('✅ Loaded also products:', alsoProducts.length);
            setAlsoConsiderProducts(alsoProducts);
          }
        } catch (error) {
          console.error('❌ Error loading related products:', error);
        } finally {
          setRelatedLoading(false);
        }
      };
      
      loadRelated();
    }
  }, [initialProduct?.id]);

  // Set random loading message on client side only to avoid hydration mismatch
  useEffect(() => {
    setLoadingMessage(getRandomMusicalMessage());
  }, []);



  // Load manufacturers and categories for dropdowns
  useEffect(() => {
    const loadOptions = async () => {
      const [manufacturersData, categoriesData] = await Promise.all([
        getManufacturers(true),
        getProductCategories()
      ]);
      setManufacturers(manufacturersData);
      setCategories(categoriesData);
    };
    loadOptions();
  }, []);

  const getRelationshipSectionsNeedingCopy = (): RelationshipSectionsToRefresh => ({
    pairs: currentPairsList.length > 0 && (
      pairsCopyState.needsRegeneration ||
      !pairsReasoningValue?.trim() ||
      !pairsCTAValue?.trim() ||
      !pairsHelperValue?.trim()
    ),
    also: currentAlsoList.length > 0 && (
      alsoCopyState.needsRegeneration ||
      !alsoReasoningValue?.trim() ||
      !alsoCTAValue?.trim() ||
      !alsoHelperValue?.trim()
    )
  });

  const requestRelationshipCopyPreview = async (
    sections: RelationshipSectionsToRefresh
  ) => {
    if (!product) {
      throw new Error('Missing product.');
    }

    const authHeaders = await getAuthHeaders();
    const response = await fetch('/api/generate-product-relationships', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders },
      body: JSON.stringify({
        productId: product.id,
        dryRun: true,
        regenerateTextOnly: true,
        sections,
        overrides: {
          pairs_well_with: currentPairsList,
          also_consider: currentAlsoList
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to regenerate copy');
    }

    const data = await response.json();
    if (!data.preview) {
      throw new Error('Missing response payload');
    }

    return data.preview;
  };

  const applyRelationshipCopyPreview = (
    preview: Partial<Product>,
    sections: RelationshipSectionsToRefresh
  ): Partial<Product> => {
    const nextChanges: Partial<Product> = {};

    if (sections.pairs) {
      if (preview.pairs_notes !== undefined) {
        nextChanges.pairs_notes = preview.pairs_notes;
      }
      if (preview.pairs_reasoning !== undefined) {
        nextChanges.pairs_reasoning = preview.pairs_reasoning;
      }
      if (preview.pairs_cta !== undefined) {
        nextChanges.pairs_cta = preview.pairs_cta;
      }
      if (preview.pairs_helper !== undefined) {
        nextChanges.pairs_helper = preview.pairs_helper;
      }
    }

    if (sections.also) {
      if (preview.also_notes !== undefined) {
        nextChanges.also_notes = preview.also_notes;
      }
      if (preview.also_reasoning !== undefined) {
        nextChanges.also_reasoning = preview.also_reasoning;
      }
      if (preview.also_cta !== undefined) {
        nextChanges.also_cta = preview.also_cta;
      }
      if (preview.also_helper !== undefined) {
        nextChanges.also_helper = preview.also_helper;
      }
    }

    Object.entries(nextChanges).forEach(([field, value]) => {
      registerChange(field, value);
    });

    setProduct(prev => {
      if (!prev) return prev;
      return withNormalizedReasoning({ ...prev, ...nextChanges });
    });

    if (sections.pairs) {
      setPairsCopyState({
        hasManualEdits: false,
        needsRegeneration: false
      });
    }

    if (sections.also) {
      setAlsoCopyState({
        hasManualEdits: false,
        needsRegeneration: false
      });
    }

    return nextChanges;
  };

  const handleSave = async () => {
    if (!product) return;

    setIsSaving(true);
    try {
      let changes = getChanges();
      const sectionsNeedingCopy = getRelationshipSectionsNeedingCopy();
      const shouldRefreshCopyBeforeSave =
        !isNewProduct && (sectionsNeedingCopy.pairs || sectionsNeedingCopy.also);

      if (shouldRefreshCopyBeforeSave) {
        setIsRefreshingCopyForSave(true);
        setOverlayCountdown({
          pairs: sectionsNeedingCopy.pairs ? 20 : null,
          also: sectionsNeedingCopy.also ? 20 : null
        });

        const preview = await requestRelationshipCopyPreview(sectionsNeedingCopy);
        const copyChanges = applyRelationshipCopyPreview(preview, sectionsNeedingCopy);
        changes = { ...changes, ...copyChanges };
        setRelationshipErrors(prev => ({
          ...prev,
          ...(sectionsNeedingCopy.pairs ? { pairs: undefined } : {}),
          ...(sectionsNeedingCopy.also ? { also: undefined } : {})
        }));
      }

      if (!validateRelationshipCopy(changes, shouldRefreshCopyBeforeSave)) {
        alert(
          isNewProduct
            ? 'Save this product once before generating relationship copy.'
            : 'Please complete the summary & handoff text before saving.'
        );
        return;
      }

      console.log('🔍 Current product before save:', {
        id: product.id,
        title: product.title,
        slug: product.slug,
        published: product.published
      });

      if (Object.keys(changes).length === 0 && !isNewProduct) {
        console.log('No changes to save');
        setIsSaving(false);
        return;
      }

      console.log('💾 Changes to save:', changes);
      console.log('🔍 Product ID being updated:', product.id);

      // Check authentication
      const { data: { user } } = await supabase.auth.getUser();
      console.log('👤 Current user:', user?.email || 'Not authenticated');

      // Sanitize content field if it exists (prevent double-stringification)
      if (changes.content) {
        // If content is a string that looks like JSON, parse it back to JSON
        if (typeof changes.content === 'string') {
          try {
            const parsed = JSON.parse(changes.content);
            changes.content = parsed; // Store as JSON object
            console.log('✅ Parsed content from string to JSON object');
          } catch (e) {
            // If it's not valid JSON, keep as-is (plain text/HTML)
            console.log('ℹ️ Content is plain text/HTML, not JSON - keeping as-is');
          }
        }
      }

      // If title changed, also update slug
      if (changes.title && changes.title !== product.title) {
        changes.slug = slugify(changes.title);
        console.log('🔄 Also updating slug to:', changes.slug);
      }

      // Add updated_at timestamp
      changes.updated_at = new Date().toISOString();

      if (isNewProduct) {
        const manufacturerId = changes.manufacturer_id ?? product.manufacturer_id ?? null;
        const categoryId = changes.category_id ?? product.category_id ?? null;

        if (!manufacturerId || !categoryId) {
          alert('Please select both a manufacturer and a category before saving.');
          setIsSaving(false);
          return;
        }

        const nameForSlug = changes.title || product.title || 'New Product';
        const newSlug = changes.slug || slugify(nameForSlug);
        const productCategories =
          (changes as any).product_categories ?? (product as any).product_categories ?? [];
        const normalizedProductCategories =
          Array.isArray(productCategories) && productCategories.length > 0
            ? productCategories
            : categoryId
              ? [categoryId]
              : [];

        const dataToInsert = {
          title: nameForSlug,
          slug: newSlug,
          brief_description: changes.brief_description ?? product.brief_description ?? '',
          content: changes.content ?? product.content ?? '',
          specs: changes.specs ?? product.specs ?? '',
          price: changes.price ?? product.price ?? null,
          show_price: changes.show_price ?? product.show_price ?? true,
          special_order_lead_time: changes.special_order_lead_time ?? product.special_order_lead_time ?? null,
          available_for_demo: changes.available_for_demo ?? product.available_for_demo ?? false,
          available_to_buy_online: changes.available_to_buy_online ?? product.available_to_buy_online ?? false,
          product_hero_image: changes.product_hero_image ?? product.product_hero_image ?? '',
          product_gallery: changes.product_gallery ?? product.product_gallery ?? [],
          manufacturer_id: manufacturerId,
          category_id: categoryId,
          topology: changes.topology ?? product.topology ?? null,
          amplifier_class: changes.amplifier_class ?? product.amplifier_class ?? null,
          product_categories: normalizedProductCategories,
          pairs_well_with: changes.pairs_well_with ?? [],
          also_consider: changes.also_consider ?? [],
          pairs_notes: changes.pairs_notes ?? product.pairs_notes ?? {},
          also_notes: changes.also_notes ?? product.also_notes ?? {},
          pairs_reasoning: changes.pairs_reasoning ?? '',
          pairs_cta: changes.pairs_cta ?? '',
          pairs_helper: changes.pairs_helper ?? '',
          also_reasoning: changes.also_reasoning ?? '',
          also_cta: changes.also_cta ?? '',
          also_helper: changes.also_helper ?? '',
          published: changes.published ?? true,
          system_category: (changes as any).system_category ?? (product as any).system_category ?? 'source',
          quote: changes.quote ?? product.quote ?? null,
          quote_attribution: changes.quote_attribution ?? product.quote_attribution ?? null,
          reivews_set: changes.reivews_set ?? product.reivews_set ?? null,
        };

        const { data: insertData, error: insertError } = await supabase
          .from('products')
          .insert([dataToInsert])
          .select(`
            *,
            categories:product_categories!products_category_id_fkey(id, name, slug),
            manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
          `)
          .single();

        if (insertError) {
          console.error('❌ Error creating product:', insertError);
          alert(insertError.message || 'Failed to create product. Please try again.');
          setIsSaving(false);
          return;
        }

        if (!insertData) {
          console.error('❌ Insert returned no data for new product');
          alert('Product was not created. Please try again.');
          setIsSaving(false);
          return;
        }

        setProduct(withNormalizedReasoning(insertData));
        clearChanges();
        setPairsCopyState({ needsRegeneration: false, hasManualEdits: false });
        setAlsoCopyState({ needsRegeneration: false, hasManualEdits: false });
        setRelationshipErrors({});
        // Navigate with preview flag so unpublished new products can be viewed immediately
        router.push(`/products/${insertData.slug}?preview=1`);
        setIsSaving(false);
        return;
      }

      // Update product in Supabase
      const { data: updateData, error: updateError } = await supabase
        .from('products')
        .update(changes)
        .eq('id', product.id)
        .select();

      console.log('📝 Update response:', { data: updateData, error: updateError });

      if (updateError) {
        console.error('❌ Error saving product:', updateError);
        alert('Failed to save changes. Please try again.');
        return;
      }

      if (!updateData || updateData.length === 0) {
        console.error('❌ Update returned no data - product may not exist or no changes were made');
        alert('Failed to update product. Please refresh and try again.');
        return;
      }

      console.log('✅ Product updated successfully in database:', updateData[0]);
      
      // Small delay to ensure Supabase has propagated the change
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Reload product data by ID (not slug, in case title/slug changed)
      const { data: updatedProduct, error: reloadError } = await supabase
        .from('products')
        .select(`
          *,
          categories:product_categories!products_category_id_fkey(id, name, slug),
          manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
        `)
        .eq('id', product.id)
        .gte('updated_at', new Date(0).toISOString()) // Cache buster
        .single();
      
      if (reloadError) {
        console.error('Error reloading product:', reloadError);
      } else if (updatedProduct) {
        console.log('📦 Reloaded product after save:', {
          id: updatedProduct.id,
          title: updatedProduct.title,
          slug: updatedProduct.slug,
          published: updatedProduct.published
        });
        // Force component re-render with new key
        setEditBarKey(prev => prev + 1);
        setProduct(withNormalizedReasoning(updatedProduct));
      }
      
      // Clear changes
      clearChanges();
      setPairsCopyState({ needsRegeneration: false, hasManualEdits: false });
      setAlsoCopyState({ needsRegeneration: false, hasManualEdits: false });
      setRelationshipErrors({});
      
      console.log('✅ Product saved successfully');
    } catch (error) {
      console.error('Error saving product:', error);
      alert('Failed to save changes. Please try again.');
    } finally {
      setIsRefreshingCopyForSave(false);
      setOverlayCountdown({
        pairs: null,
        also: null
      });
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    if (isNewProduct) {
      clearChanges();
      setPairsCopyState({ needsRegeneration: false, hasManualEdits: false });
      setAlsoCopyState({ needsRegeneration: false, hasManualEdits: false });
      setRelationshipErrors({});
      router.push(fallbackReturnTo);
      return;
    }

    // Reload product to discard changes
    if (slug) {
      loadProduct();
    }
    clearChanges();
    setPairsCopyState({ needsRegeneration: false, hasManualEdits: false });
    setAlsoCopyState({ needsRegeneration: false, hasManualEdits: false });
    setRelationshipErrors({});
  };

  const handleTogglePublish = async (published: boolean) => {
    if (!product) return;
    
    // For new/unsaved products, just track the change locally
    if (isNewProduct || !product.id) {
      console.log('🔄 Tracking publish status change locally for new product:', published);
      registerChange('published', published);
      setProduct({ ...product, published });
      return;
    }
    
    try {
      console.log('🔄 Toggling publish status to:', published, 'for product ID:', product.id);
      
      // Update published status in Supabase
      const { data: updateResult, error } = await supabase
        .from('products')
        .update({ published })
        .eq('id', product.id)
        .select();
      
      console.log('📝 Update result:', updateResult);
      
      if (error) {
        console.error('Error updating publish status:', error);
        alert('Failed to update publish status. Please try again.');
        return;
      }
      
      // Reload product data by ID
      const { data: updatedProduct, error: reloadError } = await supabase
        .from('products')
        .select(`
          *,
          categories:product_categories!products_category_id_fkey(id, name, slug),
          manufacturer:manufacturers!products_manufacturer_id_fkey(id, name, slug)
        `)
        .eq('id', product.id)
        .single();
      
      if (reloadError) {
        console.error('Error reloading product:', reloadError);
      } else if (updatedProduct) {
        console.log(`✅ Product ${published ? 'published' : 'unpublished'} successfully`);
        setProduct(withNormalizedReasoning(updatedProduct));
      }
    } catch (error) {
      console.error('Error toggling publish status:', error);
      alert('Failed to update publish status. Please try again.');
    }
  };

  const handleDelete = async () => {
    if (!product) return;
    
    setDeleteLoading(true);
    try {
      const authHeaders = await getAuthHeaders();
      const response = await fetch(`/api/products/${product.id}`, {
        method: 'DELETE',
        headers: authHeaders,
      });
      if (!response.ok) {
        const data = await response.json().catch(() => null);
        throw new Error(data?.error || 'Failed to delete product.');
      }
      
      // Redirect to products page after successful deletion
      router.push('/products');
    } catch (error) {
      console.error('Error deleting product:', error);
      alert('Failed to delete product. Please try again.');
    } finally {
      setDeleteLoading(false);
      setIsDeleteModalOpen(false);
    }
  };

  const openImageModal = (imagePath: string) => {
    setSelectedImage(imagePath);
    setIsImageModalOpen(true);
  };

  const closeImageModal = () => {
    setIsImageModalOpen(false);
    setSelectedImage(null);
  };

  const handleRelationshipFieldChange = (
    section: 'pairs' | 'also',
    field: 'reasoning' | 'cta' | 'helper',
    value: string
  ) => {
    if (!product) return;
    const mapping =
      section === 'pairs'
        ? {
            reasoning: 'pairs_reasoning',
            cta: 'pairs_cta',
            helper: 'pairs_helper'
          }
        : {
            reasoning: 'also_reasoning',
            cta: 'also_cta',
            helper: 'also_helper'
          };
    const fieldName = mapping[field] as keyof Product;
    registerChange(fieldName as string, value);
    setProduct(prev => {
      if (!prev) return prev;
      const updated = { ...prev, [fieldName]: value };
      return withNormalizedReasoning(updated);
    });
    setRelationshipErrors(prev => ({ ...prev, [section]: undefined }));
    if (section === 'pairs') {
      setPairsCopyState({
        hasManualEdits: true,
        needsRegeneration: false
      });
    } else {
      setAlsoCopyState({
        hasManualEdits: true,
        needsRegeneration: false
      });
    }
  };

  const handleRelationshipNoteChange = (
    section: 'pairs' | 'also',
    productId: string,
    value: string
  ) => {
    if (!product) return;

    const isPairs = section === 'pairs';
    const fieldName = isPairs ? 'pairs_notes' : 'also_notes';
    const selectedIds = isPairs ? currentPairsList : currentAlsoList;
    const currentNotes = isPairs ? pairsNotesValue : alsoNotesValue;
    const nextNotes = pruneRelationshipNotes({
      ...currentNotes,
      [productId]: value,
    }, selectedIds);

    if (!value.trim()) {
      delete nextNotes[productId];
    }

    registerChange(fieldName, nextNotes);
    setProduct(prev => prev ? { ...prev, [fieldName]: nextNotes } : prev);

    if (isPairs) {
      setPairsCopyState(prev => ({ ...prev, hasManualEdits: true }));
    } else {
      setAlsoCopyState(prev => ({ ...prev, hasManualEdits: true }));
    }
  };

  const handleRegenerateSection = async (section: 'pairs' | 'also') => {
    if (!product) return;
    if (regeneratingSection) return;

    const selections =
      section === 'pairs' ? currentPairsList : currentAlsoList;
    if (selections.length === 0) {
      alert('Add products before generating summary text.');
      return;
    }

    // Check if the OTHER section also needs regeneration
    const otherSection = section === 'pairs' ? 'also' : 'pairs';
    const otherList = otherSection === 'pairs' ? currentPairsList : currentAlsoList;
    const otherReasoningValue = otherSection === 'pairs' ? pairsReasoningValue : alsoReasoningValue;
    const otherCTAValue = otherSection === 'pairs' ? pairsCTAValue : alsoCTAValue;
    const otherHelperValue = otherSection === 'pairs' ? pairsHelperValue : alsoHelperValue;
    const otherCopyState = otherSection === 'pairs' ? pairsCopyState : alsoCopyState;
    
    const otherNeedsText = otherList.length > 0 && (
      otherCopyState.needsRegeneration ||
      !otherReasoningValue?.trim() ||
      !otherCTAValue?.trim() ||
      !otherHelperValue?.trim()
    );

    // If both sections need text, regenerate both at once
    const regenerateBoth = otherNeedsText;

    setRegeneratingSection(section);
    if (regenerateBoth) {
      setOverlayCountdown({
        pairs: 20,
        also: 20
      });
      setRelationshipErrors({});
    } else {
      setOverlayCountdown(prev => ({
        ...prev,
        [section]: 20
      }));
      setRelationshipErrors(prev => ({ ...prev, [section]: undefined }));
    }

    try {
      const sectionsToRefresh = {
        pairs: regenerateBoth ? true : section === 'pairs',
        also: regenerateBoth ? true : section === 'also'
      };
      const preview = await requestRelationshipCopyPreview(sectionsToRefresh);
      applyRelationshipCopyPreview(preview, sectionsToRefresh);

      // Apply pairs text if regenerated
      if (regenerateBoth || section === 'pairs') {
        setPairsCopyState({
          hasManualEdits: false,
          needsRegeneration: false
        });
      }

      // Apply also text if regenerated
      if (regenerateBoth || section === 'also') {
        setAlsoCopyState({
          hasManualEdits: false,
          needsRegeneration: false
        });
      }
    } catch (error) {
      console.error('Error regenerating relationship copy:', error);
      alert(
        error instanceof Error
          ? error.message
          : 'Failed to regenerate relationship copy.'
      );
    } finally {
      setRegeneratingSection(null);
      if (regenerateBoth) {
        setOverlayCountdown({
          pairs: null,
          also: null
        });
      } else {
        setOverlayCountdown(prev => ({
          ...prev,
          [section]: null
        }));
      }
    }
  };

  const validateRelationshipCopy = (
    draftChanges: Record<string, any> = getChanges(),
    refreshedBeforeSave = false
  ) => {
    const errors: { pairs?: string; also?: string } = {};
    const draftPairsList = (draftChanges.pairs_well_with ?? currentPairsList) as string[];
    const draftAlsoList = (draftChanges.also_consider ?? currentAlsoList) as string[];
    const draftPairsReasoning = (draftChanges.pairs_reasoning ?? pairsReasoningValue) as string | undefined;
    const draftPairsCTA = (draftChanges.pairs_cta ?? pairsCTAValue) as string | undefined;
    const draftPairsHelper = (draftChanges.pairs_helper ?? pairsHelperValue) as string | undefined;
    const draftAlsoReasoning = (draftChanges.also_reasoning ?? alsoReasoningValue) as string | undefined;
    const draftAlsoCTA = (draftChanges.also_cta ?? alsoCTAValue) as string | undefined;
    const draftAlsoHelper = (draftChanges.also_helper ?? alsoHelperValue) as string | undefined;

    if (draftPairsList.length > 0) {
      if (pairsCopyState.needsRegeneration && !refreshedBeforeSave) {
        errors.pairs = isNewProduct
          ? 'Save this product once before generating relationship copy.'
          : 'Relationship copy will refresh before saving.';
      } else if (
        !draftPairsReasoning?.trim() ||
        !draftPairsCTA?.trim() ||
        !draftPairsHelper?.trim()
      ) {
        errors.pairs =
          'Add reasoning, CTA, and warm handoff text for these pairings.';
      }
    }
    if (draftAlsoList.length > 0) {
      if (alsoCopyState.needsRegeneration && !refreshedBeforeSave) {
        errors.also = isNewProduct
          ? 'Save this product once before generating relationship copy.'
          : 'Relationship copy will refresh before saving.';
      } else if (
        !draftAlsoReasoning?.trim() ||
        !draftAlsoCTA?.trim() ||
        !draftAlsoHelper?.trim()
      ) {
        errors.also =
          'Add reasoning, CTA, and warm handoff text for these alternatives.';
      }
    }
    setRelationshipErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const renderRelationshipCopySection = (section: 'pairs' | 'also') => {
    if (!product) return null;
    const state = section === 'pairs' ? pairsCopyState : alsoCopyState;
    const error = section === 'pairs' ? relationshipErrors.pairs : relationshipErrors.also;
    const reasoningValue = section === 'pairs' ? pairsReasoningValue : alsoReasoningValue;
    const ctaValue = section === 'pairs' ? pairsCTAValue : alsoCTAValue;
    const helperValue = section === 'pairs' ? pairsHelperValue : alsoHelperValue;
    const manualEditing = section === 'pairs' ? isPairsManualEditing : isAlsoManualEditing;
    const setManualEditing = section === 'pairs' ? setIsPairsManualEditing : setIsAlsoManualEditing;
    const hasSelections = section === 'pairs' ? currentPairsList.length > 0 : currentAlsoList.length > 0;
    const canEditText = hasSelections || Boolean(reasoningValue?.trim());
    const buttonLabel = regeneratingSection === section ? 'Generating…' : 'Sync summary & handoff';
    const buttonClasses = state.needsRegeneration
      ? 'border-amber-500 text-amber-700 hover:bg-amber-50'
      : 'border-stone-300 text-stone-700 hover:bg-white';
    const headingText = section === 'pairs' ? 'Why these pair well:' : 'Why these alternatives:';
    const ctaHref =
      section === 'pairs'
        ? `/contact?subject=${encodeURIComponent(`System Building Consultation: ${product.manufacturer?.name} ${product.title}`)}&message=${encodeURIComponent(`I'm interested in building a system around the ${product.manufacturer?.name} ${product.title}. I'd like to discuss these synergies and schedule a listening session to hear how these components work together.\n\nI'm particularly interested in:\n- ${pairsWellWithProducts.slice(0, 3).map(p => `${p.manufacturer?.name} ${p.title}`).join('\n- ')}\n\nPlease let me know what times work for a home demonstration or showroom visit.`)}`
        : `/contact?subject=${encodeURIComponent(`Product Selection Consultation: ${product.categories?.name}`)}&message=${encodeURIComponent(`I'm evaluating ${product.categories?.name?.toLowerCase()} and would appreciate guidance on the options available. I'm currently considering the ${product.manufacturer?.name} ${product.title}, along with:\n\n${alsoConsiderProducts.slice(0, 4).map(p => `- ${p.manufacturer?.name || ''} ${p.title}`).join('\n')}\n\nI'd like to discuss the differences between these options and schedule a listening session to hear them for myself.\n\nPlease let me know what times work for a home demonstration or showroom visit.`)}`;
    const ctaMessage = section === 'pairs' ? 'System Building Consultation' : 'Product Selection Consultation';
    const hasText = Boolean(reasoningValue?.trim() && ctaValue?.trim() && helperValue?.trim());
    const showDisplay = hasText && (!manualEditing || !isEditMode);

    const editor = (
      <div className="mt-16 pt-12">
        <div className="mb-8 text-center">
          <p className="text-sm font-semibold text-stone-600 uppercase tracking-[0.3em]">
            Refine These Recommendations
          </p>
        </div>
        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
          <div className="flex-[2]">
            <h3 className="text-xl font-semibold text-stone-900 mb-4">{headingText}</h3>
            {canEditText ? (
              <ul className="space-y-3">
                {(reasoningValue || '').split(/\n+/).filter(Boolean).map((line: string, idx: number) => (
                  <li key={`${section}-line-${idx}`} className="flex gap-3">
                    <span className="text-stone-400 mt-1.5">•</span>
                    <textarea
                      value={line}
                      onChange={e => {
                        const lines = (reasoningValue || '').split(/\n+/);
                        lines[idx] = e.target.value;
                        handleRelationshipFieldChange(section, 'reasoning', lines.join('\n'));
                      }}
                      className="flex-1 rounded-lg border border-stone-200 bg-white/95 px-3 py-3 text-sm leading-relaxed text-stone-700 outline-none transition-all focus:border-stone-400 min-h-[72px] resize-y"
                      rows={3}
                    />
                  </li>
                ))}
              </ul>
            ) : (
              <textarea
                value={reasoningValue || ''}
                onChange={e => handleRelationshipFieldChange(section, 'reasoning', e.target.value)}
                disabled
                className="w-full rounded-xl border border-stone-200 bg-white/70 px-4 py-4 text-base leading-relaxed text-stone-700 outline-none"
                rows={6}
              />
            )}
          </div>
          <div className="hidden lg:block w-px bg-stone-300 flex-shrink-0" />
          <div className="flex-[1]">
            <label className="text-sm font-medium text-stone-700">
              CTA heading
            </label>
            <input
              type="text"
              value={ctaValue || ''}
              onChange={e => handleRelationshipFieldChange(section, 'cta', e.target.value)}
              disabled={!canEditText}
              className="mt-2 w-full rounded-lg border border-stone-200 bg-white/90 px-3 py-2 text-sm text-stone-800 outline-none transition-all focus:border-stone-400 disabled:cursor-not-allowed disabled:bg-stone-100"
            />
            <label className="mt-4 block text-sm font-medium text-stone-700">
              Warm handoff text
            </label>
              <textarea
              value={helperValue || ''}
              onChange={e => handleRelationshipFieldChange(section, 'helper', e.target.value)}
              disabled={!canEditText}
                className="mt-2 w-full rounded-lg border border-stone-200 bg-white/90 px-3 py-3 text-sm text-stone-800 outline-none transition-all focus:border-stone-400 disabled:cursor-not-allowed disabled:bg-stone-100 min-h-[96px]"
                rows={4}
            />
          </div>
        </div>
      </div>
    );

    const showManualEditButton = isEditMode && manualEditing && hasText;
    const needsAction = isEditMode && state.needsRegeneration;
    const actionLabel = !hasText
      ? 'Generate summary & warm handoff text'
      : 'Regenerate text to match selected products';
    const isPairs = section === 'pairs';
    const idList = isPairs ? currentPairsList : currentAlsoList;
    const rawList = isPairs ? pairsWellWithProducts : alsoConsiderProducts;
    const notes = isPairs ? pairsNotesValue : alsoNotesValue;
    const list = rawList.filter(p => idList.includes(p.id));
    const hasVisibleNotes = list.some(relatedProduct => notes[relatedProduct.id]?.trim());
    const sectionEyebrow = isPairs ? 'System building' : 'Compare in session';
    const sectionTitle = isPairs
      ? `Perfect partners for ${product.manufacturer?.name ? `${product.manufacturer.name}'s ` : ''}${product.title}`
      : 'Alternatives worth hearing';
    const sectionDescription = isPairs
      ? "Components chosen to complement this product's role, tonal balance, and system context."
      : 'A focused audition shortlist for comparing character, fit, and presentation before you decide.';
    const navigationButtonClass = 'absolute -translate-y-1/2 z-20 bg-white/85 hover:bg-white text-stone-600 hover:text-stone-900 border border-stone-200/80 rounded-full w-9 h-9 flex items-center justify-center shadow-md hover:shadow-lg transition-all duration-200 [&.swiper-button-disabled]:opacity-0 [&.swiper-button-disabled]:pointer-events-none';
    const addSlide = (
      <SwiperSlide className="flex overflow-visible">
        <div className="flex w-full overflow-visible min-h-[344px] items-center justify-center">
          <button
            onClick={() => (isPairs ? setShowPairsModal(true) : setShowAlsoModal(true))}
            className="group mx-auto flex h-full w-[200px] flex-col items-center justify-center gap-3 text-stone-700 transition-all duration-200 hover:opacity-80 hover:scale-[1.02] cursor-pointer"
            aria-label={isPairs ? 'Add another product' : 'Add another alternative'}
            style={{ minHeight: '100%' }}
          >
            <span className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-dashed border-stone-300 text-stone-600 transition-transform duration-200 group-hover:scale-105">
              <svg className="h-5 w-5" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="1.5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m6-6H6" />
              </svg>
            </span>
            <span className="text-sm font-semibold">{isPairs ? 'Add Product' : 'Add Alternative'}</span>
          </button>
        </div>
      </SwiperSlide>
    );

    return (
      <>
        <div className="max-w-3xl mb-8 lg:mb-10">
          <p className="mb-3 text-xs font-semibold uppercase tracking-[0.24em] text-stone-500">
            {sectionEyebrow}
          </p>
          <h3 className="text-3xl lg:text-4xl font-light tracking-tight text-stone-900">
            {sectionTitle}
          </h3>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-stone-600">
            {sectionDescription}
          </p>
        </div>

        <div className="space-y-10 transition">
          <div className="relative">
            <div>
              {list.length > 0 || isEditMode ? (
                <div className="relative rounded-[2rem] border border-white/70 bg-white/35 px-4 py-6 shadow-sm sm:px-6 lg:px-8">
                  {isPairs ? (
                    <>
                      <Swiper
                        modules={[Navigation]}
                        spaceBetween={20}
                        slidesPerView={1.2}
                        navigation={{
                          nextEl: '.pairs-swiper-next',
                          prevEl: '.pairs-swiper-prev',
                        }}
                        breakpoints={{
                          640: { slidesPerView: 2 },
                          1024: { slidesPerView: 3 },
                        }}
                        className="pairing-swiper overflow-visible"
                      >
                        {list.map((relatedProduct: Product) => (
                          <SwiperSlide key={relatedProduct.id} className="flex h-auto overflow-visible">
                            <div className="relative flex h-full w-full flex-col overflow-visible rounded-[1.75rem] bg-white/55 p-3 shadow-sm ring-1 ring-white/70 transition-colors duration-200 hover:bg-white/75">
                              <Link href={`/products/${relatedProduct.slug}`} className="block w-full">
                                <ProductCard
                                  product={{
                                    id: relatedProduct.id,
                                    title: relatedProduct.title,
                                    slug: relatedProduct.slug,
                                    price: relatedProduct.price,
                                    show_price: relatedProduct.show_price,
                                    special_order_lead_time: relatedProduct.special_order_lead_time,
                                    manufacturer: relatedProduct.manufacturer,
                                    product_hero_image: relatedProduct.product_hero_image,
                                    categories: relatedProduct.categories,
                                    featured: relatedProduct.featured
                                  }}
                                  showCategory={true}
                                />
                              </Link>
                              {(isEditMode || hasVisibleNotes) && (
                                <div className="mt-4 flex h-[7rem] items-center border-t border-stone-200/70 px-2 pt-4 text-center">
                                  {isEditMode ? (
                                    <textarea
                                      value={notes[relatedProduct.id] || ''}
                                      onChange={event => handleRelationshipNoteChange('pairs', relatedProduct.id, event.target.value)}
                                      placeholder="Why this partner belongs here..."
                                      rows={3}
                                      className="h-[5.5rem] w-full resize-none rounded-2xl border border-stone-200 bg-white/90 px-4 py-3 text-center text-sm leading-relaxed text-stone-700 shadow-inner outline-none transition-all placeholder:text-stone-400 focus:border-stone-400 focus:bg-white"
                                    />
                                  ) : (
                                    <p className={`mx-auto max-w-[18rem] text-sm font-medium leading-relaxed text-stone-700 line-clamp-3 ${notes[relatedProduct.id] ? '' : 'invisible'}`}>
                                      {notes[relatedProduct.id]}
                                    </p>
                                  )}
                                </div>
                              )}
                              {isEditMode && (
                                <button
                                  onClick={() => handleRemoveRelationship(relatedProduct.id, 'pairs')}
                                  className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-2 hover:bg-red-600 shadow-lg z-10"
                                  title="Remove"
                                >
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                  </svg>
                                </button>
                              )}
                            </div>
                          </SwiperSlide>
                        ))}
                        {isEditMode && addSlide}
                      </Swiper>
                      <button className={`pairs-swiper-prev -left-2 lg:-left-4 top-[45%] ${navigationButtonClass}`}>
                        <svg className="w-4 h-4" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M12.707 15.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 111.414 1.414L8.414 10l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd"/>
                        </svg>
                      </button>
                      <button className={`pairs-swiper-next -right-2 lg:-right-4 top-[45%] ${navigationButtonClass}`}>
                        <svg className="w-4 h-4" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M7.293 4.293a1 1 0 011.414 0l5 5a1 1 0 010 1.414l-5 5a1 1 0 11-1.414-1.414L11.586 10 7.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"/>
                        </svg>
                      </button>
                    </>
                  ) : (
                    <>
                      <Swiper
                        modules={[Navigation]}
                        spaceBetween={20}
                        slidesPerView={1.2}
                        navigation={{
                          nextEl: '.also-swiper-next',
                          prevEl: '.also-swiper-prev',
                        }}
                        breakpoints={{
                          640: { slidesPerView: 2 },
                          1024: { slidesPerView: 3 },
                        }}
                        className="also-swiper overflow-visible"
                      >
                        {list.map((relatedProduct: Product) => (
                          <SwiperSlide key={relatedProduct.id} className="flex h-auto overflow-visible">
                            <div className="relative flex h-full w-full flex-col overflow-visible rounded-[1.75rem] bg-white/55 p-3 shadow-sm ring-1 ring-white/70 transition-colors duration-200 hover:bg-white/75">
                              <Link href={`/products/${relatedProduct.slug}`} className="block w-full">
                                <ProductCard
                                  product={{
                                    id: relatedProduct.id,
                                    title: relatedProduct.title,
                                    slug: relatedProduct.slug,
                                    price: relatedProduct.price,
                                    show_price: relatedProduct.show_price,
                                    special_order_lead_time: relatedProduct.special_order_lead_time,
                                    manufacturer: relatedProduct.manufacturer,
                                    product_hero_image: relatedProduct.product_hero_image,
                                    categories: relatedProduct.categories,
                                    featured: relatedProduct.featured
                                  }}
                                  showCategory={true}
                                />
                              </Link>
                              {(isEditMode || hasVisibleNotes) && (
                                <div className="mt-4 flex h-[7rem] items-center border-t border-stone-200/70 px-2 pt-4 text-center">
                                  {isEditMode ? (
                                    <textarea
                                      value={notes[relatedProduct.id] || ''}
                                      onChange={event => handleRelationshipNoteChange('also', relatedProduct.id, event.target.value)}
                                      placeholder="What makes this alternative different..."
                                      rows={3}
                                      className="h-[5.5rem] w-full resize-none rounded-2xl border border-stone-200 bg-white/90 px-4 py-3 text-center text-sm leading-relaxed text-stone-700 shadow-inner outline-none transition-all placeholder:text-stone-400 focus:border-stone-400 focus:bg-white"
                                    />
                                  ) : (
                                    <p className={`mx-auto max-w-[18rem] text-sm font-medium leading-relaxed text-stone-700 line-clamp-3 ${notes[relatedProduct.id] ? '' : 'invisible'}`}>
                                      {notes[relatedProduct.id]}
                                    </p>
                                  )}
                                </div>
                              )}
                              {isEditMode && (
                                <button
                                  onClick={() => handleRemoveRelationship(relatedProduct.id, 'also')}
                                  className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-2 hover:bg-red-600 shadow-lg z-10"
                                  title="Remove"
                                >
                                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                  </svg>
                                </button>
                              )}
                            </div>
                          </SwiperSlide>
                        ))}
                        {isEditMode && addSlide}
                      </Swiper>
                      <button className={`also-swiper-prev -left-2 lg:-left-4 top-[45%] ${navigationButtonClass}`}>
                        <svg className="w-4 h-4" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M12.707 15.707a1 1 0 01-1.414 0l-5-5a1 1 0 010-1.414l5-5a1 1 0 111.414 1.414L8.414 10l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd"/>
                        </svg>
                      </button>
                      <button className={`also-swiper-next -right-2 lg:-right-4 top-[45%] ${navigationButtonClass}`}>
                        <svg className="w-4 h-4" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M7.293 4.293a1 1 0 011.414 0l5 5a1 1 0 010 1.414l-5 5a1 1 0 11-1.414-1.414L11.586 10 7.293 5.707a1 1 0 010-1.414z" clipRule="evenodd"/>
                        </svg>
                      </button>
                    </>
                  )}
                </div>
              ) : (
                <div className="text-center text-sm text-stone-500">
                  Add products to this section to see recommendations here.
                </div>
              )}
            </div>

            <div className="mt-8">
              {needsAction && (
                <div className="mb-6 flex justify-center">
                  <div
                    className="rounded-2xl border border-amber-200/80 bg-amber-50/80 px-5 py-4 flex flex-col items-center gap-2 max-w-md text-center shadow-sm"
                    style={{
                      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.7)'
                    }}
                  >
                    <p className="text-sm font-semibold text-amber-900">Products changed</p>
                    <p className="text-xs text-amber-800">Relationship text and card notes will refresh automatically when you save.</p>
                    <Button
                      onClick={() => handleRegenerateSection(section)}
                      variant="outline-bold"
                      size="sm"
                      disabled={regeneratingSection === section}
                    >
                      {regeneratingSection === section
                        ? `Regenerating…${overlayCountdown[section] !== null ? ` (${overlayCountdown[section]}s)` : ''}`
                        : `Refresh now${overlayCountdown[section] !== null ? ` (${overlayCountdown[section]}s)` : ''}`}
                    </Button>
                  </div>
                </div>
              )}
              {showDisplay && (
                <ReasoningDisplay
                  heading={headingText}
                  reasoning={reasoningValue}
                  cta={ctaValue || undefined}
                  helper={helperValue || undefined}
                  ctaHref={ctaHref}
                  ctaMessage={ctaMessage}
                  showHeader={false}
                />
              )}
            </div>
          </div>
        </div>

        {isEditMode && manualEditing && editor}
      </>
    );
  };

  const handleRemoveRelationship = async (productId: string, type: 'pairs' | 'also') => {
    if (!product) return;
    
    if (type === 'pairs') {
      const updated = currentPairsList.filter(id => id !== productId);
      const updatedNotes = pruneRelationshipNotes(pairsNotesValue, updated);
      registerChange('pairs_well_with', updated);
      registerChange('pairs_notes', updatedNotes);
      setProduct(prev => prev ? { ...prev, pairs_well_with: updated, pairs_notes: updatedNotes } : prev);
      const updatedProducts = pairsWellWithProducts.filter(p => p.id !== productId);
      setPairsWellWithProducts(updatedProducts);
      setPairsCopyState(prev => ({
        hasManualEdits: true,
        needsRegeneration: true
      }));
    } else {
      const updated = currentAlsoList.filter(id => id !== productId);
      const updatedNotes = pruneRelationshipNotes(alsoNotesValue, updated);
      registerChange('also_consider', updated);
      registerChange('also_notes', updatedNotes);
      setProduct(prev => prev ? { ...prev, also_consider: updated, also_notes: updatedNotes } : prev);
      const updatedProducts = alsoConsiderProducts.filter(p => p.id !== productId);
      setAlsoConsiderProducts(updatedProducts);
      setAlsoCopyState(prev => ({
        hasManualEdits: true,
        needsRegeneration: true
      }));
    }
  };

  const handleAddRelationship = async (productId: string, type: 'pairs' | 'also') => {
    if (!product) return;
    
    if (type === 'pairs') {
      if (currentPairsList.includes(productId)) return;
      const updated = [...currentPairsList, productId];
      registerChange('pairs_well_with', updated);
      registerChange('pairs_notes', pruneRelationshipNotes(pairsNotesValue, updated));
      setProduct(prev => prev ? { ...prev, pairs_well_with: updated, pairs_notes: pruneRelationshipNotes(pairsNotesValue, updated) } : prev);
      const products = await getProductsByIds([productId]);
      if (products.length > 0) {
        setPairsWellWithProducts([...pairsWellWithProducts, products[0]]);
      }
      setPairsCopyState(prev => ({
        hasManualEdits: true,
        needsRegeneration: true
      }));
    } else {
      if (currentAlsoList.includes(productId)) return;
      const updated = [...currentAlsoList, productId];
      registerChange('also_consider', updated);
      registerChange('also_notes', pruneRelationshipNotes(alsoNotesValue, updated));
      setProduct(prev => prev ? { ...prev, also_consider: updated, also_notes: pruneRelationshipNotes(alsoNotesValue, updated) } : prev);
      const products = await getProductsByIds([productId]);
      if (products.length > 0) {
        setAlsoConsiderProducts([...alsoConsiderProducts, products[0]]);
      }
      setAlsoCopyState(prev => ({
        hasManualEdits: true,
        needsRegeneration: true
      }));
    }
  };

  const formatPrice = (price?: number) => {
    if (!price) return null;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(price);
  };

  const getCallToActionButton = () => {
    if (!product) return null;
    
    if (homeDemoAvailable) {
      return (
        <>
          <Button
            href={`/contact?product=${encodeURIComponent(product.title)}&manufacturer=${encodeURIComponent(product.manufacturer?.name || '')}&demo=home`}
            variant="outline-bold"
            size="md"
            className="w-full sm:w-auto"
          >
            Home Demo
          </Button>
          <Button
            href={`/contact?product=${encodeURIComponent(product.title)}&manufacturer=${encodeURIComponent(product.manufacturer?.name || '')}&demo=store`}
            variant="primary"
            size="md"
            className="w-full sm:w-auto"
          >
            Store Demo
          </Button>
        </>
      );
    }
    
    // When home demo is not available, show only Store Demo
    return (
      <Button
        href={`/contact?product=${encodeURIComponent(product.title)}&manufacturer=${encodeURIComponent(product.manufacturer?.name || '')}&demo=store`}
        variant="primary"
        size="md"
        className="w-full sm:w-auto"
      >
        Store Demo
      </Button>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-warm-white">
        <Header />
        <div className="min-h-screen bg-warm-white py-12">
          <div className="container-custom text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">{loadingMessage}</p>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-warm-white">
        <Header />
        <div className="min-h-screen bg-warm-white py-12">
          <div className="container-custom text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h1>
            <p className="text-gray-600 mb-6">The product you're looking for doesn't exist.</p>
            <Link href="/products" className="btn-primary">
              Back to Products
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Generate structured data for SEO
  const productSchema = product ? generateProductSchema(product, product.manufacturer) : null;
  const breadcrumbSchema = product ? generateBreadcrumbSchema([
    { name: 'Home', url: 'https://fidelisav.com' },
    { name: 'Products', url: 'https://fidelisav.com/products' },
    { name: product.title, url: `https://fidelisav.com/products/${product.slug}` }
  ]) : null;
  const relationshipSectionsNeedingCopy = getRelationshipSectionsNeedingCopy();
  const copyOutOfSync = relationshipSectionsNeedingCopy.pairs || relationshipSectionsNeedingCopy.also;
  const relationshipFields = [
    'pairs_well_with',
    'also_consider',
    'pairs_notes',
    'also_notes',
    'pairs_reasoning',
    'pairs_cta',
    'pairs_helper',
    'also_reasoning',
    'also_cta',
    'also_helper'
  ];
  const hasRelationshipChanges = relationshipFields.some((field) => field in pendingChanges);
  const willRefreshCopyOnSave = !isNewProduct && copyOutOfSync;
  const forceDisableSave = isNewProduct && copyOutOfSync && hasRelationshipChanges;
  const saveDisabledReason = forceDisableSave
    ? 'Save this product once before generating relationship copy'
    : undefined;
  const saveLabel = willRefreshCopyOnSave ? 'Refresh Text & Save' : 'Save';
  const savingLabel = isRefreshingCopyForSave ? 'Refreshing text...' : 'Saving...';

  return (
    <PageLoadReveal isLoading={loading} minimumLoadTime={200} maxWaitTime={3000}>
      {/* SEO Structured Data */}
      {productSchema && <StructuredData data={[productSchema, breadcrumbSchema].filter(Boolean)} />}
      
      <div className="min-h-screen bg-warm-white pt-24 footer-scroll-reveal">
        <div className="relative z-10 bg-warm-white">
          <Header />
      <main id="main-content">
      
      {/* Edit Bar */}
      <EditBar
        key={`editbar-${editBarKey}`}
        onSave={handleSave}
        onCancel={handleCancel}
        onTogglePublish={handleTogglePublish}
        onDelete={() => setIsDeleteModalOpen(true)}
        isPublished={product.published !== false}
        onGenerateAI={handleGenerateAI}
        isGeneratingAI={isGeneratingAI}
        aiGenerationError={aiGenerationError}
        aiSuccessData={aiSuccessData}
        onOpenSEO={() => setIsSEOModalOpen(true)}
        productId={product.id}
        forceDisableSave={forceDisableSave}
        saveDisabledReason={saveDisabledReason}
        saveLabel={saveLabel}
        savingLabel={savingLabel}
        disableGenerateAI={isNewProduct || !product.id || product.id === 'new'}
        generateAIDisabledReason="Save this product once before using Flesh Out."
        forceConfirmOnCancel={isNewProduct}
        cancelConfirmMessage="Discard this new product and return to the previous page? Unsaved changes will be lost."
      />

      {/* SEO Modal */}
      <SEOModal
        isOpen={isSEOModalOpen}
        onClose={() => setIsSEOModalOpen(false)}
        briefDescription={product.brief_description || ''}
      />
      
      {/* Premium Hero Section */}
      <div className="relative bg-warm-beige border-b border-stone-200 -mt-4">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          {/* Product Header */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Product Image */}
            <div>
              {/* Main Image - Editable */}
              <EditableImage
                value={product.product_hero_image}
                fieldName="product_hero_image"
                alt={product.title}
                className="w-full h-auto max-h-[600px] object-contain mix-blend-multiply"
                folder="products"
              />
            </div>

            {/* Product Information */}
            <div className="space-y-8 lg:space-y-9">
              {/* Category - Above Title, Editable In-Situ */}
              <div className="space-y-3">
                <EditableSelect
                  value={product.category_id}
                  fieldName="category_id"
                  options={categories.map(c => ({ value: c.id, label: c.name }))}
                  label="Product Category"
                  required
                  displayValue={product.categories?.name}
                  displayLink={product.categories?.id ? `/products/list?category=${product.categories.id}` : undefined}
                  displayClassName="inline-flex text-sm font-semibold uppercase tracking-[0.2em] text-stone-500 hover:text-stone-800 transition-colors duration-200"
                />
                {isAmplifierProduct && (isEditMode || topologyLabel || amplifierClassLabel) && (
                  <div className="flex flex-wrap items-center gap-3">
                    <EditableSelect
                      value={topologyValue}
                      fieldName="topology"
                      options={TOPOLOGY_OPTIONS}
                      label="Topology"
                      placeholder="Not specified"
                      displayValue={topologyLabel ? `Topology: ${topologyLabel}` : undefined}
                      displayLink={topologyFilterHref}
                      displayClassName="inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold bg-white/85 text-stone-700 ring-1 ring-stone-200/70 shadow-sm hover:bg-white hover:text-stone-900 hover:ring-stone-300 transition-colors"
                      className="text-base [&_label]:text-sm"
                    />
                    <EditableSelect
                      value={amplifierClassValue}
                      fieldName="amplifier_class"
                      options={AMPLIFIER_CLASS_OPTIONS}
                      label="Amplifier Class"
                      placeholder="Not specified"
                      displayValue={amplifierClassLabel ? `Class: ${amplifierClassLabel}` : undefined}
                      displayLink={amplifierClassFilterHref}
                      displayClassName="inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold bg-white/85 text-stone-700 ring-1 ring-stone-200/70 shadow-sm hover:bg-white hover:text-stone-900 hover:ring-stone-300 transition-colors"
                      className="text-base [&_label]:text-sm"
                    />
                  </div>
                )}
              </div>

              {/* Product Title & Manufacturer */}
              <div className="space-y-4">
                <EditableText
                  value={product.title}
                  fieldName="title"
                  fieldType="text"
                  placeholder="Product Title"
                  required
                  className="text-6xl lg:text-7xl xl:text-8xl font-extralight text-stone-900 leading-[0.92] tracking-tighter"
                />
                <div className="text-2xl lg:text-3xl text-stone-600 font-light tracking-wide flex items-baseline gap-2 flex-wrap">
                  <span className="mr-1">by</span>
                  {(() => {
                    const currentManufacturer = manufacturers.find(m => m.id === product.manufacturer_id);
                    return (
                      <EditableSelect
                        value={product.manufacturer_id}
                        fieldName="manufacturer_id"
                        options={manufacturers.map(m => ({ value: m.id, label: m.name }))}
                        label="Manufacturer"
                        required
                        placeholder="Select manufacturer"
                        displayValue={currentManufacturer?.name}
                        displayLink={currentManufacturer?.slug ? `/manufacturers/${currentManufacturer.slug}` : undefined}
                        displayClassName="inline text-2xl lg:text-3xl font-light hover:text-stone-900 transition-colors duration-300 border-b border-stone-300 hover:border-stone-900"
                        className="text-base [&_label]:text-sm"
                      />
                    );
                  })()}
                </div>
                {specialOrderLeadTime && (
                  <div className="flex items-center gap-2 pt-1">
                    <span className="inline-flex items-center px-3.5 py-1.5 rounded-full text-sm font-semibold bg-amber-100 text-amber-900">
                      Special order · {specialOrderLeadTime}
                    </span>
                  </div>
                )}
              </div>

              {/* Price Display - Editable */}
              <div className="space-y-5">
                <EditableToggle
                  value={product.show_price || false}
                  fieldName="show_price"
                  label="Show Price"
                  description="Control whether the price is displayed on the product page"
                />

                <EditableSelect
                  value={product.special_order_lead_time || ''}
                  fieldName="special_order_lead_time"
                  label="Special Order Lead Time"
                  options={[
                    { value: '', label: 'None' },
                    { value: '1-2 weeks', label: '1-2 weeks' },
                    { value: '2-4 weeks', label: '2-4 weeks' },
                    { value: '4-6 weeks', label: '4-6 weeks' },
                  ]}
                  placeholder="Select lead time"
                  className="text-base [&_label]:text-sm"
                />
                
                {showPriceToggle ? (
                  <EditableNumber
                    value={product.price}
                    fieldName="price"
                    prefix="$"
                    step={0.01}
                    min={0}
                    placeholder="0.00"
                    className="text-2xl"
                    displayClassName="text-4xl lg:text-5xl font-light tracking-tight text-stone-900"
                  />
                ) : (
                  <Button
                    href={`/contact?product=${encodeURIComponent(product.title)}&manufacturer=${encodeURIComponent(product.manufacturer?.name || '')}&inquiry=pricing`}
                    variant="outline-bold"
                    size="md"
                  >
                    Contact for Price
                  </Button>
                )}
              </div>

              {/* Sophisticated Call to Action */}
              <div className="space-y-4">
                {/* Demo Toggle - Above buttons, same positioning as price toggle */}
                <EditableToggle
                  value={product.available_for_demo || false}
                  fieldName="available_for_demo"
                  label="Home Demo Available"
                  description="Allow customers to request home demonstrations"
                  onChange={handleDemoToggle}
                />

                <div className="flex flex-wrap items-center gap-3">
                  {getCallToActionButton()}

                  <Button
                    variant="outline"
                    size="md"
                    className="w-full sm:w-auto"
                    onClick={() => setIsTradeModalOpen(true)}
                  >
                    Discuss Trade-In / Build My System
                  </Button>
                </div>
              </div>

              {/* Product Tags and Settings */}
              <div className="space-y-4">
                {/* Display tags in view mode */}
                {!product.published && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
                    Unpublished
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Sections */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">

        {/* Quote/Testimonial Section - Timeline-style Layout - Editable */}
        {(isEditMode || product.quote) && (
          <div className="mb-32 flex flex-col items-center">
            {/* Top vertical line - above quote */}
            <div className="w-px h-32 bg-stone-300 mb-16"></div>
            
            <div className={`mx-auto px-8 text-center space-y-8 w-full ${isEditMode ? 'max-w-full' : 'max-w-4xl'}`}>
              <blockquote className="w-full">
                {/* Main quote - clean and severe - Editable */}
                <EditableTextarea
                  value={product.quote || ''}
                  fieldName="quote"
                  placeholder="Add a quote or testimonial about this product"
                  rows={3}
                  maxLength={500}
                  className="text-2xl lg:text-3xl xl:text-4xl font-light text-stone-900 leading-[1.4] tracking-wide w-full"
                />
              </blockquote>
              
              {/* Attribution - minimal and refined - Editable */}
              <EditableText
                value={product.quote_attribution || ''}
                fieldName="quote_attribution"
                placeholder="Quote attribution (e.g., reviewer name, publication)"
                className="text-sm text-stone-500 font-light tracking-[0.3em] uppercase"
              />
            </div>
            
            {/* Bottom vertical line - below quote */}
            <div className="w-px h-32 bg-stone-300 mt-16"></div>
          </div>
        )}

        {/* Tabbed Content - show in edit mode even if empty, otherwise only when content exists */}
        {(isEditMode || hasTabContent(product)) && (
          <div className="mb-32">
            <ProductTabs product={product} />
          </div>
        )}

      </div>


      {/* Synergies & Also Consider sections */}
      {(isEditMode || pairsWellWithProducts.length > 0) && (
        <div className="py-16 lg:py-20 border-t border-stone-200/70 bg-warm-beige">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            {renderRelationshipCopySection('pairs')}
          </div>
        </div>
      )}

      {(isEditMode || alsoConsiderProducts.length > 0) && (
        <div className="py-16 lg:py-20 border-t border-stone-200/70 bg-warm-beige">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            {renderRelationshipCopySection('also')}
          </div>
        </div>
      )}

      {/* Image Modal */}
      {isImageModalOpen && selectedImage && (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50" onClick={closeImageModal}>
          <div className="relative w-full h-full max-w-4xl p-4 flex items-center justify-center">
            <div className="relative w-full h-full">
              <Image
                src={getImageUrl(selectedImage)}
                alt={product.title}
                fill
                className="object-contain"
                sizes="100vw"
                quality={95}
              />
            </div>
            <button
              onClick={closeImageModal}
              className="absolute top-4 right-4 text-white hover:text-gray-300"
            >
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmation
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleDelete}
        title="Delete Product"
        message={`Are you sure you want to delete "${product.title}"? This action cannot be undone.`}
        loading={deleteLoading}
      />

      {/* Product Search Modals */}
      <ProductSearchModal
        isOpen={showPairsModal}
        onClose={() => setShowPairsModal(false)}
        onAdd={(productId) => handleAddRelationship(productId, 'pairs')}
        excludeIds={[product.id, ...(product.pairs_well_with || []), ...(product.also_consider || [])]}
      />
      
      <ProductSearchModal
        isOpen={showAlsoModal}
        onClose={() => setShowAlsoModal(false)}
        onAdd={(productId) => handleAddRelationship(productId, 'also')}
        excludeIds={[product.id, ...(product.pairs_well_with || []), ...(product.also_consider || [])]}
      />

      <TradeInModal
        open={isTradeModalOpen}
        onClose={() => setIsTradeModalOpen(false)}
        defaultSubject={`Trade-In / System Consultation: ${product.title}`}
        defaultMessage={`I'm interested in trading in gear and building a system around ${product.manufacturer?.name || ''} ${product.title}. Current equipment:\n\nBudget/goal:\n\nRoom details:`}
        source="product-detail"
      />
      </main>
      </div>


      {/* Footer */}
      <FooterWithSignIn />
    </div>
    </PageLoadReveal>
  );
}

