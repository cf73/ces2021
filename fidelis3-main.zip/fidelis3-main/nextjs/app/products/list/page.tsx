import React, { Suspense } from 'react';
import { getProductsWithCategories, getProductCategories, getManufacturers } from '../../../lib/supabase-queries';
import { Header } from '../../../components/Header';
import { FooterWithSignIn } from '../../../components/FooterWithSignIn';
import { ProductsListClient } from './ProductsListClient';
import type { Metadata } from 'next';

// Revalidate every hour (3600 seconds) - on-demand revalidation handles updates
export const revalidate = 3600;

export const metadata: Metadata = {
  title: 'Products | Fidelis',
  description: 'Browse our complete collection of high-end audio equipment.',
};

export default async function ProductsListPage() {
  // Fetch data at build time (for SEO and initial load)
  const [products, categories, manufacturers] = await Promise.all([
    getProductsWithCategories(),
    getProductCategories(),
    getManufacturers(),
  ]);

  return (
    <div className="min-h-screen pt-24 footer-scroll-reveal">
      <div className="relative z-10 bg-warm-white">
        <Header />
        
        <main id="main-content">
          <Suspense fallback={null}>
            <ProductsListClient 
              initialProducts={products}
              initialCategories={categories}
              initialManufacturers={manufacturers}
            />
          </Suspense>
        </main>
      </div>
      
      <FooterWithSignIn />
    </div>
  );
}
