'use client';

import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import type { Manufacturer } from '../../lib/supabase';
import { EditBar } from '../../components/cms/EditBar';

interface ManufacturersPageClientProps {
  manufacturers: Manufacturer[];
}

export function ManufacturersPageClient({ manufacturers }: ManufacturersPageClientProps) {
  const { user } = useAuth();

  return (
    <>
      {/* CMS Widget with Create New Functionality */}
      {user && (
        <EditBar
          createNewHref="/manufacturers/new"
          createNewLabel="Create Manufacturer"
        />
      )}
    </>
  );
}
