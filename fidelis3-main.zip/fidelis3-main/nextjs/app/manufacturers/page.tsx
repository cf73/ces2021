import React from 'react';
import { getManufacturers } from '../../lib/supabase-queries';
import { Section, Container } from '../../components/ui';
import { Header } from '../../components/Header';
import { FooterWithSignIn } from '../../components/FooterWithSignIn';
import { ManufacturerListClient } from './ManufacturerListClient';
import { ManufacturersPageClient } from './ManufacturersPageClient';
import type { Metadata } from 'next';

// Revalidate every hour (3600 seconds) - on-demand revalidation handles updates
export const revalidate = 3600;

export const metadata: Metadata = {
  title: 'Manufacturers | Fidelis',
  description: 'Explore our carefully curated collection of high-end audio equipment manufacturers.',
};

export default async function ManufacturersPage() {
  // Fetch manufacturers data at build time (for SEO and initial load)
  const manufacturers = await getManufacturers();

  return (
    <div className="min-h-screen bg-warm-cream pt-24 footer-scroll-reveal">
      <div className="relative z-10 bg-warm-cream">
        <Header />
        
        <ManufacturersPageClient manufacturers={manufacturers} />

        <main id="main-content">
        {/* Hero Section */}
        <Section variant="hero" background="custom" customBackground="bg-warm-beige" className="-mt-4">
          <Container size="6xl">
            <div className="max-w-4xl">
              <h1 className="text-4xl lg:text-5xl xl:text-6xl font-light text-stone-900 leading-tight tracking-wide mb-6">
                Manufacturers
              </h1>
              <div className="prose prose-stone prose-lg max-w-none text-stone-700 leading-relaxed">
                <p>
                  We work exclusively with manufacturers who share our commitment to sonic excellence 
                  and build quality. Every brand we represent has earned its place through decades 
                  of innovation and an unwavering dedication to the music.
                </p>
              </div>
            </div>
          </Container>
        </Section>

        {/* Manufacturers Grid */}
        <Section variant="default" background="custom" customBackground="bg-warm-cream">
          <Container size="6xl">
            <ManufacturerListClient manufacturers={manufacturers} />
          </Container>
        </Section>
        </main>
      </div>
      
      <FooterWithSignIn />
    </div>
  );
}
