'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '../../../contexts/AuthContext';
import { useEditMode } from '../../../contexts/EditModeContext';
import { getManufacturerBySlug, getProductsWithCategories } from '../../../lib/supabase-queries';
import { supabase } from '../../../lib/supabase';
import type { Manufacturer, Product, ProductCategory } from '../../../lib/supabase';
import { getRandomMusicalMessage } from '../../../utils/musicalLoadingMessages';
import { Section, Container, ProductCard } from '../../../components/ui';
import { Header } from '../../../components/Header';
import { FooterWithSignIn } from '../../../components/FooterWithSignIn';
import { slugify } from '../../../lib/utils';
import { PageLoadReveal } from '../../../components/PageLoadReveal';
import { EditBar } from '../../../components/cms/EditBar';
import { EditableText } from '../../../components/cms/EditableText';
import { EditableTextarea } from '../../../components/cms/EditableTextarea';
import { EditableImage } from '../../../components/cms/EditableImage';
import { DeleteConfirmation } from '../../../components/DeleteConfirmation';
import { sanitizeHTML } from '../../../lib/sanitize';
import { StructuredData } from '../../../components/StructuredData';
import { generateBrandSchema, generateBreadcrumbSchema } from '../../../lib/structured-data';
import { getAuthHeaders } from '../../../lib/auth-headers';

interface ManufacturerDetailClientProps {
  initialManufacturer: Manufacturer | null;
  slug: string;
}

export default function ManufacturerDetailClient({ initialManufacturer, slug }: ManufacturerDetailClientProps) {
  const router = useRouter();
  const { user } = useAuth();
  const { isEditMode, toggleEditMode, getChanges, clearChanges, setIsSaving, setOriginalValues } = useEditMode();
  
  const [manufacturer, setManufacturer] = useState<Manufacturer | null>(initialManufacturer);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [editBarKey, setEditBarKey] = useState(0);
  const [isDescriptionExpanded, setIsDescriptionExpanded] = useState(false);

  // Handle "new" slug for creating new manufacturers
  const isNewManufacturer = slug === 'new';

  // If new manufacturer, create empty template and enable edit mode
  useEffect(() => {
    if (isNewManufacturer && !manufacturer) {
      const emptyManufacturer: Manufacturer = {
        id: 'new',
        name: '',
        slug: '',
        description: '',
        logo: '',
        website: '',
        published: true,
      };
      setManufacturer(emptyManufacturer);
      
      // Automatically enable edit mode for new manufacturers
      if (!isEditMode) {
        toggleEditMode();
      }
    }
  }, [isNewManufacturer, manufacturer]);

  const scrollToProducts = () => {
    setTimeout(() => {
      const productsGrid = document.querySelector('.products-grid') || 
                          document.querySelector('[class*="grid grid-cols"]');
      if (productsGrid) {
        const navHeight = 80;
        const elementTop = productsGrid.getBoundingClientRect().top + window.pageYOffset;
        const offsetPosition = elementTop - navHeight - 20;
        
        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    }, 100);
  };

  // Load manufacturer data
  const loadManufacturer = async () => {
    if (!slug || slug === 'new') return;
    
    try {
      setLoading(true);
      const data = await getManufacturerBySlug(slug, !!user);
      if (data) {
        setEditBarKey(prev => prev + 1);
        setManufacturer(data);
        
        // Load products for this manufacturer
        const productsData = await getProductsWithCategories(!!user);
        const manufacturerProducts = productsData.filter(p => p.manufacturer?.id === data.id);
        setProducts(manufacturerProducts);
        
        // Extract unique categories
        const uniqueCategories = Array.from(
          new Map(
            manufacturerProducts
              .filter(p => p.categories)
              .map(p => [p.categories!.id, p.categories!])
          ).values()
        );
        setCategories(uniqueCategories);
      }
    } catch (error) {
      console.error('Error loading manufacturer:', error);
    } finally {
      setLoading(false);
    }
  };

  // Initial load
  useEffect(() => {
    if (initialManufacturer && !isNewManufacturer) {
      const loadProducts = async () => {
        try {
          const productsData = await getProductsWithCategories(!!user);
          const manufacturerProducts = productsData.filter(p => p.manufacturer?.id === initialManufacturer.id);
          setProducts(manufacturerProducts);
          
          const uniqueCategories = Array.from(
            new Map(
              manufacturerProducts
                .filter(p => p.categories)
                .map(p => [p.categories!.id, p.categories!])
            ).values()
          );
          setCategories(uniqueCategories);
        } catch (error) {
          console.error('Error loading products:', error);
        }
      };
      
      loadProducts();
    }
  }, [initialManufacturer?.id]);

  // Refetch when edit mode is toggled and set original values
  useEffect(() => {
    if (isEditMode && !isNewManufacturer && manufacturer) {
      // Set original values for comparison
      setOriginalValues({
        name: manufacturer.name,
        description: manufacturer.description,
        logo: manufacturer.logo,
        website: manufacturer.website,
        published: manufacturer.published !== false
      });
      loadManufacturer();
    }
  }, [isEditMode]);

  const handleSave = async () => {
    if (!manufacturer) return;

    setIsSaving(true);
    try {
      const changes = getChanges();

      if (Object.keys(changes).length === 0 && !isNewManufacturer) {
        console.log('No changes to save');
        setIsSaving(false);
        return;
      }

      // If name changed, also update slug
      const dataToSave = { ...changes };
      if (changes.name) {
        dataToSave.slug = slugify(changes.name);
      }

      if (isNewManufacturer) {
        // Create new manufacturer
        const newManufacturerData = {
          name: dataToSave.name || manufacturer.name || 'Untitled Manufacturer',
          slug: dataToSave.slug || slugify(dataToSave.name || manufacturer.name || 'untitled-manufacturer'),
          description: dataToSave.description || manufacturer.description || '',
          logo: dataToSave.logo || manufacturer.logo || '',
          website: dataToSave.website || manufacturer.website || '',
          published: manufacturer.published !== false,
        };

        const { data: newData, error: createError } = await supabase
          .from('manufacturers')
          .insert([newManufacturerData])
          .select()
          .single();

        if (createError) {
          console.error('Error creating manufacturer:', createError);
          alert('Failed to create manufacturer. Please try again.');
          return;
        }

        if (newData) {
          console.log('✅ Manufacturer created successfully:', newData);
          clearChanges();
          router.push(`/manufacturers/${newData.slug}`);
        }
      } else {
        // Update existing manufacturer
        const { data: updateData, error: updateError } = await supabase
          .from('manufacturers')
          .update(dataToSave)
          .eq('id', manufacturer.id)
          .select();

        if (updateError) {
          console.error('Error saving manufacturer:', updateError);
          alert('Failed to save changes. Please try again.');
          return;
        }

        if (!updateData || updateData.length === 0) {
          console.error('Update returned no data');
          alert('Failed to update manufacturer. Please refresh and try again.');
          return;
        }

        console.log('✅ Manufacturer updated successfully:', updateData[0]);
        
        // Reload manufacturer data
        const { data: updatedManufacturer, error: reloadError } = await supabase
          .from('manufacturers')
          .select('*')
          .eq('id', manufacturer.id)
          .single();
        
        if (reloadError) {
          console.error('Error reloading manufacturer:', reloadError);
        } else if (updatedManufacturer) {
          setEditBarKey(prev => prev + 1);
          setManufacturer(updatedManufacturer);
        }
        
        clearChanges();
      }
      
      console.log('✅ Manufacturer saved successfully');
    } catch (error) {
      console.error('Error saving manufacturer:', error);
      alert('Failed to save changes. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    if (isNewManufacturer) {
      router.push('/manufacturers');
    } else {
      loadManufacturer();
    }
  };

  const handleDelete = async () => {
    if (!manufacturer || isNewManufacturer) return;
    
    setDeleteLoading(true);
    try {
      const authHeaders = await getAuthHeaders();
      const response = await fetch(`/api/manufacturers/${manufacturer.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...authHeaders,
        },
        body: JSON.stringify({ published: false }),
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(errorData?.error || 'Failed to archive manufacturer.');
      }
      
      console.log('✅ Manufacturer archived successfully');
      alert('Manufacturer archived. Restore or delete permanently from Site Globals → Manufacturers.');
      router.push('/manufacturers');
    } catch (error) {
      console.error('Error archiving manufacturer:', error);
      alert('Failed to archive manufacturer. Please try again.');
    } finally {
      setDeleteLoading(false);
      setIsDeleteModalOpen(false);
    }
  };

  // Filter and sort products
  const filteredProducts = selectedCategory
    ? products.filter(product => product.categories?.id === selectedCategory)
    : products;

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (!a.price && !b.price) return 0;
    if (!a.price) return 1;
    if (!b.price) return -1;
    
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      default:
        return 0;
    }
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-[#fffcf9]">
        <Header />
        <div className="min-h-screen bg-[#fffcf9] py-12">
          <div className="container-custom text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-stone-600 mx-auto"></div>
            <p className="mt-4 text-stone-600">{getRandomMusicalMessage()}</p>
          </div>
        </div>
      </div>
    );
  }

  if (!manufacturer) {
    return (
      <div className="min-h-screen bg-[#fffcf9]">
        <Header />
        <div className="min-h-screen bg-[#fffcf9] py-12">
          <Container size="6xl">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Manufacturer Not Found</h1>
              <p className="text-gray-600 mb-6">The manufacturer you're looking for doesn't exist.</p>
              <Link href="/manufacturers" className="btn-primary">
                Back to Manufacturers
              </Link>
            </div>
          </Container>
        </div>
      </div>
    );
  }

  // Generate structured data for SEO
  const brandSchema = manufacturer ? generateBrandSchema(manufacturer) : null;
  const breadcrumbSchema = manufacturer ? generateBreadcrumbSchema([
    { name: 'Home', url: 'https://fidelisav.com' },
    { name: 'Manufacturers', url: 'https://fidelisav.com/manufacturers' },
    { name: manufacturer.name, url: `https://fidelisav.com/manufacturers/${manufacturer.slug}` }
  ]) : null;
  const newProductHref = manufacturer
    ? `/products/new?manufacturer=${manufacturer.id}${selectedCategory ? `&category=${selectedCategory}` : ''}&returnTo=${encodeURIComponent(`/manufacturers/${manufacturer.slug}`)}`
    : '/products/new?returnTo=/manufacturers';

  return (
    <PageLoadReveal isLoading={loading} minimumLoadTime={200} maxWaitTime={3000}>
      {/* SEO Structured Data */}
      {brandSchema && <StructuredData data={[brandSchema, breadcrumbSchema].filter(Boolean)} />}
      
      <div className="min-h-screen bg-[#fffcf9] pt-24 footer-scroll-reveal">
        <div className="relative z-10 bg-[#fffcf9]">
          <Header />
          <main id="main-content">

          {/* Edit Bar */}
          {user && (
            <EditBar
              key={`editbar-${editBarKey}`}
              onSave={handleSave}
              onCancel={handleCancel}
              onDelete={isNewManufacturer ? undefined : () => setIsDeleteModalOpen(true)}
              isPublished={manufacturer?.published !== false}
              createNewHref={newProductHref}
              createNewLabel="Add Product"
            />
          )}

          {/* Hero Section */}
          <Section variant="hero" background="custom" customBackground="bg-warm-beige" className="-mt-4">
            <Container size="6xl">
              <div className="mb-4">
                {manufacturer.published === false && (
                  <div className="mb-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
                    This manufacturer is archived. Restore it from Site Globals → Manufacturers to make it public again.
                  </div>
                )}
                {/* Grid with logo on left */}
                <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-8 mb-8">
                  {/* Logo */}
                  <div className="lg:pr-8">
                    <EditableImage
                      value={manufacturer.logo}
                      fieldName="logo"
                      alt={`${manufacturer.name} logo`}
                      className="w-full h-auto max-h-64 object-contain bg-white rounded-lg p-8 shadow-sm"
                      folder="manufacturers"
                    />
                  </div>

                  {/* Content (stays on right, no extra div) */}
                  <div className="max-w-4xl">
                    <div className="flex flex-wrap items-center gap-3 mb-4">
                      <h1 className="text-4xl lg:text-5xl xl:text-6xl font-light text-stone-900 leading-tight tracking-wide">
                      <EditableText
                        value={manufacturer.name}
                        fieldName="name"
                        fieldType="text"
                        placeholder="Manufacturer Name"
                        required
                        className="text-4xl lg:text-5xl xl:text-6xl font-light text-stone-900 leading-tight tracking-wide"
                      />
                      </h1>
                      {manufacturer.published === false && (
                        <span className="rounded-full border border-stone-200 px-3 py-1 text-xs font-semibold uppercase tracking-[0.3em] text-stone-500">
                          Archived
                        </span>
                      )}
                    </div>
                    {manufacturer.description && (
                      <div className="mb-8">
                        <div className="prose prose-stone prose-lg max-w-none text-stone-700 leading-relaxed">
                          {isEditMode ? (
                            <EditableTextarea
                              value={manufacturer.description}
                              fieldName="description"
                              placeholder="Manufacturer description..."
                              rows={8}
                              className="text-lg leading-relaxed"
                            />
                          ) : (
                            <div dangerouslySetInnerHTML={{ 
                              __html: sanitizeHTML(
                                isDescriptionExpanded 
                                  ? manufacturer.description 
                                  : (manufacturer.description.length > 300 
                                      ? manufacturer.description.substring(0, 300) + '...' 
                                      : manufacturer.description)
                              )
                            }} />
                          )}
                        </div>
                        {!isEditMode && manufacturer.description.length > 300 && (
                          <button
                            onClick={() => setIsDescriptionExpanded(!isDescriptionExpanded)}
                            className="mt-3 text-sm text-stone-600 hover:text-stone-900 transition-colors duration-200 font-medium underline decoration-stone-300 hover:decoration-stone-600"
                          >
                            {isDescriptionExpanded ? 'Show less' : 'Read more'}
                          </button>
                        )}
                      </div>
                    )}
                    {isEditMode && (
                      <div className="mb-8">
                        <EditableText
                          value={manufacturer.website || ''}
                          fieldName="website"
                          fieldType="text"
                          placeholder="https://manufacturer-website.com"
                          className="text-base"
                        />
                      </div>
                    )}
                    {!isEditMode && manufacturer.website && (
                      <Link
                        href={manufacturer.website}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center px-6 py-3 border-2 border-stone-900 text-stone-900 font-medium tracking-wide hover:bg-stone-900 hover:text-white transition-all duration-300"
                      >
                        Visit Website
                        <svg className="ml-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                        </svg>
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            </Container>
          </Section>

          {/* Products Section */}
          {!isNewManufacturer && products.length > 0 && (
            <Section variant="default" background="custom" customBackground="bg-[#fffcf9]">
              <Container size="6xl">
                {/* Main Content with Sidebar */}
                <div className="flex flex-col lg:flex-row gap-8">
                  {/* Sidebar Filters */}
                  <div className="lg:w-80 lg:flex-shrink-0 pt-16">
                    <div className="lg:sticky lg:top-32">
                      <div className="space-y-8">
                        {categories.length > 1 && (
                          <div>
                            <label className="block text-base font-semibold text-stone-900 mb-4">
                              Filter by Category
                            </label>
                            <div className="space-y-2">
                              <label className="flex items-center space-x-3 cursor-pointer group">
                                <div className="relative">
                                  <input
                                    type="radio"
                                    name="category"
                                    value=""
                                    checked={selectedCategory === ''}
                                    onChange={(e) => setSelectedCategory(e.target.value)}
                                    className="sr-only"
                                  />
                                  <div className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                                    selectedCategory === '' 
                                      ? 'border-primary-600 bg-primary-600' 
                                      : 'border-stone-300 group-hover:border-stone-400'
                                  }`}>
                                    {selectedCategory === '' && (
                                      <div className="w-2 h-2 bg-white rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                                    )}
                                  </div>
                                </div>
                                <span className="text-stone-700 group-hover:text-stone-900 transition-colors">All Categories</span>
                              </label>
                              
                              {categories.map(category => (
                                <label key={category.id} className="flex items-center space-x-3 cursor-pointer group">
                                  <div className="relative">
                                    <input
                                      type="radio"
                                      name="category"
                                      value={category.id}
                                      checked={selectedCategory === category.id}
                                      onChange={(e) => setSelectedCategory(e.target.value)}
                                      className="sr-only"
                                    />
                                    <div className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                                      selectedCategory === category.id 
                                        ? 'border-primary-600 bg-primary-600' 
                                        : 'border-stone-300 group-hover:border-stone-400'
                                    }`}>
                                      {selectedCategory === category.id && (
                                        <div className="w-2 h-2 bg-white rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                                      )}
                                    </div>
                                  </div>
                                  <span className="text-stone-700 group-hover:text-stone-900 transition-colors">{category.name}</span>
                                </label>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {sortedProducts.some(product => product.price) && (
                          <div>
                            <label className="block text-base font-semibold text-stone-900 mb-4">
                              Sort by Price
                            </label>
                            <div className="space-y-2">
                              <label className="flex items-center space-x-3 cursor-pointer group">
                                <div className="relative">
                                  <input
                                    type="radio"
                                    name="sort"
                                    value="price-low"
                                    checked={sortBy === 'price-low'}
                                    onChange={(e) => {
                                      setSortBy(e.target.value);
                                      scrollToProducts();
                                    }}
                                    className="sr-only"
                                  />
                                  <div className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                                    sortBy === 'price-low' 
                                      ? 'border-primary-600 bg-primary-600' 
                                      : 'border-stone-300 group-hover:border-stone-400'
                                  }`}>
                                    {sortBy === 'price-low' && (
                                      <div className="w-2 h-2 bg-white rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                                    )}
                                  </div>
                                </div>
                                <span className="text-stone-700 group-hover:text-stone-900 transition-colors">Low to High</span>
                              </label>
                              
                              <label className="flex items-center space-x-3 cursor-pointer group">
                                <div className="relative">
                                  <input
                                    type="radio"
                                    name="sort"
                                    value="price-high"
                                    checked={sortBy === 'price-high'}
                                    onChange={(e) => {
                                      setSortBy(e.target.value);
                                      scrollToProducts();
                                    }}
                                    className="sr-only"
                                  />
                                  <div className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                                    sortBy === 'price-high' 
                                      ? 'border-primary-600 bg-primary-600' 
                                      : 'border-stone-300 group-hover:border-stone-400'
                                  }`}>
                                    {sortBy === 'price-high' && (
                                      <div className="w-2 h-2 bg-white rounded-full absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"></div>
                                    )}
                                  </div>
                                </div>
                                <span className="text-stone-700 group-hover:text-stone-900 transition-colors">High to Low</span>
                              </label>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Products Grid Section */}
                  <div className="flex-1 pt-8 pb-16">
                    {sortedProducts.length === 0 ? (
                      <div className="text-center py-12">
                        <svg className="mx-auto h-12 w-12 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                        </svg>
                        <h3 className="mt-2 text-xl font-light text-stone-900">No products found</h3>
                        <p className="mt-1 text-stone-500">
                          {selectedCategory 
                            ? 'No products found in the selected category.'
                            : 'No products are available from this manufacturer at the moment.'
                          }
                        </p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-10 products-grid">
                        {sortedProducts.map((product) => {
                          const isPublished = product.published !== false;
                          const productHref = isPublished
                            ? `/products/${product.slug}`
                            : `/products/${product.slug}?preview=1`;
                          return (
                            <Link key={product.id} href={productHref} className="block h-full">
                              <ProductCard
                                product={{
                                  id: product.id,
                                  title: product.title,
                                  slug: product.slug,
                                  price: product.price,
                                  show_price: product.show_price,
                                  special_order_lead_time: product.special_order_lead_time,
                                  manufacturer: product.manufacturer,
                                  product_hero_image: product.product_hero_image,
                                  categories: product.categories,
                                  featured: product.featured
                                }}
                                showCategory={!selectedCategory}
                              />
                            </Link>
                          );
                        })}
                      </div>
                    )}
                  </div>
                </div>
              </Container>
            </Section>
          )}

          {/* Delete Confirmation Modal */}
          {!isNewManufacturer && (
            <DeleteConfirmation
              isOpen={isDeleteModalOpen}
              onClose={() => setIsDeleteModalOpen(false)}
              onConfirm={handleDelete}
              title="Archive Manufacturer"
              message={`Archiving "${manufacturer.name}" will unpublish ${
                products.length === 1 ? '1 linked product' : `${products.length} linked products`
              }. Restore or permanently delete archived brands from Site Globals → Manufacturers.`}
              loading={deleteLoading}
              confirmLabel="Archive"
            />
          )}
          </main>
        </div>

        {/* Footer */}
        <FooterWithSignIn />
      </div>
    </PageLoadReveal>
  );
}
