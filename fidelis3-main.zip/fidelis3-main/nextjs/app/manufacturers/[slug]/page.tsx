import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getManufacturerBySlug, getManufacturers } from '../../../lib/supabase-queries';
import ManufacturerDetailClient from './ManufacturerDetailClient';

// Enable ISR with 1 hour revalidation - on-demand revalidation handles updates
export const revalidate = 3600;

// Pre-render all manufacturer pages at build time (plus handle 'new' for creating manufacturers)
export async function generateStaticParams() {
  try {
    const manufacturers = await getManufacturers();
    return manufacturers.map((manufacturer) => ({
      slug: manufacturer.slug,
    }));
  } catch (error) {
    console.error('Error generating static params for manufacturers:', error);
    return [];
  }
}

// Generate metadata for SEO
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  // Handle 'new' manufacturer creation route
  if (slug === 'new') {
    return {
      title: 'Create New Manufacturer | Fidelis AV',
      description: 'Add a new manufacturer to the catalog',
    };
  }

  try {
    const manufacturer = await getManufacturerBySlug(slug);
    
    if (!manufacturer) {
      return {
        title: 'Manufacturer Not Found | Fidelis AV',
      };
    }

    return {
      title: `${manufacturer.name} | Manufacturers | Fidelis AV`,
      description: manufacturer.description?.substring(0, 155) || `High-end audio products from ${manufacturer.name}`,
      openGraph: {
        title: manufacturer.name,
        description: manufacturer.description?.substring(0, 155) || '',
        images: manufacturer.logo ? [
          {
            url: manufacturer.logo,
            width: 1200,
            height: 630,
            alt: `${manufacturer.name} logo`,
          },
        ] : [],
      },
      twitter: {
        card: 'summary_large_image',
        title: manufacturer.name,
        description: manufacturer.description?.substring(0, 155) || `High-end audio products from ${manufacturer.name}`,
        images: manufacturer.logo ? [manufacturer.logo] : [],
      },
    };
  } catch (error) {
    console.error('Error generating metadata:', error);
    return {
      title: 'Manufacturers | Fidelis AV',
    };
  }
}

// Server Component - fetches initial data for ISR
export default async function ManufacturerDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  // Handle 'new' manufacturer creation route
  if (slug === 'new') {
    return <ManufacturerDetailClient initialManufacturer={null} slug="new" />;
  }

  try {
    // Fetch initial manufacturer data server-side
    const initialManufacturer = await getManufacturerBySlug(slug, true);
    
    if (!initialManufacturer) {
      notFound();
    }

    // Pass initial data to client component
    return <ManufacturerDetailClient initialManufacturer={initialManufacturer} slug={slug} />;
  } catch (error) {
    console.error('Error loading manufacturer:', error);
    notFound();
  }
}
