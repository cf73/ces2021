'use client';

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { getImageUrl } from '../../lib/supabase-queries';
import type { Manufacturer } from '../../lib/supabase';
import { H2, Body } from '../../components/ui';
import { generateBlurDataURL } from '../../lib/image-loader';
import { useAuth } from '../../contexts/AuthContext';

interface ManufacturerListClientProps {
  manufacturers: Manufacturer[];
}

export function ManufacturerListClient({ manufacturers }: ManufacturerListClientProps) {
  const { user } = useAuth();

  if (manufacturers.length === 0) {
    return (
      <div className="text-center py-12">
        <H2 className="mb-4">No Manufacturers Found</H2>
        <Body className="text-stone-500">
          {user
            ? 'No published manufacturers are currently live. Use Site Globals → Manufacturers to restore an archived brand.'
            : "We're currently updating our manufacturer listings. Please check back soon."}
        </Body>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-8">
        {manufacturers.map((manufacturer) => (
          <motion.div
            key={manufacturer.id}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            whileHover={{ y: -2, scale: 1.02 }}
            className="group"
          >
            <Link
              href={`/manufacturers/${manufacturer.slug || manufacturer.id}`}
              className="block p-6 rounded-xl transition-all duration-300 hover:bg-stone-50"
            >
              {manufacturer.logo ? (
                <div className="relative h-24 flex items-center justify-center">
                  <div className="relative h-16 w-full">
                    <Image
                      src={getImageUrl(manufacturer.logo)}
                      alt={manufacturer.name}
                      fill
                      className="object-contain mix-blend-multiply transition-opacity duration-200 group-hover:opacity-80"
                      sizes="(max-width: 640px) 50vw, (max-width: 768px) 33vw, (max-width: 1024px) 25vw, 20vw"
                      quality={85}
                      placeholder="blur"
                      blurDataURL={generateBlurDataURL()}
                    />
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-24">
                  <div className="text-stone-400 text-sm text-center font-medium">
                    {manufacturer.name}
                  </div>
                </div>
              )}
            </Link>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

