import type { Metadata } from "next";
import { Suspense } from "react";
import { Poppins } from "next/font/google";
import { Analytics } from "@vercel/analytics/next";
import "./globals.css";
import "./cms-styles.css";
import { Providers } from "../components/Providers";
import { StructuredData } from "../components/StructuredData";
import { NavigationProgress } from "../components/NavigationProgress";
import { generateOrganizationSchema, generateWebSiteSchema } from "../lib/structured-data";
import { getBusinessInfo } from "../lib/supabase-queries";
import supabaseAdmin from "../lib/supabase-server-admin";

const poppins = Poppins({
  weight: ['300', '400', '500', '600', '700'],
  subsets: ["latin"],
  variable: '--font-poppins',
  display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'),
  title: "Fidelis Audio - Premium High-End Audio Equipment",
  description: "Experience the finest in high-fidelity audio equipment. Fidelis Audio offers premium speakers, amplifiers, and audio systems from the world's leading manufacturers.",
  icons: {
    icon: '/favicon.ico',
    apple: [
      { url: '/logo192.png', sizes: '192x192', type: 'image/png' },
      { url: '/logo512.png', sizes: '512x512', type: 'image/png' },
    ],
  },
  manifest: '/manifest.json',
  robots: {
    index: true,
    follow: true,
  },
  openGraph: {
    type: 'website',
    title: 'Fidelis Audio - Premium High-End Audio Equipment',
    description: 'Experience the finest in high-fidelity audio equipment.',
    images: ['/og-image.svg'],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Fidelis Audio - Premium High-End Audio Equipment',
    description: 'Experience the finest in high-fidelity audio equipment.',
    images: ['/og-image.svg'],
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const businessInfo = await getBusinessInfo(supabaseAdmin ?? undefined);

  return (
    <html lang="en" className={poppins.variable} suppressHydrationWarning>
      <head>
        <StructuredData data={[generateOrganizationSchema(businessInfo), generateWebSiteSchema()]} />
      </head>
      <body className={poppins.className}>
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[10000] focus:bg-white focus:text-stone-900 focus:px-4 focus:py-2 focus:rounded-md focus:shadow-lg"
        >
          Skip to main content
        </a>
        <Suspense fallback={null}>
          <NavigationProgress />
        </Suspense>
        <Providers>
          {children}
        </Providers>
        <Analytics />
      </body>
    </html>
  );
}
