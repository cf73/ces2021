import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const tokenRegex = /^[0-9a-fA-F-]{36}$/

export async function POST(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const body = await request.json().catch(() => ({}))
    const token = (searchParams.get('token') || body.token || '').trim()

    if (!token || !tokenRegex.test(token)) {
      return NextResponse.json(
        { error: 'Valid unsubscribe token is required' },
        { status: 400 }
      )
    }

    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseServiceKey = process.env.SUPABASE_SECRET_KEY

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('Missing Supabase configuration')
      return NextResponse.json(
        { error: 'Server configuration error' },
        { status: 500 }
      )
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey)
    const now = new Date().toISOString()

    const { data: updatedRows, error: updateError } = await supabase
      .from('newsletter_subscribers')
      .update({
        status: 'unsubscribed',
        unsubscribed_at: now,
      })
      .eq('unsubscribe_token', token)
      .neq('status', 'unsubscribed')
      .select('id')

    if (updateError) {
      console.error('Database error:', updateError)
      return NextResponse.json(
        { error: 'Failed to unsubscribe' },
        { status: 500 }
      )
    }

    if (!updatedRows || updatedRows.length === 0) {
      const { data: existing, error: existingError } = await supabase
        .from('newsletter_subscribers')
        .select('status')
        .eq('unsubscribe_token', token)
        .maybeSingle()

      if (existingError) {
        console.error('Database error:', existingError)
        return NextResponse.json(
          { error: 'Failed to validate unsubscribe token' },
          { status: 500 }
        )
      }

      if (!existing) {
        return NextResponse.json(
          { error: 'Invalid or expired unsubscribe token' },
          { status: 404 }
        )
      }
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('Newsletter unsubscribe error:', err)
    return NextResponse.json(
      { error: 'An unexpected error occurred' },
      { status: 500 }
    )
  }
}
