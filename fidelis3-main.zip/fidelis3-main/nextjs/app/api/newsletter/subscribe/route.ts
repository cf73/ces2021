import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import { checkRateLimit } from '../../../../lib/rate-limit'
import { sanitizeText } from '../../../../lib/sanitize'

export async function POST(request: NextRequest) {
  try {
    const ip =
      request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      request.headers.get('x-real-ip') ||
      'anonymous'

    const { allowed } = checkRateLimit(`newsletter:${ip}`, {
      capacity: 5,
      intervalMs: 10 * 60 * 1000,
    })

    if (!allowed) {
      return NextResponse.json(
        { error: 'Too many requests. Please try again later.' },
        { status: 429 }
      )
    }

    const { email, source } = await request.json()

    // Validate email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!email || !emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Valid email is required' },
        { status: 400 }
      )
    }

    // Use service role key for server-side operations
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseServiceKey = process.env.SUPABASE_SECRET_KEY

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('Missing Supabase configuration')
      return NextResponse.json(
        { error: 'Server configuration error' },
        { status: 500 }
      )
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    const now = new Date().toISOString()
    const { data: existingSubscriber, error: selectError } = await supabase
      .from('newsletter_subscribers')
      .select('id, status, unsubscribe_token')
      .eq('email', email)
      .maybeSingle()

    if (selectError) {
      console.error('Database error:', selectError)
      return NextResponse.json(
        { error: 'Failed to check existing signup' },
        { status: 500 }
      )
    }

    let unsubscribeToken = existingSubscriber?.unsubscribe_token

    if (!existingSubscriber) {
      const { data: insertedSubscriber, error: insertError } = await supabase
        .from('newsletter_subscribers')
        .insert({
          email,
          source,
          status: 'active',
          subscribed_at: now,
          unsubscribed_at: null,
        })
        .select('unsubscribe_token')
        .single()

      if (insertError || !insertedSubscriber) {
        console.error('Database error:', insertError)
        return NextResponse.json(
          { error: 'Failed to save signup' },
          { status: 500 }
        )
      }

      unsubscribeToken = insertedSubscriber.unsubscribe_token
    } else if (existingSubscriber.status === 'unsubscribed') {
      const { error: updateError } = await supabase
        .from('newsletter_subscribers')
        .update({
          status: 'active',
          subscribed_at: now,
          unsubscribed_at: null,
          source,
        })
        .eq('id', existingSubscriber.id)

      if (updateError) {
        console.error('Database error:', updateError)
        return NextResponse.json(
          { error: 'Failed to re-subscribe' },
          { status: 500 }
        )
      }
    }

    // Optional: Send notification email via Resend
    const resendApiKey = process.env.RESEND_API_KEY
    if (resendApiKey) {
      const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'
      const unsubscribeUrl = unsubscribeToken
        ? `${siteUrl}/unsubscribe?token=${unsubscribeToken}`
        : `${siteUrl}/unsubscribe`
      try {
        const adminEmailResponse = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${resendApiKey}`,
          },
          body: JSON.stringify({
            from: 'Fidelis AV Newsletter <contact@fidelisav.com>',
            to: ['marc@fidelisav.com'],
            subject: 'New newsletter signup',
            html: `
              <h2>New Newsletter Signup</h2>
              <p><strong>Email:</strong> ${sanitizeText(email)}</p>
              <p><strong>Source:</strong> ${sanitizeText(source || 'unspecified')}</p>
              <p><em>Captured via website newsletter form.</em></p>
            `,
          }),
        })

        if (!adminEmailResponse.ok) {
          const emailError = await adminEmailResponse.text()
          console.error('Resend admin error:', emailError)
        }

        const subscriberEmailResponse = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${resendApiKey}`,
          },
          body: JSON.stringify({
            from: 'Fidelis AV Newsletter <contact@fidelisav.com>',
            to: [email],
            subject: 'You are subscribed to the Fidelis AV newsletter',
            html: `
              <h2>Welcome to the Fidelis AV newsletter</h2>
              <p>Thanks for subscribing. We will send occasional updates and news.</p>
              <p>If this was a mistake, you can unsubscribe anytime:</p>
              <p><a href="${unsubscribeUrl}">${unsubscribeUrl}</a></p>
            `,
          }),
        })

        if (!subscriberEmailResponse.ok) {
          const emailError = await subscriberEmailResponse.text()
          console.error('Resend subscriber error:', emailError)
        }
      } catch (emailErr) {
        // Don't fail the request if email notification fails
        console.error('Email notification error:', emailErr)
      }
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('Newsletter subscribe error:', err)
    return NextResponse.json(
      { error: 'An unexpected error occurred' },
      { status: 500 }
    )
  }
}
