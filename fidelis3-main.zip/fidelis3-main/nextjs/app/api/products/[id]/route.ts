import { NextRequest, NextResponse } from 'next/server';
import supabaseAdmin from '../../../../lib/supabase-server-admin';
import { revalidatePath } from 'next/cache';
import { requireAdmin } from '../../../../lib/admin-auth';

type RouteContext = { params: Promise<{ id: string }> };

export async function DELETE(_req: NextRequest, context: RouteContext) {
  if (!supabaseAdmin) {
    return NextResponse.json({ error: 'Supabase admin client not configured' }, { status: 500 });
  }

  const adminCheck = await requireAdmin(_req);
  if ('response' in adminCheck) {
    return adminCheck.response;
  }

  const { id } = await context.params;

  try {
    const { error } = await supabaseAdmin.from('products').delete().eq('id', id);

    if (error) {
      console.error('Error deleting product:', error);
      return NextResponse.json({ error: 'Failed to delete product.' }, { status: 500 });
    }

    // Revalidate public listings
    revalidatePath('/products');
    revalidatePath('/products/list');
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Unexpected error deleting product:', error);
    return NextResponse.json({ error: 'Unexpected error deleting product.' }, { status: 500 });
  }
}

