'use server';

import { NextResponse } from 'next/server';
import { processArticleMentions } from '../../../../lib/supabase-queries';
import supabaseAdmin from '../../../../lib/supabase-server-admin';
import { createServerClient } from '../../../../lib/supabase-server';
import { requireAdmin } from '../../../../lib/admin-auth';

async function getSupabaseClient() {
  if (supabaseAdmin) {
    return supabaseAdmin;
  }
  try {
    return await createServerClient();
  } catch (error) {
    console.error('Unable to create Supabase server client:', error);
    return null;
  }
}

export async function POST(request: Request) {
  try {
    const adminCheck = await requireAdmin(request);
    if ('response' in adminCheck) {
      return adminCheck.response;
    }

    const body = await request.json();
    const { content, title, briefDescription } = body || {};

    if (!content || typeof content !== 'string') {
      return NextResponse.json({ error: 'Content is required to process mentions.' }, { status: 400 });
    }

    const client = await getSupabaseClient();
    if (!client) {
      return NextResponse.json({ error: 'Supabase client unavailable.' }, { status: 500 });
    }

    const { processedContent, mentions } = await processArticleMentions(
      content,
      typeof title === 'string' ? title : undefined,
      typeof briefDescription === 'string' ? briefDescription : undefined,
      client
    );

    return NextResponse.json({ processedContent, mentions });
  } catch (error) {
    console.error('Error processing article mentions via API:', error);
    return NextResponse.json({ error: 'Failed to process article mentions.' }, { status: 500 });
  }
}

