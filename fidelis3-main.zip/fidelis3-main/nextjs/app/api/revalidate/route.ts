import { revalidatePath, revalidateTag } from 'next/cache'
import { NextRequest } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const secret = process.env.REVALIDATE_SECRET;
    const token =
      request.headers.get('x-revalidate-secret') ||
      request.headers.get('authorization')?.replace('Bearer ', '') ||
      '';

    if (!secret || token !== secret) {
      return Response.json(
        { revalidated: false, error: 'Unauthorized' },
        { status: 401 }
      );
    }

    const { path, tag } = await request.json()
    
    if (path) {
      revalidatePath(path)
    }
    
    if (tag) {
      revalidateTag(tag)
    }
    
    return Response.json({ 
      revalidated: true, 
      now: Date.now() 
    })
  } catch (error) {
    return Response.json({ 
      revalidated: false, 
      error: 'Revalidation failed' 
    }, { status: 500 })
  }
}