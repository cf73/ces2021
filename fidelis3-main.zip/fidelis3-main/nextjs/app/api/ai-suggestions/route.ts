import { NextRequest } from 'next/server';
import { getProductById, getAllProducts } from '../../../lib/supabase-queries';
import { generateProductSuggestions } from '../../../lib/ai-suggestions';
import { requireAdmin } from '../../../lib/admin-auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  console.log('🚀 AI Suggestions API called');
  try {
    const adminCheck = await requireAdmin(request);
    if ('response' in adminCheck) {
      return adminCheck.response;
    }

    const { productId } = await request.json();
    console.log('🚀 Product ID:', productId);
    
    if (!productId) {
      console.error('🚀 No product ID provided');
      return Response.json({ error: 'Product ID is required' }, { status: 400 });
    }
    
    console.log('🚀 Fetching product and all products...');
    // Get current product and all products
    const [currentProduct, allProducts] = await Promise.all([
      getProductById(productId),
      getAllProducts()
    ]);

    console.log('🚀 Current product:', currentProduct?.title);
    console.log('🚀 All products count:', allProducts.length);

    if (!currentProduct) {
      console.error('🚀 Product not found');
      return Response.json({ error: 'Product not found' }, { status: 404 });
    }

    console.log('🚀 Generating AI suggestions...');
    // Generate AI suggestions
    const suggestions = await generateProductSuggestions({
      currentProduct,
      allProducts
    });

    console.log('🚀 AI suggestions generated:', suggestions);

    // Cache suggestions for 1 hour
    return Response.json(suggestions, {
      headers: {
        'Cache-Control': 'public, max-age=3600'
      }
    });
  } catch (error) {
    console.error('🚀 AI suggestions error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    const errorStack = error instanceof Error ? error.stack : '';
    console.error('🚀 Error stack:', errorStack);
    return Response.json({
      pairsWellWith: [],
      alsoConsider: [],
      reasoning: `Error generating suggestions. Please try again. (${errorMessage})`
    }, { 
      status: 200  // Return 200 with empty arrays so UI doesn't break
    });
  }
}

