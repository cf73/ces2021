import { NextRequest, NextResponse } from 'next/server';
import { revalidatePath } from 'next/cache';
import supabaseAdmin from '../../../../lib/supabase-server-admin';
import { requireAdmin } from '../../../../lib/admin-auth';

type RouteContext = { params: Promise<{ id: string }> };

export async function DELETE(_req: NextRequest, context: RouteContext) {
  if (!supabaseAdmin) {
    return NextResponse.json({ error: 'Supabase admin client not configured' }, { status: 500 });
  }

  const adminCheck = await requireAdmin(_req);
  if ('response' in adminCheck) {
    return adminCheck.response;
  }

  const { id } = await context.params;

  try {
    const { error: categoryError } = await supabaseAdmin
      .from('manufacturer_categories')
      .delete()
      .eq('manufacturer_id', id);

    if (categoryError) {
      console.error('Error removing manufacturer categories:', categoryError);
      return NextResponse.json({ error: 'Failed to delete manufacturer categories.' }, { status: 500 });
    }

    const { error: productError } = await supabaseAdmin
      .from('products')
      .delete()
      .eq('manufacturer_id', id);

    if (productError) {
      console.error('Error deleting manufacturer products:', productError);
      return NextResponse.json({ error: 'Failed to delete manufacturer products.' }, { status: 500 });
    }

    const { error: manufacturerError } = await supabaseAdmin
      .from('manufacturers')
      .delete()
      .eq('id', id);

    if (manufacturerError) {
      console.error('Error deleting manufacturer:', manufacturerError);
      return NextResponse.json({ error: 'Failed to delete manufacturer.' }, { status: 500 });
    }

    revalidatePath('/manufacturers');
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Unexpected error deleting manufacturer:', error);
    return NextResponse.json({ error: 'Unexpected error deleting manufacturer.' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, context: RouteContext) {
  if (!supabaseAdmin) {
    return NextResponse.json({ error: 'Supabase admin client not configured' }, { status: 500 });
  }

  const adminCheck = await requireAdmin(req);
  if ('response' in adminCheck) {
    return adminCheck.response;
  }

  const { id } = await context.params;

  try {
    const body = await req.json();
    const { published } = body as { published?: boolean };

    if (typeof published !== 'boolean') {
      return NextResponse.json({ error: 'Published flag is required.' }, { status: 400 });
    }

    const { error: manufacturerError } = await supabaseAdmin
      .from('manufacturers')
      .update({ published, updated_at: new Date().toISOString() })
      .eq('id', id);

    if (manufacturerError) {
      console.error('Error updating manufacturer publish state:', manufacturerError);
      return NextResponse.json({ error: 'Failed to update manufacturer.' }, { status: 500 });
    }

    const { error: productError } = await supabaseAdmin
      .from('products')
      .update({ published })
      .eq('manufacturer_id', id);

    if (productError) {
      console.error('Error updating manufacturer products publish state:', productError);
      return NextResponse.json({ error: 'Failed to update manufacturer products.' }, { status: 500 });
    }

    revalidatePath('/manufacturers');
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Unexpected error updating manufacturer:', error);
    return NextResponse.json({ error: 'Unexpected error updating manufacturer.' }, { status: 500 });
  }
}