import { NextResponse } from 'next/server';
import supabaseAdmin from '../../../../lib/supabase-server-admin';
import { slugify } from '../../../../lib/utils';
import { requireAdmin } from '../../../../lib/admin-auth';

export async function GET() {
  if (!supabaseAdmin) {
    return NextResponse.json(
      { error: 'Supabase admin client not configured' },
      { status: 500 }
    );
  }

  try {
    const [{ data: categories, error: categoryError }, { data: products, error: productError }] =
      await Promise.all([
        supabaseAdmin
          .from('product_categories')
          .select('id, name, hero_product_id')
          .order('name'),
        supabaseAdmin
          .from('products')
          .select('id, title, slug, product_hero_image, category_id, published')
          .eq('published', true)
          .not('product_hero_image', 'is', null)
          .order('title'),
      ]);

    if (categoryError || productError) {
      throw new Error(categoryError?.message || productError?.message || 'Unknown Supabase error');
    }

    return NextResponse.json({
      categories: categories ?? [],
      products: products ?? [],
    });
  } catch (error) {
    console.error('Failed to load category hero data:', error);
    return NextResponse.json({ error: 'Failed to load data' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  if (!supabaseAdmin) {
    return NextResponse.json(
      { error: 'Supabase admin client not configured' },
      { status: 500 }
    );
  }

  const adminCheck = await requireAdmin(request);
  if ('response' in adminCheck) {
    return adminCheck.response;
  }

  try {
    const { name } = await request.json();
    if (!name || typeof name !== 'string') {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 });
    }

    const slug = slugify(name);
    const { data, error } = await supabaseAdmin
      .from('product_categories')
      .insert({ name, slug })
      .select('id, name, slug, hero_product_id')
      .single();

    if (error) throw error;

    return NextResponse.json({ category: data }, { status: 201 });
  } catch (error) {
    console.error('Failed to create category:', error);
    return NextResponse.json({ error: 'Failed to create category' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  if (!supabaseAdmin) {
    return NextResponse.json(
      { error: 'Supabase admin client not configured' },
      { status: 500 }
    );
  }

  const adminCheck = await requireAdmin(request);
  if ('response' in adminCheck) {
    return adminCheck.response;
  }

  try {
    const { id, name } = await request.json();
    if (!id || !name) {
      return NextResponse.json({ error: 'ID and name are required' }, { status: 400 });
    }

    const slug = slugify(name);
    const { data, error } = await supabaseAdmin
      .from('product_categories')
      .update({ name, slug })
      .eq('id', id)
      .select('id, name, slug, hero_product_id')
      .single();

    if (error) throw error;

    return NextResponse.json({ category: data });
  } catch (error) {
    console.error('Failed to rename category:', error);
    return NextResponse.json({ error: 'Failed to rename category' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  if (!supabaseAdmin) {
    return NextResponse.json(
      { error: 'Supabase admin client not configured' },
      { status: 500 }
    );
  }

  const adminCheck = await requireAdmin(request);
  if ('response' in adminCheck) {
    return adminCheck.response;
  }

  try {
    const { id } = await request.json();
    if (!id) {
      return NextResponse.json({ error: 'ID is required' }, { status: 400 });
    }

    const { error } = await supabaseAdmin
      .from('product_categories')
      .delete()
      .eq('id', id);

    if (error) {
      if (error.code === '23503') {
        return NextResponse.json(
          { error: 'Cannot delete category while products reference it' },
          { status: 400 }
        );
      }
      throw error;
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Failed to delete category:', error);
    return NextResponse.json({ error: 'Failed to delete category' }, { status: 500 });
  }
}

