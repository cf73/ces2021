import { NextResponse } from 'next/server';
import supabaseAdmin from '../../../../lib/supabase-server-admin';
import { requireAdmin } from '../../../../lib/admin-auth';

export async function GET(request: Request) {
  try {
    if (!supabaseAdmin) {
      return NextResponse.json(
        { error: 'Supabase admin client not initialized' },
        { status: 500 }
      );
    }

    const adminCheck = await requireAdmin(request);
    if ('response' in adminCheck) {
      return adminCheck.response;
    }

    const { data, error } = await supabaseAdmin
      .from('manufacturers')
      .select(
        `
          *,
          products:products!products_manufacturer_id_fkey(count)
        `
      )
      .order('name');

    if (error) {
      console.error('Error fetching manufacturers for globals modal:', error);
      return NextResponse.json({ error: 'Failed to load manufacturers' }, { status: 500 });
    }

    const manufacturers =
      data?.map((manufacturer: any) => ({
        ...manufacturer,
        product_count: manufacturer.products?.[0]?.count ?? 0,
      })) ?? [];

    return NextResponse.json({ manufacturers });
  } catch (error) {
    console.error('Unexpected error loading manufacturers for globals modal:', error);
    return NextResponse.json({ error: 'Unexpected error fetching manufacturers' }, { status: 500 });
  }
}

