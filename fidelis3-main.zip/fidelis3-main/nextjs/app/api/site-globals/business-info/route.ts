import { NextResponse } from 'next/server';
import { getBusinessInfo } from '../../../../lib/supabase-queries';
import supabaseAdmin from '../../../../lib/supabase-server-admin';
import { createServerClient } from '../../../../lib/supabase-server';
import { requireAdmin } from '../../../../lib/admin-auth';

async function getClient(requireAdmin = false) {
  if (supabaseAdmin) {
    return supabaseAdmin;
  }
  if (requireAdmin) {
    return null;
  }
  try {
    return await createServerClient();
  } catch (error) {
    console.error('Unable to create Supabase client for business info route:', error);
    return null;
  }
}

export async function GET() {
  try {
    const client = await getClient();
    if (!client) {
      return NextResponse.json({ error: 'Unable to load business info.' }, { status: 500 });
    }

    const info = await getBusinessInfo(client);
    return NextResponse.json(info);
  } catch (error) {
    console.error('Error fetching business info:', error);
    return NextResponse.json({ error: 'Failed to load business info.' }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  if (!supabaseAdmin) {
    return NextResponse.json({ error: 'Supabase admin client not configured.' }, { status: 500 });
  }

  const adminCheck = await requireAdmin(request);
  if ('response' in adminCheck) {
    return adminCheck.response;
  }

  try {
    const payload = await request.json();

    const { data: existingRow, error: fetchError } = await supabaseAdmin
      .from('site_business_info')
      .select('id')
      .order('updated_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (fetchError) {
      console.error('Error fetching existing business info row:', fetchError);
      return NextResponse.json({ error: 'Failed to load current business info.' }, { status: 500 });
    }

    const targetId = payload.id || existingRow?.id || null;
    const sanitizedHours = Array.isArray(payload.store_hours) ? payload.store_hours : [];

    const { error } = await supabaseAdmin
      .from('site_business_info')
      .upsert(
        {
          ...payload,
          id: targetId || undefined,
          store_hours: sanitizedHours,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'id' }
      )
      .select('*')
      .single();

    if (error) {
      console.error('Error updating business info:', error);
      return NextResponse.json({ error: 'Failed to update business info.' }, { status: 500 });
    }

    const latest = await getBusinessInfo(supabaseAdmin);
    return NextResponse.json(latest);
  } catch (error) {
    console.error('Unexpected error updating business info:', error);
    return NextResponse.json({ error: 'Failed to update business info.' }, { status: 500 });
  }
}

