import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { checkRateLimit } from '../../../lib/rate-limit';
import { sanitizeText } from '../../../lib/sanitize';

type ContactPayload = {
  name: string;
  email: string;
  subject: string;
  message: string;
  source?: string;
  company?: string; // honeypot
};

export async function POST(request: NextRequest) {
  try {
    const ip =
      request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      request.headers.get('x-real-ip') ||
      'anonymous';

    const { allowed } = checkRateLimit(`contact:${ip}`, {
      capacity: 5,
      intervalMs: 10 * 60 * 1000,
    });

    if (!allowed) {
      return NextResponse.json(
        { error: 'Too many requests. Please try again later.' },
        { status: 429 }
      );
    }

    const body = (await request.json().catch(() => ({}))) as Partial<ContactPayload>;
    const name = (body.name || '').trim();
    const email = (body.email || '').trim();
    const subject = (body.subject || '').trim();
    const message = (body.message || '').trim();
    const source = body.source?.trim();
    const company = (body.company || '').trim();

    // Honeypot: silently succeed without side effects
    if (company) {
      return NextResponse.json({ success: true });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!name || !email || !subject || !message || !emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'All fields are required and email must be valid.' },
        { status: 400 }
      );
    }

    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseServiceKey = process.env.SUPABASE_SECRET_KEY;
    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('Missing Supabase configuration');
      return NextResponse.json(
        { error: 'Server configuration error' },
        { status: 500 }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const submittedAt = new Date().toISOString();
    const messageWithSource = source ? `${message}\n\nSource: ${source}` : message;

    const { data: submission, error: dbError } = await supabase
      .from('contact_submissions')
      .insert({
        name,
        email,
        subject,
        message: messageWithSource,
        submitted_at: submittedAt,
      })
      .select()
      .single();

    if (dbError) {
      console.error('Database error:', dbError);
      return NextResponse.json(
        { error: 'Failed to save submission' },
        { status: 500 }
      );
    }

    const resendApiKey = process.env.RESEND_API_KEY;
    if (resendApiKey) {
      const bcc = (process.env.CONTACT_BCC || '')
        .split(',')
        .map(entry => entry.trim())
        .filter(Boolean);

      try {
        const emailResponse = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${resendApiKey}`,
          },
          body: JSON.stringify({
            from: 'Fidelis AV Contact Form <contact@fidelisav.com>',
            to: ['marc@fidelisav.com'],
            bcc: bcc.length > 0 ? bcc : undefined,
            reply_to: email,
            subject: `Contact Form: ${subject}`,
            html: `
              <h2>New Contact Form Submission</h2>
              <p><strong>From:</strong> ${sanitizeText(name)} (${sanitizeText(email)})</p>
              <p><strong>Subject:</strong> ${sanitizeText(subject)}</p>
              <hr />
              <p>${sanitizeText(messageWithSource).replace(/\n/g, '<br>')}</p>
              <hr />
              <p style="color: #666; font-size: 12px;">
                Submitted at: ${new Date().toLocaleString()}<br>
                Submission ID: ${submission?.id || 'n/a'}
              </p>
            `,
          }),
        });

        if (!emailResponse.ok) {
          const emailError = await emailResponse.text();
          console.error('Resend error:', emailError);
        }
      } catch (emailError) {
        console.error('Email notification error:', emailError);
      }
    }

    return NextResponse.json({
      success: true,
      message: 'Thank you for your message. We will get back to you soon!',
      submissionId: submission?.id,
    });
  } catch (error) {
    console.error('Contact form error:', error);
    return NextResponse.json(
      { error: 'An unexpected error occurred' },
      { status: 500 }
    );
  }
}
