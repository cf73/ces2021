import { NextRequest } from 'next/server';
import { getProductById, adminGetAllProducts } from '../../../lib/supabase-queries';
import {
  ensureProductRelationships,
  generateProductRelationshipsPreview,
  generateRelationshipCopyForSelections
} from '../../../lib/generate-relationships-server';
import { checkRateLimit } from '../../../lib/rate-limit';
import { requireAdmin } from '../../../lib/admin-auth';
import { formatAnthropicError } from '../../../lib/anthropic-config';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * API route to manually trigger AI generation for a product
 * Supports dry-run mode (dryRun: true) which returns suggestions without saving
 * In dry-run mode, changes should be tracked in EditModeContext and saved via handleSave
 */
export async function POST(request: NextRequest) {
  console.log('🤖 Manual AI Generation API called');
  try {
    const adminCheck = await requireAdmin(request);
    if ('response' in adminCheck) {
      return adminCheck.response;
    }

    // Basic rate limiting: 20 requests / 5 minutes per IP
    const ip =
      request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      request.headers.get('x-real-ip') ||
      'anonymous';
    const { allowed, remaining } = checkRateLimit(`ai-gen:${ip}`);
    if (!allowed) {
      return Response.json(
        { error: 'Rate limit exceeded. Please wait before trying again.' },
        { status: 429 }
      );
    }

    const {
      productId,
      dryRun,
      regenerateTextOnly,
      sections,
      overrides
    } = await request.json();
    console.log('🤖 Product ID:', productId, 'Dry run:', dryRun);
    
    if (!productId) {
      console.error('🤖 No product ID provided');
      return Response.json({ error: 'Product ID is required' }, { status: 400 });
    }
    
    console.log('🤖 Fetching product and all products...');
    // Get current product and all products (admin: include unpublished)
    const [currentProduct, allProducts] = await Promise.all([
      getProductById(productId),
      adminGetAllProducts()
    ]);

    console.log('🤖 Current product:', currentProduct?.title);
    console.log('🤖 All products count:', allProducts.length);

    if (!currentProduct) {
      console.error('🤖 Product not found');
      return Response.json({ error: 'Product not found' }, { status: 404 });
    }

    if (regenerateTextOnly) {
      const sectionsToUpdate = {
        pairs: sections?.pairs !== false,
        also: sections?.also !== false
      };

      if (!sectionsToUpdate.pairs && !sectionsToUpdate.also) {
        return Response.json(
          { error: 'Select at least one section to regenerate.' },
          { status: 400 }
        );
      }

      const copy = await generateRelationshipCopyForSelections(
        currentProduct,
        allProducts,
        {
          pairsSelection:
            overrides?.pairs_well_with ??
            currentProduct.pairs_well_with ??
            [],
          alsoSelection:
            overrides?.also_consider ??
            currentProduct.also_consider ??
            [],
          regeneratePairs: sectionsToUpdate.pairs,
          regenerateAlso: sectionsToUpdate.also
        }
      );

      if (!copy) {
        return Response.json(
          { error: 'Failed to regenerate relationship copy.' },
          { status: 500 }
        );
      }

      return Response.json({
        success: true,
        message: 'Relationship copy generated for current selections.',
        dryRun: true,
        preview: {
          ...copy,
          pairs_well_with:
            overrides?.pairs_well_with ??
            currentProduct.pairs_well_with ??
            [],
          also_consider:
            overrides?.also_consider ??
            currentProduct.also_consider ??
            []
        }
      });
    }

    if (dryRun) {
      // Dry-run mode: generate suggestions without saving
      console.log('🤖 Dry-run mode: generating preview without saving...');
      const preview = await generateProductRelationshipsPreview(currentProduct, allProducts);
      
      if (!preview) {
        return Response.json({
          error: 'Failed to generate AI suggestions'
        }, { status: 500 });
      }
      
      const goodSynergiesCount = preview.pairs_well_with?.length || 0;
      const alsoConsiderCount = preview.also_consider?.length || 0;
      
      console.log('🤖 Preview generated successfully');
      return Response.json({
        success: true,
        message: 'AI content generated (preview mode)',
        dryRun: true,
        preview: preview,
        goodSynergies: goodSynergiesCount,
        alsoConsider: alsoConsiderCount
      });
    } else {
      // Normal mode: generate and save directly (for backward compatibility)
      console.log('🤖 Calling ensureProductRelationships...');
      const wasGenerated = await ensureProductRelationships(currentProduct, allProducts);

      // Fetch updated product to get the counts
      const updatedProduct = await getProductById(productId);
      const goodSynergiesCount = updatedProduct?.pairs_well_with?.length || 0;
      const alsoConsiderCount = updatedProduct?.also_consider?.length || 0;

      if (wasGenerated) {
        console.log('🤖 Successfully generated and saved AI content');
        return Response.json({
          success: true,
          message: 'AI content generated successfully',
          goodSynergies: goodSynergiesCount,
          alsoConsider: alsoConsiderCount
        });
      } else {
        console.log('🤖 Product already had complete relationships');
        return Response.json({
          success: true,
          message: 'Product already has complete AI content',
          alreadyComplete: true,
          goodSynergies: goodSynergiesCount,
          alsoConsider: alsoConsiderCount
        });
      }
    }

  } catch (error) {
    console.error('🤖 AI generation error:', error);
    const errorMessage = formatAnthropicError(error);

    return Response.json({
      error: errorMessage
    }, { 
      status: 500
    });
  }
}