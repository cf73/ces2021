'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { MagnifyingGlassIcon, ListBulletIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { useAuth } from '../../contexts/AuthContext';
import { getPreOwned, getImageUrl } from '../../lib/supabase-queries';
import { supabase } from '../../lib/supabase';
import type { PreOwned } from '../../lib/supabase';
import { 
  Section, 
  Container, 
  PreOwnedCard
} from '../../components/ui';
import { Header } from '../../components/Header';
import { FooterWithSignIn } from '../../components/FooterWithSignIn';
import { getRandomMusicalMessage } from '../../utils/musicalLoadingMessages';
import { PageLoadReveal } from '../../components/PageLoadReveal';
import { TradeInModal } from '../../components/TradeInModal';
import { EditBar } from '../../components/cms/EditBar';

export default function PreOwnedPage() {
  const { user } = useAuth();
  const [preOwnedItems, setPreOwnedItems] = useState<PreOwned[]>([]);
  const [filteredItems, setFilteredItems] = useState<PreOwned[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showLocalOnly, setShowLocalOnly] = useState(false);
  const [showInitialSpinner, setShowInitialSpinner] = useState(true);
  const [cardsVisible, setCardsVisible] = useState<boolean[]>([]);
  const [loadingMessage, setLoadingMessage] = useState('Loading...');
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);
  const [isBatchMode, setIsBatchMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isBatching, setIsBatching] = useState(false);
  const [batchError, setBatchError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'unpublished'>('all');

  // Update loading message on client side to avoid hydration mismatch
  useEffect(() => {
    setLoadingMessage(getRandomMusicalMessage());
  }, []);

  const fetchData = async (includeUnpublished: boolean) => {
    try {
      const data = await getPreOwned(includeUnpublished);
      console.log('[Pre-Owned Debug] Fetched items:', data.length);
      console.log('[Pre-Owned Debug] First item:', data[0]);
      console.log('[Pre-Owned Debug] First item images:', data[0]?.images);
      setPreOwnedItems(data);
      setFilteredItems(data);
      setSelectedIds(new Set());
      
      // Preload all first images
      const preloadPromises = data.map(item => {
        return new Promise<void>((resolve) => {
          if (item.images && item.images.length > 0) {
            const img = new Image();
            img.onload = () => resolve();
            img.onerror = () => resolve(); // Resolve even on error
            img.src = getImageUrl(item.images[0]);
          } else {
            resolve(); // No image to load
          }
        });
      });
      
      // Wait for all images to preload (with timeout)
      const preloadWithTimeout = Promise.race([
        Promise.all(preloadPromises),
        new Promise(resolve => setTimeout(resolve, 3000)) // 3 second timeout
      ]);
      
      await preloadWithTimeout;
      
      // Initialize cards as hidden
      setCardsVisible(new Array(data.length).fill(false));
      
      // Hide spinner and start sequential animation
      setShowInitialSpinner(false);
      
      // Trigger sequential card animation
      setTimeout(() => {
        data.forEach((_, index) => {
          setTimeout(() => {
            setCardsVisible(prev => {
              const newVisible = [...prev];
              newVisible[index] = true;
              return newVisible;
            });
          }, index * 80); // Fast 80ms intervals
        });
      }, 200); // Brief delay after spinner disappears
      
    } catch (error) {
      console.error('Error loading pre-owned data:', error);
      setPreOwnedItems([]);
      setFilteredItems([]);
      setShowInitialSpinner(false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData(false);
  }, []);

  useEffect(() => {
    if (user) {
      fetchData(true);
    }
  }, [user]);

  const toggleSelected = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleBatchUnpublish = async () => {
    if (!selectedIds.size) return;
    const confirm = window.confirm(`Unpublish ${selectedIds.size} selected item(s)?`);
    if (!confirm) return;

    setIsBatching(true);
    setBatchError(null);
    try {
      const { error } = await supabase
        .from('pre_owned')
        .update({ published: false })
        .in('id', Array.from(selectedIds));

      if (error) {
        throw error;
      }

      await fetchData(!!user);
    } catch (error: any) {
      console.error('Error batch unpublishing pre-owned items:', error);
      setBatchError(error.message || 'Failed to unpublish selected items.');
    } finally {
      setIsBatching(false);
    }
  };

  const handleBatchPublish = async () => {
    if (!selectedIds.size) return;
    const confirm = window.confirm(`Publish ${selectedIds.size} selected item(s)?`);
    if (!confirm) return;

    setIsBatching(true);
    setBatchError(null);
    try {
      const { error } = await supabase
        .from('pre_owned')
        .update({ published: true })
        .in('id', Array.from(selectedIds));

      if (error) {
        throw error;
      }

      await fetchData(!!user);
    } catch (error: any) {
      console.error('Error batch publishing pre-owned items:', error);
      setBatchError(error.message || 'Failed to publish selected items.');
    } finally {
      setIsBatching(false);
    }
  };

  const handleBatchDelete = async () => {
    if (!selectedIds.size) return;
    const confirm = window.confirm(
      `Delete ${selectedIds.size} selected item(s)? This cannot be undone.`
    );
    if (!confirm) return;

    setIsBatching(true);
    setBatchError(null);
    try {
      const { error } = await supabase
        .from('pre_owned')
        .delete()
        .in('id', Array.from(selectedIds));

      if (error) {
        throw error;
      }

      await fetchData(!!user);
    } catch (error: any) {
      console.error('Error batch deleting pre-owned items:', error);
      setBatchError(error.message || 'Failed to delete selected items.');
    } finally {
      setIsBatching(false);
    }
  };

  useEffect(() => {
    let filtered = preOwnedItems;

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(item =>
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Local only filter
    if (showLocalOnly) {
      filtered = filtered.filter(item => item.local_only);
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(item =>
        statusFilter === 'published' ? item.published !== false : item.published === false
      );
    }

    setFilteredItems(filtered);
    if (isBatchMode) {
      setSelectedIds(prev => {
        const visibleIds = new Set(filtered.map(item => item.id));
        const next = new Set([...prev].filter(id => visibleIds.has(id)));
        return next;
      });
    }
    
    // Reset and animate cards when filters change
    if (filtered.length !== filteredItems.length) {
      setCardsVisible(new Array(filtered.length).fill(false));
      setTimeout(() => {
        filtered.forEach((_, index) => {
          setTimeout(() => {
            setCardsVisible(prev => {
              const newVisible = [...prev];
              newVisible[index] = true;
              return newVisible;
            });
          }, index * 60); // Even faster for filter changes
        });
      }, 100);
    }
  }, [preOwnedItems, searchTerm, showLocalOnly, statusFilter, filteredItems.length, isBatchMode]);

  if (loading || showInitialSpinner) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fffcf9]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">{loadingMessage}</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <PageLoadReveal isLoading={loading || showInitialSpinner} minimumLoadTime={200} maxWaitTime={3000}>
        <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="min-h-screen bg-[#fffcf9] pt-24 footer-scroll-reveal"
      >
        <div className="relative z-10 bg-[#fffcf9]">
          <Header />
      
      {/* CMS Widget with Create New Functionality */}
      {user && (
        <EditBar
          createNewHref="/pre-owned/new"
          createNewLabel="Create Item"
        />
      )}

      {/* Hero Section */}
      <main id="main-content">
      <Section variant="hero" background="custom" customBackground="bg-warm-beige" className="-mt-4">
        <Container size="6xl">
          <div className="max-w-4xl">
            <h1 className="text-4xl lg:text-5xl xl:text-6xl font-light text-stone-900 leading-tight tracking-wide mb-6">Pre-Owned Equipment</h1>
            <div className="prose prose-stone prose-lg max-w-none text-stone-700 leading-relaxed">
              <p className="mb-6">
                Quality audio gear is built to last. Many of the components we sell pre-owned deliver performance that rivals or exceeds newer equipment at significantly higher prices.
              </p>
              <p className="mb-6">
                We thoroughly test and inspect every item before it goes on our floor. Each piece meets the same standards we apply to new equipment.
              </p>
              <p>
                Pre-owned gear offers serious value for both newcomers and seasoned audiophiles looking to upgrade or complete their systems.
              </p>
            </div>
          </div>
        </Container>
      </Section>

      {/* Results Grid */}
      <Section variant="compact" background="custom" customBackground="bg-[#fffcf9]">
        <Container size="6xl">
          <>
            {/* Unified Control Bar */}
            <div className="sticky top-24 z-20 mb-6 -mx-3">
              <div className="rounded-2xl border border-stone-200/70 bg-white/70 px-6 py-3 shadow-lg backdrop-blur-md">
                {/* Top row: Search, Local filter, Count, Batch toggle */}
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                    <div className="relative max-w-md w-full">
                      <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-stone-400" />
                      <input
                        type="text"
                        placeholder="Search..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full pl-10 pr-10 py-3 border border-stone-300 rounded-xl focus:ring-2 focus:ring-accent-500 focus:border-transparent transition-all duration-300 bg-white"
                      />
                      {searchTerm && (
                        <button
                          type="button"
                          onClick={() => setSearchTerm('')}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 transition-colors cursor-pointer"
                          aria-label="Clear search"
                        >
                          <XMarkIcon className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                    <label className="flex items-center gap-2 cursor-pointer whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={showLocalOnly}
                        onChange={(e) => setShowLocalOnly(e.target.checked)}
                        className="rounded border-stone-300 text-accent-600 focus:ring-accent-500"
                      />
                      <span className="text-sm text-stone-700">Local pickup only</span>
                    </label>
                  </div>
                  <div className="flex items-center gap-3 text-stone-600">
                    <span>
                      Showing {filteredItems.length} pre-owned item{filteredItems.length !== 1 ? 's' : ''}
                    </span>
                    {user && (
                      <button
                        type="button"
                        onClick={() => {
                          setIsBatchMode(prev => !prev);
                          setSelectedIds(new Set());
                          setBatchError(null);
                        }}
                        className={`inline-flex items-center justify-center h-9 w-9 rounded-full border transition-colors ${
                          isBatchMode
                            ? 'border-stone-900 bg-stone-900 text-white'
                            : 'border-stone-300 text-stone-700 hover:border-stone-400'
                        } cursor-pointer`}
                        aria-label={isBatchMode ? 'Exit select mode' : 'Enter select mode'}
                      >
                        <ListBulletIcon className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Batch mode controls - revealed when toggle is active */}
                {user && isBatchMode && (
                  <div className="mt-3 pt-3 border-t border-stone-200/70">
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="text-sm text-stone-700 font-medium">
                        {selectedIds.size} selected
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setSelectedIds(new Set(filteredItems.map(item => item.id)))}
                          disabled={filteredItems.length === 0 || selectedIds.size === filteredItems.length}
                          className="inline-flex items-center px-3 py-1.5 rounded-md border border-stone-300 text-stone-700 hover:border-stone-400 text-sm cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          Select all
                        </button>
                        <button
                          type="button"
                          onClick={() => setSelectedIds(new Set())}
                          disabled={selectedIds.size === 0}
                          className="inline-flex items-center px-3 py-1.5 rounded-md border border-stone-300 text-stone-700 hover:border-stone-400 text-sm cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          Deselect all
                        </button>
                      </div>
                      <div className="h-5 w-px bg-stone-300" />
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={handleBatchPublish}
                          disabled={isBatching || selectedIds.size === 0}
                          className="inline-flex items-center px-3 py-1.5 rounded-md border border-emerald-200 text-emerald-700 hover:border-emerald-300 text-sm cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          Publish
                        </button>
                        <button
                          type="button"
                          onClick={handleBatchUnpublish}
                          disabled={isBatching || selectedIds.size === 0}
                          className="inline-flex items-center px-3 py-1.5 rounded-md border border-stone-300 text-stone-700 hover:border-stone-400 text-sm cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          Unpublish
                        </button>
                        <button
                          type="button"
                          onClick={handleBatchDelete}
                          disabled={isBatching || selectedIds.size === 0}
                          className="inline-flex items-center px-3 py-1.5 rounded-md border border-red-200 text-red-700 hover:border-red-300 text-sm cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                          Delete
                        </button>
                      </div>
                      <div className="ml-auto flex items-center gap-2">
                        <span className="text-xs uppercase tracking-wide text-stone-500">View</span>
                        <select
                          value={statusFilter}
                          onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
                          className="rounded-md border border-stone-200 bg-white/70 px-3 py-1.5 text-sm text-stone-700 focus:border-stone-400 focus:outline-none cursor-pointer"
                          aria-label="Filter by status"
                        >
                          <option value="all">All</option>
                          <option value="published">Published</option>
                          <option value="unpublished">Unpublished</option>
                        </select>
                      </div>
                    </div>
                    {batchError && (
                      <div className="mt-2 text-sm text-red-600">{batchError}</div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {filteredItems.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-10">
                {filteredItems.map((item, index) => {
                  const href = item.published === false && user
                    ? `/pre-owned/${item.slug || item.id}?preview=1`
                    : `/pre-owned/${item.slug || item.id}`;
                  const isSelected = selectedIds.has(item.id);
                  return isBatchMode ? (
                    <div
                      key={item.id}
                      className={`relative h-full rounded-xl transition-all ${
                        isSelected ? 'bg-amber-50/80 border border-amber-200 shadow-[0_10px_30px_rgba(217,119,6,0.15)]' : ''
                      }`}
                      onClick={() => toggleSelected(item.id)}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(event) => {
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault();
                          toggleSelected(item.id);
                        }
                      }}
                    >
                      <div className="absolute top-3 right-3 z-10">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleSelected(item.id)}
                          onClick={(event) => event.stopPropagation()}
                          className="h-5 w-5 rounded border-stone-900 text-stone-900 focus:ring-stone-900 cursor-pointer"
                        />
                      </div>
                      <PreOwnedCard 
                        item={item} 
                        className="h-full" 
                        index={index}
                        isVisible={cardsVisible[index] || false}
                      showStatusBadge={!!user}
                      />
                    </div>
                  ) : (
                    <Link key={item.id} href={href} className="block h-full group">
                      <PreOwnedCard 
                        item={item} 
                        className="h-full" 
                        index={index}
                        isVisible={cardsVisible[index] || false}
                        showStatusBadge={!!user}
                      />
                    </Link>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-full border border-stone-200 bg-white text-stone-500">
                  <MagnifyingGlassIcon className="h-6 w-6" />
                </div>
                <h3 className="text-2xl font-light text-stone-900 mb-2">No items found</h3>
                <p className="text-stone-600">
                  Try adjusting your search criteria or check back later for new arrivals.
                </p>
              </div>
            )}
          </>
        </Container>
      </Section>

      {/* Trade-In Section */}
      <Section variant="compact" background="custom" customBackground="bg-warm-beige">
        <Container size="6xl">
          <div className="max-w-4xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="mb-8"
            >
              <h2 className="text-3xl lg:text-4xl font-light text-stone-900 mb-6">Trade In Your Gear</h2>
              <div className="prose prose-stone prose-lg max-w-none text-stone-700 leading-relaxed">
                <p className="mb-6">
                  Looking to upgrade? We accept quality audio equipment as trade toward new gear. 
                  Our team evaluates each piece fairly, considering current market value and condition.
                </p>
                <p className="mb-8">
                  From vintage classics to recent high-end components, we're interested in gear that 
                  meets our standards. Trade values can significantly reduce the cost of your next upgrade.
                </p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <button
                onClick={() => setIsTradeModalOpen(true)}
                className="inline-flex items-center gap-3 bg-stone-900 text-white px-8 py-4 font-medium tracking-wide hover:bg-stone-800 transition-all duration-300 shadow-sm hover:shadow-md group rounded-md cursor-pointer"
              >
                Get Trade-In Quote
                <svg className="w-4 h-4 group-hover:translate-x-0.5 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </motion.div>
          </div>
        </Container>
      </Section>
      </main>
      </div>

      </motion.div>
      </PageLoadReveal>
      <TradeInModal
        open={isTradeModalOpen}
        onClose={() => setIsTradeModalOpen(false)}
        defaultSubject="Trade-In Inquiry"
        defaultMessage="I'm interested in trading in my audio equipment. Here are the details:"
        source="pre-owned-page"
      />
      <FooterWithSignIn />
    </>
  );
}

