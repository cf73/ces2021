import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { getPreOwnedBySlug, getPreOwned } from '../../../lib/supabase-queries';
import PreOwnedDetailClient from './PreOwnedDetailClient';

// Enable ISR with 15 minute revalidation - on-demand revalidation handles updates
export const revalidate = 900;

// Pre-render all pre-owned pages at build time (plus handle 'new' for creating items)
export async function generateStaticParams() {
  try {
    const items = await getPreOwned();
    return items.map((item) => ({
      slug: item.slug || item.id, // Fall back to ID if no slug
    }));
  } catch (error) {
    console.error('Error generating static params for pre-owned:', error);
    return [];
  }
}

// Generate metadata for SEO
export async function generateMetadata({
  params,
  searchParams
}: {
  params: Promise<{ slug: string }>;
  searchParams?: Promise<{ preview?: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const resolvedSearchParams = searchParams ? await searchParams : undefined;
  const includeUnpublished = resolvedSearchParams?.preview === '1';
  // Handle 'new' item creation route
  if (slug === 'new') {
    return {
      title: 'Create New Pre-Owned Item | Fidelis AV',
      description: 'Add a new pre-owned item to the inventory',
    };
  }

  try {
    const item = await getPreOwnedBySlug(slug, includeUnpublished);
    
    if (!item) {
      return {
        title: 'Item Not Found | Fidelis AV',
      };
    }

    return {
      title: `${item.title} | Pre-Owned | Fidelis AV`,
      description: item.description?.substring(0, 155) || '',
      openGraph: {
        title: item.title,
        description: item.description?.substring(0, 155) || '',
        images: item.images?.[0] ? [
          {
            url: item.images?.[0],
            width: 1200,
            height: 630,
            alt: item.title,
          },
        ] : [],
      },
      twitter: {
        card: 'summary_large_image',
        title: item.title,
        description: item.description?.substring(0, 155) || '',
        images: item.images?.[0] ? [item.images?.[0]] : [],
      },
    };
  } catch (error) {
    console.error('Error generating metadata:', error);
    return {
      title: 'Pre-Owned | Fidelis AV',
    };
  }
}

// Server Component - fetches initial data for ISR
export default async function PreOwnedDetailPage({
  params,
  searchParams
}: {
  params: Promise<{ slug: string }>;
  searchParams?: Promise<{ preview?: string }>;
}) {
  const { slug } = await params;
  const resolvedSearchParams = searchParams ? await searchParams : undefined;
  const includeUnpublished = resolvedSearchParams?.preview === '1';
  // Handle 'new' item creation route
  if (slug === 'new') {
    return <PreOwnedDetailClient initialItem={null} slug="new" />;
  }

  try {
    // Fetch initial item data server-side
    const initialItem = await getPreOwnedBySlug(slug, includeUnpublished);
    
    if (!initialItem) {
      notFound();
    }

    // Pass initial data to client component
    return <PreOwnedDetailClient initialItem={initialItem} slug={slug} />;
  } catch (error) {
    console.error('Error loading item:', error);
    notFound();
  }
}
