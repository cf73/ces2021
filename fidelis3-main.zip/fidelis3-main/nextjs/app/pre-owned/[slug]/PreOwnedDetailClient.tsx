'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowLeftIcon, TagIcon, CalendarIcon } from '@heroicons/react/24/outline';
import { useAuth } from '../../../contexts/AuthContext';
import { useEditMode } from '../../../contexts/EditModeContext';
import { getPreOwnedBySlug } from '../../../lib/supabase-queries';
import { supabase } from '../../../lib/supabase';
import type { PreOwned } from '../../../lib/supabase';
import { getRandomMusicalMessage } from '../../../utils/musicalLoadingMessages';
import { Header } from '../../../components/Header';
import { FooterWithSignIn } from '../../../components/FooterWithSignIn';
import { slugify } from '../../../lib/utils';
import { PageLoadReveal } from '../../../components/PageLoadReveal';
import { EditBar } from '../../../components/cms/EditBar';
import { EditableText } from '../../../components/cms/EditableText';
import { EditableTextarea } from '../../../components/cms/EditableTextarea';
import { EditableNumber } from '../../../components/cms/EditableNumber';
import { EditableToggle } from '../../../components/cms/EditableToggle';
import { EditableDate } from '../../../components/cms/EditableDate';
import { EditableImageGallery } from '../../../components/cms/EditableImageGallery';
import { EditableRichText } from '../../../components/cms/EditableRichText';
import { DeleteConfirmation } from '../../../components/DeleteConfirmation';
import ProductGallery from '../../../components/ProductGallery';
import { PayPalButtonModern } from '../../../components/PayPalButtonModern';
import { StructuredData } from '../../../components/StructuredData';
import { generatePreOwnedProductSchema, generateBreadcrumbSchema } from '../../../lib/structured-data';

interface PreOwnedDetailClientProps {
  initialItem: PreOwned | null;
  slug: string;
}

export default function PreOwnedDetailClient({ initialItem, slug }: PreOwnedDetailClientProps) {
  const router = useRouter();
  const { user } = useAuth();
  const { isEditMode, toggleEditMode, getChanges, clearChanges, setIsSaving, setOriginalValues, registerChange } = useEditMode();
  
  const [item, setItem] = useState<PreOwned | null>(initialItem);
  const [loading, setLoading] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [editBarKey, setEditBarKey] = useState(0);

  // Handle "new" slug for creating new items
  const isNewItem = slug === 'new';

  // Automatically enable edit mode immediately for new items
  useEffect(() => {
    if (isNewItem && !isEditMode) {
      toggleEditMode(true); // Skip confirmation since user intent is clear
    }
  }, [isNewItem, isEditMode, toggleEditMode]);

  // If new item, create empty template
  useEffect(() => {
    if (isNewItem && !item) {
      const emptyItem: PreOwned = {
        id: 'new',
        title: '',
        slug: '',
        content: '',
        description: '',
        image: '',
        images: [],
        your_price: 0,
        new_retail_price: 0,
        hide_your_price: false,
        local_only: false,
        shipping: 0,
        original_accessories: '',
        published: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      setItem(emptyItem);
    }
  }, [isNewItem, item]);

  // Load item data when edit mode is toggled
  const loadItem = async () => {
    if (!slug || slug === 'new') return;
    
    try {
      setLoading(true);
      const data = await getPreOwnedBySlug(slug, !!user);
      if (data) {
        setEditBarKey(prev => prev + 1);
        setItem(data);
      }
    } catch (error) {
      console.error('Error loading item:', error);
    } finally {
      setLoading(false);
    }
  };

  // Refetch when edit mode is toggled
  useEffect(() => {
    if (isEditMode && !isNewItem && item) {
      // Set original values for comparison
      setOriginalValues({
        title: item.title,
        content: item.content,
        description: item.description,
        image: item.image,
        images: item.images,
        your_price: item.your_price,
        new_retail_price: item.new_retail_price,
        hide_your_price: item.hide_your_price,
        local_only: item.local_only,
        shipping: item.shipping,
        original_accessories: item.original_accessories
      });
      loadItem();
    }
  }, [isEditMode]);

  const handleSave = async () => {
    if (!item) return;

    setIsSaving(true);
    try {
      const changes = getChanges();

      if (Object.keys(changes).length === 0 && !isNewItem) {
        console.log('No changes to save');
        setIsSaving(false);
        return;
      }

      // If title changed, also update slug
      const dataToSave = { ...changes };
      if (changes.title) {
        dataToSave.slug = slugify(changes.title);
      }

      // Add updated_at timestamp
      dataToSave.updated_at = new Date().toISOString();

      if (isNewItem) {
        // Create new item
        const newItemData = {
          title: dataToSave.title || item.title || 'Untitled Item',
          slug: dataToSave.slug || slugify(dataToSave.title || item.title || 'untitled-item'),
          content: dataToSave.content || item.content || '',
          description: dataToSave.description || item.description || '',
          images: dataToSave.images || item.images || [],
          your_price: dataToSave.your_price !== undefined ? dataToSave.your_price : item.your_price || 0,
          new_retail_price: dataToSave.new_retail_price !== undefined ? dataToSave.new_retail_price : item.new_retail_price || 0,
          hide_your_price: dataToSave.hide_your_price !== undefined ? dataToSave.hide_your_price : false,
          local_only: dataToSave.local_only !== undefined ? dataToSave.local_only : false,
          shipping: dataToSave.shipping !== undefined ? dataToSave.shipping : item.shipping || 0,
          original_accessories: dataToSave.original_accessories || item.original_accessories || '',
          published: dataToSave.published !== undefined ? dataToSave.published : true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };

        const { data: newData, error: createError } = await supabase
          .from('pre_owned')
          .insert([newItemData])
          .select()
          .single();

        if (createError) {
          console.error('Error creating item:', createError);
          alert('Failed to create item. Please try again.');
          return;
        }

        if (newData) {
          console.log('✅ Item created successfully:', newData);
          clearChanges();
          // Redirect to the new item
          const nextSlug = newData.slug || newData.id;
          router.push(`/pre-owned/${nextSlug}?preview=1`);
        }
      } else {
        // Update existing item
        const { data: updateData, error: updateError } = await supabase
          .from('pre_owned')
          .update(dataToSave)
          .eq('id', item.id)
          .select();

        if (updateError) {
          console.error('Error saving item:', updateError);
          alert('Failed to save changes. Please try again.');
          return;
        }

        if (!updateData || updateData.length === 0) {
          console.error('Update returned no data');
          alert('Failed to update item. Please refresh and try again.');
          return;
        }

        console.log('✅ Item updated successfully:', updateData[0]);
        
        // Reload item data
        const { data: updatedItem, error: reloadError } = await supabase
          .from('pre_owned')
          .select('*')
          .eq('id', item.id)
          .single();
        
        if (reloadError) {
          console.error('Error reloading item:', reloadError);
        } else if (updatedItem) {
          setEditBarKey(prev => prev + 1);
          setItem(updatedItem);
        }
        
        clearChanges();
      }
      
      console.log('✅ Item saved successfully');
    } catch (error) {
      console.error('Error saving item:', error);
      alert('Failed to save changes. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    if (isNewItem) {
      router.push('/pre-owned');
    } else {
      loadItem();
    }
  };

  const handleTogglePublish = async (published: boolean) => {
    if (!item || isNewItem) return;
    
    try {
      const { data: updateResult, error } = await supabase
        .from('pre_owned')
        .update({ published })
        .eq('id', item.id)
        .select();
      
      if (error) {
        console.error('Error updating publish status:', error);
        alert('Failed to update publish status. Please try again.');
        return;
      }
      
      const { data: updatedItem, error: reloadError } = await supabase
        .from('pre_owned')
        .select('*')
        .eq('id', item.id)
        .single();
      
      if (reloadError) {
        console.error('Error reloading item:', reloadError);
      } else if (updatedItem) {
        console.log(`✅ Item ${published ? 'published' : 'unpublished'} successfully`);
        setItem(updatedItem);
      }
    } catch (error) {
      console.error('Error toggling publish status:', error);
      alert('Failed to update publish status. Please try again.');
    }
  };

  const handleDelete = async () => {
    if (!item || isNewItem) return;
    
    setDeleteLoading(true);
    try {
      const { error } = await supabase
        .from('pre_owned')
        .delete()
        .eq('id', item.id);
        
      if (error) {
        console.error('Error deleting item:', error);
        alert('Failed to delete item. Please try again.');
        return;
      }
      
      console.log('✅ Item deleted successfully');
      router.push('/pre-owned');
    } catch (error) {
      console.error('Error deleting item:', error);
      alert('Failed to delete item. Please try again.');
    } finally {
      setDeleteLoading(false);
      setIsDeleteModalOpen(false);
    }
  };

  const formatPrice = (price?: number) => {
    if (!price) return null;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-warm-white">
        <Header />
        <div className="min-h-screen bg-warm-white py-12">
          <div className="container-custom text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-stone-600 mx-auto"></div>
            <p className="mt-4 text-stone-600">{getRandomMusicalMessage()}</p>
          </div>
        </div>
      </div>
    );
  }

  if (!item) {
    return (
      <div className="min-h-screen bg-warm-white">
        <Header />
        <div className="min-h-screen bg-warm-white py-12">
          <div className="container-custom text-center">
            <h2 className="text-2xl font-bold text-stone-900 mb-4">Item Not Found</h2>
            <Link href="/pre-owned" className="btn-primary">
              Back to Pre-Owned
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const savings = item.your_price && item.new_retail_price 
    ? item.new_retail_price - item.your_price
    : null;

  const savingsPercentage = savings && item.new_retail_price
    ? (savings / item.new_retail_price) * 100
    : 0;

  // Generate structured data for SEO
  const preOwnedSchema = item ? generatePreOwnedProductSchema(item) : null;
  const breadcrumbSchema = item ? generateBreadcrumbSchema([
    { name: 'Home', url: 'https://fidelisav.com' },
    { name: 'Pre-Owned', url: 'https://fidelisav.com/pre-owned' },
    { name: item.title, url: `https://fidelisav.com/pre-owned/${item.slug || item.id}` }
  ]) : null;

  return (
    <PageLoadReveal isLoading={loading} minimumLoadTime={200} maxWaitTime={3000}>
      {/* SEO Structured Data */}
      {preOwnedSchema && <StructuredData data={[preOwnedSchema, breadcrumbSchema].filter(Boolean)} />}
      
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
        className="min-h-screen bg-warm-white pt-24 footer-scroll-reveal"
      >
        <div className="relative z-10 bg-warm-white">
          <Header />
          <main id="main-content">

          {/* Edit Bar */}
          {user && (
            <EditBar
              key={`editbar-${editBarKey}`}
              onSave={handleSave}
              onCancel={handleCancel}
              onTogglePublish={isNewItem ? undefined : handleTogglePublish}
              onDelete={isNewItem ? undefined : () => setIsDeleteModalOpen(true)}
              isPublished={item.published !== false}
            />
          )}

          {/* Hero Section */}
          <section className="bg-warm-beige border-b border-stone-200 -mt-4">
            <div className="pt-6 pb-16 lg:pb-24">
              {/* Back Link */}
              <div className="pl-[88px] pr-6 lg:pr-8 mb-12">
                <Link href="/pre-owned" className="inline-flex items-center text-stone-600 hover:text-stone-900 transition-colors duration-200">
                  <ArrowLeftIcon className="h-4 w-4 mr-2" />
                  Back to Pre-Owned
                </Link>
              </div>

              <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                {/* Item Info - Above Gallery */}
                <div className="max-w-4xl mx-auto text-center mb-12">
                  <h1 className="text-3xl lg:text-4xl xl:text-5xl font-light text-stone-900 leading-tight tracking-wide mb-6">
                    <EditableText
                      value={item.title}
                      fieldName="title"
                      fieldType="text"
                      placeholder="Item Title"
                      required
                      className="text-3xl lg:text-4xl xl:text-5xl font-light text-stone-900 leading-tight tracking-wide"
                    />
                  </h1>
                  
                  {/* Pricing */}
                  <div className="mb-6 space-y-4">
                    <EditableToggle
                      value={item.hide_your_price || false}
                      fieldName="hide_your_price"
                      label="Hide Price"
                      description="Control whether the price is displayed on the product page"
                    />
                    
                    {/* Always show price fields in CMS mode for editing, respect toggle in non-CMS mode */}
                    {(isEditMode || !(getChanges().hide_your_price ?? item.hide_your_price)) ? (
                      <div className="space-y-4">
                        <div className="flex items-center justify-center gap-4">
                          <div className="flex flex-col items-center gap-2">
                            <label className="text-sm font-medium text-stone-600 uppercase tracking-wide">Your Price</label>
                            <EditableNumber
                              value={item.your_price}
                              fieldName="your_price"
                              prefix="$"
                              step={1}
                              min={0}
                              placeholder="0"
                              className="text-2xl"
                              displayClassName="text-2xl font-light text-stone-900"
                            />
                          </div>
                          {(isEditMode || item.new_retail_price) && (
                            <div className="flex flex-col items-center gap-2">
                              <label className="text-sm font-medium text-stone-600 uppercase tracking-wide">New Retail Price</label>
                              <EditableNumber
                                value={item.new_retail_price}
                                fieldName="new_retail_price"
                                prefix="$"
                                step={1}
                                min={0}
                                placeholder="0"
                                className="text-2xl"
                                displayClassName="text-2xl text-stone-500 line-through"
                              />
                            </div>
                          )}
                        </div>
                        
                        {!isEditMode && savings && (
                          <div className="flex items-center justify-center gap-2 text-lg">
                            <TagIcon className="h-5 w-5 text-stone-600" />
                            <span className="text-stone-600 font-medium">
                              Save {formatPrice(savings)} ({savingsPercentage.toFixed(0)}% off)
                            </span>
                          </div>
                        )}
                        
                        {/* PayPal Buy Now Button - Only show in non-CMS mode */}
                        {!isEditMode && item.your_price && !item.local_only && (
                          <div className="mt-8 flex justify-center">
                            <PayPalButtonModern
                              itemName={item.title}
                              amount={item.your_price}
                              shipping={item.shipping || 0}
                              localOnly={item.local_only || false}
                            />
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="flex justify-center">
                        <Link
                          href={`/contact?subject=${encodeURIComponent(`Pricing Inquiry: ${item.title}`)}&message=${encodeURIComponent(`I'm interested in learning more about the pricing for ${item.title}. Please contact me with more information.`)}`}
                          className="inline-flex items-center px-6 py-3 border-2 border-stone-900 text-stone-900 font-medium tracking-wide uppercase hover:bg-stone-900 hover:text-white transition-all duration-300 rounded-md"
                        >
                          Call for Price
                        </Link>
                      </div>
                    )}
                    
                    <EditableToggle
                      value={item.local_only || false}
                      fieldName="local_only"
                      label="Local/Showroom Only"
                      description="Item is only available for viewing and pickup in showroom"
                    />
                  </div>
                </div>

                {/* Large Image Gallery */}
                <div className="mb-16">
                  {item.images && item.images.length > 0 ? (
                    <div className="max-w-4xl mx-auto">
                      {isEditMode ? (
                        <EditableImageGallery
                          value={item.images}
                          fieldName="images"
                          folder="pre-owned"
                          maxImages={10}
                        />
                      ) : (
                        <ProductGallery images={item.images} itemTitle={item.title} />
                      )}
                    </div>
                  ) : (
                    <div className="max-w-2xl mx-auto aspect-w-1 aspect-h-1 bg-stone-100 rounded-lg flex items-center justify-center">
                      {isEditMode ? (
                        <EditableImageGallery
                          value={item.images || []}
                          fieldName="images"
                          folder="pre-owned"
                          maxImages={10}
                        />
                      ) : (
                        <p className="text-stone-500">No images available</p>
                      )}
                    </div>
                  )}
                </div>

                {/* Additional Details - Below Gallery */}
                <div className="max-w-4xl mx-auto">
                  {/* Description */}
                  {(isEditMode || item.description) && (
                    <div className="mb-8 text-center">
                      <div className="prose max-w-none mx-auto">
                        <EditableRichText
                          value={item.description || ''}
                          fieldName="description"
                          placeholder="Detailed description of the item..."
                        />
                      </div>
                    </div>
                  )}

                  {/* Details - Centered Group */}
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-8 mb-8 text-center">
                    {(isEditMode || item.original_accessories) && (
                      <div className="flex flex-col items-center gap-2">
                        <div>
                          <h4 className="font-semibold text-stone-900">Original Accessories</h4>
                          <EditableTextarea
                            value={item.original_accessories || ''}
                            fieldName="original_accessories"
                            placeholder="e.g., Original box, manual"
                            rows={4}
                            className="text-stone-600 text-center"
                          />
                        </div>
                      </div>
                    )}
                    
                    {(isEditMode || item.shipping !== null) && (
                      <div className="flex flex-col items-center gap-2">
                        <div>
                          <h4 className="font-semibold text-stone-900">Shipping</h4>
                          {isEditMode ? (
                            <EditableNumber
                              value={item.shipping}
                              fieldName="shipping"
                              prefix="$"
                              step={1}
                              min={0}
                              placeholder="0"
                              displayClassName="text-stone-600"
                            />
                          ) : (
                            <p className="text-stone-600">
                              {item.shipping === 0 ? 'Free shipping' : formatPrice(item.shipping || 0)}
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Trade-In Section */}
          {!isEditMode && (
            <section className="bg-warm-beige py-16">
              <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 className="text-3xl font-light text-stone-900 mb-4 tracking-wide">Have Equipment to Trade?</h2>
                <p className="text-lg text-stone-700 mb-8 leading-relaxed max-w-2xl mx-auto">
                  We accept trade-ins on high-end audio equipment. Get in touch to discuss your gear.
                </p>
                <Link
                  href="/contact?inquiry=trade-in"
                  className="inline-flex items-center px-8 py-4 bg-stone-900 text-white font-medium hover:bg-stone-800 transition-all duration-300 shadow-sm hover:shadow-md"
                >
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                  </svg>
                  Inquire About Trade-In
                </Link>
              </div>
            </section>
          )}

          {/* Delete Confirmation Modal */}
          {!isNewItem && (
            <DeleteConfirmation
              isOpen={isDeleteModalOpen}
              onClose={() => setIsDeleteModalOpen(false)}
              onConfirm={handleDelete}
              title="Delete Pre-Owned Item"
              message={`Are you sure you want to delete "${item.title}"? This action cannot be undone.`}
              loading={deleteLoading}
            />
          )}
          </main>
        </div>

        {/* Footer */}
        <FooterWithSignIn />
      </motion.div>
    </PageLoadReveal>
  );
}
