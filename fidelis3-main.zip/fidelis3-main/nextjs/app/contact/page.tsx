'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { Section, Grid, Container, H2, H3, Body } from '../../components/ui';
import { TestimonialsSection } from '../../components/TestimonialsSection';
import { Header } from '../../components/Header';
import { FooterWithSignIn } from '../../components/FooterWithSignIn';
import { PageLoadReveal } from '../../components/PageLoadReveal';
import { useSiteGlobals } from '../../contexts/SiteGlobalsContext';

function ContactForm() {
  const searchParams = useSearchParams();
  const { businessInfo } = useSiteGlobals();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
    company: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    const product = searchParams?.get('product');
    const manufacturer = searchParams?.get('manufacturer');
    const demo = searchParams?.get('demo');
    const inquiry = searchParams?.get('inquiry');
    const urlSubject = searchParams?.get('subject');
    const urlMessage = searchParams?.get('message');
    
    const productWithManufacturer = manufacturer ? `${manufacturer} ${product}` : product;
    
    if (product && demo === 'store') {
      setFormData({
        name: '',
        email: '',
        subject: `Store Demo Request: ${productWithManufacturer}`,
        message: `I would like to schedule a store demo for the ${productWithManufacturer}. Please let me know what times are available.`,
        company: '',
      });
    } else if (product && demo === 'home') {
      setFormData({
        name: '',
        email: '',
        subject: `Home Demo Request: ${productWithManufacturer}`,
        message: `I would like to schedule a home demo for the ${productWithManufacturer}. Please let me know what times are available and what the process involves.`,
        company: '',
      });
    } else if (product && demo === 'request') {
      setFormData({
        name: '',
        email: '',
        subject: `Demo Request: ${productWithManufacturer}`,
        message: `I would like to schedule a demo for the ${productWithManufacturer}. Please let me know what demo options are available.`,
        company: '',
      });
    } else if (product && inquiry === 'pricing') {
      setFormData({
        name: '',
        email: '',
        subject: `Pricing Inquiry: ${productWithManufacturer}`,
        message: `I would like to know more about pricing and availability for the ${productWithManufacturer}. Please provide details about current pricing, any available promotions, and delivery options.`,
        company: '',
      });
    } else if (urlSubject || urlMessage) {
      setFormData(prev => ({
        ...prev,
        subject: urlSubject || prev.subject,
        message: urlMessage || prev.message
      }));
    }
  }, [searchParams]);

  const addressLines = [
    businessInfo?.address_line1 || '460 Amherst Street',
    businessInfo?.address_line2 || '',
    [businessInfo?.city || 'Nashua', businessInfo?.state || 'NH', businessInfo?.postal_code || '03063']
      .filter(Boolean)
      .join(', '),
  ].filter(Boolean);

  const phoneDisplay = businessInfo?.phone || '603-880-4434';
  const emailDisplay = businessInfo?.email || 'marc@fidelisav.com';
  const contactDescription =
    businessInfo?.short_description ||
    "Get in touch with us for any questions about our products or services. We're here to help you find the perfect audio solution.";

  const hours =
    businessInfo?.store_hours && businessInfo.store_hours.length > 0
      ? businessInfo.store_hours
      : [
          { label: 'Tuesday-Friday', value: '10:00 AM - 6:00 PM' },
          { label: 'Saturday', value: '10:00 AM - 4:00 PM' },
          { label: 'Sunday', value: 'Closed' },
          { label: 'Monday', value: 'By Appointment' },
        ];

  const specialNotice = businessInfo?.special_notice?.trim();

  const mapEmbedSrc =
    businessInfo?.google_map_url ||
    'https://www.google.com/maps?q=460+Amherst+Street,+Nashua,+NH+03063&output=embed';

  const virtualTourSrc =
    businessInfo?.virtual_tour_url ||
    'https://www.google.com/maps/embed?pb=!4v1759346143448!6m8!1m7!1sCAoSHENJQUJJaENJWC04Sl9BNWxhb1RqZ09qTS0zdFg.!2m2!1d42.78934369153347!2d-71.51902378620517!3f297.86!4f-2.3499999999999943!5f0.4000000000000002';

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Reset status when user starts typing again
    if (submitStatus !== 'idle') {
      setSubmitStatus('idle');
      setErrorMessage('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          source: 'contact-page',
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to send message');
      }

      setSubmitStatus('success');
      // Reset form
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: '',
        company: ''
      });
    } catch (error) {
      console.error('Form submission error:', error);
      setSubmitStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-warm-cream pt-24 footer-scroll-reveal">
      <div className="relative z-10 bg-warm-cream">
        <Header />
        
        <main id="main-content">
        {/* Hero Section */}
        <Section variant="hero" background="custom" customBackground="bg-warm-beige" className="-mt-4">
          <Container size="6xl">
            <div className="max-w-4xl mx-auto">
              <h1 className="text-4xl lg:text-5xl xl:text-6xl font-light text-stone-900 leading-tight tracking-wide mb-6">Contact Us</h1>
              <div className="prose prose-stone prose-lg max-w-none text-stone-700 leading-relaxed">
                {contactDescription}
              </div>
            </div>
          </Container>
        </Section>

        {/* Contact Content */}
        <Section variant="default" background="white">
          <Container size="6xl">
            <div className="max-w-4xl mx-auto">
              <Grid cols={2} gap="xl">
                {/* Contact Information */}
                <div>
                  <H2 className="mb-6">Get in Touch</H2>
                  
                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <svg className="h-6 w-6 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-stone-900">Address</p>
                        <div className="text-sm text-stone-600">
                          {addressLines.map((line, idx) => (
                            <span key={`address-line-${idx}`}>
                              {idx > 0 && <br />}
                              {line}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <svg className="h-6 w-6 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-stone-900">Phone</p>
                        <p className="text-sm text-stone-600">{phoneDisplay}</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <svg className="h-6 w-6 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-stone-900">Email</p>
                        <p className="text-sm text-stone-600">{emailDisplay}</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="flex-shrink-0">
                        <svg className="h-6 w-6 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-stone-900">Hours</p>
                        <div className="text-sm text-stone-600">
                          {hours.map((entry, idx) => (
                            <div key={`hours-${idx}`}>
                              {entry.label}{entry.value ? `: ${entry.value}` : ''}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {specialNotice && (
                      <div className="flex items-start">
                        <div className="flex-shrink-0">
                          <svg className="h-6 w-6 text-stone-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-stone-900">Special Notice</p>
                          <p className="text-sm text-stone-600 leading-relaxed whitespace-pre-line">
                            {specialNotice}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Contact Form */}
                <div>
                  <H2 className="mb-6">Send us a Message</H2>
                  
                  {submitStatus === 'success' && (
                    <div className="mb-6 p-4 bg-green-50 border-2 border-green-500 rounded-lg">
                      <p className="text-green-800 font-medium">
                        Thank you for your message! We'll get back to you soon.
                      </p>
                    </div>
                  )}

                  {submitStatus === 'error' && (
                    <div className="mb-6 p-4 bg-red-50 border-2 border-red-500 rounded-lg">
                      <p className="text-red-800 font-medium">
                        {errorMessage || 'There was an error sending your message. Please try again or email us directly.'}
                      </p>
                    </div>
                  )}
                  
                  <form className="space-y-4" onSubmit={handleSubmit}>
                    <input
                      type="text"
                      name="company"
                      value={formData.company}
                      onChange={handleInputChange}
                      tabIndex={-1}
                      autoComplete="off"
                      aria-hidden="true"
                      className="hidden"
                    />
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-stone-700 mb-1">
                        Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-stone-300 rounded-md focus:outline-none focus:ring-2 focus:ring-stone-500 focus:border-transparent"
                        placeholder="Your name"
                      />
                    </div>

                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-stone-700 mb-1">
                        Email
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-stone-300 rounded-md focus:outline-none focus:ring-2 focus:ring-stone-500 focus:border-transparent"
                        placeholder="your.email@example.com"
                      />
                    </div>

                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium text-stone-700 mb-1">
                        Subject
                      </label>
                      <input
                        type="text"
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-stone-300 rounded-md focus:outline-none focus:ring-2 focus:ring-stone-500 focus:border-transparent"
                        placeholder="What can we help you with?"
                      />
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-stone-700 mb-1">
                        Message
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        rows={12}
                        value={formData.message}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-stone-300 rounded-md focus:outline-none focus:ring-2 focus:ring-stone-500 focus:border-transparent resize-y"
                        placeholder="Tell us more about your inquiry..."
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full bg-stone-900 text-white py-4 px-6 font-medium tracking-wide hover:bg-stone-800 transition-all duration-300 shadow-sm hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? 'Sending...' : 'Send Message'}
                    </button>
                  </form>
                </div>
              </Grid>
            </div>
          </Container>
        </Section>

        {/* Testimonials Section */}
        <TestimonialsSection className="bg-stone-50" />

        {/* About Fidelis Section */}
        <Section variant="default" background="white">
          <Container size="6xl">
            <div className="max-w-4xl mx-auto">
              <H2 className="mb-8">About Fidelis</H2>
              <div className="prose prose-stone prose-lg max-w-none text-stone-700 leading-relaxed">
                <p className="mb-6">
                  As America's premiere importer and distributor of high-end audio gear, we source and import the world's finest equipment directly from manufacturers. What you'll find here comes from decades of relationships with the most respected names in audio, sold through our New Hampshire store and distributed nationwide through our dealer network.
                </p>
                <p className="mb-6">
                  In a world of warehouses and return policies that don't support manufacturers, we believe in curation, guidance, and real service. Every recommendation comes from hands-on experience with the gear, not algorithms or sales targets. We're here to help you navigate choices that matter, backed by expertise you can trust.
                </p>
                <p>
                  We host listening events, maintain one of New England's finest record collections, and believe the best audio discoveries happen through conversation. Come by the store, bring your favorite music, and experience the difference that genuine expertise and passion make.
                </p>
              </div>
            </div>
          </Container>
        </Section>

        {/* Showroom Section */}
        <Section variant="default" background="stone-50">
          <Container size="6xl">
            <div className="max-w-4xl mx-auto">
              <H2 className="mb-6">Visit Our Showroom</H2>
              <div className="rounded-xl overflow-hidden border border-stone-200 shadow-sm">
                <iframe
                  title="Fidelis Location"
                  src={mapEmbedSrc}
                  width="100%"
                  height="360"
                  style={{ border: 0 }}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
              <Body className="mt-4 text-stone-600">
                We welcome visitors to our showroom where you can experience our products firsthand. 
                Please call ahead to schedule an appointment for a personalized demonstration.
              </Body>
              
              {/* Virtual Tour Section */}
              <div className="mt-8">
                <H3 className="mb-4">Take a Virtual Tour</H3>
                <div className="rounded-xl overflow-hidden border border-stone-200 shadow-sm">
                  <iframe
                    title="Fidelis Showroom Virtual Tour"
                  src={virtualTourSrc}
                    width="100%"
                    height="450"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  />
                </div>
                <Body className="mt-4 text-stone-600">
                  Get a preview of our showroom environment before your visit. Navigate around to see our listening areas, 
                  product displays, and the welcoming atmosphere where we help audiophiles discover their perfect sound.
                </Body>
              </div>
            </div>
          </Container>
        </Section>
        </main>
      </div>
    </div>
  );
}

export default function ContactPage() {
  return (
    <>
      <PageLoadReveal isLoading={false} minimumLoadTime={0} maxWaitTime={1000}>
        <Suspense fallback={
          <div className="min-h-screen bg-warm-cream pt-24 footer-scroll-reveal">
            <div className="relative z-10 bg-warm-cream">
              <Header />
              <div className="flex items-center justify-center py-20">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-stone-600 mx-auto"></div>
                  <p className="mt-4 text-stone-600">Loading...</p>
                </div>
              </div>
            </div>
          </div>
        }>
          <ContactForm />
        </Suspense>
      </PageLoadReveal>
      <FooterWithSignIn />
    </>
  );
}
