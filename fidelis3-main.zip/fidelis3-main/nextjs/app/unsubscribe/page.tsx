'use client'

import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { Suspense, useEffect, useState } from 'react'

type UnsubscribeStatus = 'idle' | 'submitting' | 'success' | 'error'

function UnsubscribeContent() {
  const searchParams = useSearchParams()
  const [status, setStatus] = useState<UnsubscribeStatus>('idle')
  const [message, setMessage] = useState('Processing your request...')

  useEffect(() => {
    const token = searchParams.get('token')?.trim()

    if (!token) {
      setStatus('error')
      setMessage('Missing unsubscribe token.')
      return
    }

    const unsubscribe = async () => {
      setStatus('submitting')
      try {
        const response = await fetch(`/api/newsletter/unsubscribe?token=${encodeURIComponent(token)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
        })

        if (!response.ok) {
          const data = await response.json().catch(() => ({}))
          throw new Error(data.error || 'Unable to unsubscribe. Please try again.')
        }

        setStatus('success')
        setMessage('You have been unsubscribed from the newsletter.')
      } catch (err) {
        setStatus('error')
        setMessage(err instanceof Error ? err.message : 'Unable to unsubscribe. Please try again.')
      }
    }

    unsubscribe()
  }, [searchParams])

  return (
    <main id="main-content" className="min-h-screen bg-[#fefcfa] text-stone-900">
      <div className="max-w-xl mx-auto px-6 py-20 text-center">
        <h1 className="text-3xl md:text-4xl font-light tracking-tight mb-4">Newsletter Preferences</h1>
        <p className="text-lg text-stone-600 mb-8">{message}</p>
        {status === 'submitting' && (
          <p className="text-sm text-stone-500">Please wait a moment...</p>
        )}
        {status !== 'submitting' && (
          <Link
            href="/"
            className="inline-flex items-center justify-center rounded-full border border-stone-300 px-6 py-2 text-sm font-medium text-stone-700 hover:border-stone-400 hover:text-stone-900 transition"
          >
            Return to home
          </Link>
        )}
      </div>
    </main>
  )
}

export default function UnsubscribePage() {
  return (
    <Suspense fallback={null}>
      <UnsubscribeContent />
    </Suspense>
  )
}
