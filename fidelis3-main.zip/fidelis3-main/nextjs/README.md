# Fidelis AV — Next.js app

The Fidelis AV storefront and CMS: Next.js 15 (App Router), React 19, Tailwind CSS 4, with Supabase as the data and storage backend.

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000). Requires Node 20+ and a `.env.local` file — see [`ENV_VARIABLES.md`](ENV_VARIABLES.md).

## Scripts

- `npm run dev` — local development server
- `npm run build` — production build (used by Vercel)
- `npm run start` — serve the production build
- `npm run ai:batch` — batch-generate AI product relationships (needs `ANTHROPIC_API_KEY`, `SUPABASE_SECRET_KEY`)
- `npm run products:classify-amplifiers` — AI amplifier classification scripts

## Structure

- `app/` — routes (storefront pages, API routes, admin editing surfaces)
- `components/` — UI and CMS components
- `lib/` — Supabase clients/queries, sanitization, auth, AI helpers
- `contexts/` — auth, edit-mode, site globals providers
- `scripts/` — operational scripts run with `tsx`

## Deployment

Deployed on Vercel with Root Directory set to `nextjs`. Environment variables are managed in the Vercel dashboard. See [`SECURITY.md`](SECURITY.md) for the security posture and launch checklist.
