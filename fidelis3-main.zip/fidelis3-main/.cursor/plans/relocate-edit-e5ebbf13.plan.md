---
name: Glassmorphic Dropdown Redesign
overview: ""
todos:
  - id: a4bbbd32-4417-49ed-b02d-89c344ba6906
    content: Create searchAll function in supabase-queries.ts with parallel queries for all content types
    status: pending
  - id: 5758014b-8092-4cf2-a59d-166a7338a2c9
    content: Create SearchBar component with glassmorphic styling, type-ahead, and results dropdown
    status: pending
  - id: af31892f-c9a2-4fbe-a001-ae0854a8876f
    content: Add SearchBar to Header component for desktop view with dynamic variant based on scroll
    status: pending
  - id: 33c4a5dc-c827-4b64-b66a-0acb00664a7f
    content: Add mobile search icon and overlay to Header component
    status: pending
  - id: 66db66cb-0dd2-4e8d-a22c-777fde3bdc0c
    content: Implement keyboard navigation (arrow keys and Enter) for search results
    status: pending
  - id: 810194c0-f736-4086-9050-6224fc32518e
    content: Test search across all content types, verify styling, and check mobile responsiveness
    status: pending
---

# Glassmorphic Dropdown Redesign

## Overview

Transform the EditableSelect dropdown from its current basic yellow-highlighted style to a sophisticated glassmorphic design that matches the site's premium aesthetic, with refined typography and proper visual hierarchy.

## Design Principles

Based on the Header component's glassmorphic styling:

- Translucent white/warm backgrounds with backdrop blur
- Subtle borders and shadows
- Refined typography with proper hierarchy
- Smooth transitions and hover states
- Premium feel that matches high-end audio equipment aesthetic

## Implementation Steps

### 1. Update "Add New" Option Text

**File**: `nextjs/components/cms/EditableSelect.tsx`

Change the default `addNewLabel` prop:

- From: `'Add new...'`
- To: `'Select different category...'` (or manufacturer, depending on context)

Update the option rendering to be more contextual and less generic.

### 2. Redesign Select Field Styling

**File**: `nextjs/components/cms/EditableSelect.tsx`

Replace the current `.cms-editable-field` class usage with glassmorphic styling:

```tsx
className={`
  w-full px-4 py-3 rounded-lg
  bg-white/40 backdrop-blur-md
  border border-stone-200/50
  text-stone-900 font-medium
  shadow-sm
  hover:bg-white/50 hover:border-stone-300/60
  focus:bg-white/60 focus:border-stone-400/70 focus:outline-none focus:ring-2 focus:ring-stone-300/30
  transition-all duration-200
  ${className}
`}
```

### 3. Style Dropdown Options

**File**: `nextjs/components/cms/EditableSelect.tsx`

Update option styling for better visual hierarchy:

**Regular options:**

```tsx
className="bg-white text-stone-900 py-2 hover:bg-stone-50"
```

**Placeholder option:**

```tsx
className="bg-white text-stone-400 italic"
```

**"Select different" option:**

```tsx
className="bg-stone-50 text-stone-600 italic font-medium border-t border-stone-200 py-3"
```

Add visual separator (border-top) before the "Select different" option to distinguish it from regular options.

### 4. Enhance Label Typography

**File**: `nextjs/components/cms/EditableSelect.tsx`

Update label styling:

```tsx
className="block text-sm font-semibold text-stone-700 tracking-wide uppercase mb-2"
```

This creates better visual hierarchy and matches premium design patterns.

### 5. Add Dropdown Icon

**File**: `nextjs/components/cms/EditableSelect.tsx`

Add a custom dropdown chevron icon using CSS:

- Position a chevron icon on the right side of the select
- Style it to match the glassmorphic aesthetic
- Ensure it rotates or changes on focus/hover

### 6. Update CMS Styles for Consistency

**File**: `nextjs/app/cms-styles.css`

Add new glassmorphic select-specific styles:

```css
.cms-editable-select {
  background: linear-gradient(135deg, 
    rgba(255, 255, 255, 0.4) 0%,
    rgba(255, 255, 255, 0.3) 100%
  );
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border: 1px solid rgba(120, 113, 108, 0.2);
  box-shadow: 
    0 2px 8px rgba(0, 0, 0, 0.04),
    inset 0 1px 0 rgba(255, 255, 255, 0.5);
}

.cms-editable-select:hover {
  background: linear-gradient(135deg, 
    rgba(255, 255, 255, 0.5) 0%,
    rgba(255, 255, 255, 0.4) 100%
  );
  border-color: rgba(120, 113, 108, 0.3);
}

.cms-editable-select:focus {
  background: linear-gradient(135deg, 
    rgba(255, 255, 255, 0.6) 0%,
    rgba(255, 255, 255, 0.5) 100%
  );
  border-color: rgba(120, 113, 108, 0.4);
  box-shadow: 
    0 4px 12px rgba(0, 0, 0, 0.06),
    inset 0 1px 0 rgba(255, 255, 255, 0.6),
    0 0 0 3px rgba(120, 113, 108, 0.1);
}
```

### 7. Improve Option Hover States

**File**: `nextjs/components/cms/EditableSelect.tsx`

Since native select options have limited styling, consider:

- Ensuring proper contrast for selected state
- Using system-appropriate hover colors
- Testing across browsers for consistency

### 8. Update RelationalSelect Integration

**File**: `nextjs/components/cms/RelationalSelect.tsx`

Update the `addNewLabel` props to be more contextual:

- For manufacturer: `"Select different manufacturer..."`
- For category: `"Select different category..."`

### 9. Test Typography Hierarchy

Ensure the redesigned dropdown has proper visual weight:

- Label: Semibold, uppercase, smaller size
- Selected value: Medium weight, readable size
- Options: Regular weight, good contrast
- "Select different" option: Italic, medium weight, visually separated

### 10. Polish Transitions

Add smooth transitions for all interactive states:

- Hover: 150ms ease-out
- Focus: 200ms ease-out
- Background changes: 200ms ease-out
- Border changes: 200ms ease-out

## Visual Goals

- Replace harsh yellow highlighter with subtle, sophisticated glassmorphism
- Create visual hierarchy through typography and spacing
- Ensure dropdown feels premium and intentional
- Match the warm-white (#fefcfa) background aesthetic
- Integrate seamlessly with the site's overall design language

## Testing Checklist

- [ ] Dropdown appears glassmorphic with proper blur
- [ ] Typography is refined and hierarchical
- [ ] "Select different" option is clearly separated
- [ ] Hover and focus states feel smooth and premium
- [ ] Works across different browsers
- [ ] Maintains accessibility (contrast, keyboard nav)
- [ ] Integrates well with RelationalSelect component