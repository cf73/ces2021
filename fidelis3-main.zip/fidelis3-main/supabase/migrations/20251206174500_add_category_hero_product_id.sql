-- Ensure product_categories can reference a specific product for hero imagery

ALTER TABLE product_categories
ADD COLUMN IF NOT EXISTS hero_product_id uuid;

-- Clean up any existing constraint before recreating
ALTER TABLE product_categories
DROP CONSTRAINT IF EXISTS product_categories_hero_product_id_fkey;

ALTER TABLE product_categories
ADD CONSTRAINT product_categories_hero_product_id_fkey
FOREIGN KEY (hero_product_id) REFERENCES products(id) ON DELETE SET NULL;

COMMENT ON COLUMN product_categories.hero_product_id IS 'ID of the product whose hero image should be used for this category. When null, falls back to automatic selection.';

CREATE INDEX IF NOT EXISTS product_categories_hero_product_id_idx
ON product_categories(hero_product_id);

