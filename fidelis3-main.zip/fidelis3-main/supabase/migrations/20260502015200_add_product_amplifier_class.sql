-- Add structured amplifier operating class for product filtering.
ALTER TABLE products
ADD COLUMN IF NOT EXISTS amplifier_class TEXT;

ALTER TABLE products
DROP CONSTRAINT IF EXISTS products_amplifier_class_check;

ALTER TABLE products
ADD CONSTRAINT products_amplifier_class_check
CHECK (
  amplifier_class IS NULL
  OR amplifier_class IN ('class_a', 'class_ab', 'class_d', 'class_g', 'class_h')
);
