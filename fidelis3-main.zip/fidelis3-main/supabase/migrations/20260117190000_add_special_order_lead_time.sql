-- Add special order lead time to products
ALTER TABLE products
ADD COLUMN IF NOT EXISTS special_order_lead_time TEXT;
