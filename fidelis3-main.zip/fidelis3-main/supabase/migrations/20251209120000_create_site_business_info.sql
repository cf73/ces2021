-- Create table to hold site-wide business information
create extension if not exists "pgcrypto";

create table if not exists site_business_info (
  id uuid primary key default gen_random_uuid(),
  company_name text,
  tagline text,
  short_description text,
  about_description text,
  phone text,
  email text,
  address_line1 text,
  address_line2 text,
  city text,
  state text,
  postal_code text,
  country text default 'US',
  google_map_url text,
  virtual_tour_url text,
  store_hours jsonb default '[]'::jsonb,
  special_notice text,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

alter table site_business_info enable row level security;

create policy "Public read access"
  on site_business_info
  for select
  using (true);

-- Seed with existing information if table is empty
insert into site_business_info (
  company_name,
  tagline,
  short_description,
  about_description,
  phone,
  email,
  address_line1,
  city,
  state,
  postal_code,
  google_map_url,
  virtual_tour_url,
  store_hours,
  special_notice
)
select
  'Fidelis' as company_name,
  'FIDELIS' as tagline,
  'America''s premiere importer and distributor of high-end audio gear.' as short_description,
  'As America''s premiere importer and distributor of high-end audio gear, we source and import the world''s finest equipment directly from manufacturers.' as about_description,
  '603-880-4434' as phone,
  'marc@fidelisav.com' as email,
  '460 Amherst Street' as address_line1,
  'Nashua' as city,
  'NH' as state,
  '03063' as postal_code,
  'https://www.google.com/maps?q=460+Amherst+Street,+Nashua,+NH+03063&output=embed' as google_map_url,
  'https://www.google.com/maps/embed?pb=!4v1759346143448!6m8!1m7!1sCAoSHENJQUJJaENJWC04Sl9BNWxhb1RqZ09qTS0zdFg.!2m2!1d42.78934369153347!2d-71.51902378620517!3f297.86!4f-2.3499999999999943!5f0.4000000000000002' as virtual_tour_url,
  '[
    {"label":"Tuesday-Friday","value":"10:00 AM - 6:00 PM"},
    {"label":"Saturday","value":"10:00 AM - 4:00 PM"},
    {"label":"Sunday","value":"Closed"},
    {"label":"Monday","value":"By Appointment"}
  ]'::jsonb as store_hours,
  null::text as special_notice
where not exists (select 1 from site_business_info);

