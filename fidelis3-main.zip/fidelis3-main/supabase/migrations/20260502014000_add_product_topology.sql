-- Add structured amplifier topology for product filtering.
ALTER TABLE products
ADD COLUMN IF NOT EXISTS topology TEXT;

ALTER TABLE products
DROP CONSTRAINT IF EXISTS products_topology_check;

ALTER TABLE products
ADD CONSTRAINT products_topology_check
CHECK (topology IS NULL OR topology IN ('tube', 'solid_state', 'hybrid'));
