-- Ensure manufacturers table tracks published state
ALTER TABLE manufacturers
ADD COLUMN IF NOT EXISTS published BOOLEAN NOT NULL DEFAULT TRUE;

UPDATE manufacturers
SET published = TRUE
WHERE published IS NULL;

