-- Add per-relationship editorial notes for product carousels.
ALTER TABLE products
ADD COLUMN IF NOT EXISTS pairs_notes JSONB,
ADD COLUMN IF NOT EXISTS also_notes JSONB;
