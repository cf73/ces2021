-- Tighten newsletter_subscribers update policy (server-side only)
DROP POLICY IF EXISTS "Allow public updates by token" ON newsletter_subscribers;

CREATE POLICY "Deny public updates" ON newsletter_subscribers
  FOR UPDATE
  TO anon, authenticated
  USING (false)
  WITH CHECK (false);
