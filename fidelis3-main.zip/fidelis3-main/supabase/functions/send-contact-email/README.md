# Contact Form Email Edge Function

This Supabase Edge Function handles contact form submissions from the website.

## Features

- Validates form data (required fields, email format)
- Stores submissions in `contact_submissions` table
- Sends email notifications via Resend API
- CORS-enabled for client-side requests
- Rate limiting via Supabase RLS

## Setup

### 1. Run Database Migration

First, create the `contact_submissions` table:

```bash
# Run the migration in Supabase SQL Editor
cat supabase/migrations/20250203000000_create_contact_submissions.sql
```

Or run directly in the Supabase SQL Editor dashboard.

### 2. Deploy Edge Function

```bash
# Install Supabase CLI if you haven't
npm install -g supabase

# Login to Supabase
supabase login

# Link your project
supabase link --project-ref myrdvcihcqphixvunvkv

# Deploy the function
supabase functions deploy send-contact-email
```

### 3. Set Environment Variables

In your Supabase project dashboard, go to **Edge Functions** → **send-contact-email** → **Settings** and add:

```
RESEND_API_KEY=re_xxxxxxxxxxxxxxxxx
```

To get a Resend API key:
1. Sign up at https://resend.com (free tier: 100 emails/day)
2. Verify your domain `fidelisav.com` in Resend dashboard
3. Generate an API key
4. Add it to the Edge Function secrets

### 4. Test the Function

```bash
# Test locally (requires Supabase CLI)
supabase functions serve send-contact-email

# Test with curl
curl -X POST http://localhost:54321/functions/v1/send-contact-email \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "subject": "Test Subject",
    "message": "Test message"
  }'
```

## Email Configuration

The function sends emails to `marc@fidelisav.com` with:
- **From**: `contact@fidelisav.com` (requires domain verification in Resend)
- **Reply-To**: User's email address
- **Subject**: `Contact Form: [user's subject]`

## Error Handling

- **400**: Missing or invalid form data
- **500**: Database or unexpected errors
- Form submissions are saved even if email sending fails
- All errors are logged to Supabase Edge Function logs

## Monitoring

View function logs in Supabase dashboard:
- **Edge Functions** → **send-contact-email** → **Logs**

View submissions in database:
```sql
SELECT * FROM contact_submissions 
ORDER BY submitted_at DESC 
LIMIT 50;
```

## Rate Limiting

Currently allows unlimited submissions. To add rate limiting:

1. Create a rate limit table
2. Add rate limit check in Edge Function
3. Or use Supabase's built-in rate limiting (coming soon)

## Alternative: Skip Resend

If you don't want to use Resend, the function will still work and save submissions to the database. You can then:

1. Check the database manually
2. Set up email notifications via Supabase triggers
3. Use a different email service by modifying the Edge Function












